#!/usr/bin/env python3
"""Check the generated XM songs for stuck notes.

Looped instruments (flute, pad, brass) sustain until a key-off or the next
note on their channel. This walks each song twice (it loops) and fails if
any looped note would keep sounding longer than MAX_SUSTAIN seconds.

    python3 tools/check_audio.py          # checks audio/
"""
import glob
import os
import struct
import sys

MAX_SUSTAIN = 6.0   # seconds
def parse(path):
    b = open(path, 'rb').read()
    hsize = struct.unpack_from('<I', b, 60)[0]
    songlen, restart, nch, npat, ninst, flags, tempo, bpm = struct.unpack_from('<HHHHHHHH', b, 64)
    order = list(b[80:80 + songlen])
    off = 60 + hsize
    pats = []
    for _ in range(npat):
        plen, ptype, rows, psize = struct.unpack_from('<IBHH', b, off)
        data = b[off + plen: off + plen + psize]
        off += plen + psize
        cells = [[None] * nch for _ in range(rows)]
        i = 0
        for r in range(rows):
            for c in range(nch):
                if psize == 0:
                    continue
                x = data[i]; i += 1
                note = inst = vol = eff = par = 0
                if x & 0x80:
                    if x & 1: note = data[i]; i += 1
                    if x & 2: inst = data[i]; i += 1
                    if x & 4: vol = data[i]; i += 1
                    if x & 8: eff = data[i]; i += 1
                    if x & 16: par = data[i]; i += 1
                else:
                    note = x; inst, vol, eff, par = data[i:i + 4]; i += 4
                cells[r][c] = (note, inst, vol, eff, par)
        pats.append(cells)
    # instruments: name + whether the sample loops
    looped = {}
    for k in range(ninst):
        isize = struct.unpack_from('<I', b, off)[0]
        name = b[off + 4: off + 26].split(b'\0')[0].decode()
        nsamp = struct.unpack_from('<H', b, off + 27)[0]
        shsize = struct.unpack_from('<I', b, off + 29)[0] if nsamp else 0
        o = off + isize
        lens = []
        lp = False
        for s in range(nsamp):
            slen, ls, ll = struct.unpack_from('<III', b, o)
            typ = b[o + 14]
            lp = lp or ((typ & 3) != 0 and ll > 0)
            lens.append(slen)
            o += shsize
        o += sum(lens)
        looped[k + 1] = (name, lp)
        off = o
    return order, restart, nch, pats, looped, tempo, bpm


def longest_sustains(path):
    order, restart, nch, pats, looped, tempo, bpm = parse(path)
    rows = [row for p in order for row in pats[p]]
    n = len(rows)
    row_sec = 2.5 * tempo / bpm
    out = []
    for c in range(nch):
        # notes that start in the second pass, followed up to a third pass,
        # so a note held across the loop point is measured properly
        cur = None  # (start index, instrument, note)
        for i in range(3 * n):
            cell = rows[i % n][c]
            if not cell:
                continue
            note, inst = cell[0], cell[1]
            if note == 97 or 1 <= note <= 96:
                if cur is not None and n <= cur[0] < 2 * n:
                    out.append(((i - cur[0]) * row_sec, c, cur[0] % n, looped[cur[1]][0], cur[2]))
                cur = (i, inst, note) if 1 <= note <= 96 and looped.get(inst, ("", False))[1] else None
        if cur is not None and n <= cur[0] < 2 * n:
            out.append((float("inf"), c, cur[0] % n, looped[cur[1]][0], cur[2]))   # never released
    return sorted(out, reverse=True)


def main():
    folder = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "audio")
    bad = 0
    for path in sorted(glob.glob(os.path.join(folder, "m_*.xm"))):
        worst = longest_sustains(path)
        name = os.path.basename(path)
        if worst and worst[0][0] > MAX_SUSTAIN:
            sec, c, row, inst, note = worst[0]
            print("FAIL %s: %s note %d on channel %d (row %d) sustains %.1f s" % (name, inst, note, c, row, sec))
            bad += 1
        else:
            print("ok   %s: longest looped note %.1f s" % (name, worst[0][0] if worst else 0))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
