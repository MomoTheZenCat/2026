#!/usr/bin/env python3
# Momo Dev Story - audio generator.
#
# Synthesises soft instrument samples, composes the background music as XM
# tracker modules and renders the sound effects as WAV files into audio/.
# The BlocksDS Makefile packs them with mmutil into a Maxmod soundbank.
#
#     python3 tools/gen_audio.py        (writes audio/*.xm, audio/*.wav)
#
# Style: chill and peaceful. Slow tempos, maj7/add9 chords, lots of space,
# soft attacks and rolled-off highs so nothing gets tiring to listen to.

import math
import os
import random
import struct
import wave

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "audio")
SR = 16000          # sample rate for everything (plenty for the DS speakers)
rnd = random.Random(7)

# --------------------------------------------------------------------------
# DSP helpers
# --------------------------------------------------------------------------


def midi_hz(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def lowpass(x, cutoff):
    """One-pole low-pass: rounds off harsh highs."""
    a = math.exp(-2 * math.pi * cutoff / SR)
    y, out = 0.0, []
    for v in x:
        y = (1 - a) * v + a * y
        out.append(y)
    return out


def highpass(x, cutoff):
    lp = lowpass(x, cutoff)
    return [a - b for a, b in zip(x, lp)]


def env_adsr(n, a, d, s, r_start=None, r_len=0.0):
    """Linear attack, exponential decay to sustain level s."""
    out = []
    an = max(1, int(a * SR))
    for i in range(n):
        t = i / SR
        if i < an:
            v = i / an
        else:
            v = s + (1 - s) * math.exp(-(t - a) / max(1e-4, d))
        if r_start is not None and t > r_start:
            v *= max(0.0, 1 - (t - r_start) / max(1e-4, r_len))
        out.append(v)
    return out


def normalize(x, peak=0.9):
    m = max(1e-9, max(abs(v) for v in x))
    return [v * peak / m for v in x]


def mix(*tracks):
    n = max(len(t) for t in tracks)
    out = [0.0] * n
    for t in tracks:
        for i, v in enumerate(t):
            out[i] += v
    return out


def place(dst, src, at, gain=1.0):
    i0 = int(at * SR)
    need = i0 + len(src)
    if need > len(dst):
        dst.extend([0.0] * (need - len(dst)))
    for i, v in enumerate(src):
        dst[i0 + i] += v * gain


def silence(sec):
    return [0.0] * int(sec * SR)


# --------------------------------------------------------------------------
# Instruments (each returns (samples, root_midi, loop_start, loop_len))
# --------------------------------------------------------------------------


def inst_epiano(root=72, dur=1.1):
    """Warm Rhodes-like electric piano: soft sine body + short bell tine."""
    f = midi_hz(root)
    n = int(dur * SR)
    out = []
    for i in range(n):
        t = i / SR
        body = math.sin(2 * math.pi * f * t) + 0.22 * math.sin(2 * math.pi * 2 * f * t) * math.exp(-t * 3)
        tine = 0.18 * math.sin(2 * math.pi * 7.1 * f * t) * math.exp(-t * 28)
        trem = 1 + 0.06 * math.sin(2 * math.pi * 4.5 * t)
        out.append((body + tine) * trem)
    e = env_adsr(n, 0.006, 0.9, 0.0)
    return normalize(lowpass([a * b for a, b in zip(out, e)], 3500)), root, 0, 0


def inst_marimba(root=72, dur=0.5):
    f = midi_hz(root)
    n = int(dur * SR)
    out = []
    for i in range(n):
        t = i / SR
        v = math.sin(2 * math.pi * f * t) * math.exp(-t * 6)
        v += 0.25 * math.sin(2 * math.pi * 3.93 * f * t) * math.exp(-t * 30)
        out.append(v)
    e = env_adsr(n, 0.004, 1.0, 1.0)
    return normalize(lowpass([a * b for a, b in zip(out, e)], 4000)), root, 0, 0


def inst_harp(root=60, dur=1.1):
    """Karplus-Strong plucked string, softened."""
    f = midi_hz(root)
    period = int(SR / f)
    buf = [rnd.uniform(-1, 1) for _ in range(period)]
    buf = lowpass(buf, 2500)
    out = []
    n = int(dur * SR)
    for i in range(n):
        v = buf[i % period]
        nxt = buf[(i + 1) % period]
        buf[i % period] = 0.996 * 0.5 * (v + nxt)
        out.append(v)
    e = env_adsr(n, 0.003, 10, 1.0)
    return normalize(lowpass([a * b for a, b in zip(out, e)], 3000)), root, 0, 0


def inst_flute(root=72):
    """Breathy flute; a looped sustain so long notes hold. Soft attack comes
    from the XM volume envelope."""
    f = midi_hz(root)
    periods = 60
    loop_len = int(round(periods * SR / f))
    f = periods * SR / loop_len           # retune so the loop is seamless
    n = int(0.25 * SR) + loop_len
    out = []
    noise = lowpass([rnd.uniform(-1, 1) for _ in range(n)], 1800)
    for i in range(n):
        t = i / SR
        v = math.sin(2 * math.pi * f * t) + 0.12 * math.sin(2 * math.pi * 2 * f * t) + 0.04 * math.sin(2 * math.pi * 3 * f * t)
        breath = 0.05 * noise[i] * (1.5 if i < 0.08 * SR else 1.0)
        out.append(v + breath)
    out = normalize(lowpass(out, 3200))
    ls = n - loop_len
    return out, root, ls, loop_len


def inst_pad(root=60):
    """Soft string pad (looped)."""
    f = midi_hz(root)
    periods = 40
    loop_len = int(round(periods * SR / f))
    f = periods * SR / loop_len
    n = loop_len * 2
    out = []
    for i in range(n):
        t = i / SR
        v = 0
        for h in range(1, 6):
            v += math.sin(2 * math.pi * h * f * t + h) / (h * h)
            v += 0.5 * math.sin(2 * math.pi * h * f * 1.003 * t) / (h * h)   # gentle chorus
        out.append(v)
    out = normalize(lowpass(out, 2000))
    return out, root, loop_len, loop_len


def inst_bass(root=36, dur=0.8):
    """Round upright-bass pluck."""
    f = midi_hz(root)
    n = int(dur * SR)
    out = []
    for i in range(n):
        t = i / SR
        # strong 2nd-4th harmonics: DS speakers can't play the fundamental,
        # but the ear fills it in from these
        v = math.sin(2 * math.pi * f * t) + 0.55 * math.sin(2 * math.pi * 2 * f * t) * math.exp(-t * 3)
        v += 0.25 * math.sin(2 * math.pi * 3 * f * t) * math.exp(-t * 6)
        v += 0.12 * math.sin(2 * math.pi * 4 * f * t) * math.exp(-t * 9)
        out.append(v)
    e = env_adsr(n, 0.008, 0.6, 0.15, dur - 0.2, 0.2)
    return normalize(lowpass([a * b for a, b in zip(out, e)], 1600)), root, 0, 0


def inst_glock(root=84, dur=0.8):
    f = midi_hz(root)
    n = int(dur * SR)
    out = []
    for i in range(n):
        t = i / SR
        v = math.sin(2 * math.pi * f * t) * math.exp(-t * 3.5)
        v += 0.2 * math.sin(2 * math.pi * 2.76 * f * t) * math.exp(-t * 12)
        out.append(v)
    e = env_adsr(n, 0.002, 1, 1.0)
    return normalize(lowpass([a * b for a, b in zip(out, e)], 5000)), root, 0, 0


def inst_shaker(dur=0.09):
    n = int(dur * SR)
    noise = highpass([rnd.uniform(-1, 1) for _ in range(n)], 3000)
    noise = lowpass(noise, 7000)
    e = [math.sin(math.pi * min(1, i / n)) ** 2 for i in range(n)]
    return normalize([a * b for a, b in zip(noise, e)], 0.6), 60, 0, 0


def inst_tick(dur=0.06):
    """Woodblock 'clock tick' - the time-travel motif."""
    n = int(dur * SR)
    out = []
    for i in range(n):
        t = i / SR
        out.append(math.sin(2 * math.pi * 1250 * t) * math.exp(-t * 90) + 0.3 * math.sin(2 * math.pi * 2450 * t) * math.exp(-t * 140))
    return normalize(lowpass(out, 5000), 0.7), 60, 0, 0


def inst_brass(root=60):
    """Warm, round horn (looped sustain): a filtered saw with a gentle swell,
    no shrill edge."""
    f = midi_hz(root)
    periods = 30
    loop_len = int(round(periods * SR / f))
    f = periods * SR / loop_len
    n = int(0.12 * SR) + loop_len
    out = []
    for i in range(n):
        t = i / SR
        v = 0
        for h in range(1, 9):
            v += math.sin(2 * math.pi * h * f * t) / h * (0.8 if h > 3 else 1.0)
        bright = min(1, t / 0.04)          # the "blat" opens up as the note starts
        out.append(v * (0.6 + 0.4 * bright))
    out = normalize(lowpass(lowpass(out, 2200), 2600))
    return out, root, n - loop_len, loop_len


def inst_snare(dur=0.16):
    """Soft brushed snare."""
    n = int(dur * SR)
    noise = lowpass(highpass([rnd.uniform(-1, 1) for _ in range(n)], 700), 4500)
    out = []
    for i in range(n):
        t = i / SR
        out.append(noise[i] * math.exp(-t * 22) + 0.4 * math.sin(2 * math.pi * 190 * t) * math.exp(-t * 35))
    return normalize(out, 0.6), 60, 0, 0


def speaker_safe(data, cutoff=90):
    """Remove rumble below ~90 Hz: the DS speakers can't play it and would
    only rattle. (Headphones still get plenty of bass from the harmonics.)"""
    smp, root, ls, ll = data
    if ll:   # keep looped samples seamless: filter, then re-use the loop as is
        return normalize(highpass(smp, cutoff)), root, ls, ll
    return normalize(highpass(smp, cutoff)), root, ls, ll


INSTRUMENTS_RAW = {
    "epiano": inst_epiano(),
    "marimba": inst_marimba(),
    "harp": inst_harp(),
    "flute": inst_flute(),
    "pad": inst_pad(),
    "bass": inst_bass(),
    "glock": inst_glock(),
    "shaker": inst_shaker(),
    "tick": inst_tick(),
    "brass": inst_brass(),
    "snare": inst_snare(),
}
INSTRUMENTS = {k: speaker_safe(v) for k, v in INSTRUMENTS_RAW.items()}
INST_ORDER = ["epiano", "marimba", "harp", "flute", "pad", "bass", "glock", "shaker", "tick", "brass", "snare"]

# XM volume envelopes (tick, volume 0-64) and fadeout per instrument
ENVELOPES = {
    "flute": ([(0, 0), (6, 64), (40, 52)], 2, 600),     # breathy swell in, sustain, gentle release
    "pad": ([(0, 0), (24, 48), (60, 40)], 2, 300),
    "brass": ([(0, 0), (3, 64), (30, 50)], 2, 900),
}

# --------------------------------------------------------------------------
# XM writer
# --------------------------------------------------------------------------

NOTE_BASE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def parse_note(tok):
    """'C5', 'F#4', 'Bb3' -> MIDI number."""
    name = tok[0]
    rest = tok[1:]
    acc = 0
    if rest[:1] == "#":
        acc, rest = 1, rest[1:]
    elif rest[:1] == "b":
        acc, rest = -1, rest[1:]
    return 12 * (int(rest) + 1) + NOTE_BASE[name] + acc


def tune(root, sr):
    """XM relative note + finetune so the sample plays at pitch."""
    semis = 12 * math.log2(sr / 8363.0) + (60 - root)
    rel = math.floor(semis)
    fine = int(round((semis - rel) * 128))
    if fine > 127:
        rel, fine = rel + 1, fine - 128
    return rel, fine


def xm_instrument(name, data):
    samples, root, ls, ll = data
    pcm = [max(-32767, min(32767, int(v * 26000))) for v in samples]
    delta, prev = [], 0
    for v in pcm:
        d = (v - prev) & 0xFFFF
        delta.append(d)
        prev = v
    raw = struct.pack("<%dH" % len(delta), *delta)
    rel, fine = tune(root, SR)
    loop_type = 1 if ll else 0
    env, sustain, fade = ENVELOPES.get(name, ([], 0, 0))
    vol_pts = b"".join(struct.pack("<HH", x, y) for x, y in env) + b"\0" * (48 - 4 * len(env))
    vol_type = (1 | 2) if env else 0
    hdr = struct.pack("<I22sBH", 263, name.encode()[:22], 0, 1)
    hdr += struct.pack("<I", 40) + bytes(96) + vol_pts + bytes(48)
    hdr += struct.pack("<BBBBBBBB", len(env), 0, sustain, 0, 0, 0, 0, 0)
    hdr += struct.pack("<BB", vol_type, 0) + struct.pack("<BBBB", 0, 0, 0, 0)
    hdr += struct.pack("<H", fade) + bytes(22)
    assert len(hdr) == 263
    shdr = struct.pack("<III", len(raw), ls * 2, ll * 2)
    shdr += struct.pack("<BbBBbB22s", 64, fine, loop_type | 0x10, 128, rel, 0, name.encode()[:22])
    return hdr + shdr + raw


class Song:
    """Rows are 16th notes; 16 rows = one 4/4 bar."""

    def __init__(self, name, bpm, bars, channels=8):
        self.name = name
        self.bpm = bpm
        self.rows = bars * 16
        self.nch = channels
        self.cells = {}  # (row, ch) -> (note, inst name, vol)

    def put(self, row, ch, note, inst, vol=48):
        if 0 <= row < self.rows:
            self.cells[(row, ch)] = (note, inst, vol)

    def off(self, row, ch):
        # A release that would fall past the end of the song goes on the last
        # row instead: dropping it would leave a looped note (flute, pad,
        # brass) sustaining through the loop.
        if row >= self.rows:
            row = self.rows - 1
        if 0 <= row < self.rows and (row, ch) not in self.cells:
            self.cells[(row, ch)] = (97, 0, None)

    def line(self, ch, inst, text, start_bar=0, vol=48, echo=None, release=True):
        """text: 'E5:4 G5:2 r:2 ...' durations in 16ths. Optional echo
        channel repeats the line 3 rows later, quieter."""
        row = start_bar * 16
        for tok in text.split():
            note, _, ln = tok.partition(":")
            ln = int(ln) if ln else 2
            if note != "r":
                v = vol
                if note.endswith("!"):     # accent
                    note, v = note[:-1], min(64, vol + 8)
                if note.endswith("?"):     # ghost note
                    note, v = note[:-1], max(8, vol - 18)
                m = parse_note(note)
                self.put(row, ch, m - 11, inst, v)
                if echo is not None:
                    self.put(row + 3, echo, m - 11, inst, max(6, v // 3))
                if release and inst in ("flute", "pad", "brass"):
                    self.off(row + ln, ch)
            row += ln
        return row

    def chords(self, ch_list, inst, prog, start_bar=0, vol=30, style="arp", pattern=None):
        """prog: list of chords per bar, each a list of note names."""
        for b, chord in enumerate(prog):
            base = (start_bar + b) * 16
            notes = [parse_note(n) for n in chord]
            if style == "block":
                for k, m in enumerate(notes[:len(ch_list)]):
                    self.put(base, ch_list[k], m - 11, inst, vol)
                    if inst in ("pad", "flute"):
                        self.off(base + 15, ch_list[k])
            else:
                seq = pattern or [0, 2, 1, 3, 2, 1, 3, 2]
                step = 16 // len(seq)
                for k, idx in enumerate(seq):
                    m = notes[idx % len(notes)]
                    v = vol if k % 4 == 0 else vol - 6
                    self.put(base + k * step, ch_list[k % len(ch_list)], m - 11, inst, v)

    def bass(self, ch, prog_roots, start_bar=0, vol=40, pattern=((0, 0), (10, 7))):
        for b, root in enumerate(prog_roots):
            base = (start_bar + b) * 16
            r = parse_note(root)
            for row, interval in pattern:
                self.put(base + row, ch, r + interval - 11, "bass", vol)

    def perc(self, ch, inst, rows_in_bar, bars, start_bar=0, vol=14):
        for b in range(bars):
            for r, v in rows_in_bar:
                self.put((start_bar + b) * 16 + r, ch, 49, inst, min(64, vol + v))

    def write(self, path):
        rows_per_pat = 64
        npat = (self.rows + rows_per_pat - 1) // rows_per_pat
        hdr = b"Extended Module: " + self.name.encode()[:20].ljust(20, b" ") + b"\x1a"
        hdr += b"MomoDevStory gen".ljust(20, b" ") + struct.pack("<H", 0x0104)
        order = list(range(npat)) + [0] * (256 - npat)
        # only embed the instruments this song uses (keeps the soundbank small)
        used = [n for n in INST_ORDER if any(c[1] == n for c in self.cells.values())]
        num = {n: i + 1 for i, n in enumerate(used)}
        hdr += struct.pack("<IHHHHHHHH", 276, npat, 0, self.nch, npat, len(used), 1, 6, self.bpm)
        hdr += bytes(order)
        pats = b""
        for p in range(npat):
            data = b""
            for r in range(rows_per_pat):
                row = p * rows_per_pat + r
                for ch in range(self.nch):
                    cell = self.cells.get((row, ch))
                    if not cell or row >= self.rows:
                        data += b"\x80"
                        continue
                    note, inst, vol = cell
                    flags, body = 0x80 | 1, bytes([note])
                    if inst:
                        flags |= 2
                        body += bytes([num[inst]])
                    if vol is not None:
                        flags |= 4
                        body += bytes([0x10 + vol])
                    data += bytes([flags]) + body
            pats += struct.pack("<IBHH", 9, 0, rows_per_pat, len(data)) + data
        insts = b"".join(xm_instrument(n, INSTRUMENTS[n]) for n in used)
        with open(path, "wb") as f:
            f.write(hdr + pats + insts)


# --------------------------------------------------------------------------
# The music (all original melodies)
# --------------------------------------------------------------------------

def C(*names):
    return list(names)


def song_title():
    """Morning on the fence: harp ripples, a soft clock tick, e-piano tune.
    C Lydian colour (F#) for a little time-travel shimmer."""
    s = Song("Momo Title", 76, 16)
    prog = [C("F3", "A3", "C4", "E4"), C("G3", "B3", "D4", "F#4"), C("A3", "C4", "E4", "G4"), C("E3", "G3", "C4", "D4")] * 4
    s.chords([2], "harp", prog, vol=26, pattern=[0, 1, 2, 3, 2, 1, 2, 3])
    s.bass(3, ["F2", "G2", "A2", "E2"] * 4, vol=30, pattern=((0, 0),))
    s.perc(5, "tick", [(0, 0), (8, -2)], 16, vol=10)          # tick... tock...
    # melody enters at bar 4
    s.line(0, "epiano", "A5:6 B5:2 C6:4 E6:4 D6:6 C6:2 B5:8 "
                        "C6:4 B5:2 A5:2 G5:8 E5:4 G5:4 D5:8 r:8", start_bar=4, vol=40, echo=1)
    s.line(0, "epiano", "A5:6 B5:2 C6:4 E6:4 F#6:6 E6:2 D6:8 "
                        "E6:4 D6:2 C6:2 B5:4 A5:4 G5:16", start_bar=8, vol=40, echo=1)
    s.line(4, "flute", "E6:12 D6:4 C6:8 B5:8 A5:16 G5:16", start_bar=12, vol=30)
    s.chords([6, 7], "pad", [C("C4", "E4"), C("D4", "F#4"), C("C4", "E4"), C("B3", "D4")], start_bar=12, vol=18, style="block")
    return s


def song_balcony():
    """Sunny afternoon on the fence: marimba tune, nylon-ish harp, upright bass."""
    s = Song("Momo Balcony", 84, 16)
    prog = [C("C4", "E4", "G4", "B4"), C("E3", "G3", "B3", "D4"), C("F3", "A3", "C4", "E4"), C("G3", "B3", "D4", "E4")] * 4
    s.chords([2], "harp", prog, vol=24, pattern=[0, 2, 1, 3, 2, 3, 1, 2])
    s.bass(3, ["C2", "E2", "F2", "G2"] * 4, vol=34, pattern=((0, 0), (6, 7), (10, 12)))
    s.perc(5, "shaker", [(4, 0), (12, 0), (14, -6)], 16, vol=9)
    s.line(0, "marimba", "E5:2 G5:2 r:2 C6:2 B5:4 G5:4 D5:2 F#5:2 r:2 A5:2 G5:8 "
                         "C5:2 E5:2 r:2 A5:2 G5:4 E5:4 D5:8 r:8", vol=42, echo=1)
    s.line(0, "marimba", "E5:2 G5:2 r:2 C6:2 E6:4 D6:4 B5:2 D6:2 r:2 B5:2 A5:8 "
                         "A5:2 C6:2 r:2 A5:2 G5:4 E5:2 D5:2 C5:16", start_bar=4, vol=42, echo=1)
    s.line(4, "flute", "G5:8 E5:8 D5:8 B4:8 C5:8 E5:8 D5:16", start_bar=8, vol=26)
    s.line(0, "marimba", "r:16 r:16 E6:2 D6:2 C6:4 A5:4 G5:4 E5:4 D5:4 C5:8", start_bar=12, vol=38, echo=1)
    return s


def song_yahoo():
    """Campus groove in A Dorian: e-piano chords, marimba hook, brushy shaker."""
    s = Song("Momo Yahoo", 88, 16)
    prog = [C("A3", "C4", "E4", "G4"), C("D3", "F#3", "A3", "C4"), C("F3", "A3", "C4", "E4"), C("G3", "B3", "D4", "F#4")] * 4
    for b, ch in enumerate(prog):
        base = b * 16
        for r in (0, 6, 10):
            for k, n in enumerate(ch[1:]):
                s.put(base + r, 6 + (k % 2), parse_note(n) - 11 + 12, "epiano", 20 if r else 24)
    s.bass(3, ["A1", "D2", "F2", "G2"] * 4, vol=36, pattern=((0, 0), (3, 12), (8, 7), (14, 10)))
    s.perc(5, "shaker", [(2, -4), (4, 0), (10, -4), (12, 0)], 16, vol=8)
    s.line(0, "marimba", "r:4 A5:2 C6:2 E6:4 D6:2 C6:2 A5:4 F#5:2 A5:2 C6:4 B5:2 A5:2 "
                         "r:4 C6:2 A5:2 G5:4 E5:4 D5:4 F#5:4 A5:8", start_bar=2, vol=40, echo=1)
    s.line(0, "marimba", "r:4 A5:2 C6:2 E6:4 G6:2 E6:2 D6:4 F#6:2 E6:2 D6:4 C6:2 B5:2 "
                         "r:4 C6:2 B5:2 A5:4 G5:4 F#5:4 E5:4 A5:8", start_bar=8, vol=40, echo=1)
    s.line(4, "flute", "E6:16 D6:16 C6:16 B5:16", start_bar=12, vol=22)
    return s


def song_tropical():
    """Island breeze: marimba melody, harp, gentle shaker. F major."""
    s = Song("Momo Islands", 92, 16)
    prog = [C("F3", "A3", "C4", "E4"), C("Bb3", "D4", "F4", "A4"), C("G3", "Bb3", "D4", "F4"), C("C4", "E4", "G4", "Bb4")] * 4
    s.chords([2], "harp", prog, vol=22, pattern=[0, 1, 2, 1, 3, 2, 1, 2])
    s.bass(3, ["F2", "Bb2", "G2", "C2"] * 4, vol=34, pattern=((0, 0), (6, 0), (8, 7), (12, 12)))
    s.perc(5, "shaker", [(0, -4), (3, 0), (6, -2), (8, -4), (11, 0), (14, -2)], 16, vol=8)
    s.line(0, "marimba", "C6:2 A5:2 r:2 C6:2 D6:4 C6:4 D6:2 Bb5:2 r:2 D6:2 F6:4 D6:4 "
                         "Bb5:2 G5:2 r:2 Bb5:2 A5:4 G5:4 G5:2 A5:2 Bb5:2 C6:2 A5:8", vol=40, echo=1)
    s.line(0, "marimba", "C6:2 A5:2 r:2 C6:2 F6:4 E6:4 D6:2 Bb5:2 r:2 D6:2 C6:4 A5:4 "
                         "G5:2 Bb5:2 D6:2 C6:2 Bb5:4 A5:4 G5:2 E5:2 C5:4 F5:8", start_bar=4, vol=40, echo=1)
    s.line(4, "flute", "A5:16 F5:16 G5:16 E5:16", start_bar=8, vol=22)
    s.line(0, "marimba", "r:16 r:16 F6:2 E6:2 D6:2 C6:2 Bb5:4 G5:4 E5:4 G5:4 C6:8", start_bar=12, vol=36, echo=1)
    return s


def song_asia():
    """Temple garden: pentatonic harp (koto-ish), flute, soft pad. Slow."""
    s = Song("Momo Garden", 72, 16)
    pads = [C("D4", "A4"), C("Bb3", "F4"), C("C4", "G4"), C("A3", "E4")] * 4
    s.chords([6, 7], "pad", pads, vol=16, style="block")
    s.bass(3, ["D2", "Bb1", "C2", "A1"] * 4, vol=28, pattern=((0, 0),))
    s.line(2, "harp", "D5:2 F5:2 G5:2 A5:2 C6:4 A5:4 G5:2 F5:2 D5:4 r:8 "
                      "C5:2 D5:2 F5:2 G5:2 A5:4 G5:4 F5:4 D5:4 r:8", vol=34, echo=1)
    s.line(4, "flute", "A5:8 G5:4 F5:4 D5:16 F5:8 G5:4 A5:4 C6:8 A5:8 "
                       "D6:8 C6:4 A5:4 G5:16 F5:8 G5:4 F5:4 D5:16", start_bar=4, vol=30)
    s.line(2, "harp", "A5:2 C6:2 D6:2 C6:2 A5:4 G5:4 F5:2 G5:2 A5:4 r:8 "
                      "G5:2 F5:2 D5:2 C5:2 D5:16 r:8", start_bar=12, vol=32, echo=1)
    s.perc(5, "tick", [(0, 0)], 16, vol=8)
    return s


def song_map():
    """World map: wind-swept D Dorian adventure, flute over harp and a pedal bass."""
    s = Song("Momo World Map", 80, 16)
    prog = [C("D4", "F4", "A4", "C5"), C("D4", "G4", "B4", "D5"), C("D4", "F4", "A4", "E5"), C("Bb3", "D4", "F4", "A4")] * 4
    s.chords([2], "harp", prog, vol=24, pattern=[0, 1, 2, 3, 2, 1, 2, 1])
    s.bass(3, ["D2", "D2", "D2", "Bb1"] * 4, vol=32, pattern=((0, 0), (8, 7)))
    s.perc(5, "shaker", [(4, 0), (12, 0)], 16, vol=7)
    s.line(4, "flute", "D5:4 A5:4 G5:4 F5:2 E5:2 D5:8 B5:4 A5:4 "
                       "C6:6 B5:2 A5:4 G5:4 A5:4 F5:4 D5:8", start_bar=2, vol=34)
    s.line(4, "flute", "D5:4 A5:4 G5:4 F5:2 G5:2 A5:8 D6:4 C6:4 "
                       "B5:6 A5:2 G5:4 F5:4 E5:4 C5:4 D5:8", start_bar=6, vol=34)
    s.line(0, "epiano", "F5:8 E5:8 D5:8 B4:8 C5:8 A4:8 D5:16", start_bar=10, vol=28, echo=1)
    s.line(4, "flute", "A5:4 D6:4 C6:4 A5:4 G5:8 B5:8 A5:16 r:16", start_bar=12, vol=30)
    return s


def song_timewarp():
    """Time machine (synced to the 8-second cutscene): engine pulse and a
    speeding clock, a rising run to 88 MPH, a swirling time tunnel, landing."""
    s = Song("Momo Time Machine", 120, 5)
    # A: rows 0-19 - the car idles, Momo hops in; the clock ticks faster
    for r in range(0, 20, 2):
        s.put(r, 3, parse_note("C2") - 11, "bass", 34)
    for r in (0, 4, 8, 12, 14, 16, 17, 18, 19):
        s.put(r, 5, 49, "tick", 12 + r)
    s.put(0, 6, parse_note("C4") - 11, "pad", 14)
    s.off(19, 6)
    # B: rows 20-33 - accelerating to 88 MPH: rising arpeggio, snare roll swell
    run = ["C5", "D5", "E5", "F#5", "G5", "A5", "B5", "C6", "D6", "E6", "F#6", "G6", "B6", "C7"]
    for k, nm in enumerate(run):
        s.put(20 + k, 2, parse_note(nm) - 11, "glock", 20 + k * 2)
        s.put(20 + k, 4, 49, "snare", 10 + k * 3)
        s.put(20 + k, 3, parse_note("C2") - 11 + (k // 2), "bass", 36)
    # flash! row 34: big warm horn chord
    for ch, nm in ((0, "G5"), (1, "E5"), (6, "C5")):
        s.put(34, ch, parse_note(nm) - 11, "brass", 40)
        s.off(46, ch)
    s.put(34, 3, parse_note("C2") - 11, "bass", 44)
    # C: rows 34-51 - the time tunnel: Lydian swirl over a pedal
    swirl = ["C5", "E5", "G5", "B5", "D6", "F#6", "D6", "B5"]
    for k in range(18):
        s.put(34 + k, 2, parse_note(swirl[k % 8]) - 11 + (12 if k >= 9 else 0), "harp", 28)
        s.put(34 + k + 2, 7, parse_note(swirl[k % 8]) - 11 + (12 if k >= 9 else 0), "harp", 10)   # echo
        if k % 4 == 0:
            s.put(34 + k, 4, 49, "shaker", 12)
    s.put(42, 3, parse_note("C2") - 11, "bass", 36)
    # D: rows 52-79 - arrival in 2016: warm Cmaj9 and a few twinkles
    for ch, nm in ((0, "E5"), (1, "B4"), (6, "G4")):
        s.put(52, ch, parse_note(nm) - 11, "epiano", 34)
    s.put(52, 3, parse_note("C2") - 11, "bass", 38)
    for k, nm in enumerate(["C4", "E4", "G4", "B4", "D5"]):
        s.put(52 + k, 2, parse_note(nm) - 11, "harp", 26)
    for r, nm in ((60, "D6"), (64, "B5"), (68, "G6"), (72, "E6")):
        s.put(r, 5, parse_note(nm) - 11, "glock", 16)
    return s


SONGS = {
    "m_timewarp": song_timewarp,
    "m_title": song_title,
    "m_balcony": song_balcony,
    "m_yahoo": song_yahoo,
    "m_tropical": song_tropical,
    "m_asia": song_asia,
    # (the world map plays the title theme too - saves ~113 KB of RAM)
}

# --------------------------------------------------------------------------
# Sound effects (soft, short, never shrill)
# --------------------------------------------------------------------------


def render_note(inst, midi, dur, gain=1.0):
    smp, root, ls, ll = INSTRUMENTS[inst]
    ratio = midi_hz(midi) / midi_hz(root)
    n = int(dur * SR)
    out = []
    pos = 0.0
    for i in range(n):
        p = int(pos)
        if p >= len(smp):
            if ll:
                p = ls + (p - ls) % ll
            else:
                break
        out.append(smp[p] * gain)
        pos += ratio
    # tiny fade out to avoid clicks
    fade = min(len(out), int(0.02 * SR))
    for k in range(fade):
        out[len(out) - fade + k] *= 1 - k / fade
    return out


def soft_noise(dur, lo, hi, shape):
    n = int(dur * SR)
    x = lowpass(highpass([rnd.uniform(-1, 1) for _ in range(n)], lo), hi)
    return [v * shape(i / n) for i, v in enumerate(x)]


def sfx_select():
    return render_note("marimba", parse_note("E6"), 0.12, 0.5)


def sfx_confirm():
    out = render_note("marimba", parse_note("C6"), 0.1, 0.5)
    place(out, render_note("marimba", parse_note("G6"), 0.18, 0.5), 0.06)
    return out


def sfx_back():
    out = render_note("tick", 60, 0.06, 0.5)
    place(out, render_note("marimba", parse_note("A4"), 0.14, 0.4), 0.03)
    return out


def sfx_meow():
    """A soft little 'mew': gliding tone with a vowel-ish formant."""
    dur = 0.32
    n = int(dur * SR)
    out, ph = [], 0.0
    for i in range(n):
        t = i / dur / SR
        f = 560 + 380 * math.sin(math.pi * min(1, t * 1.3)) - 120 * t
        f *= 1 + 0.015 * math.sin(2 * math.pi * 7 * i / SR)
        ph += 2 * math.pi * f / SR
        v = math.sin(ph) + 0.45 * math.sin(2 * ph) + 0.2 * math.sin(3 * ph)
        amp = math.sin(math.pi * min(1, t)) ** 1.5
        out.append(v * amp)
    return normalize(lowpass(out, 2600), 0.7)


def sfx_purr():
    dur = 0.7
    n = int(dur * SR)
    base = lowpass([rnd.uniform(-1, 1) for _ in range(n)], 260)
    out = []
    for i in range(n):
        t = i / SR
        am = 0.55 + 0.45 * math.sin(2 * math.pi * 24 * t)
        fade = math.sin(math.pi * i / n)
        out.append(base[i] * am * fade + 0.3 * math.sin(2 * math.pi * 55 * t) * am * fade)
    return normalize(out, 0.55)


def sfx_jump():
    out = soft_noise(0.18, 400, 2500, lambda u: math.sin(math.pi * u) ** 2)
    out = normalize(out, 0.25)
    n = len(out)
    ph = 0.0
    for i in range(n):
        f = 300 + 400 * i / n
        ph += 2 * math.pi * f / SR
        out[i] += 0.25 * math.sin(ph) * math.sin(math.pi * i / n)
    return out


def sfx_heart():
    out = render_note("glock", parse_note("C6"), 0.25, 0.45)
    place(out, render_note("glock", parse_note("G6"), 0.5, 0.45), 0.06)
    return out


def sfx_fail():
    """Gentle 'uh-oh' on the woodblock and marimba, a minor second down."""
    out = render_note("marimba", parse_note("F4"), 0.16, 0.5)
    place(out, render_note("marimba", parse_note("E4"), 0.3, 0.45), 0.13)
    return out


def sfx_woof():
    out = []
    for k in range(2):
        n = int(0.12 * SR)
        bark, ph = [], 0.0
        for i in range(n):
            f = 210 - 70 * i / n
            ph += 2 * math.pi * f / SR
            bark.append((math.sin(ph) + 0.4 * math.sin(2 * ph)) * math.sin(math.pi * i / n))
        place(out, lowpass(bark, 900), k * 0.18, 0.5)
    return out


def sfx_levelup():
    """Level up! A softened Dragon-Quest-style fanfare: soft snare roll and a
    triplet pickup on warm horns, up to a held major chord, then a sparkle
    cascade. About 1.7 s, never shrill."""
    out = silence(1.9)
    for k in range(6):                                    # soft snare roll
        place(out, render_note("snare", 60, 0.12, 0.10 + k * 0.02), k * 0.035)
    for nm, at, ln in (("G4", 0.0, 0.07), ("A4", 0.07, 0.07), ("B4", 0.14, 0.07),
                       ("C5", 0.21, 0.17), ("E5", 0.40, 0.13)):
        place(out, render_note("brass", parse_note(nm), ln + 0.03, 0.36), at)
    for nm, g in (("G5", 0.34), ("E5", 0.26), ("C5", 0.24)):   # the big chord
        note = render_note("brass", parse_note(nm), 0.95, g)
        n = len(note)
        note = [v * (1 - max(0, i - n * 0.4) / (n * 0.6)) for i, v in enumerate(note)]
        place(out, note, 0.55)
    place(out, render_note("bass", parse_note("C3"), 0.6, 0.35), 0.55)
    place(out, render_note("snare", 60, 0.15, 0.22), 0.55)
    for k, nm in enumerate(["C7", "B6", "G6", "E6", "D6", "C6"]):   # sparkles falling
        place(out, render_note("glock", parse_note(nm), 0.35, 0.12), 0.72 + k * 0.05)
    return out


def sfx_engine():
    """The time machine revs up: two gears of a rising engine note (rich in
    harmonics so small speakers still carry it) plus tyre whine."""
    dur = 2.0
    n = int(dur * SR)
    out, ph = [], 0.0
    whine = lowpass(highpass([rnd.uniform(-1, 1) for _ in range(n)], 1500), 3500)
    for i in range(n):
        t = i / SR
        if t < 0.8:                        # first gear
            f = 55 + 70 * (t / 0.8) ** 0.8
        elif t < 0.9:                      # shift: the revs dip
            f = 125 - 40 * (t - 0.8) / 0.1
        else:                              # second gear, screaming towards 88 at the end
            f = 85 + 110 * ((t - 0.9) / (dur - 0.9)) ** 1.2
        ph += 2 * math.pi * f / SR
        v = 0
        for h in range(1, 9):              # pulse-ish engine tone
            v += math.sin(h * ph) / h * (1 if h % 2 else 0.6)
        v *= 0.9 + 0.1 * math.sin(2 * math.pi * 31 * t)   # cylinder rumble
        amp = min(1, t / 0.15) * (0.75 + 0.25 * t / dur)
        out.append(v * amp + whine[i] * 0.15 * (t / dur) ** 2)
    out = lowpass(out, 1800)
    n_fade = int(0.08 * SR)
    for k in range(n_fade):
        out[n - n_fade + k] *= 1 - k / n_fade
    return normalize(out, 0.7)


def sfx_boom():
    """Breaking through time: a muffled double BOOM-BOOM, an electric crackle
    and a rushing whoosh. Big but soft-edged (everything low-passed)."""
    out = silence(1.3)
    for k, at in enumerate((0.0, 0.13)):
        n = int(0.45 * SR)
        thump, ph = [], 0.0
        body = lowpass([rnd.uniform(-1, 1) for _ in range(n)], 700)
        for i in range(n):
            t = i / SR
            f = 130 * math.exp(-t * 6) + 60
            ph += 2 * math.pi * f / SR
            thump.append((math.sin(ph) * 0.9 + body[i] * 0.8) * math.exp(-t * 7))
        place(out, lowpass(thump, 1100), at, 0.8 if k == 0 else 0.65)
    # electric crackle (short band-limited bursts)
    for k in range(7):
        at = 0.02 + k * 0.045 + rnd.uniform(0, 0.02)
        burst = soft_noise(0.025, 1500, 5000, lambda u: (1 - u) ** 2)
        place(out, burst, at, 0.35)
    whoosh = soft_noise(0.9, 250, 2400, lambda u: math.sin(math.pi * min(1, u * 1.2)) ** 2 * (1 - u))
    place(out, normalize(whoosh, 0.45), 0.15)
    return normalize(out, 0.85)


def sfx_tunnel():
    """Inside the time tunnel: a rushing wind that sweeps up and down, a low
    swirling drone (two detuned tones beating) and scattered sparkles."""
    dur = 2.2
    n = int(dur * SR)
    noise = [rnd.uniform(-1, 1) for _ in range(n)]
    out, y, ph1, ph2 = [], 0.0, 0.0, 0.0
    for i in range(n):
        t = i / SR
        cutoff = 500 + 1600 * (0.5 + 0.5 * math.sin(2 * math.pi * 0.9 * t))   # whooshing sweep
        a = math.exp(-2 * math.pi * cutoff / SR)
        y = (1 - a) * noise[i] + a * y
        ph1 += 2 * math.pi * 110 / SR
        ph2 += 2 * math.pi * 116.5 / SR
        drone = (math.sin(ph1) + 0.5 * math.sin(2 * ph1) + math.sin(ph2) + 0.5 * math.sin(2 * ph2)) * 0.25
        env = min(1, t / 0.25) * min(1, (dur - t) / 0.5)
        out.append((y * 1.4 + drone) * env)
    out = highpass(out, 120)
    for k in range(9):
        nm = rnd.choice(["E6", "G6", "B6", "D7", "F#6"])
        place(out, render_note("glock", parse_note(nm), 0.3, 0.08), 0.2 + k * 0.2 + rnd.uniform(0, 0.08))
    return normalize(out, 0.6)


def sfx_land():
    """Arriving: a short tyre skid and a soft thump as the wheels touch down."""
    out = soft_noise(0.55, 900, 2600, lambda u: math.sin(math.pi * min(1, u * 2)) * (1 - u))
    out = normalize(out, 0.35)
    n = int(0.25 * SR)
    thump, ph = [], 0.0
    for i in range(n):
        t = i / SR
        ph += 2 * math.pi * (110 * math.exp(-t * 8) + 60) / SR
        thump.append(math.sin(ph) * math.exp(-t * 14))
    place(out, lowpass(thump, 800), 0.42, 0.6)
    return out


def _honk(f0, f1, dur, formant, buzz=1.0):
    """A short nasal bird call: a buzzy tone through a vowel-ish formant."""
    n = int(dur * SR)
    out, ph = [], 0.0
    for i in range(n):
        u = i / n
        f = f0 + (f1 - f0) * u
        ph += 2 * math.pi * f / SR
        v = 0
        for h in range(1, 10):
            hf = f * h
            weight = math.exp(-((hf - formant) / 450.0) ** 2) + 0.25 / h
            v += math.sin(h * ph) * weight * (buzz if h > 1 else 1)
        out.append(v * math.sin(math.pi * u) ** 0.7)
    return lowpass(out, 3000)


def sfx_quack():
    """Maru the call duck: two little 'wak-wak's."""
    out = silence(0.4)
    place(out, _honk(420, 340, 0.11, 1100), 0.0, 0.5)
    place(out, _honk(440, 330, 0.13, 1050), 0.16, 0.5)
    return normalize(out, 0.6)


def sfx_cluck():
    """A soft hen 'bok bok bawk'."""
    out = silence(0.55)
    place(out, _honk(330, 300, 0.06, 900, 0.6), 0.0, 0.5)
    place(out, _honk(330, 300, 0.06, 900, 0.6), 0.11, 0.5)
    place(out, _honk(360, 520, 0.22, 1000, 0.7), 0.24, 0.45)
    return normalize(out, 0.55)


def sfx_skillup():
    """Small bright chime for learning a skill and other little wins."""
    out = silence(0.5)
    for k, nm in enumerate(["E6", "G6", "C7"]):
        place(out, render_note("glock", parse_note(nm), 0.3, 0.28), k * 0.05)
    return out


def sfx_click():
    """Soft camera shutter."""
    out = soft_noise(0.03, 1500, 5000, lambda u: (1 - u) ** 2)
    place(out, soft_noise(0.04, 1200, 4000, lambda u: (1 - u) ** 2), 0.07)
    return normalize(out, 0.35)


def sfx_clear():
    """Short warm jingle."""
    out = silence(2.0)
    mel = [("C5", 0.0), ("E5", 0.14), ("G5", 0.28), ("C6", 0.42), ("B5", 0.7), ("A5", 0.84), ("G5", 1.0)]
    for nm, at in mel:
        place(out, render_note("marimba", parse_note(nm), 0.4, 0.45), at)
    for nm in ("C4", "E4", "G4", "B4"):
        place(out, render_note("harp", parse_note(nm), 1.0, 0.18), 1.0)
    return out


def sfx_gameover():
    """Sleepy, not scary: flute sighs down G-E-C and fades."""
    out = silence(1.8)
    for k, nm in enumerate(["G4", "E4", "C4"]):
        note = render_note("flute", parse_note(nm), 0.6 if k < 2 else 1.0, 0.35)
        n = len(note)
        note = [v * min(1, i / (0.05 * SR)) * (1 - i / n) ** 0.5 for i, v in enumerate(note)]
        place(out, note, k * 0.45)
    return out


def sfx_timewarp():
    """88 MPH: spool-up, flux sparkle, soft whoosh, warm landing chord."""
    out = silence(2.4)
    # spool up: bass glide
    n = int(0.8 * SR)
    ph, spool = 0.0, []
    for i in range(n):
        f = midi_hz(36) * 2 ** (7 * i / n / 12)
        ph += 2 * math.pi * f / SR
        spool.append((math.sin(ph) + 0.3 * math.sin(2 * ph)) * (i / n) * (1 + 0.1 * math.sin(2 * math.pi * 9 * i / SR)))
    place(out, lowpass(spool, 900), 0.0, 0.4)
    # flux sparkle
    for k, nm in enumerate(["E6", "G6", "B6", "E7"]):
        place(out, render_note("glock", parse_note(nm), 0.35, 0.25), 0.55 + k * 0.06)
    # soft whoosh
    whoosh = soft_noise(0.6, 200, 2200, lambda u: math.sin(math.pi * u) ** 2)
    place(out, normalize(whoosh, 0.35), 0.8)
    # landing chord
    for nm in ("C5", "E5", "G5", "B5"):
        place(out, render_note("epiano", parse_note(nm), 1.2, 0.18), 1.15)
    return out


SFX = {
    "s_select": sfx_select,
    "s_confirm": sfx_confirm,
    "s_back": sfx_back,
    "s_meow": sfx_meow,
    "s_purr": sfx_purr,
    "s_jump": sfx_jump,
    "s_heart": sfx_heart,
    "s_fail": sfx_fail,
    "s_woof": sfx_woof,
    "s_levelup": sfx_levelup,
    "s_click": sfx_click,
    "s_clear": sfx_clear,
    "s_gameover": sfx_gameover,
    "s_timewarp": sfx_timewarp,
    "s_skillup": sfx_skillup,
    "s_engine": sfx_engine,
    "s_boom": sfx_boom,
    "s_tunnel": sfx_tunnel,
    "s_land": sfx_land,
    "s_quack": sfx_quack,
    "s_cluck": sfx_cluck,
}


def write_wav(path, data):
    data = highpass(data, 90)
    pcm = [max(-32767, min(32767, int(v * 30000))) for v in data]
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(struct.pack("<%dh" % len(pcm), *pcm))


def render_song(song, loops=1):
    """Rough offline mix of a Song (for previewing on a computer)."""
    row_sec = 6 * 2.5 / song.bpm
    total = song.rows * row_sec * loops + 2
    out = [0.0] * int(total * SR)
    active = {}  # ch -> (start_sec, midi, inst, vol)

    def flush(ch, end_sec):
        if ch not in active:
            return
        st, midi, inst, vol = active.pop(ch)
        seg = render_note(inst, midi, min(4.0, end_sec - st + (0.4 if inst not in ("flute", "pad") else 0.15)), vol / 64.0)
        env, _, _ = ENVELOPES.get(inst, ([], 0, 0))
        if env:   # soft attack like the XM envelope
            atk = int(env[1][0] * row_sec / 6 * SR)
            for k in range(min(atk, len(seg))):
                seg[k] *= k / atk
        place(out, seg, st)

    for lp in range(loops):
        for row in range(song.rows):
            t = (lp * song.rows + row) * row_sec
            for ch in range(song.nch):
                cell = song.cells.get((row, ch))
                if not cell:
                    continue
                note, inst, vol = cell
                flush(ch, t)
                if note != 97:
                    active[ch] = (t, note + 11, inst, vol)
    for ch in list(active):
        flush(ch, song.rows * row_sec * loops)
    return out


def preview(dest):
    os.makedirs(dest, exist_ok=True)
    for name, fn in SONGS.items():
        mixd = render_song(fn())
        peak = max(abs(v) for v in mixd)
        rms = math.sqrt(sum(v * v for v in mixd) / len(mixd))
        write_wav(os.path.join(dest, name + ".wav"), [v / max(1.0, peak) * 0.8 for v in mixd])
        print("%-12s %5.1fs  peak %.2f  rms %.3f" % (name, len(mixd) / SR, peak, rms))
    for name, fn in SFX.items():
        d = fn()
        print("%-12s %5.2fs  peak %.2f" % (name, len(d) / SR, max(abs(v) for v in d)))


def main():
    import sys
    if len(sys.argv) > 2 and sys.argv[1] == "--preview":
        preview(sys.argv[2])
        return
    os.makedirs(OUT, exist_ok=True)
    for name, fn in SONGS.items():
        fn().write(os.path.join(OUT, name + ".xm"))
    for name, fn in SFX.items():
        write_wav(os.path.join(OUT, name + ".wav"), fn())
    print("wrote", len(SONGS), "songs and", len(SFX), "sound effects to", OUT)


if __name__ == "__main__":
    main()
