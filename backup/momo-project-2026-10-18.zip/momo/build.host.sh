#!/bin/sh
# Build the PC test harness (screenshots + balance simulation).
set -e
cd "$(dirname "$0")"
mkdir -p build/host
clang -O2 -Wall -Wextra -Wno-unused-parameter -DMOMO_HOST -Isource \
    source/game.c source/gfx.c source/world.c source/scores.c source/gen/assets.c host/host_main.c -o build/host/momo_host
