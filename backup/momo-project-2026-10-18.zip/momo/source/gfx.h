// Momo Dev Story - software renderer for 256x192 RGB15 framebuffers.

#ifndef MOMO_GFX_H
#define MOMO_GFX_H

#include <stdint.h>

#include "plat.h"

#define RGB(r, g, b) ((uint16_t)(((r) >> 3) | (((g) >> 3) << 5) | (((b) >> 3) << 10) | 0x8000))

#define COL_BLACK RGB(0, 0, 0)
#define COL_WHITE RGB(255, 255, 255)
#define COL_INK RGB(60, 36, 30)
#define COL_RED RGB(230, 50, 70)
#define COL_GREEN RGB(70, 190, 90)
#define COL_BLUE RGB(70, 140, 235)
#define COL_YELLOW RGB(255, 214, 60)
#define COL_ORANGE RGB(245, 140, 40)
#define COL_GRAY RGB(140, 140, 150)
#define COL_PURPLE RGB(120, 50, 180)
#define COL_PINK RGB(255, 150, 190)
#define COL_CREAM RGB(252, 240, 220)

enum {
    SPR_FLIP = 1 << 0,   // mirror horizontally
    SPR_WHITE = 1 << 1,  // draw as a white silhouette (hit flash)
};

typedef uint16_t Fb[SCREEN_W * SCREEN_H];

// Every drawing function accepts a NULL framebuffer and then does nothing:
// the DS port passes NULL for the bottom screen on frames it doesn't redraw.

void gfx_copy(uint16_t *dst, const uint16_t *src);
void gfx_fill(uint16_t *fb, int x, int y, int w, int h, uint16_t c);
void gfx_frame(uint16_t *fb, int x, int y, int w, int h, uint16_t c);
void gfx_blend(uint16_t *fb, int x, int y, int w, int h, uint16_t c);   // 50% mix
void gfx_darken(uint16_t *fb, int x, int y, int w, int h);              // 50% darker
void gfx_hline(uint16_t *fb, int x0, int x1, int y, uint16_t c);
void gfx_line(uint16_t *fb, int x0, int y0, int x1, int y1, uint16_t c);
void gfx_panel(uint16_t *fb, int x, int y, int w, int h, uint16_t fill, uint16_t border);

void gfx_clip_bottom(int y);  // sprites are cut off below this line
void gfx_sprite(uint16_t *fb, const uint8_t *px, int w, int h, int x, int y,
                const uint16_t *pal, int flags, int scale);

// Like gfx_sprite (scale 1) but pixels of colour idx_a/idx_b get an outfit
// pattern (PAT_* from world.h) in pat_col.
void gfx_sprite_pat(uint16_t *fb, const uint8_t *px, int w, int h, int x, int y,
                    const uint16_t *pal, int flags, int idx_a, int idx_b, int pat, uint16_t pat_col);

int gfx_text(uint16_t *fb, int x, int y, const char *s, uint16_t c);
int gfx_text_shadow(uint16_t *fb, int x, int y, const char *s, uint16_t c, uint16_t sh);
int gfx_text_outline(uint16_t *fb, int x, int y, const char *s, uint16_t c, uint16_t o, int scale);
int gfx_text_width(const char *s, int scale);
void gfx_text_center(uint16_t *fb, int cx, int y, const char *s, uint16_t c, uint16_t o, int scale);

void gfx_bar(uint16_t *fb, int x, int y, int w, int h, int val, int max, uint16_t fg, uint16_t bg);

#endif // MOMO_GFX_H
