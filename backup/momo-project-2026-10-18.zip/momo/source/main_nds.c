// Momo Dev Story - Nintendo DS platform layer (BlocksDS / libnds).
//
// Both screens use a 256x192 16-bit bitmap background (mode 5, BG3). The game
// renders into RAM buffers, which are DMA'd to VRAM. The top screen is double
// buffered across VRAM banks A and B; the bottom screen (bank C) is copied
// right after VBlank so the DMA stays ahead of the beam.

#include <fat.h>
#include <maxmod9.h>
#include <nds.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "game.h"
#include "plat.h"
#include "soundbank.h"
#include "soundbank_bin.h"

#define FB_BYTES (SCREEN_W * SCREEN_H * 2)

static uint16_t top_fb[SCREEN_W * SCREEN_H] __attribute__((aligned(32)));
static uint16_t bot_fb[SCREEN_W * SCREEN_H] __attribute__((aligned(32)));

// --------------------------------------------------------------------------
// Sound: Maxmod plays the XM music and WAV effects from tools/gen_audio.py
// --------------------------------------------------------------------------

// Music sits in the background; effects are quieter accents on top of it.
#define MUSIC_VOLUME 480      // module volume, 0..1024
#define SFX_MASTER 900        // effects master volume, 0..1024

static const mm_word music_ids[MUS_COUNT] = {
    [MUS_NONE] = 0,
    [MUS_TITLE] = MOD_M_TITLE,
    [MUS_BALCONY] = MOD_M_BALCONY,
    [MUS_YAHOO] = MOD_M_YAHOO,
    [MUS_TROPICAL] = MOD_M_TROPICAL,
    [MUS_ASIA] = MOD_M_ASIA,
    [MUS_MAP] = MOD_M_TITLE,        // the world map shares the title theme
    [MUS_TIMEWARP] = MOD_M_TIMEWARP,
};

typedef struct {
    mm_word id;
    uint8_t volume;    // 0..255
    uint8_t jitter;    // random pitch spread in 1/1024 steps (keeps repeats natural)
    uint8_t cooldown;  // minimum frames between two plays
    uint8_t duck;      // frames to dip the music under this jingle (0 = none)
} SfxDef;

static const SfxDef sfx_defs[SFX_COUNT] = {
    [SFX_SELECT] = { SFX_S_SELECT, 90, 40, 4 },
    [SFX_CONFIRM] = { SFX_S_CONFIRM, 110, 20, 6 },
    [SFX_BACK] = { SFX_S_BACK, 100, 20, 6 },
    [SFX_MEOW] = { SFX_S_MEOW, 150, 50, 10 },
    [SFX_PURR] = { SFX_S_PURR, 120, 30, 20 },
    [SFX_JUMP] = { SFX_S_JUMP, 110, 40, 8 },
    [SFX_HEART] = { SFX_S_HEART, 120, 30, 6 },
    [SFX_FAIL] = { SFX_S_FAIL, 120, 20, 10 },
    [SFX_WOOF] = { SFX_S_WOOF, 110, 30, 20 },
    [SFX_LEVELUP] = { SFX_S_LEVELUP, 175, 0, 60, 110 },
    [SFX_CLICK] = { SFX_S_CLICK, 110, 30, 6 },
    [SFX_CLEAR] = { SFX_S_CLEAR, 150, 0, 30, 120 },
    [SFX_GAMEOVER] = { SFX_S_GAMEOVER, 150, 0, 30, 110 },
    [SFX_TIMEWARP] = { SFX_S_TIMEWARP, 150, 0, 30, 0 },
    [SFX_SKILLUP] = { SFX_S_SKILLUP, 110, 20, 6, 0 },
    [SFX_ENGINE] = { SFX_S_ENGINE, 150, 0, 30, 0 },
    [SFX_BOOM] = { SFX_S_BOOM, 165, 0, 30, 0 },
    [SFX_TUNNEL] = { SFX_S_TUNNEL, 130, 0, 30, 0 },
    [SFX_LAND] = { SFX_S_LAND, 140, 0, 30, 0 },
    [SFX_QUACK] = { SFX_S_QUACK, 110, 40, 30, 0 },
    [SFX_CLUCK] = { SFX_S_CLUCK, 110, 60, 30, 0 },
};

static uint32_t sfx_last[SFX_COUNT];
static uint32_t frame_count;
static int music_track = -1;
static int duck_frames;          // music is dipped while a jingle plays
static int music_vol = MUSIC_VOLUME;

void plat_sfx(int id)
{
    if (id < 0 || id >= SFX_COUNT || sfx_defs[id].volume == 0)
        return;
    const SfxDef *d = &sfx_defs[id];
    // spam guard: mashing a button shouldn't pile up the same sound
    if (sfx_last[id] && frame_count - sfx_last[id] < d->cooldown)
        return;
    sfx_last[id] = frame_count ? frame_count : 1;
    if (d->duck > duck_frames)
        duck_frames = d->duck;
    mm_sound_effect e = {
        .id = d->id,
        .rate = (mm_hword)(1024 + (d->jitter ? (int)(rand() % (2 * d->jitter + 1)) - d->jitter : 0)),
        .handle = 0,
        .volume = d->volume,
        .panning = 128,
    };
    mmEffectEx(&e);
}

void plat_music(int track)
{
    if (track == music_track)
        return;
    // screens that share a song (title + world map) keep it playing seamlessly
    if (track > MUS_NONE && track < MUS_COUNT && music_track > MUS_NONE &&
        music_ids[track] == music_ids[music_track]) {
        music_track = track;
        return;
    }
    if (music_track > MUS_NONE) {
        mmStop();
        mmUnload(music_ids[music_track]);
    }
    music_track = track;
    if (track <= MUS_NONE || track >= MUS_COUNT)
        return;
    mmLoad(music_ids[track]);
    mmStart(music_ids[track], MM_PLAY_LOOP);
}

// Called once per frame: dip the music fast under a jingle, bring it back slowly.
static void audio_tick(void)
{
    int target = duck_frames > 0 ? MUSIC_VOLUME * 3 / 10 : MUSIC_VOLUME;
    if (duck_frames > 0)
        duck_frames--;
    int v = music_vol;
    if (v > target)
        v = v - 48 < target ? target : v - 48;
    else if (v < target)
        v = v + 8 > target ? target : v + 8;
    if (v != music_vol) {
        music_vol = v;
        mmSetModuleVolume((mm_word)v);
    }
}

static void audio_init(void)
{
    mmInitDefaultMem((mm_addr)soundbank_bin);
    for (int i = 0; i < SFX_COUNT; i++)
        if (sfx_defs[i].volume)
            mmLoadEffect(sfx_defs[i].id);
    mmSetModuleVolume(MUSIC_VOLUME);
    mmSetEffectsVolume(SFX_MASTER);
}

// --------------------------------------------------------------------------
// Leaderboard storage: a small file on the flashcart / DSi SD card
// --------------------------------------------------------------------------

static bool fat_ok;

static const char *const save_paths[] = {
    "sd:/momo_dev_story.sav",
    "fat:/momo_dev_story.sav",
};

bool plat_save(const void *data, int size)
{
    if (!fat_ok)
        return false;
    for (unsigned i = 0; i < sizeof(save_paths) / sizeof(save_paths[0]); i++) {
        FILE *f = fopen(save_paths[i], "wb");
        if (!f)
            continue;
        bool ok = fwrite(data, 1, (size_t)size, f) == (size_t)size;
        fclose(f);
        if (ok)
            return true;
    }
    return false;
}

bool plat_load(void *data, int size)
{
    if (!fat_ok)
        return false;
    for (unsigned i = 0; i < sizeof(save_paths) / sizeof(save_paths[0]); i++) {
        FILE *f = fopen(save_paths[i], "rb");
        if (!f)
            continue;
        bool ok = fread(data, 1, (size_t)size, f) == (size_t)size;
        fclose(f);
        if (ok)
            return true;
    }
    return false;
}

// --------------------------------------------------------------------------
// Main loop
// --------------------------------------------------------------------------

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;

    videoSetMode(MODE_5_2D);
    videoSetModeSub(MODE_5_2D);
    vramSetPrimaryBanks(VRAM_A_MAIN_BG_0x06000000, VRAM_B_MAIN_BG_0x06020000,
                        VRAM_C_SUB_BG_0x06200000, VRAM_D_LCD);

    int bg_top = bgInit(3, BgType_Bmp16, BgSize_B16_256x256, 0, 0);
    bgInitSub(3, BgType_Bmp16, BgSize_B16_256x256, 0, 0);

    audio_init();
    // without a DLDI/SD card the leaderboard simply lives for this session
    fat_ok = fatInitDefault();

    game_init((uint32_t)time(NULL) * 2654435761u);

    int shown = 0;           // VRAM half currently displayed (bmp base 0 or 8)
    bool pending = false;    // a new top frame is waiting in the back buffer

    while (1) {
        swiWaitForVBlank();

        if (pending) {
            shown ^= 1;
            bgSetMapBase(bg_top, shown ? 8 : 0);
            pending = false;
        }
        DC_FlushRange(bot_fb, FB_BYTES);
        dmaCopy(bot_fb, BG_BMP_RAM_SUB(0), FB_BYTES);

        scanKeys();
        Input in = { 0 };
        in.held = keysHeld() & 0xFFF;
        in.down = keysDown() & 0xFFF;
        if (keysDown() & KEY_TOUCH) {
            touchPosition t;
            touchRead(&t);
            in.touch = true;
            in.tx = t.px;
            in.ty = t.py;
        }

        game_update(&in);
        game_render(top_fb, bot_fb);

        DC_FlushRange(top_fb, FB_BYTES);
        dmaCopy(top_fb, BG_BMP_RAM(shown ? 0 : 8), FB_BYTES);
        pending = true;

        frame_count++;
        audio_tick();
    }
    return 0;
}
