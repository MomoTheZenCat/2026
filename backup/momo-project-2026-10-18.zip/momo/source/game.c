// Momo Dev Story - game logic and screens.
//
// Momo sits on the balcony fence watching humans walk by. Use skills (meow,
// slow blink, belly flop...) to charm them into feeding, petting, brushing
// or photographing you. Food restores HP, attention restores MP. HP slowly
// drains; collect enough love to clear the stage.

#include <stdio.h>
#include <string.h>

#include "game.h"
#include "gen/assets.h"
#include "gfx.h"
#include "scores.h"
#include "world.h"

// --------------------------------------------------------------------------
// Definitions
// --------------------------------------------------------------------------

enum {
    ST_TITLE,
    ST_INTRO,
    ST_SELECT,
    ST_CARD,
    ST_PLAY,
    ST_SKILLS,
    ST_PAUSE,
    ST_CLEAR,
    ST_GAMEOVER,
    ST_ENDING,
    ST_RESCUE,
    ST_TIMEWARP,
    ST_LEVELUP,
    ST_BUDDHA,
    ST_MAP,
    ST_TRAVEL,
    ST_RESULTS,
    ST_NAME,
    ST_RANKING,
};

enum { HQ_NONE, HQ_FULL, HQ_HALF, HQ_EMPTY, HQ_FAIL };

typedef struct {
    const char *name;
    const char *short_name; // shown by the Cat Eye above heads
    const char *desc;
    uint8_t cost;
    uint8_t power;
    uint8_t max_lv;
    uint8_t jump;     // Momo leaves the fence
    uint8_t area;     // hits everyone in range
    uint8_t self;     // needs no target
    uint8_t frame;    // main cat frame
    uint8_t dur;      // frames for on-fence skills
    uint8_t impact;   // frame the result is decided
    uint8_t sfx;
} SkillDef;

static const SkillDef skills[SK_COUNT] = {
    { "Meow", "MEOW", "[ALL] A tiny meow at\neveryone nearby. Cheap,\nweak, but it adds up!",
      2, 50, 5, 0, 1, 0, CF_MEOW, 40, 18, SFX_MEOW },
    { "Slow Blink", "BLINK", "[1] The cat kiss. Calms\ngrandmas and engineers.",
      4, 58, 5, 0, 0, 0, CF_SLOW, 48, 34, SFX_SELECT },
    { "Cute Pose", "CUTE", "[ALL] Paw up, head tilt,\nsparkly eyes. Students and\ntourists melt.",
      7, 62, 5, 0, 1, 0, CF_CUTE, 50, 26, SFX_HEART },
    { "Groom", "GROOM", "Lick that fur! Free.\nRestores a bit of MP and\nboosts your NEXT skill.",
      0, 0, 5, 0, 0, 1, CF_GROOM0, 84, 80, SFX_PURR },
    { "Food Paw", "FOODPAW", "[1] Reach out a paw at their\nlunch. If it works they\nalways FEED you.",
      8, 60, 5, 0, 0, 0, CF_REACH, 48, 28, SFX_MEOW },
    { "Loaf", "LOAF", "[1] Become bread. Busy humans\nfind it oddly calming.",
      6, 58, 5, 0, 0, 0, CF_LOAF, 60, 40, SFX_PURR },
    { "Cat Yoga", "YOGA", "[1] A big downward-cat\nstretch. Joggers and\nengineers respect it.",
      9, 66, 5, 0, 0, 0, CF_YOGA, 60, 36, SFX_SELECT },
    { "Purr", "PURR", "[ALL] Purr engine at full\nrev. Big range. Dog people\nand execs love it.",
      12, 64, 5, 0, 1, 0, CF_PURR, 70, 50, SFX_PURR },
    { "Shin Bump", "SHINBUMP", "[1] Jump off the fence and\nbonk their shins. Costly\nbut very effective.",
      15, 80, 5, 1, 0, 0, CF_BUMP, 0, 0, SFX_JUMP },
    { "Belly Up", "BELLY", "[1] Jump down and flop over\nshowing the fluffy belly.\nThe ultimate move.",
      20, 90, 5, 1, 0, 0, CF_BELLY0, 0, 0, SFX_JUMP },
    { "Cat Eye", "EYE", "Passive. Lv1 mood, Lv2\nwhat they like, Lv3 their\nweakness, Lv4 success %.",
      0, 0, 4, 0, 0, 0, CF_SIT0, 0, 0, SFX_SELECT },
};

typedef struct {
    const char *name;
    uint8_t sprite;
    uint8_t resist;   // 0..100
    uint8_t weak;     // skill they can't resist
    uint8_t likes;    // reaction on success
    uint8_t hostile;  // 0 friendly, 1 grumpy, 2 shoos cats
    uint8_t speed;    // 1/16 px per frame
    const char *ok;
    const char *fail;
} ArchDef;

static const ArchDef archs[PK_COUNT] = {
    [PK_CATLOVER] = { "Cat Lover", PK_CATLOVER, 5, SK_MEOW, RE_FEED, 0, 10, "Kitty!! <3", "Aww, shy?" },
    [PK_STUDENT] = { "Student", PK_STUDENT, 25, SK_CUTE, RE_PHOTO, 0, 12, "Omg so cute!", "Late for class!" },
    [PK_GRANNY] = { "Grandma", PK_GRANNY, 10, SK_BLINK, RE_FEED, 0, 6, "Here, sweetie.", "Hmph." },
    [PK_KID] = { "Kid", PK_KID, 20, SK_BELLY, RE_PET, 0, 14, "KITTY!!", "Mom, wait up!" },
    [PK_JOGGER] = { "Jogger", PK_JOGGER, 70, SK_YOGA, RE_PET, 1, 26, "Nice stretch!", "No time!" },
    [PK_COMMUTER] = { "Commuter", PK_COMMUTER, 60, SK_LOAF, RE_PHOTO, 1, 16, "...brb, cat.", "I'm on a call!" },
    [PK_DOGWALKER] = { "Dog Walker", PK_DOGWALKER, 55, SK_PURR, RE_BRUSH, 2, 12, "Good kitty.", "WOOF! WOOF!" },
    [PK_COURIER] = { "Courier", PK_COURIER, 50, SK_BUMP, RE_PET, 1, 20, "Package: cat.", "Gotta go!" },
    [PK_TOURIST] = { "Tourist", PK_TOURIST, 20, SK_CUTE, RE_PHOTO, 0, 9, "Wow! Photo!", "Where's Yahoo?" },
    [PK_DEVDAD] = { "Uncle Dev", PK_DEVDAD, 0, SK_ANY, RE_MASSAGE, 0, 8, "Who's a good cat?", "" },
    [PK_ENGINEER] = { "Engineer", PK_ENGINEER, 35, SK_BLINK, RE_BRUSH, 0, 12, "Brb, petting.", "Prod is down!" },
    [PK_PM] = { "Product Mgr", PK_PM, 30, SK_CUTE, RE_PHOTO, 0, 13, "For the deck!", "Let's sync." },
    [PK_GUARD] = { "Security", PK_GUARD, 75, SK_BELLY, RE_FEED, 2, 10, "...ok, one treat.", "No cats on campus!" },
    [PK_INTERN] = { "Intern", PK_INTERN, 10, SK_FOODPAW, RE_FEED, 0, 13, "Want my lunch?", "Oops, meeting!" },
    [PK_EXEC] = { "Executive", PK_EXEC, 80, SK_PURR, RE_PET, 1, 12, "Hm. Synergy.", "Not now." },
    [PK_ALIEN] = { "Alien", PK_ALIEN, 40, SK_PURR, RE_PHOTO, 0, 9, "Bleep! Cute!", "Zzzt?" },
    [PK_SHAMAN] = { "Shaman", PK_SHAMAN, 40, SK_BLINK, RE_BRUSH, 0, 7, "The spirits approve.", "Not today, small one." },
    [PK_MONK] = { "Monk", PK_MONK, 55, SK_BLINK, RE_BRUSH, 0, 7, "Amitabha... cute.", "*meditates*" },
    [PK_SURFER] = { "Surfer", PK_SURFER, 30, SK_YOGA, RE_PET, 0, 13, "Gnarly kitty!", "Surf's up, bye!" },
    // Momo's own humans: never spawn as passers-by, only in the rescue scene
    [PK_EVANS] = { "Dad Evans", PK_EVANS, 0, SK_ANY, RE_MASSAGE, 0, 8, "Who's my good cat?", "Hi Momo!" },
    [PK_SHANNON] = { "Mom Shannon", PK_SHANNON, 0, SK_ANY, RE_PET, 0, 8, "Let's have a chat!", "Hi Momo!" },
};

// Backgrounds are stored as 256-colour images and expanded into a few
// RGB15 buffers on demand (small LRU cache).
#define BG_SLOTS 3
static uint16_t bg_cache[BG_SLOTS][SCREEN_W * SCREEN_H] __attribute__((aligned(32)));
static int bg_cache_key[BG_SLOTS] = { -1, -1, -1 };
static uint32_t bg_cache_use[BG_SLOTS];
static uint32_t bg_clock;

static void tint_pixel(uint16_t *c, int tint)
{
    int r = *c & 31, g = (*c >> 5) & 31, b = (*c >> 10) & 31;
    if (tint == TINT_GOLDEN) {
        r = r + 4 > 31 ? 31 : r + 4;
        g = g * 9 / 10 + 1;
        b = b * 6 / 10;
    } else if (tint == TINT_EVENING) {
        r = r * 6 / 10 + 2;
        g = g * 55 / 100 + 1;
        b = b * 8 / 10 + 5;
        if (b > 31)
            b = 31;
    }
    *c = (uint16_t)(r | (g << 5) | (b << 10) | 0x8000);
}

static const uint16_t *bg_get(int id, int tint)
{
    int key = id * 4 + tint;
    int slot = 0;
    bg_clock++;
    for (int i = 0; i < BG_SLOTS; i++) {
        if (bg_cache_key[i] == key) {
            bg_cache_use[i] = bg_clock;
            return bg_cache[i];
        }
        if (bg_cache_use[i] < bg_cache_use[slot])
            slot = i;
    }
    const BgImage *b = &bg_images[id];
    uint16_t pal[256];
    for (int i = 0; i < 256; i++) {
        pal[i] = b->pal[i];
        if (tint)
            tint_pixel(&pal[i], tint);
    }
    uint16_t *dst = bg_cache[slot];
    for (int i = 0; i < SCREEN_W * SCREEN_H; i++)
        dst[i] = pal[b->px[i]];
    bg_cache_key[slot] = key;
    bg_cache_use[slot] = bg_clock;
    return dst;
}

#define BGIMG(id) bg_get(id, 0)

static const uint16_t *stage_background(int stage)
{
    return bg_get(stages[stage].bg, stages[stage].tint);
}

typedef struct {
    const char *name;
    const char *breed;
    const char *perk;
    int hp, mp;
} CatDef;

static const CatDef cats[CAT_KINDS] = {
    { "MOMO", "Orange Tabby", "Big appetite: FEED\nrewards +30%.", 60, 40 },
    { "MOCHI", "Ragdoll", "So fluffy: PET and BRUSH\nrewards +40%.", 66, 36 },
    { "OREO", "Tuxedo Kitty", "Agile: jump skills cost\n40% less MP.", 56, 46 },
};

// --------------------------------------------------------------------------
// State
// --------------------------------------------------------------------------

#define MAX_PEOPLE 6
#define MAX_POPUPS 12
#define LANE_Y0 178
#define LANE_Y1 189

enum { P_WALK, P_HOLD, P_REACT, P_FLEE, P_LEAVE };
enum { M_IDLE, M_WALK, M_ACT, M_JUMP_DOWN, M_GROUND, M_JUMP_UP, M_SHOCK, M_HIDE };
enum { RAGE_NONE, RAGE_RED, RAGE_BLACK };

typedef struct {
    bool active;
    uint8_t arch;
    int npc;           // index into npcs[], -1 for unnamed specials
    int x16;           // x * 16
    int y;             // feet
    int dir;           // +1 right, -1 left
    int speed;
    int state;
    int timer;
    bool done;         // already interacted
    int result;        // HQ_*
    int icon_t;
    const char *say;
    int say_t;
    int dist;          // walked distance for animation
    uint16_t pal[16];
    bool dog;
    int rage;          // RAGE_*: flaming humans hurt Momo unless she hides
    bool hit;          // already hurt Momo once
    uint8_t pat;       // outfit pattern (PAT_*)
    uint8_t robe;      // outfit covers the legs too
    uint16_t pat_col;
} Person;

typedef struct {
    int x, y, t;
    char txt[20];
    uint16_t col;
    int icon;          // -1 = text popup
    int vx;
} Popup;

static struct {
    int state;
    int prev_state;
    uint32_t frame;
    uint32_t rng;
    int t;             // time in current state

    int cat;
    int stage;
    int hp, maxhp, mp, maxmp;
    int xp, lv, points;
    int skill_lv[SK_COUNT];
    int love;
    int sel;           // selected skill (play)
    int menu_sel;      // skill tree cursor
    bool shiny;        // groom buff
    int combo;         // successes so far in the current multi-target skill
    int stats[5];      // hearts by HQ_*
    int charmed;

    char msg[64];
    int msg_t;

    // Momo
    int mx16, my;      // position (x*16), feet y
    int mstate, mt;
    int facing;        // +1 right, -1 left
    int act;           // skill in progress
    int target;
    int home_x16;      // where to jump back to
    int jx0, jy0, jx1, jy1;
    bool ground;

    int drain_acc, regen_acc;
    int spawn_t;
    int stage_t;
    bool devdad_seen;
    bool evans_seen, shannon_seen;  // easter egg: the parents stroll by
    // Momo's housemates (balcony + Home): Maru, BieJi, Ms. Dong
    int pet_k;          // which one is out (-1 = none)
    int pet_x16, pet_dir, pet_pause, pet_timer, pet_lap, pet_greet_t;
    bool pet_greeted;
    bool pet_flee;      // Maru running away from Momo
    bool rescue_used;  // Evans & Shannon save Momo once per playthrough
    int groom_var;     // which grooming routine (lick, drumstick, wash, scratch)
    bool lvup_pending; // a level-up happened: open the skill tree when safe
    bool lvup_big;     // ...with the big celebration first (first level-up)
    bool music_off;
    bool buddha_pending; // 5 hearts at once: Momo reaches enlightenment
    int idle_anim;     // frames left of a spontaneous idle groom
    int idle_var;
    bool clear_pending;
    int flash_t;
    int hurt_t;        // Momo flashes white after being hit
    int idle_t;        // frames without input (for the sunbeam pancake)
    int music;
    int code_pos;      // progress through the secret code

    Person people[MAX_PEOPLE];
    Popup pops[MAX_POPUPS];
    uint8_t roster[24];   // npcs who can show up on this stage
    int roster_n;

    // world tour
    uint32_t visited;   // bit per destination cleared
    int loc;            // map pin Momo is at
    int map_sel;        // map cursor (pin index, NUM_DESTS = home)
    int travel_from;
    int cam_x;          // map scroll

    // difficulty of the current stage
    int goal, drain, spawn_min, spawn_max, resist_bonus, rage_bonus;
    bool retry;         // replaying a stage after a game over
    int ease;           // 0..100: tutorial easing (gentler hunger, hits, failures)

    // run statistics and leaderboard
    int lives;
    int round;          // 1 = first lap; clearing the whole map starts the next
    int endings;
    int stages_cleared;
    int total_love;
    int buddhas;
    uint32_t run_frames;
    uint32_t score;
    int rank_pos;       // where this run landed (-1 = not on the board)
    char initials[4];
    int name_pos;
    RankTable ranks;
    bool ranks_loaded;
    int ranking_hl;     // highlighted row on the ranking screen
    bool ending_reached;

    char dbg[256];
    int tally[8];      // balance telemetry, see TL_*
} G;

enum { TL_DRAIN, TL_FAIL, TL_RAGE, TL_GAIN_HP, TL_GAIN_MP, TL_TRIES, TL_SPAWNS, TL_RAGES };

// --------------------------------------------------------------------------
// Helpers
// --------------------------------------------------------------------------

static uint32_t rnd(void)
{
    uint32_t x = G.rng;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    G.rng = x;
    return x;
}

static int rndn(int n)
{
    return n > 0 ? (int)(rnd() % (uint32_t)n) : 0;
}

// Balance knobs (tuned with `momo_host deaths`).
#ifndef K_MAX
#define K_MAX 15        // destinations after which difficulty stops growing
#endif
#ifndef HOME_STEP
#define HOME_STEP 1     // Home is this many destinations harder than the last
#endif
#ifndef DRAIN_STEP
#define DRAIN_STEP 5    // hunger speed-up per destination, in 1/6 frames
#endif
#ifndef RESIST_STEP
#define RESIST_STEP 4   // resistance per destination, in halves
#endif
#ifndef RAGE_STEP
#define RAGE_STEP 6     // rage chance per destination, in half percents
#endif
#ifndef EASY_DRAIN
#define EASY_DRAIN 12   // tutorial stages: slower hunger
#endif
#ifndef EASY_RESIST
#define EASY_RESIST 20
#endif
#ifndef EASY_RAGE
#define EASY_RAGE 15
#endif
#ifndef GOAL_STEP
#define GOAL_STEP 5     // extra love needed per destination, in halves
#endif
#ifndef RETRY_EASE
#define RETRY_EASE 50   // tutorial easing (%) when retrying after a game over
#endif
#ifndef HOME_RAGE
#define HOME_RAGE 20    // Home: less rage than the ramp alone would give
#endif
#ifndef EASY_HURT
#define EASY_HURT 50    // tutorial stages: % of normal damage
#endif

static int clampi(int v, int lo, int hi)
{
    return v < lo ? lo : v > hi ? hi : v;
}

static int absi(int v)
{
    return v < 0 ? -v : v;
}

static bool title_code(const Input *in);
static void warp_to_map(void);
static void housemate_tick(void);

static void set_state(int s)
{
    G.prev_state = G.state;
    G.state = s;
    G.t = 0;
    // code_pos is kept: a level-up or cutscene popping up mid-code must not
    // swallow the secret code
}

static void say(const char *s)
{
    snprintf(G.msg, sizeof(G.msg), "%s", s);
    G.msg_t = 240;
}

static void popup_text(int x, int y, const char *s, uint16_t col)
{
    for (int i = 0; i < MAX_POPUPS; i++) {
        Popup *q = &G.pops[i];
        if (q->t > 50 && q->icon < 0 && absi(q->y - y) < 10 && absi(q->x - x) < 60)
            y = q->y - 10;
    }
    for (int i = 0; i < MAX_POPUPS; i++) {
        Popup *p = &G.pops[i];
        if (p->t > 0)
            continue;
        p->x = x;
        p->y = y;
        p->t = 70;
        p->col = col;
        p->icon = -1;
        p->vx = 0;
        snprintf(p->txt, sizeof(p->txt), "%s", s);
        return;
    }
}

static void popup_icon(int x, int y, int icon, int vx)
{
    for (int i = 0; i < MAX_POPUPS; i++) {
        Popup *p = &G.pops[i];
        if (p->t > 0)
            continue;
        p->x = x;
        p->y = y;
        p->t = 50;
        p->icon = icon;
        p->vx = vx;
        p->txt[0] = 0;
        return;
    }
}

static const uint16_t *cat_palette(void)
{
    return &cat_pal[G.cat * 16];
}

static const uint8_t *cat_frame(int f)
{
    return &cat_px[(G.cat * CF_COUNT + f) * CAT_W * CAT_H];
}

static void draw_cat(uint16_t *fb, int frame, int cx, int feet, int flags, int scale)
{
    gfx_sprite(fb, cat_frame(frame), CAT_W, CAT_H, cx - 16 * scale, feet - 32 * scale,
               cat_palette(), flags, scale);
}

static void draw_icon(uint16_t *fb, int icon, int cx, int y)
{
    const Sprite *s = &icons[icon];
    gfx_sprite(fb, s->px, s->w, s->h, cx - s->w / 2, y, ui_pal, 0, 1);
}

static int skill_cost(int sk)
{
    int lv = G.skill_lv[sk];
    int c = skills[sk].cost - (lv > 1 ? (lv - 1) / 2 : 0);
    if (G.cat == 2 && skills[sk].jump)
        c = c * 6 / 10;
    if (skills[sk].cost > 0 && c < 1)
        c = 1;
    return c;
}

static int xp_need(void)
{
    return 40 + 30 * (G.lv - 1);
}

// --------------------------------------------------------------------------
// People
// --------------------------------------------------------------------------

static const uint8_t skin_tones[][3] = {
    { 255, 226, 200 }, { 246, 206, 172 }, { 234, 190, 150 }, { 214, 166, 124 },
    { 192, 140, 100 }, { 164, 110, 74 }, { 128, 84, 56 }, { 98, 64, 44 },
};
static const uint8_t hair_cols[][3] = {
    { 30, 26, 26 }, { 64, 42, 30 }, { 110, 72, 44 }, { 220, 186, 110 }, { 150, 70, 40 }, { 40, 34, 40 },
};
static const uint8_t top_cols[][3] = {
    { 220, 70, 80 }, { 70, 120, 210 }, { 80, 170, 100 }, { 240, 196, 70 }, { 150, 90, 200 },
    { 50, 170, 170 }, { 240, 140, 60 }, { 240, 150, 190 }, { 236, 236, 236 }, { 70, 70, 80 },
};
static const uint8_t bot_cols[][3] = {
    { 60, 84, 140 }, { 44, 44, 52 }, { 190, 170, 120 }, { 120, 120, 132 }, { 90, 60, 110 },
};
static const uint8_t fur_cols[][3] = {
    { 170, 110, 60 }, { 220, 180, 110 }, { 50, 44, 40 }, { 236, 232, 224 },
};

#define C3(a) RGB((a)[0], (a)[1], (a)[2])

static uint16_t shade(const uint8_t *c, int pct)
{
    return RGB(c[0] * pct / 100, c[1] * pct / 100, c[2] * pct / 100);
}

// Each named human has a fixed look: everything is derived from a hash of
// their name, so they look the same every time (outfits follow the stage).
static uint32_t name_hash(const char *s)
{
    uint32_t h = 5381;
    while (*s)
        h = h * 33 + (uint8_t)*s++;
    return h ? h : 1;
}

static uint32_t hrnd(uint32_t *h)
{
    uint32_t x = *h;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *h = x;
    return x;
}

static bool costume_exempt(int arch)
{
    return arch == PK_DEVDAD || arch == PK_EVANS || arch == PK_SHANNON || arch == PK_ALIEN ||
           arch == PK_SHAMAN || arch == PK_MONK || arch == PK_GUARD;
}

static void person_palette(Person *p)
{
    uint16_t *pal = p->pal;
    uint32_t h = p->npc >= 0 ? name_hash(npcs[p->npc].name) : (rnd() | 1);
#define PICK(n) ((int)(hrnd(&h) % (uint32_t)(n)))
    const uint8_t *skin = skin_tones[PICK(8)];
    const uint8_t *hair = hair_cols[PICK(6)];
    const uint8_t *top = top_cols[PICK(10)];
    const uint8_t *bot = bot_cols[PICK(5)];
    int shoes = PICK(2);
    int acc = PICK(10);
    int fur = PICK(4);
    static const uint8_t gray[3] = { 196, 196, 200 };
    static const uint8_t purple[3] = { 104, 52, 176 };
    static const uint8_t navy[3] = { 44, 54, 96 };
    static const uint8_t suit[3] = { 64, 64, 74 };
    static const uint8_t hoodie[3] = { 118, 118, 130 };
    static const uint8_t black[3] = { 30, 26, 26 };
    static const uint8_t alien_skin[3] = { 130, 210, 120 };
    static const uint8_t silver[3] = { 190, 196, 210 };
    static const uint8_t saffron[3] = { 236, 140, 40 };
    static const uint8_t poncho[3] = { 170, 60, 40 };

    if (p->arch == PK_GRANNY || p->arch == PK_EXEC)
        hair = gray;
    if (p->arch == PK_ENGINEER || p->arch == PK_INTERN)
        top = purple;
    if (p->arch == PK_GUARD)
        top = navy;
    if (p->arch == PK_EXEC || p->arch == PK_COMMUTER)
        top = suit;
    if (p->arch == PK_DEVDAD) {
        top = hoodie;
        hair = black;
        skin = skin_tones[1];
        bot = bot_cols[0];
    }
    if (p->arch == PK_ALIEN) {
        skin = alien_skin;
        top = silver;
        bot = silver;
    }
    if (p->arch == PK_MONK)
        top = saffron;
    if (p->arch == PK_SHAMAN) {
        top = poncho;
        hair = black;
    }

    // local outfit for the destination
    const Costume *cos = &costumes[stages[G.stage].costume];
    p->pat = PAT_NONE;
    p->robe = p->arch == PK_MONK || p->arch == PK_SHAMAN;
    uint16_t top15 = C3(top);
    if (stages[G.stage].costume != COS_NONE && !costume_exempt(p->arch)) {
        int k = PICK(4);
        top = cos->tops[k];
        bot = cos->bottoms[PICK(2)];
        p->pat = cos->pattern;
        p->robe = cos->robe;
        const uint8_t *pc = cos->pat[PICK(2)];
        p->pat_col = (pc[0] | pc[1] | pc[2]) ? C3(pc) : shade(top, 70);
        top15 = C3(top);
    }

    pal[0] = 0;
    pal[1] = RGB(40, 28, 28);
    pal[2] = C3(skin);
    pal[3] = shade(skin, 82);
    pal[4] = C3(hair);
    pal[5] = top15;
    pal[6] = shade(top, 78);
    pal[7] = p->robe ? top15 : C3(bot);
    pal[8] = shoes ? RGB(50, 40, 40) : RGB(232, 232, 232);
    // accessories
    pal[9] = C3(top_cols[acc]);
    pal[10] = RGB(120, 84, 60);
    if (p->arch == PK_COURIER) {
        pal[9] = RGB(196, 146, 92);
        pal[10] = RGB(150, 100, 60);
    }
    if (p->arch == PK_GUARD) {
        pal[9] = C3(navy);
        pal[10] = RGB(240, 200, 60);
    }
    if (p->arch == PK_INTERN || p->arch == PK_ENGINEER || p->arch == PK_PM)
        pal[9] = C3(purple);
    if (p->arch == PK_EXEC || p->arch == PK_COMMUTER)
        pal[9] = RGB(200, 40, 50);
    if (p->arch == PK_DEVDAD)
        pal[10] = RGB(60, 60, 70);
    if (p->arch == PK_SHAMAN) {
        pal[9] = RGB(230, 60, 40);    // feathers
        pal[10] = RGB(40, 150, 220);
    }
    if (p->arch == PK_SURFER)
        pal[9] = C3(top_cols[acc]);   // surfboard
    if (p->arch == PK_ALIEN)
        pal[9] = RGB(250, 80, 80);    // antenna light
    pal[11] = RGB(28, 24, 28);
    pal[12] = RGB(255, 255, 255);
    pal[13] = RGB(250, 200, 70);
    pal[14] = C3(fur_cols[fur]);
    pal[15] = RGB(240, 110, 150);
    if (p->arch == PK_EVANS)
        memcpy(pal, evans_pal, sizeof(evans_pal));
    if (p->arch == PK_SHANNON)
        memcpy(pal, shannon_pal, sizeof(shannon_pal));
#undef PICK
}

static const char *pname(const Person *p)
{
    return p->npc >= 0 ? npcs[p->npc].name : archs[p->arch].name;
}

static int p_weak(const Person *p)
{
    return p->npc >= 0 ? npcs[p->npc].weak : archs[p->arch].weak;
}

static int p_resist(const Person *p)
{
    return p->npc >= 0 ? npcs[p->npc].resist : archs[p->arch].resist;
}

static int p_likes(const Person *p)
{
    return p->npc >= 0 ? npcs[p->npc].likes : archs[p->arch].likes;
}

static Person *spawn_person(int arch, int npc)
{
    for (int i = 0; i < MAX_PEOPLE; i++) {
        Person *p = &G.people[i];
        if (p->active)
            continue;
        memset(p, 0, sizeof(*p));
        p->active = true;
        p->arch = arch;
        p->npc = npc;
        p->dir = rndn(2) ? 1 : -1;
        p->x16 = (p->dir > 0 ? -20 : SCREEN_W + 20) * 16;
        p->y = LANE_Y0 + rndn(LANE_Y1 - LANE_Y0 + 1);
        p->speed = archs[arch].speed + rndn(4);
        p->state = P_WALK;
        p->dog = arch == PK_DOGWALKER;
        person_palette(p);
        // chance (percent) to show up furious: red flames burn HP, black
        // flames burn HP and MP. Later stages get angrier.
        static const uint8_t red_pct[PK_COUNT] = {
            [PK_COURIER] = 55, [PK_COMMUTER] = 30, [PK_JOGGER] = 20, [PK_DOGWALKER] = 10,
            [PK_STUDENT] = 5, [PK_PM] = 10, [PK_ENGINEER] = 8,
        };
        static const uint8_t black_pct[PK_COUNT] = {
            [PK_GUARD] = 40, [PK_EXEC] = 35, [PK_COMMUTER] = 10, [PK_DOGWALKER] = 5,
        };
        int red = red_pct[arch], black = black_pct[arch];
        if (archs[arch].hostile)
            red = clampi(red + G.rage_bonus, 0, 100);
        int r = rndn(100);
        if (r < black)
            p->rage = RAGE_BLACK;
        else if (r < black + red)
            p->rage = RAGE_RED;
        G.tally[TL_SPAWNS]++;
        if (p->rage) {
            G.tally[TL_RAGES]++;
            p->speed += 8;
            p->done = true;
            char buf[64];
            snprintf(buf, sizeof(buf), p->rage == RAGE_RED ? "%s is furious! Hold B to hide!"
                                                            : "%s has a dark aura!! Hold B to hide!", pname(p));
            say(buf);
            plat_sfx(SFX_WOOF);
        }
        return p;
    }
    return NULL;
}

static Person *spawn(int arch)
{
    return spawn_person(arch, -1);
}

static void build_roster(void)
{
    G.roster_n = 0;
    bool dest = G.stage >= STG_DEST0 && G.stage < STG_HOME;
    for (int i = 0; i < npc_count && G.roster_n < (int)sizeof(G.roster); i++)
        if (npcs[i].home == G.stage || (dest && npcs[i].home == NPC_TRAVELER))
            G.roster[G.roster_n++] = (uint8_t)i;
}

static int count_people(void)
{
    int n = 0;
    for (int i = 0; i < MAX_PEOPLE; i++)
        n += G.people[i].active;
    return n;
}

static void spawn_tick(void)
{
    const StageDef *sd = &stages[G.stage];
    if (--G.spawn_t > 0)
        return;
    (void)sd;
    G.spawn_t = G.spawn_min + rndn(G.spawn_max - G.spawn_min);
    if (count_people() >= 5)
        return;

    // Easter egg: Dad Evans or Mom Shannon very rarely stroll past. Only a
    // jump-down skill gets their attention.
    if (G.stage_t > 10 * 60 && rndn(100) < 2) {
        bool e = !G.evans_seen && (G.shannon_seen || rndn(2));
        if (e || !G.shannon_seen) {
            if (e)
                G.evans_seen = true;
            else
                G.shannon_seen = true;
            Person *p = spawn(e ? PK_EVANS : PK_SHANNON);
            if (p) {
                p->rage = RAGE_NONE;
                p->done = false;
                say(e ? "Is that... Dad Evans?! Jump down to say hi!" : "Mom Shannon is walking by! Jump down!");
            }
            return;
        }
    }

    // Uncle Dev, the secret back-massage guy: shows up once per stage when
    // Momo is struggling, or occasionally late in the stage.
    if (!G.devdad_seen && G.stage_t > 40 * 60 &&
        (G.hp * 100 / G.maxhp < 40 || (G.stage_t > 75 * 60 && rndn(4) == 0))) {
        G.devdad_seen = true;
        spawn(PK_DEVDAD);
        return;
    }

    // pick someone from the local cast who isn't already on screen
    for (int tries = 0; tries < 8 && G.roster_n > 0; tries++) {
        int npc = G.roster[rndn(G.roster_n)];
        bool here = false;
        for (int i = 0; i < MAX_PEOPLE; i++)
            if (G.people[i].active && G.people[i].npc == npc)
                here = true;
        if (!here) {
            spawn_person(npcs[npc].arch, npc);
            return;
        }
    }
}

static int px(const Person *p)
{
    return p->x16 >> 4;
}

static int momo_x(void)
{
    return G.mx16 >> 4;
}

// nearest person Momo can interact with
static int find_target(int range)
{
    int best = -1, bd = 9999;
    for (int i = 0; i < MAX_PEOPLE; i++) {
        Person *p = &G.people[i];
        if (!p->active || p->done || p->state != P_WALK)
            continue;
        int d = absi(px(p) - momo_x());
        if (d < range && d < bd) {
            bd = d;
            best = i;
        }
    }
    return best;
}

static int skill_range(int sk)
{
    if (sk == SK_PURR)
        return 84;
    return skills[sk].jump ? 56 : skills[sk].area ? 60 : 40;
}

static int success_chance(const Person *p, int sk)
{
    int weak = p_weak(p);
    if (p->arch == PK_EVANS || p->arch == PK_SHANNON)
        return skills[sk].jump ? 100 : 0;
    if (weak == SK_ANY)
        return 100;
    int lv = G.skill_lv[sk];
    int c = skills[sk].power + 8 * (lv - 1) - (p_resist(p) + G.resist_bonus) * 6 / 10;
    if (weak == sk)
        c += 35;
    if (G.shiny)
        c += 12 + 3 * G.skill_lv[SK_GROOM];
    if (G.cat == 2 && skills[sk].jump)
        c += 5;
    // multi-target skills are a gamble, focused ones are reliable
    if (skills[sk].area)
        c = c * 4 / 5;
    else
        c += 10;
    return clampi(c, 5, 97);
}

static void gain_xp(int amount)
{
    G.xp += amount;
    while (G.xp >= xp_need()) {
        G.xp -= xp_need();
        G.lv++;
        G.points += 2;
        G.lvup_pending = true;
        if (G.lv == 2) {
            // the first level-up is a big deal: extra points and Cat Eye +1
            G.points += 3;
            if (G.skill_lv[SK_EYE] < skills[SK_EYE].max_lv)
                G.skill_lv[SK_EYE]++;
            G.lvup_big = true;
        }
        G.maxhp += 10;
        G.maxmp += 5;
        G.hp = clampi(G.hp + G.maxhp / 4, 0, G.maxhp);
        G.mp = clampi(G.mp + G.maxmp / 4, 0, G.maxmp);
        popup_text(momo_x() - 36, G.my - 50, "LEVEL UP!", COL_YELLOW);
        say("Level up! Spend your new skill points.");
        plat_sfx(SFX_LEVELUP);
    }
}

static bool resolve(Person *p, int sk)
{
    const ArchDef *a = &archs[p->arch];
    int chance = success_chance(p, sk);
    int r = rndn(100);
    char buf[24];

    p->icon_t = 120;
    p->say_t = 110;
    int dir_to_momo = momo_x() < px(p) ? -1 : 1;

    if (p->arch == PK_EVANS || p->arch == PK_SHANNON) {
        p->dir = dir_to_momo;
        if (!skills[sk].jump) {
            // a wave from the fence isn't enough - they wave back and walk on
            p->say = a->fail;
            p->result = HQ_NONE;
            p->state = P_LEAVE;
            p->done = true;
            snprintf(G.msg, sizeof(G.msg), "%s waves. Jump down to get their attention!", pname(p));
            G.msg_t = 200;
            return false;
        }
        p->state = P_REACT;
        p->timer = 150;
        p->done = true;
        p->result = HQ_FULL;
        G.love += 4;
        G.total_love += 4;
        G.stats[HQ_FULL]++;
        G.charmed++;
        for (int k = 0; k < 5; k++)
            popup_icon(px(p) - 10 + rndn(20), p->y - 52, IC_HEART_FULL, rndn(3) - 1);
        plat_sfx(SFX_HEART);
        if (p->arch == PK_EVANS) {
            p->say = "Massage time!";
            G.hp = G.maxhp;
            G.mp = G.maxmp;
            popup_text(momo_x() - 40, G.my - 44, "FULL HP/MP!", COL_YELLOW);
            say("Dad Evans gives Momo a big back massage! HP/MP full!");
        } else {
            p->say = "You're doing great!";
            gain_xp(xp_need() - G.xp);
            popup_text(momo_x() - 36, G.my - 56, "LEVEL UP!", COL_YELLOW);
            say("Mom Shannon has a little chat with Momo... LEVEL UP!");
        }
        return true;
    }

    if (r >= chance) {
        // failure: "!" over their head, they hurry off, Momo loses HP
        int dmg = 3 + 4 * a->hostile;
        if (skills[sk].area)
            dmg = (dmg + 1) / 2;   // a shrug from a crowd stings less
        dmg = (dmg * (100 - (100 - EASY_HURT) * G.ease / 100) + 99) / 100;
        p->result = HQ_FAIL;
        p->say = a->fail;
        p->state = P_FLEE;
        p->dir = -dir_to_momo;
        p->speed = a->speed * 2 + 10;
        p->done = true;
        G.hp -= dmg;
        G.tally[TL_FAIL] += dmg;
        G.stats[HQ_FAIL]++;
        snprintf(buf, sizeof(buf), "-%d HP", dmg);
        popup_text(momo_x() - 20, G.my - 44, buf, COL_RED);
        plat_sfx(p->dog ? SFX_WOOF : SFX_FAIL);
        if (G.mstate == M_ACT || G.mstate == M_IDLE) {
            G.mstate = M_SHOCK;
            G.mt = 0;
        }
        snprintf(G.msg, sizeof(G.msg), "%s wasn't impressed by %s.", pname(p), skills[sk].name);
        G.msg_t = 200;
        return false;
    }

    int q;
    bool weak = p_weak(p) == sk || p_weak(p) == SK_ANY;
    if (r < chance * (weak ? 70 : 40) / 100)
        q = HQ_FULL;
    else if (r < chance * 80 / 100)
        q = HQ_HALF;
    else
        q = HQ_EMPTY;
    int mult = q == HQ_FULL ? 100 : q == HQ_HALF ? 60 : 25;
    mult = skills[sk].area ? mult * 6 / 10 : mult * 12 / 10;

    p->result = q;
    p->say = a->ok;
    p->state = P_REACT;
    p->timer = 120;
    p->dir = dir_to_momo;
    p->done = true;
    G.stats[q]++;
    G.charmed++;
    G.love += q == HQ_FULL ? 3 : q == HQ_HALF ? 2 : 1;
    G.total_love += q == HQ_FULL ? 3 : q == HQ_HALF ? 2 : 1;

    int re = p_likes(p);
    if (sk == SK_FOODPAW && re != RE_MASSAGE)
        re = RE_FEED;
    int hp = 0, mp = 0, xp = q == HQ_FULL ? 24 : q == HQ_HALF ? 14 : 6;
    switch (re) {
        case RE_FEED:
            hp = 35 * mult / 100;
            if (G.cat == 0)
                hp = hp * 13 / 10;
            break;
        case RE_PET:
            mp = 25 * mult / 100;
            if (G.cat == 1)
                mp = mp * 14 / 10;
            break;
        case RE_BRUSH:
            mp = 28 * mult / 100;
            hp = 6;
            if (G.cat == 1)
                mp = mp * 14 / 10;
            break;
        case RE_PHOTO:
            mp = 18 * mult / 100;
            xp *= 2;
            G.love += 1;
            G.flash_t = 4;
            plat_sfx(SFX_CLICK);
            break;
        case RE_MASSAGE:
            hp = G.maxhp;
            mp = G.maxmp;
            G.love += 4;
            p->result = HQ_FULL;
            break;
    }
    if (hp < 1 && (re == RE_FEED))
        hp = 1;
    if (mp < 1 && (re == RE_PET || re == RE_BRUSH || re == RE_PHOTO))
        mp = 1;
    G.tally[TL_GAIN_HP] += clampi(hp, 0, G.maxhp - G.hp);
    G.tally[TL_GAIN_MP] += clampi(mp, 0, G.maxmp - G.mp);
    G.hp = clampi(G.hp + hp, 0, G.maxhp);
    G.mp = clampi(G.mp + mp, 0, G.maxmp);

    int y = G.my - 44 - 20 * G.combo;
    if (re == RE_MASSAGE) {
        popup_text(momo_x() - 40, y, "FULL HP/MP!", COL_YELLOW);
        snprintf(G.msg, sizeof(G.msg), "Uncle Dev gives Momo a back massage! Pat pat pat...");
        G.msg_t = 240;
    } else {
        if (hp) {
            snprintf(buf, sizeof(buf), "+%d HP", hp);
            popup_text(momo_x() - 24 - 28 * G.combo, y, buf, COL_GREEN);
            y -= 10;
        }
        if (mp) {
            snprintf(buf, sizeof(buf), "+%d MP", mp);
            popup_text(momo_x() - 24 - 28 * G.combo, y, buf, COL_BLUE);
        }
        static const char *verbs[] = { "feeds", "pets", "brushes", "photographs" };
        snprintf(G.msg, sizeof(G.msg), "%s %s %s!", pname(p), verbs[re], cats[G.cat].name);
        G.msg_t = 200;
    }
    for (int k = 0; k < (q == HQ_FULL ? 4 : 2); k++)
        popup_icon(px(p) - 8 + rndn(16), p->y - 50, IC_HEART_FULL, rndn(3) - 1);
    plat_sfx(SFX_HEART);
    gain_xp(xp);
    return true;
}

static void people_tick(void)
{
    for (int i = 0; i < MAX_PEOPLE; i++) {
        Person *p = &G.people[i];
        if (!p->active)
            continue;
        if (p->icon_t > 0)
            p->icon_t--;
        if (p->say_t > 0)
            p->say_t--;
        switch (p->state) {
            case P_WALK:
            case P_FLEE:
            case P_LEAVE: {
                int sp = p->speed;
                // humans slow down a little when they notice the cat
                if (p->state == P_WALK && absi(px(p) - momo_x()) < 48)
                    sp = sp * 2 / 3;
                p->x16 += p->dir * sp;
                p->dist += sp;
                if (p->rage && !p->hit && absi(px(p) - momo_x()) < 22) {
                    if (G.mstate == M_HIDE) {
                        p->hit = true;
                        popup_text(momo_x() - 20, G.my - 30, "Phew!", COL_WHITE);
                    } else {
                        int dmg = p->rage == RAGE_BLACK ? 24 : 14;
                        dmg = dmg * (100 - (100 - EASY_HURT) * G.ease / 100) / 100;
                        if (!G.rescue_used)
                            dmg = G.hp;   // first time: knocked out, cue the rescue
                        char buf[20];
                        p->hit = true;
                        G.hp -= dmg;
                        G.tally[TL_RAGE] += dmg;
                        snprintf(buf, sizeof(buf), "-%d HP", dmg);
                        popup_text(momo_x() - 20, G.my - 44, buf, COL_RED);
                        if (p->rage == RAGE_BLACK) {
                            G.mp = clampi(G.mp - 15, 0, G.maxmp);
                            popup_text(momo_x() - 20, G.my - 54, "-15 MP", COL_PURPLE);
                        }
                        G.hurt_t = 30;
                        p->result = HQ_FAIL;
                        p->icon_t = 60;
                        p->say = p->rage == RAGE_BLACK ? "..." : "OUTTA MY WAY!";
                        p->say_t = 60;
                        plat_sfx(SFX_FAIL);
                        if (G.mstate == M_IDLE || G.mstate == M_WALK || G.mstate == M_ACT) {
                            G.mstate = M_SHOCK;
                            G.mt = 0;
                        }
                        say("Ouch! Hold B to hide from flaming humans.");
                    }
                }
                if (px(p) < -40 || px(p) > SCREEN_W + 40)
                    p->active = false;
                break;
            }
            case P_HOLD:
                break;
            case P_REACT:
                if (--p->timer <= 0) {
                    p->state = P_LEAVE;
                    p->dir = rndn(2) ? 1 : -1;
                }
                break;
        }
    }
}

// --------------------------------------------------------------------------
// Momo
// --------------------------------------------------------------------------

static void start_skill(int sk)
{
    const SkillDef *s = &skills[sk];
    if (G.skill_lv[sk] <= 0) {
        say("That skill is locked. Press X to learn it.");
        plat_sfx(SFX_BACK);
        return;
    }
    int cost = skill_cost(sk);
    if (G.mp < cost) {
        say("Not enough MP! Try Groom or a cheap Meow.");
        plat_sfx(SFX_BACK);
        return;
    }
    int target = -1;
    if (!s->self) {
        target = find_target(skill_range(sk));
        if (target < 0) {
            say("Nobody in range. Walk closer with Left/Right.");
            plat_sfx(SFX_BACK);
            return;
        }
    }
    G.mp -= cost;
    G.tally[TL_TRIES]++;
    G.act = sk;
    if (sk == SK_GROOM)
        G.groom_var = rndn(4);
    G.target = target;
    G.mt = 0;
    plat_sfx(s->sfx);

    if (target >= 0) {
        Person *p = &G.people[target];
        p->state = P_HOLD;
        p->dir = momo_x() < px(p) ? -1 : 1;
        G.facing = px(p) < momo_x() ? -1 : 1;
    }
    if (s->area) {
        for (int i = 0; i < MAX_PEOPLE; i++) {
            Person *p = &G.people[i];
            if (p->active && !p->done && !p->rage && p->state == P_WALK &&
                absi(px(p) - momo_x()) < skill_range(sk)) {
                p->state = P_HOLD;
                p->dir = momo_x() < px(p) ? -1 : 1;
            }
        }
    }
    if (s->jump) {
        Person *p = &G.people[target];
        G.home_x16 = G.mx16;
        G.jx0 = momo_x();
        G.jy0 = G.my;
        G.jx1 = px(p) + (momo_x() < px(p) ? -18 : 18);
        G.jy1 = p->y + 1;
        G.mstate = M_JUMP_DOWN;
    } else {
        G.mstate = M_ACT;
    }
}

static void finish_skill_on_fence(void)
{
    const SkillDef *s = &skills[G.act];
    if (G.act == SK_GROOM) {
        int mp = 4 + 2 * G.skill_lv[SK_GROOM];
        G.mp = clampi(G.mp + mp, 0, G.maxmp);
        G.shiny = true;
        char buf[16];
        snprintf(buf, sizeof(buf), "+%d MP", mp);
        popup_text(momo_x() - 20, G.my - 44, buf, COL_BLUE);
        say("Fur is shiny! Your next skill is more likely to work.");
        return;
    }
    bool used = false;
    G.combo = 0;
    if (s->area) {
        int hits = 0;
        for (int i = 0; i < MAX_PEOPLE; i++) {
            Person *p = &G.people[i];
            if (p->active && p->state == P_HOLD) {
                if (resolve(p, G.act)) {
                    hits++;
                    G.combo++;
                }
                used = true;
            }
        }
        if (hits >= 2) {
            // several fans at once: bonus love and a little extra of both bars
            char buf[24];
            snprintf(buf, sizeof(buf), "COMBO x%d!", hits);
            popup_text(momo_x() - 36, G.my - 64, buf, COL_YELLOW);
            G.love += hits - 1;
            G.hp = clampi(G.hp + 3 * hits, 0, G.maxhp);
            G.mp = clampi(G.mp + 2 * hits, 0, G.maxmp);
            snprintf(G.msg, sizeof(G.msg), "%d humans charmed at once! Combo bonus!", hits);
            G.msg_t = 200;
            if (hits >= 5)
                G.buddha_pending = true;
        }
    } else if (G.target >= 0 && G.people[G.target].active && G.people[G.target].state == P_HOLD) {
        resolve(&G.people[G.target], G.act);
        used = true;
    }
    G.combo = 0;
    if (used)
        G.shiny = false;
}

static void momo_tick(const Input *in)
{
    const StageDef *sd = &stages[G.stage];
    G.mt++;
    switch (G.mstate) {
        case M_HIDE:
            if (!(in->held & IN_B)) {
                G.mstate = M_IDLE;
                G.mt = 0;
            }
            break;
        case M_IDLE:
        case M_WALK: {
            if (in->held & IN_B) {
                G.mstate = M_HIDE;
                G.mt = 0;
                plat_sfx(SFX_BACK);
                break;
            }
            int dx = 0;
            if (in->held & IN_LEFT)
                dx = -1;
            if (in->held & IN_RIGHT)
                dx = 1;
            if (dx) {
                if (G.mstate != M_WALK)
                    G.mt = 0;
                G.mstate = M_WALK;
                G.facing = dx;
                G.mx16 = clampi(G.mx16 + dx * 20, sd->fence_x0 * 16, sd->fence_x1 * 16);
            } else if (G.mstate == M_WALK) {
                G.mstate = M_IDLE;
                G.mt = 0;
            }
            // now and then Momo grooms on her own
            if (dx || G.mstate != M_IDLE)
                G.idle_anim = 0;
            else if (G.idle_anim > 0)
                G.idle_anim--;
            else if (G.idle_t > 30 && G.idle_t < 300 && rndn(700) == 0) {
                G.idle_anim = 100;
                G.idle_var = rndn(4);
            }
            break;
        }
        case M_ACT: {
            const SkillDef *s = &skills[G.act];
            if (G.mt == s->impact)
                finish_skill_on_fence();
            if (G.mt >= s->dur) {
                G.mstate = M_IDLE;
                G.mt = 0;
            }
            break;
        }
        case M_JUMP_DOWN: {
            int t = G.mt, T = 24;
            G.mx16 = (G.jx0 + (G.jx1 - G.jx0) * t / T) * 16;
            G.my = G.jy0 + (G.jy1 - G.jy0) * t / T - (t * (T - t)) / 8;
            G.ground = t > T / 2;
            if (t >= T) {
                G.my = G.jy1;
                G.mstate = M_GROUND;
                G.mt = 0;
                G.ground = true;
            }
            break;
        }
        case M_GROUND:
            if (G.mt == 36) {
                Person *p = &G.people[G.target];
                if (p->active && p->state == P_HOLD) {
                    resolve(p, G.act);
                    G.shiny = false;
                }
            }
            if (G.mt >= 100 || (G.mt > 40 && G.mstate == M_GROUND &&
                                (!G.people[G.target].active || G.people[G.target].state != P_REACT))) {
                G.mstate = M_JUMP_UP;
                G.mt = 0;
                G.jx0 = momo_x();
                G.jy0 = G.my;
                G.jx1 = G.home_x16 >> 4;
                G.jy1 = sd->fence_y;
                G.facing = G.jx1 < G.jx0 ? -1 : 1;
                plat_sfx(SFX_JUMP);
            }
            break;
        case M_JUMP_UP: {
            int t = G.mt, T = 24;
            G.mx16 = (G.jx0 + (G.jx1 - G.jx0) * t / T) * 16;
            G.my = G.jy0 + (G.jy1 - G.jy0) * t / T - (t * (T - t)) / 6;
            G.ground = t < T / 2;
            if (t >= T) {
                G.my = sd->fence_y;
                G.mstate = M_IDLE;
                G.mt = 0;
                G.ground = false;
            }
            break;
        }
        case M_SHOCK:
            if (G.mt > 36 || ((in->held & IN_B) && G.mt > 8)) {
                G.mstate = M_IDLE;
                G.mt = 0;
            }
            break;
    }
}

// grooming routines: 0 paw lick + leg-up, 1 back-view drumstick,
// 2 face wash, 3 hind-leg ear scratch
static int groom_frame(int var, int t)
{
    switch (var) {
        case 0: return t >= 44 ? CF_CELLO : (t / 10) % 2 ? CF_GROOM1 : CF_GROOM0;
        case 1: return (t / 8) % 2 ? CF_DRUM1 : CF_DRUM0;
        case 2: return (t / 10) % 2 ? CF_WASH1 : CF_WASH0;
        default: return (t / 4) % 2 ? CF_SCRATCH1 : CF_SCRATCH0;
    }
}

static int momo_frame(int *flags)
{
    *flags = G.facing < 0 ? SPR_FLIP : 0;
    int t = G.mt;
    switch (G.mstate) {
        case M_IDLE: {
            int k = (G.frame / 20) % 12;
            if (G.pet_greet_t > 0)
                return G.pet_greet_t > 60 ? CF_MEOW : CF_HAPPY;   // hello, housemate!
            if (G.idle_anim > 0)
                return groom_frame(G.idle_var, 100 - G.idle_anim);
            if (G.idle_t > 360 && G.hp * 100 / G.maxhp >= 25)
                return CF_FLAT;  // melted into a sunbeam
            if ((G.frame % 240) < 8)
                return CF_BLINK;
            if ((G.frame % 900) >= 600 && (G.frame % 900) < 640)
                return CF_YAWN;
            if (G.hp * 100 / G.maxhp < 25)
                return (G.frame / 30) % 2 ? CF_SHOCK : CF_SIT0;
            if (G.shiny && (G.frame / 16) % 4 == 0)
                return CF_HAPPY;
            return k < 6 ? CF_SIT0 : k < 9 ? CF_SIT1 : CF_SIT2;
        }
        case M_WALK:
            return CF_WALK0 + (t / 6) % 4;
        case M_ACT:
            switch (G.act) {
                case SK_MEOW: return t < 30 ? CF_MEOW : CF_HAPPY;
                case SK_BLINK: return t < 14 ? CF_SLOW : t < 34 ? CF_BLINK : CF_SLOW;
                case SK_GROOM: return groom_frame(G.groom_var, t);
                case SK_YOGA: *flags = G.facing < 0 ? SPR_FLIP : 0; return CF_YOGA;
                case SK_PURR: return CF_PURR;
                default: return skills[G.act].frame;
            }
        case M_JUMP_DOWN:
        case M_JUMP_UP:
            return CF_JUMP;
        case M_GROUND:
            if (G.act == SK_BELLY)
                return (t / 12) % 2 ? CF_BELLY1 : CF_BELLY0;
            return t < 40 ? ((t / 8) % 2 ? CF_BUMP : CF_WALK1) : CF_BLISS;
        case M_SHOCK:
            return CF_SHOCK;
        case M_HIDE:
            return CF_SIT0;
    }
    return CF_SIT0;
}

// --------------------------------------------------------------------------
// Stage flow
// --------------------------------------------------------------------------

static void new_game(int cat)
{
    G.cat = cat;
    G.stage = 0;
    G.maxhp = cats[cat].hp;
    G.maxmp = cats[cat].mp;
    G.lv = 1;
    G.xp = 0;
    G.points = 0;
    memset(G.skill_lv, 0, sizeof(G.skill_lv));
    G.skill_lv[SK_MEOW] = 1;
    G.skill_lv[SK_BLINK] = 1;
    G.skill_lv[SK_GROOM] = 1;
    G.skill_lv[SK_BUMP] = 1;
    G.skill_lv[SK_EYE] = 1;
    G.rescue_used = false;
    G.lvup_pending = false;
    G.lvup_big = false;
    G.buddha_pending = false;
    G.sel = SK_MEOW;
    G.lives = 3;
    G.retry = false;
    G.round = 1;
    G.endings = 0;
    G.stages_cleared = 0;
    G.total_love = 0;
    G.buddhas = 0;
    G.run_frames = 0;
    G.score = 0;
    G.visited = 0;
    G.loc = 0;
    G.map_sel = 0;
    G.rank_pos = -1;
}

static int count_visited(void)
{
    int n = 0;
    for (int i = 0; i < NUM_DESTS; i++)
        n += (G.visited >> i) & 1;
    return n;
}

// Difficulty: the first two stages are a gentle tutorial; every destination
// cleared makes the next one hungrier, pickier and angrier.
static void set_difficulty(void)
{
    const StageDef *sd = &stages[G.stage];
    int k = G.stage >= STG_DEST0 ? count_visited() : 0;
    if (G.stage == STG_HOME)
        k = count_visited() + HOME_STEP;
    if (k > K_MAX)
        k = K_MAX;
    k += (G.round - 1) * 6;   // every new lap of the world is tougher
    if (k > K_MAX + 6)
        k = K_MAX + 6;
    // tutorial easing: full on the first two stages, fading out over the
    // first two destinations
    int v = count_visited();
    G.ease = G.round > 1 || G.stage == STG_HOME ? 0 : G.stage < STG_DEST0 ? 100 : v == 0 ? 60 : v == 1 ? 30 : 0;
    if (G.retry && G.ease < RETRY_EASE)
        G.ease = RETRY_EASE;   // just lost a life here: go a bit easier
    G.goal = sd->goal + GOAL_STEP * k / 2;
    G.drain = sd->drain - k * DRAIN_STEP / 6 + EASY_DRAIN * G.ease / 100;
    if (G.drain < 15)
        G.drain = 15;
    G.spawn_min = sd->spawn_min - 2 * k;
    G.spawn_max = sd->spawn_max - 4 * k;
    if (G.spawn_min < 50)
        G.spawn_min = 50;
    if (G.spawn_max < G.spawn_min + 40)
        G.spawn_max = G.spawn_min + 40;
    G.resist_bonus = RESIST_STEP * k / 2 - EASY_RESIST * G.ease / 100;
    G.rage_bonus = RAGE_STEP * k / 2 - EASY_RAGE * G.ease / 100;
    if (G.stage == STG_HOME)
        G.rage_bonus -= HOME_RAGE;   // half the street is grumpy: keep it fair
}

static void start_stage(void)
{
    const StageDef *sd = &stages[G.stage];
    G.hp = G.maxhp;
    G.mp = G.maxmp;
    G.love = 0;
    G.shiny = false;
    G.charmed = 0;
    memset(G.stats, 0, sizeof(G.stats));
    memset(G.people, 0, sizeof(G.people));
    memset(G.pops, 0, sizeof(G.pops));
    G.mx16 = ((sd->fence_x0 + sd->fence_x1) / 2) * 16;
    G.my = sd->fence_y;
    G.mstate = M_IDLE;
    G.mt = 0;
    G.facing = 1;
    G.ground = false;
    G.drain_acc = 0;
    G.regen_acc = 0;
    G.spawn_t = 40;
    G.stage_t = 0;
    G.devdad_seen = false;
    G.evans_seen = false;
    G.pet_k = -1;
    G.pet_timer = 900;      // first stroll after ~15 s
    G.pet_lap = 0;
    G.pet_greet_t = 0;
    G.shannon_seen = false;
    G.clear_pending = false;
    G.flash_t = 0;
    G.hurt_t = 0;
    G.idle_t = 0;
    set_difficulty();
    build_roster();
    if (G.stage == STG_BALCONY)
        say("Humans incoming! Up/Down: pick skill, A: use it.");
    else if (G.stage == STG_YAHOO)
        say("Welcome to Yahoo! HQ. Watch out for Security.");
    else if (G.stage == STG_HOME)
        say("The final evening at home. Good luck, Momo!");
    else {
        char buf[64];
        snprintf(buf, sizeof(buf), "Welcome to %s! Charm the locals.", sd->place);
        say(buf);
    }
}

static void stage_cleared(void)
{
    G.stages_cleared++;
    G.retry = false;
    if (G.stage >= STG_DEST0 && G.stage < STG_HOME) {
        G.visited |= 1u << (G.stage - STG_DEST0);
        G.loc = G.stage - STG_DEST0;
    }
}

static void open_map(void)
{
    if (G.stage == STG_YAHOO) {
        G.loc = 0;   // the time machine parks in the Bay Area
        G.map_sel = 0;
        say("The time machine can go anywhere now! Pick a destination.");
    }
    // start the cursor on the next unvisited place
    for (int i = 0; i < NUM_DESTS; i++)
        if (!((G.visited >> i) & 1)) {
            G.map_sel = i;
            break;
        }
    if (count_visited() >= HOME_UNLOCK)
        G.map_sel = G.visited == (1u << NUM_DESTS) - 1 ? NUM_DESTS : G.map_sel;
    set_state(ST_MAP);
}

static bool home_open(void)
{
    return count_visited() >= HOME_UNLOCK;
}

static void map_tick(const Input *in)
{
    int n = NUM_DESTS + 1;
    int sel = G.map_sel;
    if (in->down & (IN_RIGHT | IN_DOWN | IN_R))
        sel = (sel + 1) % n;
    if (in->down & (IN_LEFT | IN_UP | IN_L))
        sel = (sel + n - 1) % n;
    if (sel == NUM_DESTS && !home_open())
        sel = (in->down & (IN_RIGHT | IN_DOWN | IN_R)) ? 0 : NUM_DESTS - 1;
    bool go = (in->down & IN_A) != 0;
    if (in->touch && in->ty >= 34 && in->ty < 34 + 10 * 13) {
        int row = (in->ty - 34) / 13, col = in->tx >= 128 ? 1 : 0;
        int k = col * 10 + row;
        if (k < n && (k < NUM_DESTS || home_open())) {
            if (k == sel)
                go = true;
            sel = k;
        }
    }
    if (sel != G.map_sel)
        plat_sfx(SFX_SELECT);
    G.map_sel = sel;
    if (go && G.t > 15) {
        plat_sfx(SFX_JUMP);
        G.travel_from = G.loc;
        set_state(ST_TRAVEL);
    }
    // scroll the 512-wide map to keep the cursor in view
    int target = clampi(map_pins[G.map_sel * 2] - 128, 0, bg_images[BG_MAP].w - SCREEN_W);
    G.cam_x += (target - G.cam_x) / 3 + (target > G.cam_x) - (target < G.cam_x);
}

static void finish_run(bool ending)
{
    G.score = (uint32_t)G.total_love * 10 + (uint32_t)G.stages_cleared * 300 + (uint32_t)G.lv * 50 +
              (uint32_t)G.buddhas * 500 + (uint32_t)G.endings * 2000u + (uint32_t)(G.round - 1) * 1000u;
    (void)ending;
    G.rank_pos = scores_rank(&G.ranks, G.score);
    G.ending_reached = G.endings > 0;
    set_state(ST_RESULTS);
    plat_sfx(SFX_CLEAR);
}

static void name_tick(const Input *in)
{
    char *c = &G.initials[G.name_pos];
    if (in->down & IN_UP)
        *c = *c == 'Z' ? 'A' : *c + 1;
    if (in->down & IN_DOWN)
        *c = *c == 'A' ? 'Z' : *c - 1;
    if (in->down & (IN_UP | IN_DOWN))
        plat_sfx(SFX_SELECT);
    if ((in->down & IN_LEFT) && G.name_pos > 0)
        G.name_pos--;
    if ((in->down & (IN_RIGHT | IN_A)) && G.name_pos < 2) {
        G.name_pos++;
        plat_sfx(SFX_CONFIRM);
    } else if ((in->down & (IN_A | IN_START)) && G.name_pos == 2 && G.t > 10) {
        RankEntry e;
        memset(&e, 0, sizeof(e));
        memcpy(e.name, G.initials, 4);
        e.cat = (uint8_t)G.cat;
        e.stages = (uint8_t)G.stages_cleared;
        e.level = (uint8_t)G.lv;
        e.ending = G.ending_reached;
        e.score = G.score;
        e.frames = G.run_frames;
        G.ranking_hl = scores_insert(&G.ranks, &e);
        scores_save(&G.ranks);
        plat_sfx(SFX_SKILLUP);
        set_state(ST_RANKING);
    }
}

static void play_tick(const Input *in)
{
    
    G.stage_t++;

    if (in->down & IN_START) {
        set_state(ST_PAUSE);
        plat_sfx(SFX_SELECT);
        return;
    }
    if (G.buddha_pending && (G.mstate == M_IDLE || G.mstate == M_WALK)) {
        G.buddha_pending = false;
        set_state(ST_BUDDHA);
        plat_sfx(SFX_CLEAR);
        return;
    }
    if (G.lvup_pending && (G.mstate == M_IDLE || G.mstate == M_WALK)) {
        G.lvup_pending = false;
        if (G.lvup_big) {
            G.lvup_big = false;
            set_state(ST_LEVELUP);
            // (the fanfare already played in gain_xp)
        } else if (G.points > 0) {
            G.menu_sel = G.sel;
            set_state(ST_SKILLS);
        }
        return;
    }
    if (in->down & IN_X) {
        G.menu_sel = G.sel;
        set_state(ST_SKILLS);
        plat_sfx(SFX_SELECT);
        return;
    }

    // skill selection: 2 columns x 5 rows on the bottom screen
    if (in->down & IN_UP)
        G.sel = (G.sel + SK_ACTIVE - 1) % SK_ACTIVE;
    if (in->down & IN_DOWN)
        G.sel = (G.sel + 1) % SK_ACTIVE;
    if (in->down & (IN_L | IN_Y))
        G.sel = (G.sel + SK_ACTIVE - 5) % SK_ACTIVE;
    if (in->down & IN_R)
        G.sel = (G.sel + 5) % SK_ACTIVE;
    if (in->down & (IN_UP | IN_DOWN | IN_L | IN_R | IN_Y))
        plat_sfx(SFX_SELECT);

    bool use = (in->down & IN_A) != 0;
    if (in->touch) {
        if (in->ty >= 44 && in->ty < 124) {
            int row = (in->ty - 44) / 16;
            int col = in->tx >= 128 ? 1 : 0;
            int sk = col * 5 + row;
            if (sk < SK_ACTIVE) {
                if (sk == G.sel)
                    use = true;
                else {
                    G.sel = sk;
                    plat_sfx(SFX_SELECT);
                }
            }
        } else if (in->ty >= 172 && in->tx >= 188) {
            G.menu_sel = G.sel;
            set_state(ST_SKILLS);
            plat_sfx(SFX_SELECT);
            return;
        }
    }
    if (use && (G.mstate == M_IDLE || G.mstate == M_WALK) && !G.clear_pending)
        start_skill(G.sel);

    if (in->held || in->touch)
        G.idle_t = 0;
    else
        G.idle_t++;
    if (G.hurt_t > 0)
        G.hurt_t--;

    momo_tick(in);
    people_tick();
    spawn_tick();
    housemate_tick();

    for (int i = 0; i < MAX_POPUPS; i++) {
        Popup *p = &G.pops[i];
        if (p->t > 0) {
            p->t--;
            if (p->t % 2 == 0)
                p->y--;
            p->x += p->vx * (p->t % 4 == 0);
        }
    }
    if (G.msg_t > 0)
        G.msg_t--;
    if (G.flash_t > 0)
        G.flash_t--;

    // hunger and a trickle of MP
    if (++G.drain_acc >= G.drain) {
        G.drain_acc = 0;
        G.hp--;
        G.tally[TL_DRAIN]++;
    }
    if (++G.regen_acc >= 90) {
        G.regen_acc = 0;
        G.mp = clampi(G.mp + 1, 0, G.maxmp);
    }

    if (G.hp <= 0) {
        G.hp = 0;
        if (!G.rescue_used) {
            // the very first time Momo collapses, her humans come running
            G.rescue_used = true;
            set_state(ST_RESCUE);
            plat_sfx(SFX_CONFIRM);
        } else {
            G.lives--;
            G.retry = true;
            set_state(ST_GAMEOVER);
            plat_sfx(SFX_GAMEOVER);
        }
        return;
    }
    if (G.love >= G.goal && !G.clear_pending) {
        G.clear_pending = true;
        G.t = 0;
        say("That's enough love! Stage clear!");
    }
    if (G.clear_pending && (G.mstate == M_IDLE || G.mstate == M_WALK) && ++G.t > 90) {
        stage_cleared();
        set_state(ST_CLEAR);
        plat_sfx(SFX_CLEAR);
    }
}

static void skills_tick(const Input *in)
{
    if ((in->down & (IN_X | IN_START)) || ((in->down & IN_B) && G.code_pos != 9)) {
        set_state(ST_PLAY);
        plat_sfx(SFX_BACK);
        return;
    }
    if (in->down & IN_UP) {
        G.menu_sel = (G.menu_sel + SK_COUNT - 1) % SK_COUNT;
        plat_sfx(SFX_SELECT);
    }
    if (in->down & IN_DOWN) {
        G.menu_sel = (G.menu_sel + 1) % SK_COUNT;
        plat_sfx(SFX_SELECT);
    }
    bool buy = (in->down & IN_A) != 0;
    if (in->touch) {
        if (in->ty >= 26 && in->ty < 26 + SK_COUNT * 11) {
            int row = (in->ty - 26) / 11;
            if (row == G.menu_sel && in->tx >= 200)
                buy = true;
            G.menu_sel = row;
        } else if (in->ty >= 172 && in->tx >= 188) {
            set_state(ST_PLAY);
            plat_sfx(SFX_BACK);
            return;
        }
    }
    if (buy) {
        int sk = G.menu_sel;
        if (G.points > 0 && G.skill_lv[sk] < skills[sk].max_lv) {
            G.points--;
            G.skill_lv[sk]++;
            plat_sfx(SFX_SKILLUP);
            if (G.points == 0) {
                // all points spent: straight back to the fence
                say("Skills learned! Back to charming humans.");
                set_state(ST_PLAY);
            }
        } else {
            plat_sfx(SFX_BACK);
        }
    }
}

// --------------------------------------------------------------------------
// Update
// --------------------------------------------------------------------------

#define INTRO_LEN 840

// The classic code on the title screen: Up Up Down Down Left Right Left Right B A
static bool title_code(const Input *in)
{
    static const uint32_t code[10] = { IN_UP, IN_UP, IN_DOWN, IN_DOWN, IN_LEFT, IN_RIGHT,
                                       IN_LEFT, IN_RIGHT, IN_B, IN_A };
    int pos = G.code_pos;
    uint32_t k = in->down & (IN_UP | IN_DOWN | IN_LEFT | IN_RIGHT | IN_A | IN_B | IN_X | IN_Y | IN_START);
    if (!k)
        return false;
    if (k == code[pos]) {
        if (++pos == 10) {
            G.code_pos = 0;
            return true;
        }
    } else {
        pos = k == code[0] ? 1 : 0;
    }
    G.code_pos = pos;
    return false;
}

static void warp_to_map(void)
{
    plat_sfx(SFX_SKILLUP);
    G.stage = STG_YAHOO;
    G.stages_cleared = 2;
    open_map();
    say("Secret code! Straight to the world map. Good luck!");
}

// The secret code is also a play-testing shortcut: wherever it is entered it
// jumps one step ahead (stage 1 -> time machine -> Yahoo! -> map -> ...).
static void ending_next(void)
{
    G.endings++;
    if (G.visited == (1u << NUM_DESTS) - 1) {
        // the whole world is stamped: back to stage 1 for another lap
        G.round++;
        G.visited = 0;
        G.loc = 0;
        G.stage = STG_BALCONY;
        G.rescue_used = false;
        plat_sfx(SFX_SKILLUP);
        set_state(ST_CARD);
    } else {
        finish_run(true);
    }
}

static void code_skip(void)
{
    plat_sfx(SFX_SKILLUP);
    switch (G.state) {
        case ST_TITLE:
        case ST_INTRO:
        case ST_SELECT:
            new_game(G.state == ST_SELECT ? G.menu_sel : 0);
            warp_to_map();
            return;
        case ST_MAP:
            if (G.map_sel < NUM_DESTS) {
                G.visited |= 1u << G.map_sel;
                G.stages_cleared++;
                say("Secret code: destination stamped!");
            }
            return;
        case ST_TRAVEL:
            G.loc = G.map_sel;
            G.stage = G.map_sel == NUM_DESTS ? STG_HOME : STG_DEST0 + G.map_sel;
            set_state(ST_CARD);
            return;
        case ST_TIMEWARP:
            G.stage = STG_YAHOO;
            set_state(ST_CARD);
            return;
        case ST_ENDING:
            ending_next();
            return;
        case ST_RESULTS:
        case ST_NAME:
        case ST_RANKING:
            set_state(ST_TITLE);
            return;
        default:
            break;
    }
    // anything inside a stage: count it as cleared and move on
    if (G.state != ST_CLEAR)
        stage_cleared();
    G.hp = G.hp > 0 ? G.hp : G.maxhp;
    if (G.stage == STG_BALCONY)
        set_state(ST_TIMEWARP);
    else if (G.stage == STG_HOME)
        set_state(ST_ENDING);
    else
        open_map();
}

#define RESCUE_LEN 330
#define TRAVEL_LEN 30     // frames for the time machine to hop across the map
// Ending timeline. The ending: the time machine takes Momo and her humans on vacation to Cat
// Planet, where everything is food.
#define ENDING_SPACE 170
#define ENDING_LAND 290
#define ENDING_DONE (ENDING_LAND + 150)
#define TIMEWARP_LEN 500
#define BUDDHA_LEN 460

static void buddha_finish(void)
{
    G.love = G.goal > G.love ? G.goal : G.love;
    G.buddhas++;
    stage_cleared();
    set_state(ST_CLEAR);
    plat_sfx(SFX_CLEAR);
}

static void rescue_finish(void)
{
    G.hp = G.maxhp;
    G.mp = G.maxmp;
    memset(G.people, 0, sizeof(G.people));
    memset(G.pops, 0, sizeof(G.pops));
    G.mstate = M_IDLE;
    G.mt = 0;
    G.my = stages[G.stage].fence_y;
    G.ground = false;
    G.spawn_t = 90;
    G.hurt_t = 0;
    say("Back to work! (Evans & Shannon only save you once.)");
    set_state(ST_PLAY);
}

void game_init(uint32_t seed)
{
    memset(&G, 0, sizeof(G));
    G.rng = seed ? seed : 0x1234567;
    G.state = ST_TITLE;
    G.music = -1;
    new_game(0);
    scores_load(&G.ranks);
}

// How often the bottom screen must be redrawn: every 3rd frame during play
// (HUD bars and text), every 2nd frame in menus and cutscenes, and every
// frame on screens where the bottom shows smooth animation.
bool game_bottom_due(uint32_t frame)
{
    int every = 2;
    if (G.state == ST_PLAY || G.state == ST_SKILLS)
        every = 3;
    if (G.state == ST_NAME || G.state == ST_SELECT)
        every = 1;
    return every <= 1 || frame % (uint32_t)every == 0;
}

int game_state(void)
{
    return G.state;
}

const char *game_debug(void)
{
    int n = snprintf(G.dbg, sizeof(G.dbg), "st=%d t=%d hp=%d/%d mp=%d/%d love=%d lv=%d xp=%d people=%d",
                     G.state, G.t, G.hp, G.maxhp, G.mp, G.maxmp, G.love, G.lv, G.xp, count_people());
#ifdef MOMO_HOST
    n += snprintf(G.dbg + n, sizeof(G.dbg) - n, " | momo %d,%d m%d", momo_x(), G.my, G.mstate);
    for (int i = 0; i < MAX_PEOPLE && n < (int)sizeof(G.dbg) - 16; i++)
        if (G.people[i].active)
            n += snprintf(G.dbg + n, sizeof(G.dbg) - n, " [%d:%d,%d s%d]", G.people[i].arch,
                          px(&G.people[i]), G.people[i].y, G.people[i].state);
#endif
    (void)n;
    return G.dbg;
}

void game_update(const Input *in)
{
    G.frame++;
    G.t++;
    if (title_code(in)) {
        code_skip();
        return;
    }
    if (G.state != ST_TITLE && G.state != ST_INTRO && G.state != ST_SELECT && G.state != ST_PAUSE &&
        G.state != ST_RESULTS && G.state != ST_NAME && G.state != ST_RANKING && G.state != ST_ENDING)
        G.run_frames++;
    rnd();
    bool ok = (in->down & (IN_A | IN_START)) || in->touch;

    switch (G.state) {
        case ST_TITLE:
            if (in->down & IN_SELECT) {
                plat_sfx(SFX_SELECT);
                G.ranking_hl = -1;
                set_state(ST_RANKING);
            } else if (ok) {
                plat_sfx(SFX_CONFIRM);
                set_state(ST_INTRO);
            }
            break;
        case ST_INTRO:
            if ((in->down & IN_START) || ((in->down & IN_B) && G.code_pos != 9) || G.t >= INTRO_LEN) {
                set_state(ST_SELECT);
                G.menu_sel = 0;
            }
            break;
        case ST_SELECT:
            if (in->down & IN_LEFT) {
                G.menu_sel = (G.menu_sel + 2) % 3;
                plat_sfx(SFX_SELECT);
            }
            if (in->down & IN_RIGHT) {
                G.menu_sel = (G.menu_sel + 1) % 3;
                plat_sfx(SFX_SELECT);
            }
            if (in->touch && in->ty >= 150) {
                int c = in->tx * 3 / SCREEN_W;
                if (c == G.menu_sel)
                    ok = true;
                else {
                    G.menu_sel = c;
                    plat_sfx(SFX_SELECT);
                    ok = false;
                }
            } else if (in->touch) {
                ok = false;
            }
            if (ok && G.t > 10) {
                plat_sfx(SFX_MEOW);
                new_game(G.menu_sel);
                set_state(ST_CARD);
            }
            break;
        case ST_CARD:
            if (ok && G.t > 20) {
                plat_sfx(SFX_CONFIRM);
                start_stage();
                set_state(ST_PLAY);
            }
            break;
        case ST_PLAY:
            play_tick(in);
            break;
        case ST_SKILLS:
            skills_tick(in);
            break;
        case ST_PAUSE:
            if (in->down & IN_START) {
                set_state(ST_PLAY);
                plat_sfx(SFX_BACK);
            } else if (in->down & IN_SELECT) {
                set_state(ST_TITLE);
            } else if (in->down & IN_X) {
                G.music_off = !G.music_off;
                plat_sfx(SFX_SELECT);
            }
            break;
        case ST_CLEAR:
            if (ok && G.t > 60) {
                plat_sfx(SFX_CONFIRM);
                if (G.stage == STG_BALCONY) {
                    set_state(ST_TIMEWARP);
                } else if (G.stage == STG_HOME) {
                    set_state(ST_ENDING);
                } else {
                    open_map();
                }
            }
            break;
        case ST_GAMEOVER:
            if (G.t > 60 && G.lives > 0 && (in->down & IN_A)) {
                plat_sfx(SFX_CONFIRM);
                set_state(ST_CARD);
            } else if (G.t > 60 && (G.lives == 0 ? ok : ((in->down & IN_B) != 0 && G.code_pos != 9))) {
                finish_run(false);
            }
            break;
        case ST_ENDING:
            if (G.t == 85 || G.t == ENDING_LAND + 45)
                plat_sfx(SFX_JUMP);
            if (G.t == 112)
                plat_sfx(SFX_ENGINE);    // everyone's aboard: rev up
            if (G.t == 166)
                plat_sfx(SFX_BOOM);      // off to Cat Planet
            if (G.t == 176)
                plat_sfx(SFX_TUNNEL);    // flying through space
            if (G.t == ENDING_LAND + 34)
                plat_sfx(SFX_LAND);      // touchdown on Cat Planet
            if (G.t == ENDING_LAND)
                plat_sfx(SFX_CLEAR);
            if (G.t < ENDING_LAND && (in->down & IN_START) && G.t > 30)
                G.t = ENDING_LAND;
            else if (ok && G.t > ENDING_DONE)
                ending_next();
            break;
        case ST_MAP:
            map_tick(in);
            break;
        case ST_TRAVEL:
            if (G.t >= TRAVEL_LEN + 5 || ((in->down & IN_START) && G.t > 10)) {
                G.loc = G.map_sel;
                G.stage = G.map_sel == NUM_DESTS ? STG_HOME : STG_DEST0 + G.map_sel;
                set_state(ST_CARD);
            }
            break;
        case ST_RESULTS:
            if (ok && G.t > 60) {
                plat_sfx(SFX_CONFIRM);
                if (scores_rank(&G.ranks, G.score) >= 0) {
                    memcpy(G.initials, "MOM", 4);
                    G.name_pos = 0;
                    set_state(ST_NAME);
                } else {
                    G.ranking_hl = -1;
                    set_state(ST_RANKING);
                }
            }
            break;
        case ST_NAME:
            name_tick(in);
            break;
        case ST_RANKING:
            if (G.t > 20 && (ok || ((in->down & IN_B) && G.code_pos != 9)))
                set_state(ST_TITLE);
            break;
        case ST_TIMEWARP:
            if (G.t == 85)
                plat_sfx(SFX_JUMP);
            if (G.t == 160)
                plat_sfx(SFX_ENGINE);     // revving up, peaking at 88 MPH right at the flash
            if (G.t == 238)
                plat_sfx(SFX_BOOM);       // breaking through time
            if (G.t == 250)
                plat_sfx(SFX_TUNNEL);     // rushing through the time tunnel
            if (G.t == 384)
                plat_sfx(SFX_LAND);       // wheels touch down in 2016
            if (G.t == 390)
                plat_sfx(SFX_HEART);
            if (G.t >= TIMEWARP_LEN || ((in->down & IN_START) && G.t > 30)) {
                G.stage = STG_YAHOO;
                set_state(ST_CARD);
            }
            break;
        case ST_BUDDHA:
            if (G.t == 60 || G.t == 140 || G.t == 220)
                plat_sfx(SFX_SKILLUP);
            if (G.t >= BUDDHA_LEN || (ok && G.t > 160))
                buddha_finish();
            break;
        case ST_LEVELUP:
            if (G.t >= 170 || (ok && G.t > 70)) {
                G.menu_sel = SK_EYE;
                set_state(ST_SKILLS);
                plat_sfx(SFX_CONFIRM);
            }
            break;
        case ST_RESCUE:
            if (G.t == 130 || G.t == 160)
                plat_sfx(SFX_HEART);
            if (G.t >= RESCUE_LEN || (ok && G.t > 200)) {
                plat_sfx(SFX_CONFIRM);
                rescue_finish();
            }
            break;
    }

    // background music follows the screen
    int mus;
    switch (G.state) {
        case ST_PLAY:
        case ST_SKILLS:
            mus = stages[G.stage].music;
            break;
        case ST_MAP:
        case ST_TRAVEL:
            mus = MUS_MAP;
            break;
        case ST_PAUSE:
        case ST_CLEAR:
        case ST_GAMEOVER:
        case ST_LEVELUP:
        case ST_BUDDHA:
            mus = MUS_NONE;
            break;
        case ST_TIMEWARP:
            mus = MUS_TIMEWARP;
            break;
        case ST_ENDING:
            // let the engine and the time boom speak, music once we've landed
            mus = G.t < ENDING_LAND ? MUS_NONE : MUS_TITLE;
            break;
        default:
            mus = MUS_TITLE;
            break;
    }
    if (G.music_off)
        mus = MUS_NONE;
    if (mus != G.music) {
        G.music = mus;
        plat_music(mus);
    }
}

// --------------------------------------------------------------------------
// Rendering helpers
// --------------------------------------------------------------------------

// Overlay text above heads is placed so labels never cover each other.
#define MAX_LABELS 24
static struct { int x, y, w, h; } labels[MAX_LABELS];
static int num_labels;

static int place_label(int x, int y, int w, int h)
{
    for (int tries = 0; tries < 6; tries++) {
        bool hit = false;
        for (int i = 0; i < num_labels; i++) {
            if (x < labels[i].x + labels[i].w && labels[i].x < x + w &&
                y < labels[i].y + labels[i].h && labels[i].y < y + h) {
                y = labels[i].y - h - 1;
                hit = true;
                break;
            }
        }
        if (!hit)
            break;
    }
    if (num_labels < MAX_LABELS) {
        labels[num_labels].x = x;
        labels[num_labels].y = y;
        labels[num_labels].w = w;
        labels[num_labels].h = h;
        num_labels++;
    }
    return y;
}

static void draw_bubble(uint16_t *fb, int cx, int y, const char *s)
{
    int w = gfx_text_width(s, 1) + 6;
    int x = clampi(cx - w / 2, 1, SCREEN_W - w - 1);
    y = place_label(x, y, w, 12);
    gfx_panel(fb, x, y, w, 12, COL_WHITE, COL_INK);
    gfx_text(fb, x + 3, y + 2, s, COL_INK);
}

static void draw_person(uint16_t *fb, Person *p, bool targeted, bool primary)
{
    const ArchDef *a = &archs[p->arch];
    int pose;
    if (p->state == P_WALK || p->state == P_FLEE || p->state == P_LEAVE)
        pose = PF_WALK0 + (p->dist / 96) % 4;
    else if (p->state == P_HOLD)
        pose = PF_STAND;
    else {
        int re = p_likes(p);
        if (G.ground && G.target >= 0 && &G.people[G.target] == p)
            pose = PF_KNEEL;
        else if (re == RE_PHOTO)
            pose = PF_PHOTO;
        else
            pose = (G.frame / 12) % 3 ? PF_REACH : PF_STAND;
    }
    int x = px(p);
    int flags = p->dir < 0 ? SPR_FLIP : 0;
    const uint8_t *spr = &person_px[(a->sprite * PF_COUNT + pose) * PERSON_W * PERSON_H];

    if (p->dog) {
        int dx = x + p->dir * 20;
        int dflags = p->dir < 0 ? SPR_FLIP : 0;
        int df = (p->dist / 64) % 2;
        if (p->state == P_HOLD || p->state == P_REACT)
            df = 0;
        int dy = p->y + 1;
        if (p->result == HQ_FAIL && p->icon_t > 60)
            dy -= (G.frame / 3) % 2 * 2; // barking hop
        gfx_line(fb, x + p->dir * 10, p->y - 16, dx + p->dir * 4, dy - 8, RGB(200, 40, 40));
        gfx_sprite(fb, &dog_px[df * DOG_W * DOG_H], DOG_W, DOG_H, dx - 12, dy - 16, p->pal, dflags, 1);
    }

    if (p->rage) {
        // a big flickering aura behind them
        int base = p->rage == RAGE_RED ? IC_FLAME_RED0 : IC_FLAME_BLACK0;
        int fr = (G.frame / 5) % 2;
        static const int8_t ox[4] = { -10, 2, -4, 8 };
        static const int8_t oy[4] = { -40, -50, -28, -34 };
        for (int k = 0; k < 4; k++) {
            const Sprite *f = &icons[base + ((fr + k) & 1)];
            int fx = x - p->dir * 6 + ox[k] - f->w;
            int fy = p->y + oy[k] - ((G.frame / 3 + k) % 4);
            gfx_sprite(fb, f->px, f->w, f->h, fx, fy, ui_pal, (k & 1) ? SPR_FLIP : 0, 2);
        }
    }
    // soft shadow
    gfx_blend(fb, x - 7, p->y - 1, 14, 2, RGB(60, 60, 60));
    gfx_sprite_pat(fb, spr, PERSON_W, PERSON_H, x - 12, p->y - 48, p->pal, flags, 5, p->robe ? 7 : 5,
                   p->pat, p->pat_col);

    int head = p->y - 48;
    // reaction props in their hands
    if (p->state == P_REACT && pose != PF_STAND) {
        int hx = x + p->dir * 12;
        int re = (G.act == SK_FOODPAW && G.target >= 0 && &G.people[G.target] == p) ? RE_FEED : p_likes(p);
        int ic = re == RE_FEED ? IC_FISH : re == RE_PET ? IC_HAND : re == RE_BRUSH ? IC_BRUSH : re == RE_MASSAGE ? IC_HAND : -1;
        if (ic >= 0)
            draw_icon(fb, ic, hx, (pose == PF_KNEEL ? p->y - 18 : head + 2) + (G.frame / 8) % 2);
        if (re == RE_MASSAGE && (G.frame / 10) % 2)
            gfx_text_outline(fb, hx - 28, head - 4, "pat pat", COL_YELLOW, COL_INK, 1);
        if (p->arch == PK_SHANNON) {
            static const char *chat[] = { "You're doing great!", "So proud of you!", "Eat well, okay?" };
            p->say = chat[(G.frame / 50) % 3];
            p->say_t = 20;
        }
    }

    // Labels belong to humans you can see: once the body has walked off the
    // edge, drop them (they used to stay pinned to the screen edge).
    if (x < -6 || x > SCREEN_W + 6)
        return;
    // keep text readable near the edge only while the human is mostly on screen
    bool edge_ok = x >= 12 && x <= SCREEN_W - 12;

    // result icon (hearts or "!")
    int iy = head - 14 + ((G.frame / 10) % 2);
    if (p->icon_t > 0 && p->result != HQ_NONE) {
        static const int map[] = { 0, IC_HEART_FULL, IC_HEART_HALF, IC_HEART_EMPTY, IC_EXCLAIM };
        draw_icon(fb, map[p->result], x, iy);
    } else if (!p->done && p->state == P_WALK) {
        // Cat Eye overlay
        int eye = G.skill_lv[SK_EYE];
        int ey = head - 10;
        bool secret = p_weak(p) == SK_ANY;
        bool parent = p->arch == PK_EVANS || p->arch == PK_SHANNON;
        int res = p_resist(p);
        if (eye >= 1) {
            uint16_t mood = secret ? COL_PURPLE : res < 30 ? COL_GREEN : res < 60 ? COL_YELLOW : COL_RED;
            gfx_fill(fb, x - 3, ey + 2, 6, 6, COL_INK);
            gfx_fill(fb, x - 2, ey + 3, 4, 4, mood);
        }
        if (eye >= 2 && !secret) {
            static const int likes_icon[] = { IC_FISH, IC_HAND, IC_BRUSH, IC_CAMERA, IC_HAND };
            draw_icon(fb, likes_icon[p_likes(p)], x + 12, ey + 1);
        }
        if (eye >= 3) {
            char buf[16];
            if (eye >= 4 && targeted && !skills[G.sel].self)
                snprintf(buf, sizeof(buf), "%s %d%%", secret ? (parent ? "JUMP!" : "???") : skills[p_weak(p)].short_name,
                         success_chance(p, G.sel));
            else
                snprintf(buf, sizeof(buf), "%s", secret ? (parent ? "JUMP!" : "???") : skills[p_weak(p)].short_name);
            int w = gfx_text_width(buf, 1) + 2;
            int lx = edge_ok ? clampi(x - w / 2, 0, SCREEN_W - w) : x - w / 2;
            int ly = place_label(lx, ey - 10, w, 10);
            gfx_text_outline(fb, lx + 1, ly + 1, buf, targeted ? COL_WHITE : COL_YELLOW, COL_INK, 1);
        }
    }
    if (p->say_t > 0 && p->say && p->say[0] && edge_ok)
        draw_bubble(fb, x, head - 30, p->say);
    if (primary && (p->npc >= 0 || p->arch == PK_EVANS || p->arch == PK_SHANNON) && p->state == P_WALK) {
        // name tag under the feet so it never fights with the head overlays
        const char *nm = pname(p);
        int w = gfx_text_width(nm, 1);
        int lx = edge_ok ? clampi(x - w / 2, 0, SCREEN_W - w) : x - w / 2;
        gfx_text_outline(fb, lx, clampi(p->y + 1, 0, SCREEN_H - 8), nm, COL_WHITE, COL_INK, 1);
    }
    if (targeted)
        draw_icon(fb, IC_ARROW, x, head - 6 - (G.skill_lv[SK_EYE] >= 1 ? 6 : 0) - ((G.frame / 8) % 2) - 40 * 0);
}

static void draw_momo_effects(uint16_t *fb, int x, int y)
{
    int t = G.mt;
    if (G.mstate == M_ACT) {
        switch (G.act) {
            case SK_MEOW:
                if (t < 34)
                    draw_bubble(fb, x + 18, y - 44, "Meow~");
                break;
            case SK_CUTE:
                draw_icon(fb, IC_SPARKLE, x - 14 + (t / 6) % 3, y - 34 + (t / 5) % 4);
                draw_icon(fb, IC_SPARKLE, x + 14 - (t / 7) % 3, y - 26 - (t / 4) % 4);
                break;
            case SK_PURR:
                draw_icon(fb, IC_NOTE, x + 14 + (t / 10) % 4, y - 30 - (t / 3) % 16);
                draw_icon(fb, IC_NOTE, x - 16 - (t / 8) % 4, y - 24 - (t / 4) % 12);
                break;
            case SK_GROOM:
                if ((t / 12) % 2)
                    gfx_text_outline(fb, x + 12, y - 30, G.groom_var == 3 ? "scritch" : "lick",
                                     COL_PINK, COL_INK, 1);
                break;
            case SK_LOAF:
                draw_icon(fb, IC_ZZZ, x + 14, y - 30 - (t / 10) % 4);
                break;
            case SK_BLINK:
                if (t > 14 && t < 34)
                    draw_icon(fb, IC_HEART_EMPTY, x + 16, y - 34);
                break;
        }
    }
    if (G.shiny && (G.frame / 6) % 3 == 0)
        draw_icon(fb, IC_SPARKLE, x - 12 + (G.frame / 18) % 24, y - 28 + (G.frame / 7) % 10);
}

static void draw_pops(uint16_t *fb)
{
    for (int i = 0; i < MAX_POPUPS; i++) {
        Popup *p = &G.pops[i];
        if (p->t <= 0)
            continue;
        if (p->icon >= 0)
            draw_icon(fb, p->icon, p->x, p->y);
        else
            gfx_text_outline(fb, p->x, p->y, p->txt, p->col, COL_INK, 1);
    }
}

// --------------------------------------------------------------------------
// Ambient animation: a light layer of moving things over each background
// --------------------------------------------------------------------------

static uint32_t amb_hash(uint32_t k, uint32_t t)
{
    uint32_t h = k * 2654435761u ^ (t * 40503u + 0x9E3779B9u);
    h ^= h >> 15;
    h *= 2246822519u;
    h ^= h >> 13;
    return h;
}

// soft, half-transparent cloud puff drifting across the sky
static void amb_clouds(uint16_t *fb, int t, int n, int ymax)
{
    for (int k = 0; k < n; k++) {
        int w = 34 + (k * 13) % 20;
        int x = (k * 131 + t / (5 + k)) % (SCREEN_W + w + 20) - w - 10;
        int y = 6 + (k * 17) % (ymax > 20 ? ymax - 14 : 6);
        gfx_blend(fb, x + 6, y, w - 12, 3, COL_WHITE);
        gfx_blend(fb, x, y + 3, w, 5, COL_WHITE);
        gfx_blend(fb, x + w / 4, y - 2, w / 3, 2, COL_WHITE);
    }
}

static void amb_birds(uint16_t *fb, int t, int n, uint16_t col)
{
    for (int k = 0; k < n; k++) {
        int x = SCREEN_W + 10 - (t / 2 + k * 157) % (SCREEN_W + 60);
        int y = 22 + k * 11 + ((t / 9 + k * 3) % 8 < 4 ? 0 : 1);
        int up = ((t / 6 + k) & 1);   // flap
        gfx_line(fb, x - 3, y - up, x, y + 1 - up * 0, col);
        gfx_line(fb, x, y + 1, x + 3, y - up, col);
    }
}

static void amb_sparkle(uint16_t *fb, int t, int y0, int y1, int n)
{
    for (int k = 0; k < n; k++) {
        uint32_t h = amb_hash(k, t / 10 + k);
        int x = h % SCREEN_W, y = y0 + (h >> 12) % (y1 - y0);
        if (((h >> 20) & 3) == 0)
            continue;
        gfx_fill(fb, x, y, 2, 1, COL_WHITE);
        if ((h >> 23) & 1)
            gfx_fill(fb, x + 2, y, 1, 1, RGB(200, 230, 250));
    }
}

static void amb_fall(uint16_t *fb, int t, int n, int speed, int sway, int ymax, uint16_t c1, uint16_t c2, int len)
{
    for (int k = 0; k < n; k++) {
        int y = (k * 53 + t * speed / 4) % ymax;
        int x = (k * 71 + ((t / 4 + k * 7) % 16 < 8 ? 0 : sway) + y * sway / 16) % SCREEN_W;
        if (len > 1)
            gfx_line(fb, x, y, x - 1, y + len, k & 1 ? c1 : c2);
        else
            gfx_fill(fb, x, y, 1 + (k % 3 == 0), 1 + (k % 3 == 0), k & 1 ? c1 : c2);
    }
}

static void amb_fireflies(uint16_t *fb, int t, int y0, int y1)
{
    for (int k = 0; k < 10; k++) {
        if ((t / 12 + k * 5) % 9 < 3)
            continue;   // blink
        int x = (k * 59 + (t / 3) * ((k & 1) ? 1 : -1) / 4 + 512) % SCREEN_W;
        int y = y0 + (k * 23 + (t / 10 + k) % 6) % (y1 - y0);
        gfx_fill(fb, x, y, 2, 2, RGB(230, 250, 120));
        gfx_blend(fb, x - 1, y - 1, 4, 4, RGB(230, 250, 120));
    }
}

// one small butterfly flitting around the bougainvillea at the right edge,
// well away from Momo in the middle
static void amb_butterfly(uint16_t *fb, int t)
{
    int ph = (t / 3) % 60;
    int x = 222 + (ph < 30 ? ph : 60 - ph) - 15;
    int y = 92 + ((t / 7) % 6 < 3 ? 0 : 2) + ((t / 40) % 2) * 4;
    int open = (t / 4) & 1;
    gfx_fill(fb, x - 1 - open, y, 1 + open, 2, RGB(250, 210, 80));
    gfx_fill(fb, x + 1, y, 1 + open, 2, RGB(250, 210, 80));
    gfx_fill(fb, x, y, 1, 3, COL_INK);
}

// The prayer flags catch a breeze every few seconds, then hang still again.
// Rows under the string are nudged sideways in a travelling wave, sampled
// from the clean background so nothing smears.
static void amb_flags(uint16_t *fb, const uint16_t *bg, int t)
{
    int cyc = t % 420;
    if (cyc >= 160)
        return;
    int env = cyc < 30 ? cyc : cyc > 130 ? 160 - cyc : 30;   // 0..30 ramp in/out
    for (int x = 104; x <= 210; x++) {
        int u = (x - 104) * 256 / 102;                       // 0..256 along the string
        int sag = (u * (256 - u)) * 12 / 16384;              // sin-ish sag, matches the art
        int sy = 58 + 2 * (x - 104) / 102 + sag;
        for (int dy = 1; dy <= 10; dy++) {
            int y = sy + dy;
            // wave: phase moves along the string over time, stronger at the flag tips
            int ph = (t * 6 + x * 9 + dy * 20) & 255;
            int w = ph < 128 ? ph - 64 : 192 - ph;           // triangle wave -64..64
            int dx = w * dy * env / (64 * 10 * 9);   // up to ~3 px at the flag tips
            int sx = x - dx;
            if (sx < 0 || sx >= SCREEN_W || y >= SCREEN_H)
                continue;
            fb[y * SCREEN_W + x] = bg[y * SCREEN_W + sx];
        }
    }
}

// Machu Picchu's llama: mostly stands around, sometimes grazes, sometimes
// ambles a few steps one way and later back.
static void amb_llama(uint16_t *fb, int t)
{
    int cyc = t % 900, lap = (t / 900) & 1;
    int frame = 0, dx = 0;
    if (cyc >= 240 && cyc < 420)
        frame = 1;                                   // grazing
    else if (cyc >= 600 && cyc < 680) {              // a few steps
        frame = 2 + (cyc / 10) % 2;
        dx = (cyc - 600) / 8;
    } else if (cyc >= 680)
        dx = 10;
    if (lap)
        dx = 10 - dx;                                // next lap walks back
    gfx_sprite(fb, &llama_px[frame * LLAMA_W * LLAMA_H], LLAMA_W, LLAMA_H, LLAMA_X - dx, LLAMA_Y,
               llama_pal, 0, 1);
}

// The Amazon sloth: hangs still for a long time, slowly turns its head, and
// once in a while stretches an arm.
static void amb_sloth(uint16_t *fb, int t)
{
    int cyc = t % 720;
    int frame = (cyc >= 300 && cyc < 400) ? 1 : (cyc >= 560 && cyc < 640) ? 2 : 0;
    gfx_sprite(fb, &sloth_px[frame * SLOTH_W * SLOTH_H], SLOTH_W, SLOTH_H, SLOTH_X, SLOTH_Y, sloth_pal, 0, 1);
}

// Kept deliberately calm: at most one or two small things move per scene,
// and some only now and then, so nothing pulls attention from the humans.
// Every 20 s or so a squirrel scampers onto the fence from the right, sits
// and flicks its tail, then dashes off. It keeps its distance from Momo.
static void amb_squirrel(uint16_t *fb, int t)
{
    int cyc = t % 1200;
    if (cyc >= 300)
        return;
    int mx = G.state == ST_PLAY || G.state == ST_SKILLS || G.state == ST_PAUSE ? momo_x() : 0;
    if (mx > 206)
        return;                                 // Momo is guarding that corner: no squirrel today
    int stop = mx > 170 ? 244 : 222;
    int x, frame, flags = 0;
    if (cyc < 60) {                             // run in from the right edge (facing left)
        x = 264 - (264 - stop) * cyc / 60;
        frame = (cyc / 4) & 1;
        flags = SPR_FLIP;
    } else if (cyc < 240) {                     // sit, nibble, flick the tail
        x = stop;
        frame = (cyc % 50) < 10 ? 3 : 2;
        flags = SPR_FLIP;
    } else {                                    // dash off to the right
        x = stop + (264 - stop) * (cyc - 240) / 60;
        frame = (cyc / 4) & 1;
    }
    int fy = stages[G.stage].fence_y;
    gfx_sprite(fb, &squirrel_px[frame * SQUIRREL_W * SQUIRREL_H], SQUIRREL_W, SQUIRREL_H,
               x - SQUIRREL_W / 2, fy - SQUIRREL_H + 1, squirrel_pal, flags, 1);
}

// Momo's housemates (balcony + Home) take turns strolling along the path:
// Maru the call duck, BieJi the black silkie and Ms. Dong the puffy-cheeked hen.
static const struct {
    const char *name;
    const char *hello;
    const uint8_t *px;
    const uint16_t *pal;
    int w, h, sfx;
} housemates[3] = {
    { "Maru", "Quack!", maru_px, maru_pal, MARU_W, MARU_H, SFX_QUACK },
    { "BieJi", "Cluck~", bieji_px, bieji_pal, BIEJI_W, BIEJI_H, SFX_CLUCK },
    { "Ms. Dong", "Bok bok!", msdong_px, msdong_pal, MSDONG_W, MSDONG_H, SFX_CLUCK },
};

static void draw_housemate(uint16_t *fb)
{
    if (G.pet_k < 0)
        return;
    int k = G.pet_k, x = G.pet_x16 >> 4, feet = 176;
    int frame = G.pet_pause ? 0 : (x / (G.pet_flee ? 3 : 5)) & 1;
    gfx_sprite(fb, housemates[k].px + frame * housemates[k].w * housemates[k].h, housemates[k].w, housemates[k].h,
               x - housemates[k].w / 2, feet - housemates[k].h - (G.pet_pause > 50 ? 1 : 0), housemates[k].pal,
               G.pet_dir > 0 ? 0 : SPR_FLIP, 1);
    if (x < -4 || x > SCREEN_W + 4)
        return;
    int tw = gfx_text_width(housemates[k].name, 1);
    gfx_text_outline(fb, x - tw / 2, feet - housemates[k].h - 10, housemates[k].name, RGB(255, 240, 200), COL_INK, 1);
    const char *line = G.pet_flee ? "QUACK!!" : (G.pet_pause > 20 ? (k == 0 ? "Hmph." : housemates[k].hello) : NULL);
    if (line) {   // hello to Momo (or, for Maru, not)
        int bw = gfx_text_width(line, 1) + 6;
        int bx = clampi(x - bw / 2, 1, SCREEN_W - bw - 1), by = feet - housemates[k].h - 24;
        gfx_panel(fb, bx, by, bw, 12, COL_WHITE, COL_INK);
        gfx_text(fb, bx + 3, by + 2, line, G.pet_flee ? COL_RED : COL_INK);
    }
}

static void housemate_tick(void)
{
    if (G.stage != STG_BALCONY && G.stage != STG_HOME)   // they live on the balcony
        return;
    if (G.pet_greet_t > 0)
        G.pet_greet_t--;
    if (G.pet_k < 0) {
        if (--G.pet_timer > 0)
            return;
        G.pet_k = G.pet_lap % 3;
        G.pet_dir = (G.pet_lap / 3) % 2 ? -1 : 1;
        G.pet_x16 = (G.pet_dir > 0 ? -22 : SCREEN_W + 22) * 16;
        G.pet_greeted = false;
        G.pet_flee = false;
        G.pet_pause = 0;
        G.pet_lap++;
        return;
    }
    if (G.pet_pause > 0) {
        G.pet_pause--;
        return;
    }
    int x = G.pet_x16 >> 4;
    // Maru doesn't like Momo: if the cat jumps down anywhere near, she bolts
    if (G.pet_k == 0 && !G.pet_flee && G.ground && absi(x - momo_x()) < 70) {
        G.pet_flee = true;
        G.pet_dir = momo_x() < x ? 1 : -1;
        plat_sfx(SFX_QUACK);
        say("QUACK!! Maru flees from Momo.");
    }
    G.pet_x16 += G.pet_dir * (G.pet_flee ? 40 : 6);   // a slow, waddly stroll (or a panicked dash)
    x = G.pet_x16 >> 4;
    if (G.pet_k == 0 && !G.pet_greeted && !G.pet_flee && G.mstate == M_IDLE && absi(x - momo_x()) < 14) {
        // Maru walks right under Momo with her beak in the air
        G.pet_greeted = true;
        G.pet_pause = 50;
        plat_sfx(SFX_QUACK);
        say("Maru ignores Momo. Hmph.");
    } else if (G.pet_k != 0 && !G.pet_greeted && G.mstate == M_IDLE && absi(x - momo_x()) < 14) {
        // stop, look up and say hello; Momo is delighted
        G.pet_greeted = true;
        G.pet_pause = 90;
        G.pet_greet_t = 90;
        plat_sfx(housemates[G.pet_k].sfx);
        G.mp = clampi(G.mp + 3, 0, G.maxmp);
        popup_text(momo_x() - 20, G.my - 44, "+3 MP", COL_BLUE);
        popup_icon(momo_x(), G.my - 34, IC_HEART_FULL, 0);
        char buf[64];
        snprintf(buf, sizeof(buf), "%s says hello to %s!", housemates[G.pet_k].name, cats[G.cat].name);
        say(buf);
    }
    if (x < -30 || x > SCREEN_W + 30) {
        G.pet_k = -1;
        G.pet_timer = 1800;                // next one in ~30 s
    }
}

static void draw_ambient(uint16_t *fb, int stage, int t)
{
    const StageDef *sd = &stages[stage];
    if (sd->bg == BG_BALCONY)
        amb_flags(fb, stage_background(stage), t);
    if (stage == STG_BALCONY || stage == STG_HOME)
        draw_housemate(fb);
    if (sd->tint == TINT_EVENING) {   // evening at home: fireflies come out
        amb_fireflies(fb, t, 70, 112);
        return;
    }
    switch (sd->bg) {
        case BG_BALCONY:
            amb_butterfly(fb, t);
            amb_squirrel(fb, t);
            break;
        case BG_YAHOO:
            amb_clouds(fb, t, 2, 50);
            break;
        case BG_SF:
        case BG_PUERTORICO:
        case BG_FLORIDA:
        case BG_USVI:
        case BG_HAWAII:
        case BG_TAHITI:
            amb_birds(fb, t, 2, RGB(250, 250, 250));   // seabirds
            break;
        case BG_MEXICO:
        case BG_TEXAS:
        case BG_TAIWAN:
        case BG_HENAN:
        case BG_PARIS:
            amb_birds(fb, t, 2, RGB(60, 56, 60));
            break;
        case BG_ALASKA:
            amb_fall(fb, t, 36, 3, 6, 160, COL_WHITE, RGB(220, 230, 245), 1);   // snow
            break;
        case BG_SEATTLE:
            amb_fall(fb, t, 22, 5, 2, 150, RGB(176, 190, 212), RGB(200, 210, 226), 3);   // light drizzle
            break;
        case BG_GUATEMALA:
            amb_clouds(fb, t, 2, 40);
            for (int k = 0; k < 4; k++) {   // the volcano puffs smoke
                int age = (t + k * 45) % 180;
                int r = 3 + age / 24;
                gfx_blend(fb, 196 + age / 9 - r, 30 - age / 5 - r / 2, r * 2, r, RGB(230, 230, 236));
            }
            break;
        case BG_SHASTA: {
            // the little saucer at (200, 30) lights up for a few seconds, then rests
            int cyc = t % 720;
            if (cyc >= 200)
                break;
            for (int k = 0; k < 5; k++) {
                bool on = ((t / 8 + k) % 3) == 0;
                gfx_fill(fb, 189 + k * 5, 32, 2, 2, on ? RGB(255, 240, 120) : RGB(255, 90, 90));
            }
            for (int k = 0; k < 3; k++) {
                int y = 35 + (t / 2 + k * 5) % 14;
                int half = 4 + (y - 35) * 5 / 14;
                gfx_blend(fb, 200 - half, y, half * 2, 1, RGB(220, 255, 230));
            }
            break;
        }
        case BG_AMAZON:
            amb_sloth(fb, t);
            break;
        case BG_MACHUPICCHU:
            amb_llama(fb, t);
            amb_birds(fb, t, 1, RGB(40, 40, 44));   // a condor gliding
            break;
        case BG_JAPAN:
            amb_clouds(fb, t, 2, 40);
            amb_fall(fb, t, 18, 2, 10, 160, RGB(255, 200, 220), RGB(255, 225, 235), 1);   // sakura petals
            break;
    }
}

static void render_stage_top(uint16_t *fb)
{
    gfx_copy(fb, stage_background(G.stage));
    draw_ambient(fb, G.stage, (int)G.frame);

    int tgt = -1;
    if (G.mstate == M_IDLE || G.mstate == M_WALK)
        tgt = find_target(skill_range(G.sel));
    num_labels = 0;

    // depth sort people (and Momo when she's down on the path) by feet y
    int order[MAX_PEOPLE], n = 0;
    for (int i = 0; i < MAX_PEOPLE; i++)
        if (G.people[i].active)
            order[n++] = i;
    for (int i = 1; i < n; i++)
        for (int j = i; j > 0 && G.people[order[j]].y < G.people[order[j - 1]].y; j--) {
            int tmp = order[j];
            order[j] = order[j - 1];
            order[j - 1] = tmp;
        }

    int flags;
    int frame = momo_frame(&flags);
    int mx = momo_x();
    if (G.hurt_t > 0 && (G.hurt_t / 3) % 2)
        flags |= SPR_WHITE;
    bool momo_drawn = false;
    if (G.mstate == M_HIDE) {
        // ducked behind the fence: only the ears and eyes peek over
        gfx_clip_bottom(G.my + 1);
        draw_cat(fb, CF_SIT0, mx, G.my + 22, 0, 1);
        gfx_clip_bottom(SCREEN_H);
        momo_drawn = true;
    } else if (!G.ground) {
        draw_cat(fb, frame, mx + ((G.mstate == M_ACT && G.act == SK_PURR) ? (G.frame % 2) : 0), G.my, flags, 1);
        momo_drawn = true;
    }
    for (int k = 0; k < n; k++) {
        Person *p = &G.people[order[k]];
        if (!momo_drawn && p->y > G.my) {
            draw_cat(fb, frame, mx, G.my, flags, 1);
            momo_drawn = true;
        }
        bool marked = order[k] == tgt;
        if (tgt >= 0 && skills[G.sel].area && p->state == P_WALK && !p->done &&
            absi(px(p) - mx) < skill_range(G.sel))
            marked = true;
        draw_person(fb, p, marked, order[k] == tgt);
    }
    if (!momo_drawn)
        draw_cat(fb, frame, mx, G.my, flags, 1);
    draw_momo_effects(fb, mx, G.my);
    draw_pops(fb);

    if (G.flash_t > 0)
        gfx_blend(fb, 0, 0, SCREEN_W, SCREEN_H, COL_WHITE);

    // love counter in the corner
    char buf[24];
    snprintf(buf, sizeof(buf), "%d/%d", G.love, G.goal);
    gfx_panel(fb, 2, 2, 20 + gfx_text_width(buf, 1), 14, RGB(255, 245, 235), COL_INK);
    draw_icon(fb, IC_HEART_FULL, 11, 4);
    gfx_text(fb, 19, 5, buf, COL_INK);
}

static void render_hud(uint16_t *fb)
{
    char buf[48];
    gfx_copy(fb, BGIMG(BG_PANEL));
    gfx_panel(fb, 2, 2, 252, 38, RGB(255, 250, 240), COL_INK);
    snprintf(buf, sizeof(buf), "%s  Lv%d", cats[G.cat].name, G.lv);
    gfx_text(fb, 8, 6, buf, COL_INK);
    int lx = 8 + gfx_text_width(buf, 1) + 6;
    for (int k = 0; k < G.lives; k++)
        draw_icon(fb, IC_PAW, lx + 3 + k * 8, 6);
    if (G.points > 0 && (G.frame / 20) % 2)
        gfx_text(fb, lx + 30, 6, "+SP!", COL_RED);
    draw_icon(fb, IC_HEART_FULL, 196, 5);
    snprintf(buf, sizeof(buf), "%d/%d", G.love, G.goal);
    gfx_text(fb, 208, 6, buf, COL_INK);

    draw_icon(fb, IC_HP, 12, 18);
    gfx_bar(fb, 20, 17, 100, 8, G.hp, G.maxhp, COL_RED, RGB(90, 40, 40));
    snprintf(buf, sizeof(buf), "%3d", G.hp);
    gfx_text(fb, 122, 17, buf, COL_INK);
    draw_icon(fb, IC_MP, 160, 18);
    gfx_bar(fb, 168, 17, 56, 8, G.mp, G.maxmp, COL_BLUE, RGB(40, 50, 90));
    snprintf(buf, sizeof(buf), "%d", G.mp);
    gfx_text(fb, 228, 17, buf, COL_INK);
    gfx_text(fb, 8, 29, "XP", COL_GRAY);
    gfx_bar(fb, 26, 30, 226, 5, G.xp, xp_need(), COL_YELLOW, RGB(90, 80, 50));
}

static void render_play_bottom(uint16_t *fb)
{
    char buf[48];
    render_hud(fb);

    for (int sk = 0; sk < SK_ACTIVE; sk++) {
        int col = sk / 5, row = sk % 5;
        int x = 2 + col * 127, y = 44 + row * 16;
        bool locked = G.skill_lv[sk] <= 0;
        bool sel = sk == G.sel;
        int cost = skill_cost(sk);
        uint16_t fill = sel ? RGB(255, 214, 120) : RGB(255, 250, 240);
        gfx_panel(fb, x, y, 125, 15, fill, sel ? COL_ORANGE : RGB(200, 180, 160));
        if (locked) {
            gfx_text(fb, x + 4, y + 4, skills[sk].name, RGB(180, 170, 160));
            gfx_text(fb, x + 100, y + 4, "--", RGB(180, 170, 160));
            continue;
        }
        gfx_text(fb, x + 4, y + 4, skills[sk].name, COL_INK);
        if (cost == 0)
            snprintf(buf, sizeof(buf), "FREE");
        else
            snprintf(buf, sizeof(buf), "%2d", cost);
        gfx_text(fb, x + 121 - gfx_text_width(buf, 1), y + 4, buf, G.mp >= cost ? COL_BLUE : COL_RED);
        for (int k = 0; k < G.skill_lv[sk]; k++)
            gfx_fill(fb, x + 4 + k * 4, y + 12, 3, 2, COL_ORANGE);
    }

    // target info (Cat Eye)
    gfx_panel(fb, 2, 126, 252, 32, RGB(255, 250, 240), COL_INK);
    int tgt = find_target(skill_range(G.sel));
    draw_icon(fb, IC_EYE, 12, 130);
    if (tgt >= 0) {
        const Person *tp = &G.people[tgt];
        const ArchDef *a = &archs[tp->arch];
        int eye = G.skill_lv[SK_EYE];
        int res = p_resist(tp);
        bool secret = p_weak(tp) == SK_ANY;
        snprintf(buf, sizeof(buf), "%s", secret && eye < 3 ? "???" : pname(tp));
        int nx = gfx_text(fb, 22, 130, buf, COL_INK);
        if (tp->npc >= 0) {
            snprintf(buf, sizeof(buf), " (%s)", a->name);
            gfx_text(fb, nx, 130, buf, RGB(150, 130, 120));
        }
        if (eye >= 1) {
            const char *mood = secret ? "Mystery" : res < 30 ? "Friendly" : res < 60 ? "Neutral" : "Cold";
            gfx_text(fb, 8, 142, mood, secret ? COL_PURPLE : res < 30 ? COL_GREEN : res < 60 ? COL_ORANGE : COL_RED);
        }
        if (eye >= 2 && !secret) {
            static const char *likes[] = { "Food", "Pets", "Brush", "Photo", "Rub" };
            snprintf(buf, sizeof(buf), "Likes:%s", likes[p_likes(tp)]);
            gfx_text(fb, 80, 142, buf, COL_INK);
        }
        if (eye >= 3) {
            bool parent = tp->arch == PK_EVANS || tp->arch == PK_SHANNON;
            // weakness in red, spelled out in full (e.g. "Food Paw")
            snprintf(buf, sizeof(buf), "%s", secret ? (parent ? "Jump!" : "Anything") : skills[p_weak(tp)].name);
            gfx_text(fb, 252 - gfx_text_width(buf, 1), 142, buf, COL_RED);
        }
        if (eye >= 4 && !skills[G.sel].self) {
            snprintf(buf, sizeof(buf), "%d%%", success_chance(tp, G.sel));
            gfx_fill(fb, 216, 129, 36, 10, RGB(255, 250, 240));
            gfx_text(fb, 250 - gfx_text_width(buf, 1), 130, buf, COL_BLUE);
        }
        if (eye < 2)
            gfx_text(fb, 80, 142, "Cat Eye Lv2: more", RGB(170, 150, 140));
    } else {
        gfx_text(fb, 22, 130, "No human in range", RGB(170, 150, 140));
        gfx_text(fb, 8, 142, "Walk along the fence: < >", RGB(170, 150, 140));
    }

    // message line + buttons
    gfx_panel(fb, 2, 160, 252, 12, RGB(60, 40, 36), COL_INK);
    int split = 0;
    if (G.msg_t > 0) {
        // word-wrap: first line up to 31 chars, the rest on a second line
        char line[33];
        int len = (int)strlen(G.msg);
        split = len;
        if (len > 31) {
            split = 31;
            while (split > 0 && G.msg[split] != ' ')
                split--;
            if (split == 0)
                split = 31;
        }
        snprintf(line, sizeof(line), "%.*s", split, G.msg);
        gfx_text(fb, 5, 162, line, COL_CREAM);
    } else {
        gfx_text(fb, 5, 162, skills[G.sel].name, COL_YELLOW);
    }
    if (G.msg_t > 0 && split < (int)strlen(G.msg)) {
        gfx_panel(fb, 2, 172, 184, 18, RGB(60, 40, 36), COL_INK);
        char line[24];
        const char *rest = G.msg + split;
        while (*rest == ' ')
            rest++;
        snprintf(line, sizeof(line), "%s", rest);
        gfx_text(fb, 5, 177, line, COL_CREAM);
    } else {
        gfx_text(fb, 4, 180, "A:Use B:Hide <>:Walk", COL_INK);
    }
    gfx_panel(fb, 188, 174, 66, 16, G.points ? RGB(255, 214, 120) : RGB(255, 250, 240), COL_ORANGE);
    gfx_text(fb, 194, 178, "X:Skill", COL_INK);
}

static void render_skills_bottom(uint16_t *fb)
{
    char buf[40];
    gfx_copy(fb, BGIMG(BG_PANEL));
    gfx_panel(fb, 2, 2, 252, 22, RGB(255, 250, 240), COL_INK);
    gfx_text(fb, 8, 9, "SKILL TREE", COL_ORANGE);
    snprintf(buf, sizeof(buf), "Points: %d", G.points);
    gfx_text(fb, 248 - gfx_text_width(buf, 1), 9, buf, G.points ? COL_RED : COL_INK);
    for (int sk = 0; sk < SK_COUNT; sk++) {
        int y = 26 + sk * 11;
        bool sel = sk == G.menu_sel;
        if (sel)
            gfx_fill(fb, 2, y, 252, 11, RGB(255, 214, 120));
        gfx_text(fb, 8, y + 2, skills[sk].name, G.skill_lv[sk] ? COL_INK : RGB(170, 150, 140));
        for (int k = 0; k < skills[sk].max_lv; k++) {
            uint16_t c = k < G.skill_lv[sk] ? COL_ORANGE : RGB(220, 200, 180);
            gfx_fill(fb, 110 + k * 9, y + 2, 7, 7, COL_INK);
            gfx_fill(fb, 111 + k * 9, y + 3, 5, 5, c);
        }
        if (skills[sk].cost) {
            snprintf(buf, sizeof(buf), "%dMP", skills[sk].cost);
            gfx_text(fb, 160, y + 2, buf, COL_BLUE);
        }
        if (sel && G.points > 0 && G.skill_lv[sk] < skills[sk].max_lv)
            gfx_text_outline(fb, 216, y + 2, "+ A", COL_WHITE, COL_RED, 1);
    }
    gfx_panel(fb, 2, 148, 252, 30, RGB(255, 250, 240), COL_INK);
    gfx_text(fb, 6, 151, skills[G.menu_sel].desc, COL_INK);
    gfx_text(fb, 4, 181, "A:Learn  B:Back", COL_INK);
    gfx_panel(fb, 188, 178, 66, 13, RGB(255, 250, 240), COL_ORANGE);
    gfx_text(fb, 198, 181, "Back", COL_INK);
}

// --------------------------------------------------------------------------
// Screens
// --------------------------------------------------------------------------

static void render_title(uint16_t *top, uint16_t *bot)
{
    gfx_copy(top, BGIMG(BG_TITLE));
    int k = (G.frame / 20) % 12;
    G.cat = G.cat < CAT_KINDS ? G.cat : 0;
    int save = G.cat;
    G.cat = 0;
    draw_cat(top, (G.frame % 200) < 8 ? CF_BLINK : k < 7 ? CF_SIT0 : CF_SIT1, 196, 113, SPR_FLIP, 1);
    G.cat = save;
    int bounce = (G.frame / 8) % 2;
    gfx_text_center(top, 128, 18 + bounce, "MOMO", RGB(255, 170, 60), COL_INK, 4);
    gfx_text_center(top, 128, 56, "DEV STORY", COL_WHITE, COL_INK, 2);
    if ((G.frame / 30) % 2)
        gfx_text_center(top, 128, 176, "PRESS START", COL_YELLOW, COL_INK, 1);

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 16, 24, 224, 70, RGB(255, 250, 240), COL_INK);
    gfx_text_center(bot, 128, 32, "A cat's guide to", COL_INK, RGB(255, 250, 240), 1);
    gfx_text_center(bot, 128, 44, "charming humans", COL_INK, RGB(255, 250, 240), 1);
    draw_icon(bot, IC_HEART_FULL, 100, 62);
    draw_icon(bot, IC_HEART_HALF, 128, 62);
    draw_icon(bot, IC_HEART_EMPTY, 156, 62);
    gfx_text_center(bot, 128, 78, "Meow. Blink. Belly up.", COL_ORANGE, RGB(255, 250, 240), 1);
    gfx_text_center(bot, 128, 112, "START / A / Tap: play", COL_INK, RGB(252, 240, 220), 1);
    gfx_text_center(bot, 128, 128, "SELECT: ranking", COL_INK, RGB(252, 240, 220), 1);
    gfx_text_center(bot, 128, 160, "Momo Dev Story", RGB(150, 120, 100), RGB(252, 240, 220), 1);
    gfx_text_center(bot, 128, 172, "2026.10.26", RGB(150, 120, 100), RGB(252, 240, 220), 1);
}

static const char *intro_lines[] = {
    "One sunny morning in\nCalifornia...",
    "...a little orange cat\npacked a tiny bindle.",
    "Momo was setting off on\na GREAT ADVENTURE!",
    "(To the balcony fence.\n It's a big world.)",
    "Humans walk by all day.\nEvery one is a chance...",
    "...for snacks, pets, and\nmaybe a back massage.",
};

static void render_intro(uint16_t *top, uint16_t *bot)
{
    int t = G.t;
    int save = G.cat;
    G.cat = 0;
    if (t < 300) {
        gfx_copy(top, BGIMG(BG_INTRO));
        int x = t < 180 ? -20 + t * 148 / 180 : 128;
        if (t < 180)
            draw_cat(top, CF_ADV0 + (t / 7) % 4, x, 176, 0, 1);
        else {
            draw_cat(top, CF_ADVSIT, x, 176, 0, 1);
            if ((t / 10) % 2)
                draw_icon(top, IC_SPARKLE, x + 16, 140);
        }
    } else {
        gfx_copy(top, BGIMG(BG_BALCONY));
        int u = t - 300;
        if (u < 120) {
            int x = 270 - u * 130 / 120;
            draw_cat(top, CF_ADV0 + (u / 7) % 4, x, 184, SPR_FLIP, 1);
        } else if (u < 150) {
            int s = u - 120, T = 30;
            int x = 140 - s * 10 / T;
            int y = 184 + (113 - 184) * s / T - s * (T - s) / 6;
            draw_cat(top, CF_JUMP, x, y, SPR_FLIP, 1);
        } else {
            draw_cat(top, u < 300 ? CF_ADVSIT : ((G.frame / 20) % 2 ? CF_SIT0 : CF_SIT1), 130, 113, 0, 1);
            if (u > 300) {
                // a cat lover walks by and notices
                int px2 = -20 + (u - 300) * 7 / 10;
                if (px2 > 110)
                    px2 = 110;
                const uint8_t *spr = &person_px[(PK_CATLOVER * PF_COUNT + (px2 < 110 ? PF_WALK0 + (u / 8) % 4 : PF_REACH)) * PERSON_W * PERSON_H];
                static uint16_t pal[16];
                if (!pal[1]) {
                    G.people[0].arch = PK_CATLOVER;
                    person_palette(&G.people[0]);
                    memcpy(pal, G.people[0].pal, sizeof(pal));
                }
                gfx_sprite(top, spr, PERSON_W, PERSON_H, px2 - 12, 184 - 48, pal, 0, 1);
                if (px2 >= 110) {
                    draw_icon(top, IC_HEART_FULL, px2, 120 + (G.frame / 10) % 2);
                    draw_bubble(top, 128, 72, "Meow~");
                }
            }
        }
        if (t > 700) {
            int a = t - 700;
            int y = a < 30 ? -40 + a * 2 : 20;
            gfx_text_center(top, 128, y, "MOMO", RGB(255, 170, 60), COL_INK, 4);
            if (a > 30)
                gfx_text_center(top, 128, 56, "DEV STORY", COL_WHITE, COL_INK, 2);
        }
    }
    G.cat = save;

    gfx_copy(bot, BGIMG(BG_PANEL));
    int line = clampi(t / 140, 0, 5);
    int shown = (t % 140) / 2;
    char buf[64];
    snprintf(buf, sizeof(buf), "%s", intro_lines[line]);
    if (shown < (int)strlen(buf))
        buf[shown] = 0;
    gfx_panel(bot, 8, 60, 240, 40, RGB(255, 250, 240), COL_INK);
    gfx_text(bot, 18, 70, buf, COL_INK);
    gfx_text_center(bot, 128, 176, "START: skip", RGB(150, 120, 100), RGB(252, 240, 220), 1);
}

static void render_select(uint16_t *top, uint16_t *bot)
{
    gfx_copy(top, BGIMG(BG_SELECT));
    gfx_text_center(top, 128, 6, "Choose your adventurer!", COL_WHITE, COL_INK, 1);
    int save = G.cat;
    static const int cx[3] = { 48, 128, 208 };
    for (int c = 0; c < 3; c++) {
        G.cat = c;
        bool sel = c == G.menu_sel;
        int f = CF_SIT0;
        if (sel) {
            int k = (G.frame / 16) % 8;
            f = k == 0 ? CF_MEOW : k < 4 ? CF_SIT1 : k == 5 ? CF_HAPPY : CF_SIT2;
        } else if ((G.frame + c * 70) % 200 < 8) {
            f = CF_BLINK;
        }
        draw_cat(top, f, cx[c], 164 - (sel ? (G.frame / 8) % 2 : 0), 0, 2);
        uint16_t nc = sel ? COL_YELLOW : COL_WHITE;
        gfx_text_center(top, cx[c], 180, cats[c].name, nc, COL_INK, 1);
        if (sel)
            draw_icon(top, IC_ARROW, cx[c], 86 + (G.frame / 10) % 2 * 2);
    }
    G.cat = save;

    gfx_copy(bot, BGIMG(BG_PANEL));
    const CatDef *cd = &cats[G.menu_sel];
    gfx_panel(bot, 8, 8, 240, 110, RGB(255, 250, 240), COL_INK);
    gfx_text_outline(bot, 18, 16, cd->name, COL_ORANGE, COL_INK, 2);
    gfx_text(bot, 18, 38, cd->breed, COL_INK);
    gfx_text(bot, 18, 54, cd->perk, COL_INK);
    char buf[32];
    snprintf(buf, sizeof(buf), "HP %3d", cd->hp);
    gfx_text(bot, 18, 82, buf, COL_RED);
    gfx_bar(bot, 76, 82, 160, 8, cd->hp, 120, COL_RED, RGB(90, 40, 40));
    snprintf(buf, sizeof(buf), "MP %3d", cd->mp);
    gfx_text(bot, 18, 98, buf, COL_BLUE);
    gfx_bar(bot, 76, 98, 160, 8, cd->mp, 60, COL_BLUE, RGB(40, 50, 90));
    for (int c = 0; c < 3; c++) {
        bool sel = c == G.menu_sel;
        gfx_panel(bot, 6 + c * 83, 150, 78, 24, sel ? RGB(255, 214, 120) : RGB(255, 250, 240), sel ? COL_ORANGE : RGB(200, 180, 160));
        gfx_text_center(bot, 45 + c * 83, 158, cats[c].name, COL_INK, sel ? RGB(255, 214, 120) : RGB(255, 250, 240), 1);
    }
    gfx_text_center(bot, 128, 132, "< > choose   A: GO!", COL_INK, RGB(252, 240, 220), 1);
}

static void render_card(uint16_t *top, uint16_t *bot)
{
    const StageDef *sd = &stages[G.stage];
    gfx_copy(top, stage_background(G.stage));
    gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
    if (G.round > 1) {
        char rb[24];
        snprintf(rb, sizeof(rb), "ROUND %d", G.round);
        gfx_text_center(top, 128, 24, rb, COL_RED, COL_WHITE, 2);
    }
    gfx_text_center(top, 128, 50, sd->name, COL_YELLOW, COL_INK, 2);
    gfx_text_center(top, 128, 76, sd->place, COL_WHITE, COL_INK, 2);
    draw_cat(top, (G.frame / 20) % 2 ? CF_SIT0 : CF_SIT1, 128, 150, 0, 1);

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 8, 240, 50, RGB(255, 250, 240), COL_INK);
    gfx_text(bot, 16, 16, sd->story, COL_INK);
    char buf[48];
    gfx_panel(bot, 8, 64, 240, 80, RGB(255, 250, 240), COL_INK);
    set_difficulty();
    snprintf(buf, sizeof(buf), "GOAL: collect %d love", G.goal);
    gfx_text(bot, 16, 72, buf, COL_RED);
    draw_icon(bot, IC_HEART_FULL, 22, 88);
    gfx_text(bot, 32, 88, "+3", COL_INK);
    draw_icon(bot, IC_HEART_HALF, 82, 88);
    gfx_text(bot, 92, 88, "+2", COL_INK);
    draw_icon(bot, IC_HEART_EMPTY, 142, 88);
    gfx_text(bot, 152, 88, "+1", COL_INK);
    draw_icon(bot, IC_EXCLAIM, 202, 86);
    gfx_text(bot, 210, 88, "-HP", COL_RED);
    gfx_text(bot, 16, 104, "Food = HP, Attention = MP", COL_INK);
    gfx_text(bot, 16, 116, "HP drains. Don't starve!", COL_INK);
    gfx_text(bot, 16, 128, "Cat Eye reveals weakness.", COL_INK);
    if (G.stage >= STG_DEST0) {
        int stars = clampi(1 + (count_visited() + (G.stage == STG_HOME ? 4 : 0)) / 3, 1, 5);
        gfx_text(bot, 16, 148, "Difficulty:", COL_INK);
        for (int k = 0; k < 5; k++)
            draw_icon(bot, k < stars ? IC_HEART_FULL : IC_HEART_EMPTY, 116 + k * 14, 148);
    }
    if ((G.frame / 30) % 2)
        gfx_text_center(bot, 128, 164, "Press A to start", COL_ORANGE, RGB(252, 240, 220), 1);
}

static void render_hearts_rain(uint16_t *fb)
{
    for (int i = 0; i < 18; i++) {
        int x = (i * 53 + 17) % SCREEN_W;
        int y = (int)((G.frame * (1 + i % 3) + i * 37) % (SCREEN_H + 20)) - 10;
        draw_icon(fb, i % 3 == 0 ? IC_HEART_FULL : i % 3 == 1 ? IC_HEART_HALF : IC_SPARKLE, x, y);
    }
}

static void render_clear(uint16_t *top, uint16_t *bot)
{
    const StageDef *sd = &stages[G.stage];
    gfx_copy(top, stage_background(G.stage));
    gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, RGB(255, 200, 220));
    render_hearts_rain(top);
    gfx_text_center(top, 128, 30, "STAGE CLEAR!", COL_YELLOW, COL_INK, 2);
    draw_cat(top, (G.frame / 16) % 2 ? CF_HAPPY : CF_BLISS, 128, 150, 0, 2);

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 8, 240, 136, RGB(255, 250, 240), COL_INK);
    char buf[48];
    snprintf(buf, sizeof(buf), "%s - %s", sd->name, sd->place);
    gfx_text(bot, 16, 16, buf, COL_ORANGE);
    snprintf(buf, sizeof(buf), "Humans charmed: %d", G.charmed);
    gfx_text(bot, 16, 36, buf, COL_INK);
    draw_icon(bot, IC_HEART_FULL, 22, 54);
    snprintf(buf, sizeof(buf), "x %d", G.stats[HQ_FULL]);
    gfx_text(bot, 34, 55, buf, COL_INK);
    draw_icon(bot, IC_HEART_HALF, 92, 54);
    snprintf(buf, sizeof(buf), "x %d", G.stats[HQ_HALF]);
    gfx_text(bot, 104, 55, buf, COL_INK);
    draw_icon(bot, IC_HEART_EMPTY, 162, 54);
    snprintf(buf, sizeof(buf), "x %d", G.stats[HQ_EMPTY]);
    gfx_text(bot, 174, 55, buf, COL_INK);
    draw_icon(bot, IC_EXCLAIM, 22, 70);
    snprintf(buf, sizeof(buf), "x %d  awkward moments", G.stats[HQ_FAIL]);
    gfx_text(bot, 34, 73, buf, COL_INK);
    snprintf(buf, sizeof(buf), "Level %d   Love %d", G.lv, G.love);
    gfx_text(bot, 16, 96, buf, COL_INK);
    if (G.devdad_seen)
        gfx_text(bot, 16, 116, "Secret: met Uncle Dev!", COL_PURPLE);
    if (G.t > 60 && (G.frame / 30) % 2)
        gfx_text_center(bot, 128, 164, "Press A", COL_ORANGE, RGB(252, 240, 220), 1);
}

static void render_gameover(uint16_t *top, uint16_t *bot)
{
    gfx_copy(top, stage_background(G.stage));
    gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
    gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
    gfx_text_center(top, 128, 40, "GAME OVER", COL_RED, COL_INK, 2);
    draw_cat(top, CF_SLEEP, 128, 150, 0, 2);
    if ((G.frame / 30) % 2)
        draw_icon(top, IC_ZZZ, 160, 90);

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 30, 240, 60, RGB(255, 250, 240), COL_INK);
    char buf[96];
    snprintf(buf, sizeof(buf), "%s got too hungry and\nfell asleep on the fence...", cats[G.cat].name);
    gfx_text(bot, 16, 40, buf, COL_INK);
    gfx_text(bot, 16, 68, "Tip: FEED fans restore HP!", COL_ORANGE);
    snprintf(buf, sizeof(buf), "Lives left: %d", G.lives);
    gfx_text_center(bot, 128, 100, buf, G.lives ? COL_INK : COL_RED, RGB(252, 240, 220), 1);
    for (int k = 0; k < G.lives; k++)
        draw_icon(bot, IC_PAW, 110 + k * 14, 112);
    if (G.t > 60) {
        if (G.lives > 0) {
            gfx_text_center(bot, 128, 132, "A: Try again", COL_INK, RGB(252, 240, 220), 1);
            gfx_text_center(bot, 128, 148, "B: Give up (see score)", COL_INK, RGB(252, 240, 220), 1);
        } else {
            gfx_text_center(bot, 128, 132, "No lives left...", COL_RED, RGB(252, 240, 220), 1);
            gfx_text_center(bot, 128, 148, "A: See your score", COL_INK, RGB(252, 240, 220), 1);
        }
    }
}

static void draw_human(uint16_t *fb, int arch, int pose, int x, int feet, bool flip)
{
    static uint16_t pals[PK_COUNT][16];
    static bool ready[PK_COUNT];
    if (!ready[arch]) {
        Person tmp;
        memset(&tmp, 0, sizeof(tmp));
        tmp.arch = arch;
        uint32_t save = G.rng;
        person_palette(&tmp);
        G.rng = save;
        memcpy(pals[arch], tmp.pal, sizeof(tmp.pal));
        ready[arch] = true;
    }
    const uint8_t *spr = &person_px[(arch * PF_COUNT + pose) * PERSON_W * PERSON_H];
    gfx_blend(fb, x - 7, feet - 1, 14, 2, RGB(60, 60, 60));
    gfx_sprite(fb, spr, PERSON_W, PERSON_H, x - 12, feet - 48, pals[arch], flip ? SPR_FLIP : 0, 1);
}

static void render_rescue(uint16_t *top, uint16_t *bot)
{
    int t = G.t;
    int mx = momo_x();
    int fy = stages[G.stage].fence_y;
    gfx_copy(top, stage_background(G.stage));

    // Evans stands just below Momo, Shannon next to him
    int side = mx < 70 ? 1 : -1;            // which side they stand on
    int ex = clampi(mx + side * 14, 14, 242);
    int sx = clampi(ex + side * 26, 10, 246);
    int start = side < 0 ? -30 : SCREEN_W + 30;
    int walk = t < 90 ? t : 90;
    int ecur = start + (ex - start) * walk / 90;
    int scur = start + (sx - start) * clampi(t - 12, 0, 90) / 90;
    bool leaving = t > 270;
    if (leaving) {
        ecur = ex + (start - ex) * (t - 270) / 60;
        scur = sx + (start - sx) * (t - 270) / 60;
    }
    bool e_face = leaving ? (start > ex) : (mx > ecur);   // sprites face right
    bool s_face = leaving ? (start > sx) : (mx > scur);
    int epose = (t < 90 || leaving) ? PF_WALK0 + (t / 8) % 4 : (t / 10) % 3 ? PF_REACH : PF_STAND;
    int spose = (t < 102 || leaving) ? PF_WALK0 + (t / 8) % 4 : (t / 12) % 4 ? PF_REACH : PF_STAND;

    int cf = t < 110 ? CF_SLEEP : t < 200 ? ((t / 16) % 2 ? CF_HAPPY : CF_BLISS) : t < 240 ? CF_MEOW : CF_HAPPY;
    draw_cat(top, cf, mx, fy, 0, 1);
    if (t < 110 && (t / 20) % 2)
        draw_icon(top, IC_ZZZ, mx + 14, fy - 30);

    draw_human(top, PK_SHANNON, spose, scur, 186, !s_face);
    draw_human(top, PK_EVANS, epose, ecur, 182, !e_face);

    if (t >= 100 && t < 270) {
        draw_icon(top, IC_HAND, mx - side * 2, fy - 30 + (t / 6) % 2 * 2);
        if ((t / 10) % 2)
            gfx_text_outline(top, mx - 28, fy - 46, "pat pat", COL_YELLOW, COL_INK, 1);
        draw_icon(top, IC_FISH, mx + side * 14, fy - 14 + (t / 8) % 2);
        for (int k = 0; k < 4; k++) {
            int hy = fy - 20 - ((t * 2 + k * 23) % 60);
            draw_icon(top, k & 1 ? IC_HEART_FULL : IC_HEART_HALF, mx - 24 + k * 16, hy);
        }
    }
    num_labels = 0;
    if (t > 50 && t < 140)
        draw_bubble(top, scur, 120, "MOMO!!");
    if (t >= 140 && t < 210)
        draw_bubble(top, ecur, 118, "Dinner time, buddy!");
    if (t >= 210 && t < 280)
        draw_bubble(top, scur, 120, "Don't scare us like that!");
    gfx_text_center(top, 128, 8, "RESCUE!", COL_YELLOW, COL_INK, 2);

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 8, 240, 92, RGB(255, 250, 240), COL_INK);
    gfx_text(bot, 16, 16, "Dad Evans and Mom Shannon", COL_ORANGE);
    gfx_text(bot, 16, 28, "came running to save", COL_INK);
    gfx_text(bot, 16, 40, "their sleepy, hungry cat!", COL_INK);
    gfx_text(bot, 16, 60, "Snacks + back pats =", COL_INK);
    gfx_text(bot, 16, 72, "FULL HP and MP!", COL_RED);
    gfx_text(bot, 16, 86, "(This only happens once...)", RGB(150, 120, 100));
    int fill = clampi((t - 140) * 100 / 70, 0, 100);
    int hp = G.maxhp * fill / 100, mp = G.maxmp * fill / 100;
    draw_icon(bot, IC_HP, 20, 113);
    gfx_bar(bot, 30, 112, 200, 9, hp, G.maxhp, COL_RED, RGB(90, 40, 40));
    draw_icon(bot, IC_MP, 20, 129);
    gfx_bar(bot, 30, 128, 200, 9, mp, G.maxmp, COL_BLUE, RGB(40, 50, 90));
    if (t > 200 && (G.frame / 30) % 2)
        gfx_text_center(bot, 128, 164, "Press A to continue", COL_ORANGE, RGB(252, 240, 220), 1);
}

// The car faces right; flip it to drive leftwards.
static void draw_car(uint16_t *fb, int cx, int feet, bool momo, bool flip)
{
    int f = (momo ? 2 : 0) + (G.frame / 3) % 2;
    gfx_blend(fb, cx - 28, feet - 2, 56, 3, RGB(40, 40, 40));
    gfx_sprite(fb, &car_px[f * CAR_W * CAR_H], CAR_W, CAR_H, cx - 32, feet - CAR_H, car_pal, flip ? SPR_FLIP : 0, 1);
}

static void draw_bolt(uint16_t *fb, int x0, int y0, int x1, int y1, uint32_t seed)
{
    uint32_t r = seed * 2654435761u + 1;
    int px0 = x0, py0 = y0;
    for (int k = 1; k <= 6; k++) {
        r ^= r << 13;
        r ^= r >> 17;
        r ^= r << 5;
        int nx = x0 + (x1 - x0) * k / 6 + (k < 6 ? (int)(r % 17) - 8 : 0);
        int ny = y0 + (y1 - y0) * k / 6;
        gfx_line(fb, px0, py0, nx, ny, COL_WHITE);
        gfx_line(fb, px0 + 1, py0, nx + 1, ny, RGB(140, 230, 255));
        px0 = nx;
        py0 = ny;
    }
}

static void draw_fire_trail(uint16_t *fb, int x0, int x1, int y)
{
    // twin trails of fire left on the road by the tyres
    for (int x = x0; x < x1; x += 7) {
        int fr = ((x + G.frame) / 5) & 1;
        const Sprite *f = &icons[IC_FLAME_RED0 + fr];
        int h = ((x * 7 + G.frame) % 3);
        gfx_sprite(fb, f->px, f->w, f->h, x, y - f->h - h, ui_pal, 0, 1);
        gfx_sprite(fb, f->px, f->w, f->h, x + 3, y - f->h + 4 - h, ui_pal, SPR_FLIP, 1);
    }
}

static void render_timewarp(uint16_t *top, uint16_t *bot)
{
    int t = G.t;
    static const char *lines[4] = {
        "Dad Evans rolls up in a\nvery suspicious silver car\nwith Mom Shannon...",
        "\"Hold on to your whiskers,\nMomo! We need 88 MPH!\"",
        "The flux gizmo is fluxing!\nTravelling back in time...",
        "They landed at Yahoo! HQ\nin Sunnyvale... in 2016!",
    };
    int scene;
    int fy = stages[0].fence_y;
    if (t < 150) {
        scene = 0;
        gfx_copy(top, stage_background(0));
        int cx = t < 70 ? -40 + (150 + 40) * t / 70 : 150;
        bool in_car = t >= 110;
        if (!in_car) {
            int mx = clampi(momo_x(), 50, 220);
            if (t < 80) {
                draw_cat(top, (t / 20) % 2 ? CF_SIT0 : CF_SIT1, mx, fy, 0, 1);
            } else {
                int s = t - 80, T = 30;
                int x = mx + (cx - 6 - mx) * s / T;
                int y = fy + (168 - fy) * s / T - s * (T - s) / 5;
                draw_cat(top, CF_JUMP, x, y, cx < mx ? SPR_FLIP : 0, 1);
            }
        }
        draw_car(top, cx, 188, in_car, false);
        num_labels = 0;
        if (t > 72 && t < 110)
            draw_bubble(top, cx + 10, 140, "Hop in, Momo!");
        if (t > 115)
            draw_bubble(top, cx, 140, "Next stop: 2016!");
    } else if (t < 250) {
        scene = 1;
        gfx_copy(top, stage_background(0));
        int s = t - 150;
        int cx = 150 + s * s / 26;
        draw_fire_trail(top, 150, clampi(cx - 30, 150, SCREEN_W), 188);
        draw_car(top, cx, 188, true, false);
        if ((t / 6) % 2)
            gfx_text_outline(top, 150, 30, "88 MPH", COL_YELLOW, COL_RED, 2);
        if (s > 40 && (t / 4) % 3 == 0)
            draw_bolt(top, 40 + (int)(t * 37 % 160), 0, clampi(cx, 0, 255), 168, (uint32_t)t);
        if (s > 70)
            for (int k = 0; k < (s - 70) / 8; k++)
                gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, COL_WHITE);
    } else if (t < 380) {
        scene = 2;
        int s = t - 250;
        gfx_fill(top, 0, 0, SCREEN_W, SCREEN_H, RGB(10, 14, 50));
        // streaking time tunnel
        for (int k = 0; k < 40; k++) {
            int y = (k * 37 + 11) % SCREEN_H;
            int sp = 4 + k % 5 * 3;
            int len = 20 + (k * 13) % 50;
            int x = SCREEN_W - (int)((t * sp + k * 71) % (SCREEN_W + len));
            uint16_t col = k % 3 == 0 ? COL_WHITE : k % 3 == 1 ? RGB(110, 200, 255) : RGB(60, 90, 220);
            gfx_fill(top, x, y, len, 1 + (k % 4 == 0), col);
        }
        int jig = (t % 2) * 2 - 1;
        draw_fire_trail(top, 0, 96, 130);
        draw_car(top, 128, 130 + jig, true, false);
        if ((t / 5) % 4 == 0)
            draw_bolt(top, 128 + jig * 30, 0, 128, 104, (uint32_t)t);
        int year = 2026 - clampi(s / 10, 0, 10);
        char buf[8];
        snprintf(buf, sizeof(buf), "%d", year);
        gfx_text_center(top, 128, 22, buf, year == 2016 ? COL_YELLOW : COL_WHITE, COL_INK, 4);
        if (s > 90) {
            gfx_text_center(top, 128, 156, "BACK TO 2016", COL_YELLOW, RGB(200, 40, 20), 2);
        }
        if (s < 12)
            gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, COL_WHITE);
    } else {
        scene = 3;
        int s = t - 380;
        gfx_copy(top, BGIMG(BG_YAHOO));
        int cx = s < 50 ? -40 + (128 + 40) * s / 50 : 128;
        draw_fire_trail(top, 0, clampi(cx - 34, 0, 128), 188);
        draw_car(top, cx, 188, true, false);
        for (int k = 0; k < clampi(3 - s / 10, 0, 3); k++)
            gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, COL_WHITE);
        gfx_text_center(top, 128, 30, "SUNNYVALE", COL_WHITE, COL_PURPLE, 2);
        gfx_text_center(top, 128, 52, "2016", COL_YELLOW, COL_PURPLE, 3);
        num_labels = 0;
        if (s > 55)
            draw_bubble(top, cx - 10, 142, "Is this... 2016?!");
    }

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 40, 240, 48, RGB(255, 250, 240), COL_INK);
    gfx_text(bot, 16, 48, lines[scene], COL_INK);
    gfx_text_center(bot, 128, 120, "TIME TRAVEL", COL_ORANGE, RGB(252, 240, 220), 2);
    gfx_text_center(bot, 128, 176, "START: skip", RGB(150, 120, 100), RGB(252, 240, 220), 1);
}

static int isqrt(int v)
{
    int r = 0;
    while ((r + 1) * (r + 1) <= v)
        r++;
    return r;
}

static void ring(uint16_t *fb, int cx, int cy, int r, uint16_t col)
{
    for (int y = -r; y <= r; y++) {
        int x = isqrt(r * r - y * y);
        gfx_fill(fb, cx - x, cy + y, 2, 1, col);
        gfx_fill(fb, cx + x - 1, cy + y, 2, 1, col);
    }
}

static void disc(uint16_t *fb, int cx, int cy, int r, uint16_t col)
{
    for (int y = -r; y <= r; y++) {
        int x = isqrt(r * r - y * y);
        gfx_fill(fb, cx - x, cy + y, 2 * x + 1, 1, col);
    }
}

// Cat Planet seen from space: a round head with two pointy ears.
static void draw_cat_planet(uint16_t *fb, int cx, int cy, int r)
{
    for (int side = -1; side <= 1; side += 2) {
        int ex = cx + side * r * 3 / 5, h = r * 3 / 4;
        for (int y = 0; y < h; y++) {
            int w = (r / 2) * y / h;
            gfx_fill(fb, ex - w + side * (h - y) / 4, cy - r * 3 / 5 - h + y, 2 * w + 1, 1, RGB(196, 130, 200));
        }
    }
    disc(fb, cx, cy, r, RGB(150, 214, 176));
    disc(fb, cx - r / 4, cy - r / 4, r / 2, RGB(176, 230, 196));
    if (r >= 16) {   // a sleepy face
        gfx_fill(fb, cx - r / 3 - 2, cy, 5, 1, COL_INK);
        gfx_fill(fb, cx + r / 3 - 2, cy, 5, 1, COL_INK);
        gfx_fill(fb, cx - 1, cy + r / 4, 3, 2, COL_PINK);
    }
}


static void render_ending(uint16_t *top, uint16_t *bot)
{
    int t = G.t;
    static const char *lines[3] = {
        "Dad Evans and Mom Shannon\nhave a surprise for the\nhardest-working cat...",
        "\"Hold on to your whiskers!\nNext stop: Cat Planet!\"",
        "Welcome to Cat Planet,\nwhere everything is food!",
    };
    int scene;
    num_labels = 0;
    if (t < ENDING_SPACE) {
        // home: the car pulls up, everyone hops in, lift-off
        scene = 0;
        gfx_copy(top, stage_background(STG_HOME));
        int fy = stages[STG_HOME].fence_y;
        int cx = t < 60 ? -40 + (160 + 40) * t / 60 : 160;
        int feet = t < 140 ? 188 : 188 - (t - 140) * (t - 140) / 5;
        for (int k = 0; k < 2; k++) {   // parents walk in, then climb aboard
            int pk = k ? PK_SHANNON : PK_EVANS, home = k ? 70 : 100, base = k ? 186 : 182;
            int walk = clampi(t - k * 10, 0, 70);
            int x = -20 + (home + 20) * walk / 70;
            bool moving = walk < 70;
            if (t >= 110) {
                int s = clampi(t - 110 - k * 6, 0, 24);
                x = home + (cx - 8 - home) * s / 24;
                moving = s < 24;
                if (s >= 24)
                    continue;   // inside the car
            }
            draw_human(top, pk, moving ? PF_WALK0 + (t / 8) % 4 : (k && t > 70 && t < 100) ? PF_REACH : PF_STAND,
                       x, base, false);
        }
        bool in_car = t >= 110;
        if (!in_car) {
            int mx = clampi(momo_x(), 50, 220);
            if (t < 80) {
                draw_cat(top, (t / 20) % 2 ? CF_SIT0 : CF_SIT1, mx, fy, 0, 1);
            } else {
                int s = t - 80, T = 30;
                int x = mx + (cx - 6 - mx) * s / T;
                int y = fy + (168 - fy) * s / T - s * (T - s) / 5;
                draw_cat(top, CF_JUMP, x, y, cx < mx ? SPR_FLIP : 0, 1);
            }
        }
        if (t >= 140)
            for (int k = -1; k <= 1; k += 2)
                draw_icon(top, IC_FLAME_RED0 + (t / 3 + k) % 2 * 1, cx + k * 18, feet - 2);
        draw_car(top, cx, feet, in_car, false);
        if (t > 72 && t < 108)
            draw_bubble(top, 70, 124, "Vacation time, Momo!");
        if (t > 115 && t < 150)
            draw_bubble(top, cx, 124, "To Cat Planet!");
    } else if (t < ENDING_LAND) {
        // space: Earth falls behind, Cat Planet grows ahead
        scene = 1;
        int s = t - ENDING_SPACE;
        gfx_fill(top, 0, 0, SCREEN_W, SCREEN_H, RGB(14, 10, 44));
        for (int k = 0; k < 48; k++) {
            int x = (k * 89 + 13) % SCREEN_W - (s * (1 + k % 3)) / 4;
            x = ((x % SCREEN_W) + SCREEN_W) % SCREEN_W;
            int y = (k * 53 + 7) % SCREEN_H;
            if ((k + t / 10) % 7)
                gfx_fill(top, x, y, 1 + (k % 5 == 0), 1, k % 4 ? COL_WHITE : RGB(255, 230, 160));
        }
        int er = clampi(16 - s / 8, 3, 16);
        disc(top, 40 - s / 3, 40, er, RGB(60, 120, 220));
        disc(top, 40 - s / 3 - er / 3, 40 - er / 4, er / 2, RGB(80, 180, 90));
        draw_cat_planet(top, 290 - s * 3 / 4, 70, clampi(8 + s / 3, 8, 44));
        int cx = 30 + s * 3 / 4, cy = 150 - s / 3 + (t / 8) % 2;
        draw_fire_trail(top, 0, clampi(cx - 34, 0, SCREEN_W), cy);
        draw_car(top, cx, cy, true, false);
        if (s > 70)
            gfx_text_center(top, 128, 160, "CAT PLANET", COL_YELLOW, COL_PURPLE, 2);
        if (s > 108)
            gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, COL_WHITE);
    } else {
        // Cat Planet: land, hop out, feast
        scene = 2;
        int s = t - ENDING_LAND;
        gfx_copy(top, BGIMG(BG_CATPLANET));
        int cx = 30;
        int feet = s < 40 ? -10 + 198 * s / 40 : 188;
        if (s < 40)
            for (int k = -1; k <= 1; k += 2)
                draw_icon(top, IC_FLAME_RED0 + (t / 3) % 2, cx + k * 18, feet - 2);
        draw_car(top, cx, feet, s < 45, false);

        int mx = 128, mfeet = 178;
        if (s < 45) {
            // still riding in the car
        } else if (s < 75) {
            int u = s - 45, T = 30;
            draw_cat(top, CF_JUMP, cx + 6 + (mx - cx - 6) * u / T, 170 + (mfeet - 170) * u / T - u * (T - u) / 4, 0, 1);
        } else {
            int u = s - 75;
            static const uint8_t munch[8] = { CF_HAPPY, CF_HAPPY, CF_BLISS, CF_HAPPY, CF_PURR, CF_WASH0, CF_WASH1, CF_BLISS };
            draw_cat(top, munch[(u / 18) % 8], mx, mfeet, 0, 1);
            if ((u / 18) % 8 < 3)   // nom nom: little fish pop up
                draw_icon(top, IC_FISH, mx + 12 + (u % 18) / 3, mfeet - 34 - (u % 18));
        }
        for (int k = 0; k < 2; k++) {   // the parents step out and pet her
            int pk = k ? PK_SHANNON : PK_EVANS, dest = k ? 170 : 92, base = k ? 186 : 182;
            int u = clampi(s - 55 - k * 12, 0, 50);
            if (s < 55 + k * 12)
                continue;
            int x = cx + (dest - cx) * u / 50;
            int pose = u < 50 ? PF_WALK0 + (t / 8) % 4 : ((t + k * 20) / 24) % 3 ? PF_REACH : PF_STAND;
            draw_human(top, pk, pose, x, base, k && u >= 50);
        }
        if (s > 120)
            render_hearts_rain(top);
        if (s > 110 && s < 190)
            draw_bubble(top, 92, 110, "Dinner is served!");
        else if (s >= 190 && s < 270)
            draw_bubble(top, 170, 110, "Happy vacation, Momo!");
        else if (s >= 270)
            draw_bubble(top, mx, 120, "Mrrrow~");
        for (int k = 0; k < clampi(3 - s / 8, 0, 3); k++)
            gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, COL_WHITE);
    }

    gfx_copy(bot, BGIMG(BG_PANEL));
    if (t < ENDING_LAND + 110) {
        gfx_panel(bot, 8, 40, 240, 48, RGB(255, 250, 240), COL_INK);
        gfx_text(bot, 16, 48, lines[scene], COL_INK);
        gfx_text_center(bot, 128, 120, "VACATION!", COL_ORANGE, RGB(252, 240, 220), 2);
        if (t < ENDING_LAND)
            gfx_text_center(bot, 128, 176, "START: skip", RGB(150, 120, 100), RGB(252, 240, 220), 1);
        return;
    }
    gfx_panel(bot, 8, 8, 240, 120, RGB(255, 250, 240), COL_INK);
    char buf[112];
    snprintf(buf, sizeof(buf), "%s charmed %d places\naround the world. Now it's\nvacation time on Cat\nPlanet with Dad and Mom!",
             cats[G.cat].name, count_visited());
    gfx_text(bot, 16, 16, buf, COL_INK);
    gfx_text(bot, 16, 64, "Salary: unlimited treats.", COL_ORANGE);
    gfx_text(bot, 16, 76, "Benefits: daily massages.", COL_ORANGE);
    if (G.visited == (1u << NUM_DESTS) - 1)
        gfx_text_center(bot, 128, 100, "TO BE CONTINUED", COL_PURPLE, RGB(255, 250, 240), 1);
    else
        gfx_text_center(bot, 128, 100, "THE END", COL_PURPLE, RGB(255, 250, 240), 2);
    gfx_text_center(bot, 128, 134, "Starring Momo", COL_INK, RGB(252, 240, 220), 1);
    gfx_text_center(bot, 128, 145, "with Evans & Shannon", COL_INK, RGB(252, 240, 220), 1);
    gfx_text_center(bot, 128, 157, "MOMO DEV STORY 2026.10.26", COL_ORANGE, RGB(252, 240, 220), 1);
    if (G.visited == (1u << NUM_DESTS) - 1)
        gfx_text_center(bot, 128, 114, "World complete! Next round!", COL_RED, RGB(255, 250, 240), 1);
    if (t > ENDING_DONE && (G.frame / 30) % 2)
        gfx_text_center(bot, 128, 174, "Press START", COL_INK, RGB(252, 240, 220), 1);
}

static void render_buddha(uint16_t *top, uint16_t *bot)
{
    int t = G.t;
    int fy = stages[G.stage].fence_y;
    int mx = momo_x();
    gfx_copy(top, stage_background(G.stage));
    if (t < 60) {
        // something is happening... Momo trembles as golden light gathers
        draw_cat(top, CF_SHOCK, mx + (t % 2) * 2 - 1, fy, 0, 1);
        for (int k = 0; k < t / 15; k++)
            gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, RGB(255, 220, 120));
        if (t > 44)
            gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, COL_WHITE);
    } else {
        int u = t - 60;
        gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, RGB(120, 70, 20));
        int scale = u < 60 ? 1 : u < 130 ? 2 : 3;
        int lift = clampi(u, 0, 160);
        int cx = mx + (128 - mx) * clampi(u, 0, 120) / 120;
        int feet = fy + (164 - fy) * clampi(u - 40, 0, 120) / 120 - (scale == 1 ? lift / 4 : 0);
        int hy = feet - 32 * scale + 10 * scale;   // head centre
        // holy rays
        static const int8_t dx[16] = { 0, 49, 90, 117, 127, 117, 90, 49, 0, -49, -90, -117, -127, -117, -90, -49 };
        static const int8_t dy[16] = { -127, -117, -90, -49, 0, 49, 90, 117, 127, 117, 90, 49, 0, -49, -90, -117 };
        for (int k = 0; k < 16; k++) {
            int a = (k + u / 8) % 16;
            gfx_line(top, cx, hy, cx + dx[a] * 2, hy + dy[a] * 2, k & 1 ? RGB(255, 230, 140) : RGB(255, 200, 90));
        }
        // halo
        ring(top, cx, hy, 14 * scale, RGB(255, 236, 160));
        ring(top, cx, hy, 14 * scale + 3, RGB(255, 210, 110));
        // golden clouds drifting at the bottom
        for (int k = 0; k < 6; k++) {
            int x = (k * 53 + u) % (SCREEN_W + 60) - 30;
            gfx_fill(top, x, 172 + (k % 2) * 6, 44, 10, RGB(250, 214, 130));
            gfx_fill(top, x + 6, 168 + (k % 2) * 6, 30, 6, RGB(255, 232, 170));
        }
        int f = (u / 20) % 2 ? CF_BUDDHA1 : CF_BUDDHA0;
        gfx_sprite(top, cat_frame(f), CAT_W, CAT_H, cx - 16 * scale, feet - 32 * scale,
                   &buddha_pal[G.cat * 16], 0, scale);
        render_hearts_rain(top);
        if (u > 80)
            gfx_text_center(top, 128, 8, "NEKO NYORAI", RGB(255, 220, 90), RGB(150, 40, 20), 2);
        if (u > 150 && (u / 10) % 2)
            gfx_text_center(top, 128, 178, "ENLIGHTENMENT!", COL_WHITE, RGB(150, 40, 20), 1);
        if (u < 10)
            gfx_blend(top, 0, 0, SCREEN_W, SCREEN_H, COL_WHITE);
    }

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 16, 240, 110, RGB(255, 250, 240), COL_INK);
    gfx_text_center(bot, 128, 26, "5 HEARTS AT ONCE!!", COL_RED, RGB(255, 250, 240), 1);
    draw_icon(bot, IC_HEART_FULL, 80, 42);
    draw_icon(bot, IC_HEART_FULL, 104, 42);
    draw_icon(bot, IC_HEART_FULL, 128, 42);
    draw_icon(bot, IC_HEART_FULL, 152, 42);
    draw_icon(bot, IC_HEART_FULL, 176, 42);
    gfx_text(bot, 20, 62, "So much love at once that", COL_INK);
    snprintf(G.dbg, sizeof(G.dbg), "%s reached enlightenment", cats[G.cat].name);
    gfx_text(bot, 20, 74, G.dbg, COL_INK);
    gfx_text(bot, 20, 86, "and became the Neko Nyorai!", COL_INK);
    gfx_text_center(bot, 128, 106, "STAGE CLEARED INSTANTLY", COL_ORANGE, RGB(255, 250, 240), 1);
    if (t > 160 && (G.frame / 30) % 2)
        gfx_text_center(bot, 128, 164, "Press A", COL_ORANGE, RGB(252, 240, 220), 1);
}

static void render_levelup(uint16_t *top, uint16_t *bot)
{
    int t = G.t;
    gfx_copy(top, stage_background(G.stage));
    gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
    // spinning rays
    for (int k = 0; k < 16; k++) {
        static const int8_t dx[16] = { 0, 49, 90, 117, 127, 117, 90, 49, 0, -49, -90, -117, -127, -117, -90, -49 };
        static const int8_t dy[16] = { -127, -117, -90, -49, 0, 49, 90, 117, 127, 117, 90, 49, 0, -49, -90, -117 };
        int a = (k + t / 6) % 16, b = (a + 4) % 16;
        int x1 = 128 + dx[a] * 2, y1 = 100 + dy[a] * 2;
        int x2 = 128 + dx[b] * 2 / 3, y2 = 100 + dy[b] * 2 / 3;
        gfx_line(top, 128, 100, x1, y1, k & 1 ? COL_YELLOW : COL_ORANGE);
        gfx_line(top, 128, 100, (x1 + x2) / 2, (y1 + y2) / 2, k & 1 ? COL_ORANGE : COL_YELLOW);
    }
    int drop = t < 20 ? (20 - t) * 6 : 0;
    int bounce = t >= 20 && t < 40 ? ((40 - t) / 4) % 2 * 3 : 0;
    gfx_text_center(top, 128, 8 - drop + bounce, "LEVEL", COL_YELLOW, COL_RED, 4);
    gfx_text_center(top, 128, 46 - drop + bounce, "UP!!", COL_YELLOW, COL_RED, 4);
    draw_cat(top, (t / 10) % 2 ? CF_HAPPY : CF_CUTE, 128, 178, 0, 2);
    for (int k = 0; k < 6; k++)
        draw_icon(top, IC_SPARKLE, 60 + k * 27 + (t / 4 + k) % 5, 120 + ((t * 3 + k * 40) % 60));

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 8, 240, 140, RGB(255, 250, 240), COL_INK);
    gfx_text_center(bot, 128, 16, "CAT EYE LEVEL UP!", COL_RED, RGB(255, 250, 240), 1);
    const Sprite *e = &icons[IC_EYE];
    int pulse = (t / 8) % 2;
    gfx_sprite(bot, e->px, e->w, e->h, 128 - e->w * (4 + pulse) / 2, 32 - pulse * 3, ui_pal, 0, 4 + pulse);
    static const char *eye_lines[5][2] = {
        { "", "" },
        { "see each human's mood", "" },
        { "see what each human likes", "(food, pets, brush, photos)" },
        { "see each human's WEAKNESS", "(shown above their head)" },
        { "see your exact chance", "of success!" },
    };
    int eye = clampi(G.skill_lv[SK_EYE], 1, 4);
    char line[40];
    snprintf(line, sizeof(line), "Cat Eye is now Lv%d: you", eye);
    gfx_text(bot, 24, 72, line, COL_INK);
    gfx_text(bot, 24, 84, eye_lines[eye][0], COL_INK);
    gfx_text(bot, 24, 96, eye_lines[eye][1], COL_GRAY);
    char buf[32];
    snprintf(buf, sizeof(buf), "+%d SKILL POINTS!", G.points);
    gfx_text_center(bot, 128, 116, buf, COL_ORANGE, COL_INK, 1);
    gfx_text_center(bot, 128, 132, "Spend them now!", COL_INK, RGB(255, 250, 240), 1);
    if (t > 70 && (G.frame / 20) % 2)
        gfx_text_center(bot, 128, 168, "Press A", COL_ORANGE, RGB(252, 240, 220), 1);
}

static void blit_map(uint16_t *fb, int cam)
{
    const BgImage *m = &bg_images[BG_MAP];
    for (int y = 0; y < SCREEN_H; y++) {
        const uint8_t *src = m->px + y * m->w + cam;
        uint16_t *dst = fb + y * SCREEN_W;
        for (int x = 0; x < SCREEN_W; x++)
            dst[x] = m->pal[src[x]];
    }
}

static const char *dest_label(int i)
{
    return i == NUM_DESTS ? stages[STG_HOME].short_name : stages[STG_DEST0 + i].short_name;
}

static void draw_map_pins(uint16_t *fb, int cam)
{
    for (int i = 0; i <= NUM_DESTS; i++) {
        int x = map_pins[i * 2] - cam, y = map_pins[i * 2 + 1];
        if (x < -8 || x > SCREEN_W + 8)
            continue;
        if (i == NUM_DESTS) {
            // home: a little house, padlocked until enough places are visited
            gfx_fill(fb, x - 4, y - 4, 9, 6, home_open() ? RGB(240, 200, 120) : RGB(150, 150, 150));
            gfx_line(fb, x - 5, y - 4, x, y - 9, COL_RED);
            gfx_line(fb, x, y - 9, x + 5, y - 4, COL_RED);
            gfx_fill(fb, x - 1, y - 2, 3, 4, COL_INK);
        } else if ((G.visited >> i) & 1) {
            draw_icon(fb, IC_PAW, x, y - 5);
        } else if ((G.frame / 20 + i) % 2) {
            gfx_frame(fb, x - 4, y - 3, 9, 7, COL_WHITE);
        }
    }
}

static void render_map(uint16_t *top, uint16_t *bot)
{
    int cam = clampi(G.cam_x, 0, bg_images[BG_MAP].w - SCREEN_W);
    blit_map(top, cam);
    amb_sparkle(top, (int)G.frame, 0, SCREEN_H, 10);   // the ocean glints, gently
    amb_clouds(top, (int)G.frame, 3, 180);
    draw_map_pins(top, cam);
    // Momo waits at her current spot
    int lx = map_pins[G.loc * 2] - cam, ly = map_pins[G.loc * 2 + 1];
    draw_cat(top, (G.frame / 20) % 2 ? CF_SIT0 : CF_SIT1, lx, ly + 2, 0, 1);
    int sx = map_pins[G.map_sel * 2] - cam, sy = map_pins[G.map_sel * 2 + 1];
    draw_icon(top, IC_ARROW, sx, sy - 16 - (G.frame / 8) % 2 * 2);
    const char *nm = G.map_sel == NUM_DESTS ? stages[STG_HOME].place : stages[STG_DEST0 + G.map_sel].place;
    gfx_text_center(top, clampi(sx, gfx_text_width(nm, 1) / 2 + 2, SCREEN_W - gfx_text_width(nm, 1) / 2 - 2),
                    clampi(sy - 28, 2, SCREEN_H - 10), nm, COL_YELLOW, COL_INK, 1);
    gfx_panel(top, 2, 2, 132, 13, RGB(255, 250, 240), COL_INK);
    char buf[40];
    snprintf(buf, sizeof(buf), "WORLD TOUR %2d/%d", count_visited(), NUM_DESTS);
    gfx_text(top, 6, 5, buf, COL_INK);
    if (cam > 0 && (G.frame / 16) % 2)
        gfx_text_outline(top, 2, 92, "<", COL_WHITE, COL_INK, 1);
    if (cam < bg_images[BG_MAP].w - SCREEN_W && (G.frame / 16) % 2)
        gfx_text_outline(top, 248, 92, ">", COL_WHITE, COL_INK, 1);

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 2, 2, 252, 30, RGB(255, 250, 240), COL_INK);
    bool locked = G.map_sel == NUM_DESTS && !home_open();
    bool done = G.map_sel < NUM_DESTS && ((G.visited >> G.map_sel) & 1);
    gfx_text(bot, 8, 6, nm, COL_ORANGE);
    gfx_text(bot, 8, 18, G.map_sel == NUM_DESTS ? (locked ? "Visit 4 places to unlock" : "FINAL STAGE - go home!")
                                               : done ? "Visited - play again?" : "New destination!",
             done ? COL_GREEN : COL_INK);
    for (int i = 0; i <= NUM_DESTS; i++) {
        int col = i / 10, row = i % 10;
        int x = 2 + col * 127, y = 34 + row * 13;
        bool sel = i == G.map_sel;
        bool lock = i == NUM_DESTS && !home_open();
        gfx_panel(bot, x, y, 125, 12, sel ? RGB(255, 214, 120) : RGB(255, 250, 240), sel ? COL_ORANGE : RGB(210, 190, 170));
        if (i < NUM_DESTS && ((G.visited >> i) & 1))
            draw_icon(bot, IC_PAW, x + 7, y + 3);
        gfx_text(bot, x + 14, y + 2, dest_label(i), lock ? RGB(180, 170, 160) : COL_INK);
    }
    uint32_t sec = G.run_frames / 60;
    snprintf(buf, sizeof(buf), "A:Go  Time %02u:%02u", (unsigned)(sec / 60), (unsigned)(sec % 60));
    gfx_text(bot, 132, 180, buf, COL_INK);
    for (int k = 0; k < G.lives; k++)
        draw_icon(bot, IC_PAW, 8 + k * 10, 181);
}

static void render_travel(uint16_t *top, uint16_t *bot)
{
    int t = clampi(G.t * 100 / TRAVEL_LEN, 0, 100);   // progress 0..100
    int x0 = map_pins[G.travel_from * 2], y0 = map_pins[G.travel_from * 2 + 1];
    int x1 = map_pins[G.map_sel * 2], y1 = map_pins[G.map_sel * 2 + 1];
    int cx = x0 + (x1 - x0) * t / 100;
    int cy = y0 + (y1 - y0) * t / 100 - (t * (100 - t)) / 80;   // hop through the air
    int cam = clampi(cx - 128, 0, bg_images[BG_MAP].w - SCREEN_W);
    blit_map(top, cam);
    draw_map_pins(top, cam);
    for (int k = 0; k < 8; k++) {
        int tt = clampi(t - k * 4, 0, 100);
        int fx = x0 + (x1 - x0) * tt / 100 - cam;
        int fy = y0 + (y1 - y0) * tt / 100 - (tt * (100 - tt)) / 80 + 10;
        draw_icon(top, IC_FLAME_RED0 + (k + G.frame / 4) % 2, fx, fy);
    }
    draw_car(top, cx - cam, cy + 12, true, x1 < x0);
    if ((G.frame / 6) % 2)
        gfx_text_outline(top, 160, 176, "88 MPH", COL_YELLOW, COL_RED, 1);

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 60, 240, 40, RGB(255, 250, 240), COL_INK);
    const char *nm = G.map_sel == NUM_DESTS ? stages[STG_HOME].place : stages[STG_DEST0 + G.map_sel].place;
    gfx_text_center(bot, 128, 68, "Next stop:", COL_INK, RGB(255, 250, 240), 1);
    gfx_text_center(bot, 128, 82, nm, COL_ORANGE, RGB(255, 250, 240), 1);
}

static void fmt_time(char *buf, int n, uint32_t frames)
{
    uint32_t sec = frames / 60;
    snprintf(buf, (size_t)n, "%02u:%02u", (unsigned)(sec / 60), (unsigned)(sec % 60));
}

static void render_results(uint16_t *top, uint16_t *bot)
{
    gfx_copy(top, BGIMG(BG_TITLE));
    gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
    gfx_text_center(top, 128, 16, G.ending_reached ? "THE END" : "RUN OVER", COL_YELLOW, COL_INK, 3);
    draw_cat(top, G.ending_reached ? ((G.frame / 16) % 2 ? CF_HAPPY : CF_BLISS) : CF_SLEEP, 128, 150, 0, 2);
    char buf[48];
    snprintf(buf, sizeof(buf), "SCORE %u", (unsigned)G.score);
    gfx_text_center(top, 128, 160, buf, COL_WHITE, COL_INK, 2);
    if (G.rank_pos >= 0 && (G.frame / 20) % 2) {
        snprintf(buf, sizeof(buf), "NEW RANK #%d!", G.rank_pos + 1);
        gfx_text_center(top, 128, 50, buf, COL_RED, COL_WHITE, 2);
    }

    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 6, 240, 150, RGB(255, 250, 240), COL_INK);
    int y = 14;
#define ROW(label, val, pts) do { \
        gfx_text(bot, 16, y, label, COL_INK); \
        snprintf(buf, sizeof(buf), "%d", (int)(val)); \
        gfx_text(bot, 136 - gfx_text_width(buf, 1), y, buf, COL_INK); \
        snprintf(buf, sizeof(buf), "%6d", (int)(pts)); \
        gfx_text(bot, 240 - gfx_text_width(buf, 1), y, buf, COL_ORANGE); \
        y += 13; \
    } while (0)
    ROW("Love", G.total_love, G.total_love * 10);
    ROW("Stages", G.stages_cleared, G.stages_cleared * 300);
    ROW("Level", G.lv, G.lv * 50);
    ROW("Nyorai", G.buddhas, G.buddhas * 500);
    ROW("Endings", G.endings, G.endings * 2000);
    if (G.round > 1)
        ROW("Rounds", G.round - 1, (G.round - 1) * 1000);
#undef ROW
    gfx_hline(bot, 16, 240, y, COL_INK);
    y += 5;
    snprintf(buf, sizeof(buf), "%u", (unsigned)G.score);
    gfx_text(bot, 16, y, "TOTAL", COL_RED);
    gfx_text(bot, 240 - gfx_text_width(buf, 1), y, buf, COL_RED);
    y += 16;
    fmt_time(buf, sizeof(buf), G.run_frames);
    gfx_text(bot, 16, y, "Time played", COL_INK);
    gfx_text(bot, 240 - gfx_text_width(buf, 1), y, buf, COL_INK);
    y += 13;
    snprintf(buf, sizeof(buf), "%d/%d", count_visited(), NUM_DESTS);
    gfx_text(bot, 16, y, "Places visited", COL_INK);
    gfx_text(bot, 240 - gfx_text_width(buf, 1), y, buf, COL_INK);
    if (G.t > 60 && (G.frame / 30) % 2)
        gfx_text_center(bot, 128, 170, G.rank_pos >= 0 ? "A: enter your initials" : "A: see the ranking",
                        COL_ORANGE, RGB(252, 240, 220), 1);
}

static void render_name(uint16_t *top, uint16_t *bot)
{
    gfx_copy(top, BGIMG(BG_TITLE));
    gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
    char buf[32];
    snprintf(buf, sizeof(buf), "RANK #%d", G.rank_pos + 1);
    gfx_text_center(top, 128, 20, buf, COL_YELLOW, COL_INK, 3);
    gfx_text_center(top, 128, 56, "Enter your initials", COL_WHITE, COL_INK, 1);
    for (int i = 0; i < 3; i++) {
        char ch[2] = { G.initials[i], 0 };
        int x = 128 - 60 + i * 40;
        bool cur = i == G.name_pos;
        gfx_panel(top, x - 4, 82, 40, 44, cur ? RGB(255, 214, 120) : RGB(255, 250, 240), cur ? COL_ORANGE : COL_INK);
        gfx_text_outline(top, x + 4, 90, ch, COL_INK, RGB(255, 250, 240), 3);
        if (cur && (G.frame / 10) % 2) {
            draw_icon(top, IC_ARROW, x + 16, 72);
        }
    }
    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 40, 240, 70, RGB(255, 250, 240), COL_INK);
    gfx_text_center(bot, 128, 50, "Up/Down: change letter", COL_INK, RGB(255, 250, 240), 1);
    gfx_text_center(bot, 128, 66, "Left/Right: move", COL_INK, RGB(255, 250, 240), 1);
    gfx_text_center(bot, 128, 82, "A on the last letter: done", COL_INK, RGB(255, 250, 240), 1);
}

static void render_ranking(uint16_t *top, uint16_t *bot)
{
    gfx_copy(top, BGIMG(BG_TITLE));
    gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
    gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
    gfx_text_center(top, 128, 4, "RANKING", COL_YELLOW, COL_INK, 2);
    gfx_text(top, 4, 26, " #  NAME  SCORE  ST  TIME", RGB(200, 200, 210));
    char buf[48], tm[12];
    for (int i = 0; i < RANK_N; i++) {
        int y = 38 + i * 15;
        bool hl = i == G.ranking_hl;
        if (hl)
            gfx_fill(top, 2, y - 2, 252, 12, (G.frame / 10) % 2 ? RGB(150, 80, 40) : RGB(110, 60, 30));
        if (i < (int)G.ranks.count) {
            const RankEntry *e = &G.ranks.e[i];
            fmt_time(tm, sizeof(tm), e->frames);
            snprintf(buf, sizeof(buf), "%2d  %-3s %6u  %2d %s", i + 1, e->name, (unsigned)e->score, e->stages, tm);
            gfx_text_outline(top, 4, y, buf, i == 0 ? COL_YELLOW : COL_WHITE, COL_INK, 1);
            gfx_fill(top, 236, y, 7, 7, COL_INK);   // which cat: a swatch of her fur
            gfx_fill(top, 237, y + 1, 5, 5, cat_pal[e->cat * 16 + 2]);
            if (e->ending)
                draw_icon(top, IC_SPARKLE, 250, y + 1);
        } else {
            snprintf(buf, sizeof(buf), "%2d  ---      -   -  --:--", i + 1);
            gfx_text(top, 4, y, buf, RGB(140, 130, 130));
        }
    }
    gfx_copy(bot, BGIMG(BG_PANEL));
    gfx_panel(bot, 8, 50, 240, 64, RGB(255, 250, 240), COL_INK);
    gfx_text_center(bot, 128, 58, "MOMO DEV STORY", COL_ORANGE, RGB(255, 250, 240), 1);
    gfx_text_center(bot, 128, 72, "ST = stages cleared", COL_INK, RGB(255, 250, 240), 1);
    gfx_text_center(bot, 128, 86, "sparkle = reached the end", COL_INK, RGB(255, 250, 240), 1);
    if (G.ranking_hl >= 0) {
        snprintf(buf, sizeof(buf), "You placed #%d!", G.ranking_hl + 1);
        gfx_text_center(bot, 128, 100, buf, COL_RED, RGB(255, 250, 240), 1);
    }
    if ((G.frame / 30) % 2)
        gfx_text_center(bot, 128, 164, "Press A", COL_ORANGE, RGB(252, 240, 220), 1);
}

void game_render(uint16_t *top, uint16_t *bot)
{
    switch (G.state) {
        case ST_TITLE:
            render_title(top, bot);
            break;
        case ST_INTRO:
            render_intro(top, bot);
            break;
        case ST_SELECT:
            render_select(top, bot);
            break;
        case ST_CARD:
            render_card(top, bot);
            break;
        case ST_PLAY:
            render_stage_top(top);
            render_play_bottom(bot);
            break;
        case ST_SKILLS:
            render_stage_top(top);
            gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
            gfx_text_center(top, 128, 80, "SKILLS", COL_YELLOW, COL_INK, 2);
            render_skills_bottom(bot);
            break;
        case ST_PAUSE:
            render_stage_top(top);
            gfx_darken(top, 0, 0, SCREEN_W, SCREEN_H);
            gfx_text_center(top, 128, 80, "PAUSED", COL_WHITE, COL_INK, 2);
            render_play_bottom(bot);
            gfx_darken(bot, 0, 0, SCREEN_W, SCREEN_H);
            gfx_panel(bot, 32, 58, 192, 62, RGB(255, 250, 240), COL_INK);
            gfx_text_center(bot, 128, 68, "START: resume", COL_INK, RGB(255, 250, 240), 1);
            gfx_text_center(bot, 128, 84, G.music_off ? "X: music OFF" : "X: music ON", COL_INK,
                            RGB(255, 250, 240), 1);
            gfx_text_center(bot, 128, 100, "SELECT: quit to title", COL_INK, RGB(255, 250, 240), 1);
            break;
        case ST_CLEAR:
            render_clear(top, bot);
            break;
        case ST_GAMEOVER:
            render_gameover(top, bot);
            break;
        case ST_ENDING:
            render_ending(top, bot);
            break;
        case ST_RESCUE:
            render_rescue(top, bot);
            break;
        case ST_TIMEWARP:
            render_timewarp(top, bot);
            break;
        case ST_LEVELUP:
            render_levelup(top, bot);
            break;
        case ST_BUDDHA:
            render_buddha(top, bot);
            break;
        case ST_MAP:
            render_map(top, bot);
            break;
        case ST_TRAVEL:
            render_travel(top, bot);
            break;
        case ST_RESULTS:
            render_results(top, bot);
            break;
        case ST_NAME:
            render_name(top, bot);
            break;
        case ST_RANKING:
            render_ranking(top, bot);
            break;
    }
}

// --------------------------------------------------------------------------
// Balance-test bot (host builds only)
// --------------------------------------------------------------------------
#ifdef MOMO_HOST

#include "bot.h"

static uint8_t bot_notice[MAX_PEOPLE];   // 0 unknown, 1 will hide, 2 missed it
static int bot_cool;

static int count_in_range(int sk)
{
    int n = 0;
    for (int i = 0; i < MAX_PEOPLE; i++) {
        Person *p = &G.people[i];
        if (p->active && !p->done && !p->rage && p->state == P_WALK &&
            absi(px(p) - momo_x()) < skill_range(sk))
            n++;
    }
    return n;
}

static void bot_spend(const BotCfg *b)
{
    static const uint8_t smart_order[] = {
        SK_EYE, SK_EYE, SK_CUTE, SK_FOODPAW, SK_YOGA, SK_LOAF, SK_PURR, SK_BELLY, SK_MEOW,
        SK_CUTE, SK_FOODPAW, SK_BLINK, SK_GROOM, SK_BELLY, SK_PURR, SK_YOGA, SK_EYE, SK_MEOW,
        SK_BUMP, SK_LOAF, SK_CUTE, SK_FOODPAW, SK_BLINK, SK_PURR, SK_BELLY, SK_YOGA,
    };
    while (G.points > 0) {
        int sk = -1;
        if (b->smart) {
            for (unsigned i = 0; i < sizeof(smart_order); i++) {
                int s = smart_order[i];
                int want = 0;
                for (unsigned j = 0; j <= i; j++)
                    want += smart_order[j] == s;
                if (G.skill_lv[s] < want + (s == SK_EYE ? 0 : 0) && G.skill_lv[s] < skills[s].max_lv) {
                    sk = s;
                    break;
                }
            }
        }
        if (sk < 0) {
            for (int tries = 0; tries < 50 && sk < 0; tries++) {
                int s = rndn(SK_COUNT);
                if (G.skill_lv[s] < skills[s].max_lv)
                    sk = s;
            }
        }
        if (sk < 0)
            break;
        G.points--;
        G.skill_lv[sk]++;
    }
}

static Input bot_input(const BotCfg *b)
{
    Input in = { 0 };
    int mx = momo_x();

    // flaming humans: hide if we noticed them
    bool threat = false;
    for (int i = 0; i < MAX_PEOPLE; i++) {
        Person *p = &G.people[i];
        if (!p->active || !p->rage || p->hit) {
            bot_notice[i] = 0;
            continue;
        }
        int rel = (mx - px(p)) * p->dir;   // >0 means approaching
        if (rel > -16 && rel < 70) {
            if (!bot_notice[i])
                bot_notice[i] = rndn(100) < b->react_pct ? 1 : 2;
            if (bot_notice[i] == 1)
                threat = true;
        }
    }
    if (threat) {
        in.held = IN_B;
        return in;
    }
    if (G.mstate != M_IDLE && G.mstate != M_WALK)
        return in;
    if (bot_cool > 0) {
        bot_cool--;
        return in;
    }

    // pick the best skill for whoever is in range
    int best = -1, best_score = 0;
    for (int sk = 0; sk < SK_ACTIVE; sk++) {
        if (G.skill_lv[sk] <= 0 || G.mp < skill_cost(sk) || skills[sk].self)
            continue;
        int t = find_target(skill_range(sk));
        if (t < 0)
            continue;
        int score;
        if (b->smart) {
            int n = skills[sk].area ? count_in_range(sk) : 1;
            int ch = success_chance(&G.people[t], sk);
            if (G.skill_lv[SK_EYE] < 3 && p_weak(&G.people[t]) == sk)
                ch -= 30; // can't see the weakness yet
            int pen = 3 + 4 * archs[G.people[t].arch].hostile;
            score = ch * n * (skills[sk].area ? 6 : 12) - (100 - ch) * pen * 6 - skill_cost(sk) * 20;
            if (ch < 35)
                score = 0;
        } else {
            score = 1 + rndn(100);
        }
        if (score > best_score) {
            best_score = score;
            best = sk;
        }
    }
    if (best >= 0 && rndn(100) < b->act_pct) {
        G.sel = best;
        in.down = IN_A;
        bot_cool = b->delay;
        return in;
    }

    if (G.mp < 8 && G.skill_lv[SK_GROOM] > 0 && find_target(60) < 0) {
        G.sel = SK_GROOM;
        in.down = IN_A;
        bot_cool = b->delay;
        return in;
    }

    // wander towards the closest charmable human
    int goal = -1, gd = 9999;
    for (int i = 0; i < MAX_PEOPLE; i++) {
        Person *p = &G.people[i];
        if (!p->active || p->done || p->rage || p->state != P_WALK)
            continue;
        int d = absi(px(p) - mx);
        if (d < gd) {
            gd = d;
            goal = i;
        }
    }
    if (goal >= 0 && gd > 14)
        in.held = px(&G.people[goal]) < mx ? IN_LEFT : IN_RIGHT;
    return in;
}

void game_cheat(int what)
{
    Person *p;
    switch (what) {
        case 0: // reach the love goal
            G.love = G.goal;
            break;
        case 1: // a furious courier
            p = spawn(PK_COURIER);
            if (p) {
                p->rage = RAGE_RED;
                p->done = true;
            }
            break;
        case 2:
            spawn(PK_DEVDAD);
            break;
        case 3:
            G.skill_lv[SK_EYE] = 4;
            G.points = 4;
            break;
        case 4: // a guard with a black aura
            p = spawn(PK_GUARD);
            if (p) {
                p->rage = RAGE_BLACK;
                p->done = true;
            }
            break;
        case 5: // crowd of friendly humans right in front of Momo
            for (int i = 0; i < 3; i++) {
                p = spawn(i == 0 ? PK_CATLOVER : i == 1 ? PK_STUDENT : PK_GRANNY);
                if (p) {
                    p->x16 = (momo_x() - 30 + i * 28) * 16;
                    p->rage = RAGE_NONE;
                    p->done = false;
                }
            }
            break;
        case 6:
            G.hp = 1;
            break;
        case 7:
            gain_xp(xp_need());
            break;
        case 8:
            G.buddha_pending = true;
            break;
        case 9: // jump to the world map as if Yahoo! was just cleared
            G.stage = STG_YAHOO;
            G.stages_cleared = 2;
            open_map();
            break;
        case 10: // pretend a few destinations are done
            G.visited |= 0x15;
            break;
        case 12: // stamp the whole map
            G.visited = (1u << NUM_DESTS) - 1;
            break;
        case 13: // the parents walk by, right in front of Momo
            memset(G.people, 0, sizeof(G.people));
            for (int k = 0; k < 2; k++) {
                p = spawn(k ? PK_SHANNON : PK_EVANS);
                if (p) {
                    p->x16 = (momo_x() + 24 + k * 60) * 16;
                    p->rage = RAGE_NONE;
                    p->done = false;
                    p->speed = 1;
                }
            }
            G.spawn_t = 9999;
            break;
        case 11: // end the run
            G.total_love = 321;
            G.stages_cleared = 7;
            finish_run(false);
            break;
    }
}

// Plays a whole run like a player would: balcony, Yahoo!, six destinations
// in map order, then home. Game overs cost a life and retry the stage.
int game_sim(int cat, const BotCfg *b, uint32_t seed, SimResult *res)
{
    static const int order[SIM_STAGES] = {
        STG_BALCONY, STG_YAHOO, STG_DEST0 + 0, STG_DEST0 + 3, STG_DEST0 + 15, STG_DEST0 + 8,
        STG_DEST0 + 16, STG_DEST0 + 17, STG_HOME,
    };
    int len = b->full ? NUM_DESTS + 3 : SIM_STAGES;
    memset(res, 0, sizeof(*res));
    res->stages = len;
    game_init(seed);
    new_game(cat);
    for (int k = 0; k < len; k++) {
        G.stage = !b->full ? order[k] : k < 2 ? k : k == len - 1 ? STG_HOME : STG_DEST0 + k - 2;
        int min_hp = 9999;
        int f = 0;
        bool cleared = false;
        while (!cleared) {
            start_stage();
            G.state = ST_PLAY;
            memset(bot_notice, 0, sizeof(bot_notice));
            for (; f < 60 * 60 * 30; f++) {
                if (G.points)
                    bot_spend(b);
                Input in = bot_input(b);
                G.frame++;
                G.run_frames++;
                play_tick(&in);
                if (G.state == ST_PAUSE || G.state == ST_SKILLS || G.state == ST_LEVELUP)
                    G.state = ST_PLAY;
                if (G.state == ST_BUDDHA) {
                    res->buddha++;
                    buddha_finish();
                }
                if (G.state == ST_RESCUE) {
                    res->rescued = k + 1;
                    rescue_finish();
                    min_hp = 9999;   // the scripted knock-out isn't a close call
                    continue;
                }
                if (G.hp < min_hp)
                    min_hp = G.hp;
                if (G.state != ST_PLAY)
                    break;
            }
            if (G.state == ST_CLEAR) {
                cleared = true;
            } else if (G.state == ST_GAMEOVER && G.lives > 0) {
                res->retries++;
                res->deaths[k]++;
            } else {
                if (G.state == ST_GAMEOVER)
                    res->deaths[k]++;
                break;
            }
        }
        res->frames[k] = f;
        res->min_hp[k] = min_hp;
        res->fails[k] = G.stats[HQ_FAIL];
        res->charmed[k] = G.charmed;
        res->level[k] = G.lv;
        res->devdad[k] = G.devdad_seen;
        memcpy(res->tally[k], G.tally, sizeof(G.tally));
        memset(G.tally, 0, sizeof(G.tally));
        if (!cleared) {
            res->result = k;
            res->timeout = G.state == ST_PLAY;
            finish_run(false);
            res->score = G.score;
            res->run_frames = G.run_frames;
            return k;
        }
    }
    res->result = len;
    finish_run(true);
    res->score = G.score;
    res->run_frames = G.run_frames;
    return len;
}

#endif // MOMO_HOST
