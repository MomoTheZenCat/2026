// Momo Dev Story - platform interface.
//
// The game itself is plain C that renders into two 256x192 RGB15 buffers.
// main_nds.c implements this for the Nintendo DS (BlocksDS/libnds) and
// host/host_main.c implements it on a PC for automated screenshot tests.

#ifndef MOMO_PLAT_H
#define MOMO_PLAT_H

#include <stdbool.h>
#include <stdint.h>

#define SCREEN_W 256
#define SCREEN_H 192

// Same bit layout as libnds KEY_* so the DS port can pass keysHeld() through.
enum {
    IN_A = 1 << 0,
    IN_B = 1 << 1,
    IN_SELECT = 1 << 2,
    IN_START = 1 << 3,
    IN_RIGHT = 1 << 4,
    IN_LEFT = 1 << 5,
    IN_UP = 1 << 6,
    IN_DOWN = 1 << 7,
    IN_R = 1 << 8,
    IN_L = 1 << 9,
    IN_X = 1 << 10,
    IN_Y = 1 << 11,
};

typedef struct {
    uint32_t held;
    uint32_t down;
    bool touch;      // stylus went down this frame
    int tx, ty;      // touch position on the bottom screen
} Input;

enum {
    SFX_SELECT,
    SFX_CONFIRM,
    SFX_BACK,
    SFX_MEOW,
    SFX_PURR,
    SFX_JUMP,
    SFX_HEART,
    SFX_FAIL,
    SFX_WOOF,
    SFX_LEVELUP,
    SFX_CLICK,
    SFX_CLEAR,
    SFX_GAMEOVER,
    SFX_TIMEWARP,
    SFX_SKILLUP,
    SFX_ENGINE,
    SFX_BOOM,
    SFX_TUNNEL,
    SFX_LAND,
    SFX_QUACK,
    SFX_CLUCK,
    SFX_COUNT
};

void plat_sfx(int id);

enum { MUS_NONE, MUS_TITLE, MUS_BALCONY, MUS_YAHOO, MUS_TROPICAL, MUS_ASIA, MUS_MAP, MUS_TIMEWARP, MUS_COUNT };

void plat_music(int track);

// Persistent storage for the leaderboard. Returns false if unavailable.
bool plat_save(const void *data, int size);
bool plat_load(void *data, int size);

#endif // MOMO_PLAT_H
