// Momo Dev Story - software renderer.

#include <stdbool.h>
#include <string.h>

#include "gen/assets.h"
#include "gfx.h"

void gfx_copy(uint16_t *dst, const uint16_t *src)
{
    memcpy(dst, src, SCREEN_W * SCREEN_H * 2);
}

static int clip_bottom = SCREEN_H;

void gfx_clip_bottom(int y)
{
    clip_bottom = y < SCREEN_H ? y : SCREEN_H;
}

static int clip(int *x, int *y, int *w, int *h)
{
    if (*x < 0) { *w += *x; *x = 0; }
    if (*y < 0) { *h += *y; *y = 0; }
    if (*x + *w > SCREEN_W) *w = SCREEN_W - *x;
    if (*y + *h > SCREEN_H) *h = SCREEN_H - *y;
    return *w > 0 && *h > 0;
}

void gfx_fill(uint16_t *fb, int x, int y, int w, int h, uint16_t c)
{
    if (!clip(&x, &y, &w, &h))
        return;
    for (int j = 0; j < h; j++) {
        uint16_t *p = fb + (y + j) * SCREEN_W + x;
        for (int i = 0; i < w; i++)
            p[i] = c;
    }
}

void gfx_frame(uint16_t *fb, int x, int y, int w, int h, uint16_t c)
{
    gfx_fill(fb, x, y, w, 1, c);
    gfx_fill(fb, x, y + h - 1, w, 1, c);
    gfx_fill(fb, x, y, 1, h, c);
    gfx_fill(fb, x + w - 1, y, 1, h, c);
}

static inline uint16_t mix(uint16_t a, uint16_t b)
{
    return (uint16_t)((((a & 0x7BDE) >> 1) + ((b & 0x7BDE) >> 1)) | 0x8000);
}

void gfx_blend(uint16_t *fb, int x, int y, int w, int h, uint16_t c)
{
    if (!clip(&x, &y, &w, &h))
        return;
    for (int j = 0; j < h; j++) {
        uint16_t *p = fb + (y + j) * SCREEN_W + x;
        for (int i = 0; i < w; i++)
            p[i] = mix(p[i], c);
    }
}

void gfx_darken(uint16_t *fb, int x, int y, int w, int h)
{
    if (!clip(&x, &y, &w, &h))
        return;
    for (int j = 0; j < h; j++) {
        uint16_t *p = fb + (y + j) * SCREEN_W + x;
        for (int i = 0; i < w; i++)
            p[i] = (uint16_t)(((p[i] & 0x7BDE) >> 1) | 0x8000);
    }
}

void gfx_hline(uint16_t *fb, int x0, int x1, int y, uint16_t c)
{
    gfx_fill(fb, x0, y, x1 - x0 + 1, 1, c);
}

void gfx_line(uint16_t *fb, int x0, int y0, int x1, int y1, uint16_t c)
{
    int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    int dy = y1 > y0 ? y0 - y1 : y1 - y0;
    int sx = x0 < x1 ? 1 : -1;
    int sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;
    for (;;) {
        if (x0 >= 0 && x0 < SCREEN_W && y0 >= 0 && y0 < SCREEN_H)
            fb[y0 * SCREEN_W + x0] = c;
        if (x0 == x1 && y0 == y1)
            break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}

void gfx_panel(uint16_t *fb, int x, int y, int w, int h, uint16_t fill, uint16_t border)
{
    gfx_fill(fb, x + 1, y + 1, w - 2, h - 2, fill);
    gfx_fill(fb, x + 2, y, w - 4, 1, border);
    gfx_fill(fb, x + 2, y + h - 1, w - 4, 1, border);
    gfx_fill(fb, x, y + 2, 1, h - 4, border);
    gfx_fill(fb, x + w - 1, y + 2, 1, h - 4, border);
    gfx_fill(fb, x + 1, y + 1, 1, 1, border);
    gfx_fill(fb, x + w - 2, y + 1, 1, 1, border);
    gfx_fill(fb, x + 1, y + h - 2, 1, 1, border);
    gfx_fill(fb, x + w - 2, y + h - 2, 1, 1, border);
}

void gfx_sprite(uint16_t *fb, const uint8_t *px, int w, int h, int x, int y,
                const uint16_t *pal, int flags, int scale)
{
    // No divisions in here: the ARM9 has no hardware divider.
    if (scale < 1)
        scale = 1;
    int flip = flags & SPR_FLIP;
    uint16_t white = COL_WHITE;
    for (int v = 0; v < h; v++) {
        const uint8_t *row = px + v * w;
        for (int sy = y + v * scale, k = 0; k < scale; k++, sy++) {
            if (sy < 0 || sy >= clip_bottom)
                continue;
            uint16_t *dst = fb + sy * SCREEN_W;
            int sx = x;
            for (int u = 0; u < w; u++, sx += scale) {
                uint8_t c = row[flip ? (w - 1 - u) : u];
                if (c == 0)
                    continue;
                uint16_t col = (flags & SPR_WHITE) ? white : pal[c];
                for (int m = 0; m < scale; m++) {
                    int xx = sx + m;
                    if (xx >= 0 && xx < SCREEN_W)
                        dst[xx] = col;
                }
            }
        }
    }
}

static inline bool pattern_hit(int pat, int u, int v)
{
    switch (pat) {
        case 1: return (u * 3 + v * 5) % 7 == 0;          // flowers
        case 2: return v % 3 == 0;                        // stripes
        case 3: return (((u >> 1) + (v >> 1)) & 1) != 0;  // check
        case 4: return (u * 5 + v * 7) % 11 == 0;         // dots
    }
    return false;
}

void gfx_sprite_pat(uint16_t *fb, const uint8_t *px, int w, int h, int x, int y,
                    const uint16_t *pal, int flags, int idx_a, int idx_b, int pat, uint16_t pat_col)
{
    int flip = flags & SPR_FLIP;
    for (int v = 0; v < h; v++) {
        int sy = y + v;
        if (sy < 0 || sy >= clip_bottom)
            continue;
        const uint8_t *row = px + v * w;
        uint16_t *dst = fb + sy * SCREEN_W;
        for (int u = 0; u < w; u++) {
            int sx = x + u;
            if (sx < 0 || sx >= SCREEN_W)
                continue;
            int su = flip ? (w - 1 - u) : u;
            uint8_t c = row[su];
            if (c == 0)
                continue;
            uint16_t col = pal[c];
            if ((c == idx_a || c == idx_b) && pattern_hit(pat, su, v))
                col = pat_col;
            dst[sx] = (flags & SPR_WHITE) ? COL_WHITE : col;
        }
    }
}

static void glyph(uint16_t *fb, int x, int y, char ch, uint16_t c, int scale)
{
    if (ch < 32 || ch > 127)
        ch = '?';
    const uint8_t *g = &font8x8[(ch - 32) * 8];
    for (int v = 0; v < 8; v++) {
        uint8_t bits = g[v];
        if (!bits)
            continue;
        for (int sy = y + v * scale, k = 0; k < scale; k++, sy++) {
            if (sy < 0 || sy >= SCREEN_H)
                continue;
            uint16_t *dst = fb + sy * SCREEN_W;
            for (int u = 0; u < 8; u++) {
                if (!(bits & (0x80 >> u)))
                    continue;
                for (int m = 0, xx = x + u * scale; m < scale; m++, xx++)
                    if (xx >= 0 && xx < SCREEN_W)
                        dst[xx] = c;
            }
        }
    }
}

static int text_scaled(uint16_t *fb, int x, int y, const char *s, uint16_t c, int scale)
{
    int x0 = x;
    for (; *s; s++) {
        if (*s == '\n') {
            x = x0;
            y += 9 * scale;
            continue;
        }
        glyph(fb, x, y, *s, c, scale);
        x += 8 * scale;
    }
    return x;
}

int gfx_text(uint16_t *fb, int x, int y, const char *s, uint16_t c)
{
    return text_scaled(fb, x, y, s, c, 1);
}

int gfx_text_shadow(uint16_t *fb, int x, int y, const char *s, uint16_t c, uint16_t sh)
{
    text_scaled(fb, x + 1, y + 1, s, sh, 1);
    return text_scaled(fb, x, y, s, c, 1);
}

int gfx_text_outline(uint16_t *fb, int x, int y, const char *s, uint16_t c, uint16_t o, int scale)
{
    static const int8_t d[8][2] = {
        { -1, -1 }, { 0, -1 }, { 1, -1 }, { -1, 0 }, { 1, 0 }, { -1, 1 }, { 0, 1 }, { 1, 1 }
    };
    for (int k = 0; k < 8; k++)
        text_scaled(fb, x + d[k][0] * scale, y + d[k][1] * scale, s, o, scale);
    if (scale > 1)
        text_scaled(fb, x + scale, y + scale * 2, s, o, scale);
    return text_scaled(fb, x, y, s, c, scale);
}

int gfx_text_width(const char *s, int scale)
{
    int n = 0, best = 0;
    for (; *s; s++) {
        if (*s == '\n') {
            n = 0;
            continue;
        }
        if (++n > best)
            best = n;
    }
    return best * 8 * scale;
}

void gfx_text_center(uint16_t *fb, int cx, int y, const char *s, uint16_t c, uint16_t o, int scale)
{
    gfx_text_outline(fb, cx - gfx_text_width(s, scale) / 2, y, s, c, o, scale);
}

void gfx_bar(uint16_t *fb, int x, int y, int w, int h, int val, int max, uint16_t fg, uint16_t bg)
{
    gfx_fill(fb, x, y, w, h, COL_INK);
    gfx_fill(fb, x + 1, y + 1, w - 2, h - 2, bg);
    if (max <= 0)
        return;
    if (val < 0)
        val = 0;
    if (val > max)
        val = max;
    int fw = (w - 2) * val / max;
    gfx_fill(fb, x + 1, y + 1, fw, h - 2, fg);
    gfx_fill(fb, x + 1, y + 1, fw, 1, mix(fg, COL_WHITE));
}
