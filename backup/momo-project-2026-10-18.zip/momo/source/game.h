// Momo Dev Story - game logic and screens.

#ifndef MOMO_GAME_H
#define MOMO_GAME_H

#include <stdbool.h>
#include <stdint.h>

#include "plat.h"

void game_init(uint32_t seed);
void game_update(const Input *in);
void game_render(uint16_t *top, uint16_t *bot);   // bot may be NULL: skip it
bool game_bottom_due(uint32_t frame);              // redraw the bottom this frame?

// Exposed for the host test harness.
int game_state(void);
const char *game_debug(void);

#endif // MOMO_GAME_H
