// Momo Dev Story - leaderboard.

#ifndef MOMO_SCORES_H
#define MOMO_SCORES_H

#include <stdint.h>

#define RANK_N 10

typedef struct {
    char name[4];      // three initials + NUL
    uint8_t cat;
    uint8_t stages;    // stages cleared
    uint8_t level;
    uint8_t ending;    // 1 if the run reached the ending
    uint32_t score;
    uint32_t frames;   // play time at 60 fps
} RankEntry;

typedef struct {
    uint32_t magic;
    uint32_t count;
    RankEntry e[RANK_N];
} RankTable;

void scores_load(RankTable *t);
void scores_save(const RankTable *t);
// Position (0-based) a score would take, or -1 if it doesn't make the board.
int scores_rank(const RankTable *t, uint32_t score);
// Inserts and returns the position, or -1.
int scores_insert(RankTable *t, const RankEntry *e);

#endif // MOMO_SCORES_H
