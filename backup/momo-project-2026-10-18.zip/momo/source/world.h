// Momo Dev Story - world data: stages, the cast of named humans, outfits.

#ifndef MOMO_WORLD_H
#define MOMO_WORLD_H

#include <stdint.h>

#include "gen/assets.h"

enum {
    SK_MEOW,
    SK_BLINK,
    SK_CUTE,
    SK_GROOM,
    SK_FOODPAW,
    SK_LOAF,
    SK_YOGA,
    SK_PURR,
    SK_BUMP,
    SK_BELLY,
    SK_EYE,
    SK_COUNT
};
#define SK_ACTIVE SK_EYE
#define SK_ANY 255

enum { RE_FEED, RE_PET, RE_BRUSH, RE_PHOTO, RE_MASSAGE };

// A named human. The same person always looks the same and has the same
// weakness, resistance and favourite reaction, so players can learn them.
typedef struct {
    const char *name;
    uint8_t arch;     // PK_* (sprite, temper, speed, quotes)
    uint8_t weak;     // SK_* they can't resist
    uint8_t resist;   // 0..100
    uint8_t likes;    // RE_*
    uint8_t home;     // stage they live at, or NPC_TRAVELER (whole world tour)
} Npc;

#define NPC_TRAVELER 255

// Local outfits: humans get dressed for the destination.
enum {
    COS_NONE,
    COS_ALOHA,
    COS_KIMONO,
    COS_ROBE,
    COS_PARKA,
    COS_WOVEN,
    COS_BRETON,
    COS_PLAID,
    COS_RAINCOAT,
    COS_TROPIC,
    COS_HIKER,
    COS_EARTH,
    COS_COUNT
};

enum { PAT_NONE, PAT_FLOWERS, PAT_STRIPES, PAT_CHECK, PAT_DOTS };

typedef struct {
    uint8_t pattern;       // PAT_* drawn over the top (and robe)
    uint8_t robe;          // 1: bottom uses the top colour (kimono, monk robe)
    uint8_t tops[4][3];    // top colours to pick from
    uint8_t bottoms[2][3];
    uint8_t pat[2][3];     // pattern colours
} Costume;

enum { TINT_DAY, TINT_GOLDEN, TINT_EVENING };

typedef struct {
    const char *name;      // "STAGE 1" / "WORLD TOUR"
    const char *place;     // "The Balcony"
    const char *short_name;// map list label (max 12 chars)
    const char *story;
    uint8_t bg;            // BG_*
    uint8_t tint;
    uint8_t music;         // MUS_*
    uint8_t costume;       // COS_*
    uint8_t fence_y, fence_x0, fence_x1;
    uint8_t drain;         // frames per HP lost (base)
    uint8_t spawn_min, spawn_max;
    uint8_t goal;          // base love goal
} StageDef;

enum {
    STG_BALCONY = 0,
    STG_YAHOO = 1,
    STG_DEST0 = 2,         // 18 world tour destinations follow
    STG_HOME = STG_DEST0 + 18,
    NUM_STAGES
};
#define NUM_DESTS 18
#define HOME_UNLOCK 4      // destinations to clear before Home opens

extern const StageDef stages[NUM_STAGES];
extern const Npc npcs[];
extern const int npc_count;
extern const Costume costumes[COS_COUNT];

#endif // MOMO_WORLD_H
