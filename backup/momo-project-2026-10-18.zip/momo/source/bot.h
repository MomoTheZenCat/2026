// Momo Dev Story - balance-test bot interface (host builds only).

#ifndef MOMO_BOT_H
#define MOMO_BOT_H

#include <stdint.h>

typedef struct {
    int smart;      // 1: picks good skills and spends points well
    int react_pct;  // chance to notice and hide from a flaming human
    int act_pct;    // chance per decision to actually use a skill
    int delay;      // frames between decisions
    int full;       // 1: tour all 18 destinations before going home
} BotCfg;

#define SIM_STAGES 9    // short route: balcony, Yahoo!, six destinations, home
#define SIM_MAX 21      // full route: balcony, Yahoo!, all destinations, home

typedef struct {
    int result;      // stages cleared (0..stages)
    int stages;      // length of the route played
    int timeout;
    int buddha;      // times the Neko Nyorai cutscene happened
    int rescued;
    int retries;     // game overs that cost a life
    int deaths[SIM_MAX];  // game overs per stage (the free rescue not included)
    uint32_t score;
    uint32_t run_frames;     // stage (1-based) where Evans & Shannon helped, 0 = never
    int frames[SIM_MAX];
    int min_hp[SIM_MAX];
    int fails[SIM_MAX];
    int charmed[SIM_MAX];
    int level[SIM_MAX];
    int devdad[SIM_MAX];
    int tally[SIM_MAX][8];  // drain, fail, rage, +hp, +mp, tries, spawns, rages
} SimResult;

void game_cheat(int what);
int game_sim(int cat, const BotCfg *b, uint32_t seed, SimResult *res);

#endif // MOMO_BOT_H
