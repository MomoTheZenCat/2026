// Momo Dev Story - world data: stages, the cast of named humans, outfits.
//
// Every named human always has the same weakness, resistance and favourite
// reaction (and the same look), so players can learn them and write guides.
// `./build/host/momo_host guide` prints the whole cast as a Markdown table.

#include "world.h"
#include "plat.h"

#define D(home) (STG_DEST0 + (home))
#define T NPC_TRAVELER

enum {
    W_SF, W_ALASKA, W_PR, W_HAWAII, W_SEATTLE, W_MEXICO, W_GUATEMALA, W_TEXAS, W_SHASTA,
    W_FLORIDA, W_USVI, W_AMAZON, W_MACHU, W_TAHITI, W_TAIWAN, W_JAPAN, W_HENAN, W_PARIS,
};

const Npc npcs[] = {
    // --- world travellers: they pop up anywhere on the world tour ---
    { "Linda", PK_CATLOVER, SK_MEOW, 5, RE_FEED, T },
    { "Hiro", PK_TOURIST, SK_CUTE, 20, RE_PHOTO, T },
    { "Marco", PK_COURIER, SK_BUMP, 50, RE_PET, T },
    { "Fatima", PK_DOGWALKER, SK_PURR, 55, RE_BRUSH, T },

    // --- the balcony ---
    { "Linda", PK_CATLOVER, SK_MEOW, 5, RE_FEED, STG_BALCONY },
    { "Grandma Mei", PK_GRANNY, SK_BLINK, 10, RE_FEED, STG_BALCONY },
    { "Jake", PK_JOGGER, SK_YOGA, 70, RE_PET, STG_BALCONY },
    { "Priya", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, STG_BALCONY },
    { "Marco", PK_COURIER, SK_BUMP, 50, RE_PET, STG_BALCONY },
    { "Ollie", PK_KID, SK_BELLY, 20, RE_PET, STG_BALCONY },
    { "Fatima", PK_DOGWALKER, SK_PURR, 55, RE_BRUSH, STG_BALCONY },
    { "Greg", PK_COMMUTER, SK_LOAF, 60, RE_PHOTO, STG_BALCONY },
    { "Rosa", PK_CATLOVER, SK_FOODPAW, 8, RE_FEED, STG_BALCONY },
    { "Ben", PK_STUDENT, SK_YOGA, 30, RE_PHOTO, STG_BALCONY },
    { "Auntie Lily", PK_GRANNY, SK_FOODPAW, 10, RE_FEED, STG_BALCONY },
    { "Darnell", PK_JOGGER, SK_BUMP, 60, RE_PET, STG_BALCONY },
    { "Sofia", PK_KID, SK_CUTE, 15, RE_PET, STG_BALCONY },
    { "Hiro", PK_TOURIST, SK_CUTE, 20, RE_PHOTO, STG_BALCONY },

    // --- Yahoo! HQ, 2016 ---
    { "Raj", PK_ENGINEER, SK_BLINK, 35, RE_BRUSH, STG_YAHOO },
    { "Wei", PK_ENGINEER, SK_YOGA, 40, RE_BRUSH, STG_YAHOO },
    { "Ashley", PK_PM, SK_CUTE, 30, RE_PHOTO, STG_YAHOO },
    { "Tom", PK_PM, SK_LOAF, 35, RE_PHOTO, STG_YAHOO },
    { "Kevin", PK_INTERN, SK_FOODPAW, 10, RE_FEED, STG_YAHOO },
    { "Mia", PK_INTERN, SK_MEOW, 10, RE_FEED, STG_YAHOO },
    { "Big Al", PK_GUARD, SK_BELLY, 75, RE_FEED, STG_YAHOO },
    { "Officer Chen", PK_GUARD, SK_BLINK, 70, RE_FEED, STG_YAHOO },
    { "Mr. Yodel", PK_EXEC, SK_PURR, 80, RE_PET, STG_YAHOO },
    { "Jake", PK_JOGGER, SK_YOGA, 70, RE_PET, STG_YAHOO },
    { "Marco", PK_COURIER, SK_BUMP, 50, RE_PET, STG_YAHOO },
    { "Linda", PK_CATLOVER, SK_MEOW, 5, RE_FEED, STG_YAHOO },

    // --- San Francisco ---
    { "Sam", PK_COMMUTER, SK_LOAF, 55, RE_PHOTO, D(W_SF) },
    { "Luna", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_SF) },
    { "Pete", PK_COURIER, SK_BUMP, 50, RE_PET, D(W_SF) },
    { "Grandpa Joe", PK_GRANNY, SK_BLINK, 15, RE_FEED, D(W_SF) },
    { "Ava", PK_DOGWALKER, SK_PURR, 50, RE_BRUSH, D(W_SF) },
    { "Kai", PK_JOGGER, SK_YOGA, 65, RE_PET, D(W_SF) },
    { "Noor", PK_ENGINEER, SK_BLINK, 35, RE_BRUSH, D(W_SF) },

    // --- Alaska ---
    { "Aiyana", PK_CATLOVER, SK_MEOW, 10, RE_FEED, D(W_ALASKA) },
    { "Bud", PK_DOGWALKER, SK_PURR, 55, RE_BRUSH, D(W_ALASKA) },
    { "Hank", PK_COURIER, SK_BUMP, 55, RE_PET, D(W_ALASKA) },
    { "Elsa", PK_TOURIST, SK_CUTE, 25, RE_PHOTO, D(W_ALASKA) },
    { "Skip", PK_JOGGER, SK_YOGA, 70, RE_PET, D(W_ALASKA) },
    { "Nana Ruth", PK_GRANNY, SK_BLINK, 10, RE_FEED, D(W_ALASKA) },
    { "Musher Mike", PK_DOGWALKER, SK_LOAF, 60, RE_BRUSH, D(W_ALASKA) },

    // --- Puerto Rico ---
    { "Isabella", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_PR) },
    { "Luis", PK_COMMUTER, SK_LOAF, 55, RE_PHOTO, D(W_PR) },
    { "Abuela Carmen", PK_GRANNY, SK_FOODPAW, 10, RE_FEED, D(W_PR) },
    { "Javi", PK_KID, SK_BELLY, 20, RE_PET, D(W_PR) },
    { "Marisol", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_PR) },
    { "Tito", PK_COURIER, SK_BUMP, 50, RE_PET, D(W_PR) },
    { "Coqui Kid", PK_KID, SK_MEOW, 15, RE_PET, D(W_PR) },

    // --- Hawaii ---
    { "Keoni", PK_SURFER, SK_YOGA, 30, RE_PET, D(W_HAWAII) },
    { "Leilani", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_HAWAII) },
    { "Tutu Malia", PK_GRANNY, SK_BLINK, 10, RE_FEED, D(W_HAWAII) },
    { "Kimo", PK_SURFER, SK_BELLY, 35, RE_PHOTO, D(W_HAWAII) },
    { "Mele", PK_STUDENT, SK_CUTE, 20, RE_PHOTO, D(W_HAWAII) },
    { "Duke", PK_DOGWALKER, SK_PURR, 50, RE_BRUSH, D(W_HAWAII) },
    { "Auntie Pua", PK_GRANNY, SK_FOODPAW, 10, RE_FEED, D(W_HAWAII) },

    // --- Seattle ---
    { "Riley", PK_ENGINEER, SK_BLINK, 35, RE_BRUSH, D(W_SEATTLE) },
    { "Juniper", PK_STUDENT, SK_YOGA, 30, RE_PHOTO, D(W_SEATTLE) },
    { "Doug", PK_COMMUTER, SK_LOAF, 60, RE_PHOTO, D(W_SEATTLE) },
    { "Sasha", PK_DOGWALKER, SK_PURR, 55, RE_BRUSH, D(W_SEATTLE) },
    { "Brooks", PK_JOGGER, SK_YOGA, 70, RE_PET, D(W_SEATTLE) },
    { "Wren", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_SEATTLE) },
    { "Barista Moss", PK_INTERN, SK_FOODPAW, 15, RE_FEED, D(W_SEATTLE) },

    // --- Mexico ---
    { "Lupita", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_MEXICO) },
    { "Diego", PK_COURIER, SK_BUMP, 50, RE_PET, D(W_MEXICO) },
    { "Dona Elena", PK_GRANNY, SK_FOODPAW, 10, RE_FEED, D(W_MEXICO) },
    { "Mateo", PK_KID, SK_BELLY, 20, RE_PET, D(W_MEXICO) },
    { "Ximena", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_MEXICO) },
    { "Don Pancho", PK_COMMUTER, SK_LOAF, 60, RE_PHOTO, D(W_MEXICO) },
    { "Mariachi Beto", PK_TOURIST, SK_PURR, 30, RE_PHOTO, D(W_MEXICO) },

    // --- Guatemala ---
    { "Ana", PK_CATLOVER, SK_BLINK, 10, RE_FEED, D(W_GUATEMALA) },
    { "Pedro", PK_COURIER, SK_BUMP, 55, RE_PET, D(W_GUATEMALA) },
    { "Rosa Maria", PK_GRANNY, SK_MEOW, 10, RE_FEED, D(W_GUATEMALA) },
    { "Kevin Jr.", PK_KID, SK_CUTE, 20, RE_PET, D(W_GUATEMALA) },
    { "Lucia", PK_TOURIST, SK_CUTE, 20, RE_PHOTO, D(W_GUATEMALA) },
    { "Oscar", PK_DOGWALKER, SK_PURR, 55, RE_BRUSH, D(W_GUATEMALA) },
    { "Weaver Itzel", PK_GRANNY, SK_LOAF, 15, RE_BRUSH, D(W_GUATEMALA) },

    // --- Texas ---
    { "Dolly", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_TEXAS) },
    { "Cody", PK_JOGGER, SK_BUMP, 65, RE_PET, D(W_TEXAS) },
    { "Earl", PK_GRANNY, SK_BLINK, 15, RE_FEED, D(W_TEXAS) },
    { "Tex", PK_COURIER, SK_BUMP, 60, RE_PET, D(W_TEXAS) },
    { "Bubba", PK_DOGWALKER, SK_BELLY, 60, RE_BRUSH, D(W_TEXAS) },
    { "Maria", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_TEXAS) },
    { "Oil Baron Bo", PK_EXEC, SK_LOAF, 80, RE_PET, D(W_TEXAS) },

    // --- Mt. Shasta (they came in peace) ---
    { "Zorp", PK_ALIEN, SK_PURR, 40, RE_PHOTO, D(W_SHASTA) },
    { "Blip", PK_ALIEN, SK_MEOW, 30, RE_PHOTO, D(W_SHASTA) },
    { "Glorx", PK_ALIEN, SK_BELLY, 60, RE_PET, D(W_SHASTA) },
    { "Sky", PK_TOURIST, SK_YOGA, 25, RE_PHOTO, D(W_SHASTA) },
    { "River", PK_CATLOVER, SK_BLINK, 10, RE_FEED, D(W_SHASTA) },
    { "Ranger Dan", PK_GUARD, SK_LOAF, 70, RE_FEED, D(W_SHASTA) },
    { "Xyl-9", PK_ALIEN, SK_CUTE, 45, RE_BRUSH, D(W_SHASTA) },

    // --- Florida ---
    { "Bev", PK_GRANNY, SK_BLINK, 10, RE_FEED, D(W_FLORIDA) },
    { "Chad", PK_JOGGER, SK_YOGA, 65, RE_PET, D(W_FLORIDA) },
    { "Destiny", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_FLORIDA) },
    { "Gator Gary", PK_DOGWALKER, SK_BELLY, 60, RE_BRUSH, D(W_FLORIDA) },
    { "Coral", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_FLORIDA) },
    { "Buzz", PK_EXEC, SK_PURR, 80, RE_PET, D(W_FLORIDA) },
    { "Shelly", PK_SURFER, SK_YOGA, 30, RE_PHOTO, D(W_FLORIDA) },

    // --- U.S. Virgin Islands ---
    { "Keisha", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_USVI) },
    { "Captain Ray", PK_COMMUTER, SK_LOAF, 55, RE_PHOTO, D(W_USVI) },
    { "Miss Hyacinth", PK_GRANNY, SK_FOODPAW, 10, RE_FEED, D(W_USVI) },
    { "Jalen", PK_SURFER, SK_YOGA, 35, RE_PET, D(W_USVI) },
    { "Nia", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_USVI) },
    { "Desmond", PK_COURIER, SK_BUMP, 50, RE_PET, D(W_USVI) },
    { "Sailor Jo", PK_TOURIST, SK_BELLY, 30, RE_PHOTO, D(W_USVI) },

    // --- The Amazon ---
    { "Shaman Yawa", PK_SHAMAN, SK_BLINK, 40, RE_BRUSH, D(W_AMAZON) },
    { "Taina", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_AMAZON) },
    { "Dr. Ruiz", PK_TOURIST, SK_CUTE, 30, RE_PHOTO, D(W_AMAZON) },
    { "Iara", PK_STUDENT, SK_YOGA, 30, RE_PHOTO, D(W_AMAZON) },
    { "Bento", PK_COURIER, SK_BUMP, 55, RE_PET, D(W_AMAZON) },
    { "Shaman Kaya", PK_SHAMAN, SK_PURR, 45, RE_PET, D(W_AMAZON) },
    { "Little Caua", PK_KID, SK_BELLY, 20, RE_PET, D(W_AMAZON) },

    // --- Machu Picchu ---
    { "Guide Quispe", PK_COMMUTER, SK_LOAF, 50, RE_PHOTO, D(W_MACHU) },
    { "Mama Rosa", PK_GRANNY, SK_FOODPAW, 10, RE_FEED, D(W_MACHU) },
    { "Inti", PK_KID, SK_BELLY, 20, RE_PET, D(W_MACHU) },
    { "Killa", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_MACHU) },
    { "Backpacker Ben", PK_TOURIST, SK_YOGA, 25, RE_PHOTO, D(W_MACHU) },
    { "Tupac", PK_JOGGER, SK_YOGA, 70, RE_PET, D(W_MACHU) },
    { "Llama Lady", PK_DOGWALKER, SK_BLINK, 45, RE_BRUSH, D(W_MACHU) },

    // --- Tahiti ---
    { "Moana", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_TAHITI) },
    { "Teva", PK_SURFER, SK_BELLY, 35, RE_PHOTO, D(W_TAHITI) },
    { "Mama Tiare", PK_GRANNY, SK_BLINK, 10, RE_FEED, D(W_TAHITI) },
    { "Hina", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_TAHITI) },
    { "Manu", PK_SURFER, SK_YOGA, 30, RE_PET, D(W_TAHITI) },
    { "Claire", PK_TOURIST, SK_CUTE, 20, RE_PHOTO, D(W_TAHITI) },
    { "Resort Boss", PK_EXEC, SK_PURR, 75, RE_PET, D(W_TAHITI) },

    // --- Taiwan ---
    { "A-Ma Chen", PK_GRANNY, SK_FOODPAW, 5, RE_FEED, D(W_TAIWAN) },
    { "Xiao Ming", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_TAIWAN) },
    { "Uncle Lin", PK_COMMUTER, SK_LOAF, 55, RE_PHOTO, D(W_TAIWAN) },
    { "Yu-Ting", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_TAIWAN) },
    { "Ah-Hao", PK_COURIER, SK_BUMP, 55, RE_PET, D(W_TAIWAN) },
    { "Wen", PK_JOGGER, SK_YOGA, 60, RE_PET, D(W_TAIWAN) },
    { "Boba Jia-Hui", PK_INTERN, SK_FOODPAW, 10, RE_FEED, D(W_TAIWAN) },

    // --- Japan ---
    { "Yuki", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_JAPAN) },
    { "Kenji", PK_COMMUTER, SK_LOAF, 60, RE_PHOTO, D(W_JAPAN) },
    { "Obaachan Hana", PK_GRANNY, SK_BLINK, 10, RE_FEED, D(W_JAPAN) },
    { "Sora", PK_KID, SK_BELLY, 20, RE_PET, D(W_JAPAN) },
    { "Takeshi", PK_COURIER, SK_BUMP, 55, RE_PET, D(W_JAPAN) },
    { "Sakura", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_JAPAN) },
    { "Salaryman Goto", PK_EXEC, SK_LOAF, 75, RE_PET, D(W_JAPAN) },

    // --- Henan (Shaolin monks, Longmen Grottoes) ---
    { "Master Shi", PK_MONK, SK_BLINK, 60, RE_BRUSH, D(W_HENAN) },
    { "Brother Wu", PK_MONK, SK_YOGA, 55, RE_PET, D(W_HENAN) },
    { "Little Bao", PK_KID, SK_BELLY, 20, RE_PET, D(W_HENAN) },
    { "Ling", PK_TOURIST, SK_CUTE, 25, RE_PHOTO, D(W_HENAN) },
    { "Grandpa Zhang", PK_GRANNY, SK_PURR, 15, RE_FEED, D(W_HENAN) },
    { "Abbot Fang", PK_MONK, SK_PURR, 75, RE_PET, D(W_HENAN) },
    { "Brother Liu", PK_MONK, SK_LOAF, 50, RE_BRUSH, D(W_HENAN) },

    // --- Paris ---
    { "Amelie", PK_CATLOVER, SK_MEOW, 5, RE_FEED, D(W_PARIS) },
    { "Pierre", PK_COMMUTER, SK_LOAF, 60, RE_PHOTO, D(W_PARIS) },
    { "Madame Colette", PK_GRANNY, SK_BLINK, 10, RE_FEED, D(W_PARIS) },
    { "Jules", PK_COURIER, SK_BUMP, 55, RE_PET, D(W_PARIS) },
    { "Chloe", PK_STUDENT, SK_CUTE, 25, RE_PHOTO, D(W_PARIS) },
    { "Bernard", PK_DOGWALKER, SK_PURR, 55, RE_BRUSH, D(W_PARIS) },
    { "Chef Gaston", PK_EXEC, SK_FOODPAW, 70, RE_FEED, D(W_PARIS) },

    // --- Home again (the final stage: everyone from the start, all grown up) ---
    { "Linda", PK_CATLOVER, SK_MEOW, 10, RE_FEED, STG_HOME },
    { "Grandma Mei", PK_GRANNY, SK_BLINK, 15, RE_FEED, STG_HOME },
    { "Jake", PK_JOGGER, SK_YOGA, 75, RE_PET, STG_HOME },
    { "Priya", PK_STUDENT, SK_CUTE, 30, RE_PHOTO, STG_HOME },
    { "Marco", PK_COURIER, SK_BUMP, 60, RE_PET, STG_HOME },
    { "Fatima", PK_DOGWALKER, SK_PURR, 60, RE_BRUSH, STG_HOME },
    { "Greg", PK_COMMUTER, SK_LOAF, 70, RE_PHOTO, STG_HOME },
    { "Darnell", PK_JOGGER, SK_BUMP, 70, RE_PET, STG_HOME },
    { "Big Al", PK_GUARD, SK_BELLY, 80, RE_FEED, STG_HOME },
    { "Mr. Yodel", PK_EXEC, SK_PURR, 85, RE_PET, STG_HOME },
};

const int npc_count = sizeof(npcs) / sizeof(npcs[0]);

#define DEST_LEDGE 117

#ifndef HOME_DRAIN   // the final stage (tuned with `momo_host deaths`)
#define HOME_DRAIN 28
#endif
#ifndef HOME_SPMIN
#define HOME_SPMIN 76
#endif
#ifndef HOME_SPMAX
#define HOME_SPMAX 160
#endif
#ifndef HOME_GOAL
#define HOME_GOAL 30
#endif

const StageDef stages[NUM_STAGES] = {
    [STG_BALCONY] = { "STAGE 1", "The Balcony", "Balcony",
                      "Momo's kingdom: a fence,\nsome bougainvillea, and a\nsteady stream of humans.",
                      BG_BALCONY, TINT_DAY, MUS_BALCONY, COS_NONE, 113, 40, 236, 32, 80, 170, 24 },
    [STG_YAHOO] = { "STAGE 2", "Yahoo! HQ 2016", "Yahoo! 2016",
                    "The time machine landed\nat Yahoo! HQ in 2016.\nCharm the purple campus!",
                    BG_YAHOO, TINT_DAY, MUS_YAHOO, COS_NONE, 117, 28, 228, 28, 70, 150, 30 },

    [D(W_SF)] = { "WORLD TOUR", "San Francisco", "San Fran",
                  "Fog, cable cars and the\nGolden Gate. Techies and\ntourists everywhere.",
                  BG_SF, TINT_DAY, MUS_BALCONY, COS_NONE, DEST_LEDGE, 24, 232, 30, 78, 165, 26 },
    [D(W_ALASKA)] = { "WORLD TOUR", "Alaska", "Alaska",
                      "Snowy peaks and the\nnorthern lights. Bundle\nup, everyone's in parkas!",
                      BG_ALASKA, TINT_DAY, MUS_BALCONY, COS_PARKA, DEST_LEDGE, 24, 232, 26, 82, 170, 26 },
    [D(W_PR)] = { "WORLD TOUR", "Puerto Rico", "Puerto Rico",
                  "Old San Juan: pastel\nhouses, El Morro and\nwarm Caribbean breezes.",
                  BG_PUERTORICO, TINT_DAY, MUS_TROPICAL, COS_TROPIC, DEST_LEDGE, 24, 232, 30, 78, 165, 26 },
    [D(W_HAWAII)] = { "WORLD TOUR", "Hawaii", "Hawaii",
                      "Aloha! Surfers, shave ice\nand Diamond Head. Aloha\nshirts are mandatory.",
                      BG_HAWAII, TINT_DAY, MUS_TROPICAL, COS_ALOHA, DEST_LEDGE, 24, 232, 30, 78, 165, 26 },
    [D(W_SEATTLE)] = { "WORLD TOUR", "Seattle", "Seattle",
                       "Space Needle, coffee and\ndrizzle. Bring a raincoat\nto Pike Place Market!",
                       BG_SEATTLE, TINT_DAY, MUS_BALCONY, COS_RAINCOAT, DEST_LEDGE, 24, 232, 28, 76, 160, 26 },
    [D(W_MEXICO)] = { "WORLD TOUR", "Mexico", "Mexico",
                      "Papel picado, pyramids\nand cacti. Colourful\nsarapes all around.",
                      BG_MEXICO, TINT_DAY, MUS_TROPICAL, COS_WOVEN, DEST_LEDGE, 24, 232, 28, 78, 165, 26 },
    [D(W_GUATEMALA)] = { "WORLD TOUR", "Guatemala", "Guatemala",
                         "Antigua's yellow arch\nunder three volcanoes.\nWoven textiles galore.",
                         BG_GUATEMALA, TINT_DAY, MUS_TROPICAL, COS_WOVEN, DEST_LEDGE, 24, 232, 28, 78, 165, 26 },
    [D(W_TEXAS)] = { "WORLD TOUR", "Texas", "Texas",
                     "Everything's bigger in\nTexas. Remember the\nAlamo... and the cat.",
                     BG_TEXAS, TINT_DAY, MUS_BALCONY, COS_PLAID, DEST_LEDGE, 24, 232, 27, 76, 160, 26 },
    [D(W_SHASTA)] = { "WORLD TOUR", "Mount Shasta", "Mt. Shasta",
                      "A sacred mountain... with\na UFO parked on it. The\naliens want photos!",
                      BG_SHASTA, TINT_DAY, MUS_YAHOO, COS_HIKER, DEST_LEDGE, 24, 232, 28, 78, 165, 26 },
    [D(W_FLORIDA)] = { "WORLD TOUR", "Florida", "Florida",
                       "Flamingos, rockets and\nbeach boardwalks. Watch\nout for Gator Gary.",
                       BG_FLORIDA, TINT_DAY, MUS_TROPICAL, COS_TROPIC, DEST_LEDGE, 24, 232, 28, 78, 165, 26 },
    [D(W_USVI)] = { "WORLD TOUR", "U.S. Virgin Islands", "USVI",
                    "Turquoise bays and white\nsails. Island time is\nslow... but HP isn't.",
                    BG_USVI, TINT_DAY, MUS_TROPICAL, COS_TROPIC, DEST_LEDGE, 24, 232, 28, 80, 168, 26 },
    [D(W_AMAZON)] = { "WORLD TOUR", "The Amazon", "Amazon",
                      "A great brown river and a\nshaman's round maloca.\nThe jungle is listening.",
                      BG_AMAZON, TINT_DAY, MUS_TROPICAL, COS_EARTH, DEST_LEDGE, 24, 232, 26, 80, 168, 26 },
    [D(W_MACHU)] = { "WORLD TOUR", "Machu Picchu", "Machu Picchu",
                     "Ancient terraces high in\nthe Andes. Llamas judge\nyou silently.",
                     BG_MACHUPICCHU, TINT_DAY, MUS_TITLE, COS_WOVEN, DEST_LEDGE, 24, 232, 26, 80, 168, 26 },
    [D(W_TAHITI)] = { "WORLD TOUR", "Tahiti", "Tahiti",
                      "Overwater bungalows and a\nlagoon so blue it hurts.\nPure paradise.",
                      BG_TAHITI, TINT_DAY, MUS_TROPICAL, COS_ALOHA, DEST_LEDGE, 24, 232, 30, 80, 168, 26 },
    [D(W_TAIWAN)] = { "WORLD TOUR", "Taiwan", "Taiwan",
                      "Taipei 101, red lanterns\nand bubble tea. Dad's\nhometown crowd!",
                      BG_TAIWAN, TINT_DAY, MUS_ASIA, COS_NONE, DEST_LEDGE, 24, 232, 28, 76, 160, 26 },
    [D(W_JAPAN)] = { "WORLD TOUR", "Japan", "Japan",
                     "Mt. Fuji, a torii gate and\ncherry blossoms. Kimono\nseason!",
                     BG_JAPAN, TINT_DAY, MUS_ASIA, COS_KIMONO, DEST_LEDGE, 24, 232, 28, 78, 165, 26 },
    [D(W_HENAN)] = { "WORLD TOUR", "Henan", "Henan",
                       "Shaolin monks train by the\nLongmen Grottoes. Inner\npeace makes them resist.",
                       BG_HENAN, TINT_DAY, MUS_ASIA, COS_ROBE, DEST_LEDGE, 24, 232, 26, 80, 170, 26 },
    [D(W_PARIS)] = { "WORLD TOUR", "Paris", "Paris",
                     "Croissants, cafes and the\nEiffel Tower. Stripes\nare very a la mode.",
                     BG_PARIS, TINT_DAY, MUS_TITLE, COS_BRETON, DEST_LEDGE, 24, 232, 28, 76, 160, 26 },

    [STG_HOME] = { "FINAL STAGE", "Home Sweet Home", "HOME",
                   "Back to the balcony for\none last evening. The\nwhole street is here!",
                   BG_BALCONY, TINT_EVENING, MUS_BALCONY, COS_NONE, 113, 40, 236, HOME_DRAIN, HOME_SPMIN, HOME_SPMAX, HOME_GOAL },
};

const Costume costumes[COS_COUNT] = {
    [COS_NONE] = { PAT_NONE, 0, { { 0 } }, { { 0 } }, { { 0 } } },
    [COS_ALOHA] = { PAT_FLOWERS, 0,
                    { { 220, 60, 70 }, { 40, 120, 200 }, { 30, 160, 150 }, { 250, 190, 50 } },
                    { { 200, 180, 130 }, { 70, 90, 140 } },
                    { { 255, 255, 255 }, { 255, 190, 210 } } },
    [COS_KIMONO] = { PAT_DOTS, 1,
                     { { 40, 50, 120 }, { 190, 40, 60 }, { 230, 150, 180 }, { 40, 130, 120 } },
                     { { 0, 0, 0 }, { 0, 0, 0 } },
                     { { 255, 220, 230 }, { 250, 230, 150 } } },
    [COS_ROBE] = { PAT_NONE, 1,
                   { { 236, 140, 40 }, { 220, 120, 30 }, { 150, 140, 130 }, { 236, 150, 50 } },
                   { { 0, 0, 0 }, { 0, 0, 0 } },
                   { { 0, 0, 0 }, { 0, 0, 0 } } },
    [COS_PARKA] = { PAT_STRIPES, 0,
                    { { 210, 50, 50 }, { 40, 90, 180 }, { 240, 140, 30 }, { 60, 140, 80 } },
                    { { 40, 40, 50 }, { 70, 70, 80 } },
                    { { 0, 0, 0 }, { 0, 0, 0 } } },   // darker quilting: computed
    [COS_WOVEN] = { PAT_STRIPES, 0,
                    { { 200, 40, 80 }, { 230, 120, 30 }, { 50, 120, 190 }, { 120, 40, 140 } },
                    { { 60, 70, 110 }, { 50, 40, 40 } },
                    { { 250, 210, 60 }, { 60, 180, 120 } } },
    [COS_BRETON] = { PAT_STRIPES, 0,
                     { { 245, 245, 240 }, { 245, 245, 240 }, { 245, 245, 240 }, { 245, 245, 240 } },
                     { { 40, 40, 60 }, { 120, 100, 80 } },
                     { { 30, 40, 100 }, { 180, 30, 40 } } },
    [COS_PLAID] = { PAT_CHECK, 0,
                    { { 190, 40, 40 }, { 40, 80, 160 }, { 60, 120, 60 }, { 200, 120, 40 } },
                    { { 60, 84, 140 }, { 50, 60, 100 } },
                    { { 0, 0, 0 }, { 0, 0, 0 } } },
    [COS_RAINCOAT] = { PAT_NONE, 0,
                       { { 250, 210, 40 }, { 40, 60, 110 }, { 60, 120, 80 }, { 200, 50, 50 } },
                       { { 40, 40, 50 }, { 60, 84, 140 } },
                       { { 0, 0, 0 }, { 0, 0, 0 } } },
    [COS_TROPIC] = { PAT_FLOWERS, 0,
                     { { 250, 150, 170 }, { 120, 210, 220 }, { 250, 230, 120 }, { 170, 230, 140 } },
                     { { 240, 240, 230 }, { 200, 180, 130 } },
                     { { 255, 255, 255 }, { 240, 90, 120 } } },
    [COS_HIKER] = { PAT_NONE, 0,
                    { { 110, 120, 60 }, { 220, 110, 40 }, { 170, 40, 40 }, { 60, 100, 140 } },
                    { { 170, 150, 110 }, { 90, 80, 60 } },
                    { { 0, 0, 0 }, { 0, 0, 0 } } },
    [COS_EARTH] = { PAT_DOTS, 0,
                    { { 170, 140, 90 }, { 110, 120, 70 }, { 150, 90, 50 }, { 200, 170, 110 } },
                    { { 110, 80, 50 }, { 80, 70, 50 } },
                    { { 230, 200, 120 }, { 200, 60, 40 } } },
};
