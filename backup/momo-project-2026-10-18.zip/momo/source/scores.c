// Momo Dev Story - leaderboard, saved through the platform layer.

#include <string.h>

#include "plat.h"
#include "scores.h"

#define RANK_MAGIC 0x4D4F4D31u   // "MOM1"

void scores_load(RankTable *t)
{
    if (!plat_load(t, sizeof(*t)) || t->magic != RANK_MAGIC || t->count > RANK_N) {
        memset(t, 0, sizeof(*t));
        t->magic = RANK_MAGIC;
    }
}

void scores_save(const RankTable *t)
{
    plat_save(t, sizeof(*t));
}

int scores_rank(const RankTable *t, uint32_t score)
{
    for (uint32_t i = 0; i < t->count; i++)
        if (score > t->e[i].score)
            return (int)i;
    return t->count < RANK_N ? (int)t->count : -1;
}

int scores_insert(RankTable *t, const RankEntry *e)
{
    int pos = scores_rank(t, e->score);
    if (pos < 0)
        return -1;
    int last = t->count < RANK_N ? (int)t->count : RANK_N - 1;
    for (int i = last; i > pos; i--)
        t->e[i] = t->e[i - 1];
    t->e[pos] = *e;
    if (t->count < RANK_N)
        t->count++;
    return pos;
}
