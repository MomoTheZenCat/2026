# Renders contact sheets of all sprites for eyeballing (not used by the build).
import sys
from PIL import Image
import gen_sprites as S

PERSON_PAL = [(0,0,0),(40,30,30),(232,190,160),(200,150,120),(60,40,30),(220,80,90),(170,50,60),
              (60,80,140),(60,50,50),(240,200,80),(110,80,60),(30,30,30),(255,255,255),(200,160,110),(190,140,90),(240,120,150)]

def render(c, pal, scale=3):
    im = Image.new("RGB", (c.w, c.h), (120, 170, 120))
    px = im.load()
    for y in range(c.h):
        for x in range(c.w):
            v = c.px[y][x]
            if v:
                px[x, y] = pal[v] if v < len(pal) else (255, 0, 255)
    return im.resize((c.w * scale, c.h * scale), Image.NEAREST)

def sheet(imgs, cols, out):
    w = max(i.width for i in imgs); h = max(i.height for i in imgs)
    rows = (len(imgs) + cols - 1) // cols
    sh = Image.new("RGB", (cols * (w + 4), rows * (h + 4)), (40, 40, 40))
    for k, im in enumerate(imgs):
        sh.paste(im, ((k % cols) * (w + 4), (k // cols) * (h + 4)))
    sh.save(out)

out = sys.argv[1]
cats = []
for kind in ("momo", "mochi", "oreo"):
    pal = [(0,0,0)] + S.CAT_PALETTES[kind]
    fr = S.cat_frames(kind)
    cats += [render(fr[n], pal) for n in S.CAT_FRAME_NAMES]
sheet(cats, 12, out + "/cats.png")
ppl = []
for n in S.PEOPLE_ORDER:
    ppl += [render(c, PERSON_PAL) for c in S.person_frames(n)]
sheet(ppl, 16, out + "/people.png")
sheet([render(S.dog(0), PERSON_PAL, 4), render(S.dog(1), PERSON_PAL, 4)] +
      [render(S.icon(n), S.UI_PAL, 6) for n in S.ICON_ORDER], 10, out + "/icons.png")
