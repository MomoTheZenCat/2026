# Momo Dev Story - procedural background art (256x192, full colour).
# Each function returns a PIL RGB image. Imported by gen_assets.py.

import math
import random

from PIL import Image, ImageDraw, ImageFont

W, H = 256, 192
FONT_DIR = "/System/Library/Fonts/Supplemental/"


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def vgrad(d, x0, y0, x1, y1, c0, c1):
    for y in range(y0, y1):
        t = (y - y0) / max(1, (y1 - y0 - 1))
        d.line([(x0, y), (x1 - 1, y)], fill=lerp(c0, c1, t))


def speckle(img, box, colors, density, rnd):
    x0, y0, x1, y1 = box
    px = img.load()
    for _ in range(int((x1 - x0) * (y1 - y0) * density)):
        x = rnd.randrange(x0, x1)
        y = rnd.randrange(y0, y1)
        px[x, y] = rnd.choice(colors)


def blob(d, cx, cy, r, color, rnd, n=7, spread=0.6):
    """Leafy cluster made of overlapping circles."""
    for _ in range(n):
        a = rnd.random() * math.tau
        rr = r * (0.4 + rnd.random() * 0.6)
        ox = math.cos(a) * r * spread
        oy = math.sin(a) * r * spread * 0.8
        d.ellipse([cx + ox - rr, cy + oy - rr, cx + ox + rr, cy + oy + rr], fill=color)


def tree_canopy(d, img, cx, cy, r, rnd, dark, mid, light):
    blob(d, cx, cy, r, dark, rnd, n=14, spread=0.75)
    blob(d, cx - r * 0.15, cy - r * 0.2, r * 0.75, mid, rnd, n=10, spread=0.7)
    blob(d, cx - r * 0.3, cy - r * 0.4, r * 0.4, light, rnd, n=6, spread=0.6)


def grass_clump(d, cx, by, h, w, rnd, c_dark, c_light):
    for i in range(int(w * 1.6)):
        t = rnd.random() * 2 - 1
        x_top = cx + t * w * 1.2 + rnd.randint(-2, 2)
        y_top = by - h * (1 - abs(t) * 0.55) - rnd.randint(0, 3)
        x_bot = cx + t * w * 0.35
        d.line([(x_bot, by), (x_top, y_top)], fill=rnd.choice([c_dark, c_light, c_light]))


def shrub(d, cx, cy, r, rnd):
    blob(d, cx, cy, r, (34, 74, 34), rnd, n=8, spread=0.5)
    blob(d, cx - 1, cy - 2, r * 0.7, (58, 110, 46), rnd, n=6, spread=0.5)
    blob(d, cx - 2, cy - 3, r * 0.35, (96, 150, 64), rnd, n=3, spread=0.5)


def bougainvillea(d, img, x0, y0, x1, y1, rnd, flowers=40):
    for _ in range(int((x1 - x0) * (y1 - y0) / 30)):
        x = rnd.uniform(x0, x1)
        y = rnd.uniform(y0, y1)
        r = rnd.uniform(2, 4.5)
        c = rnd.choice([(40, 92, 36), (62, 122, 44), (88, 150, 58), (52, 104, 40)])
        d.ellipse([x - r, y - r * 0.7, x + r, y + r * 0.7], fill=c)
    for _ in range(flowers):
        x = rnd.uniform(x0, x1)
        y = rnd.uniform(y0, y1)
        c = rnd.choice([(214, 28, 96), (236, 60, 130), (190, 20, 80)])
        d.rectangle([x, y, x + 1, y + 1], fill=c)
        if rnd.random() < 0.5:
            d.point((x + 2, y), fill=c)


def prayer_flags(d, x0, y0, x1, y1, sag, rnd, colors):
    """A sagging string of little flags between two points."""
    n = 0
    pts = []
    steps = int(abs(x1 - x0))
    for i in range(steps + 1):
        t = i / steps
        x = x0 + (x1 - x0) * t
        y = y0 + (y1 - y0) * t + math.sin(t * math.pi) * sag
        pts.append((x, y))
    d.line(pts, fill=(200, 60, 50), width=1)
    i = 3
    while i < len(pts) - 3:
        x, y = pts[i]
        c = colors[n % len(colors)]
        d.polygon([(x - 3, y), (x + 3, y), (x + 2, y + 8), (x - 2, y + 7)], fill=c)
        d.line([(x - 3, y), (x + 3, y)], fill=(210, 70, 60))
        n += 1
        i += 9


def siding(d, x0, y0, x1, y1, base, line, step=6):
    d.rectangle([x0, y0, x1, y1], fill=base)
    for x in range(x0, x1 + 1, step):
        d.line([(x, y0), (x, y1)], fill=line)


def slat_fence(d, x0, y0, x1, y1, slat=(150, 156, 160), gap=(70, 76, 82), cap=(176, 182, 186)):
    d.rectangle([x0, y0, x1, y1], fill=gap)
    y = y0 + 5
    while y < y1:
        d.rectangle([x0, y, x1, y + 4], fill=slat)
        d.line([(x0, y), (x1, y)], fill=(178, 184, 188))
        y += 7
    # top cap rail (Momo's catwalk)
    d.rectangle([x0 - 2, y0, x1, y0 + 4], fill=cap)
    d.line([(x0 - 2, y0), (x1, y0)], fill=(206, 210, 212))
    d.line([(x0 - 2, y0 + 5), (x1, y0 + 5)], fill=(96, 100, 104))
    # posts
    for px in range(x0 + 2, x1, 54):
        d.rectangle([px, y0 + 5, px + 3, y1], fill=(128, 134, 138))


def balcony(seed=7):
    rnd = random.Random(seed)
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    vgrad(d, 0, 0, W, 96, (32, 96, 210), (150, 196, 240))

    # far apartment building ("807") on the left
    d.rectangle([0, 52, 92, 112], fill=(176, 182, 188))
    siding(d, 0, 60, 92, 112, (184, 190, 196), (160, 166, 172), 5)
    d.polygon([(0, 52), (96, 52), (88, 46), (0, 46)], fill=(70, 74, 82))
    d.rectangle([6, 66, 30, 84], fill=(70, 84, 104))
    d.rectangle([40, 66, 64, 84], fill=(70, 84, 104))
    d.rectangle([0, 86, 92, 89], fill=(110, 116, 124))
    for x in range(2, 92, 4):
        d.line([(x, 86), (x, 96)], fill=(96, 100, 108))
    d.rectangle([66, 92, 86, 112], fill=(150, 156, 162))
    d.rectangle([60, 58, 78, 64], fill=(60, 66, 74))
    big = ImageFont.truetype(FONT_DIR + "Arial Bold.ttf", 7)
    d.text((62, 57), "807", font=big, fill=(230, 232, 236))

    # big pine tree on the left
    d.polygon([(46, 120), (52, 40), (56, 40), (60, 120)], fill=(88, 64, 48))
    d.line([(54, 60), (30, 36)], fill=(88, 64, 48), width=2)
    d.line([(54, 50), (80, 26)], fill=(88, 64, 48), width=2)
    for (cx, cy, r) in [(30, 30, 16), (54, 18, 18), (82, 24, 15), (20, 52, 12), (70, 44, 12), (40, 6, 12)]:
        tree_canopy(d, img, cx, cy, r, rnd, (24, 56, 36), (36, 78, 46), (60, 104, 58))
    # tree behind the house
    tree_canopy(d, img, 112, 54, 20, rnd, (30, 66, 40), (46, 90, 50), (74, 120, 64))

    # the house on the right (two storeys, light grey board siding)
    siding(d, 96, 0, 255, 120, (204, 208, 212), (178, 182, 188), 6)
    d.rectangle([236, 0, 255, 120], fill=(190, 194, 198))
    # upper balcony: roof overhang + cable railing
    d.polygon([(92, 6), (240, 0), (240, 6), (96, 10)], fill=(72, 76, 84))
    d.rectangle([98, 12, 230, 50], fill=(150, 156, 164))
    d.rectangle([102, 14, 226, 46], fill=(120, 134, 150))
    for y in range(16, 46, 3):
        d.line([(102, y), (226, y)], fill=(196, 200, 206))
    for x in (100, 142, 184, 226):
        d.rectangle([x - 2, 12, x + 1, 50], fill=(170, 176, 182))
    d.rectangle([96, 48, 232, 56], fill=(176, 180, 186))
    d.line([(96, 56), (232, 56)], fill=(110, 114, 120))
    # support posts
    d.rectangle([100, 56, 104, 112], fill=(176, 180, 186))
    d.rectangle([206, 56, 210, 112], fill=(176, 180, 186))
    # ground floor: sliding doors in the shade
    d.rectangle([105, 57, 205, 112], fill=(96, 104, 114))
    for x in (110, 140, 170):
        d.rectangle([x, 64, x + 26, 110], fill=(54, 66, 84))
        d.line([(x + 4, 66), (x + 12, 90)], fill=(84, 98, 120))
    prayer_flags(d, 104, 58, 206, 60, 12, rnd,
                 [(240, 240, 232), (244, 220, 120), (236, 236, 228), (230, 120, 110), (240, 240, 232)])

    # bougainvillea and potted plants behind the fence
    bougainvillea(d, img, 120, 80, 238, 112, rnd, flowers=60)
    bougainvillea(d, img, 40, 92, 110, 112, rnd, flowers=12)
    d.rectangle([232, 100, 240, 110], fill=(230, 230, 226))  # succulent pot
    blob(d, 236, 98, 4, (90, 150, 110), rnd, n=4)

    # garden bed to the left of the fence
    d.rectangle([0, 110, 34, 152], fill=(122, 74, 52))
    speckle(img, (0, 110, 34, 152), [(150, 96, 64), (96, 58, 42), (84, 50, 36)], 0.35, rnd)
    shrub(d, 18, 112, 12, rnd)

    # Momo's fence (fence top at y=112)
    slat_fence(d, 32, 112, 255, 158)
    # bougainvillea draping over the fence front
    for (x0, x1, dy) in [(150, 200, 26), (200, 250, 34), (226, 255, 18)]:
        bougainvillea(d, img, x0, 116, x1, 116 + dy, rnd, flowers=18)

    # mulch bed + shrubs + ornamental grass
    d.rectangle([0, 152, 255, 168], fill=(122, 74, 52))
    speckle(img, (0, 152, 256, 169), [(150, 96, 64), (96, 58, 42), (170, 120, 80), (84, 50, 36)], 0.35, rnd)
    for x in range(40, 256, 26):
        shrub(d, x + rnd.randint(-4, 4), 154, 7 + rnd.randint(0, 3), rnd)
    grass_clump(d, 14, 160, 34, 12, rnd, (120, 140, 140), (170, 188, 184))
    grass_clump(d, 4, 120, 20, 10, rnd, (120, 140, 140), (170, 188, 184))
    grass_clump(d, 26, 140, 22, 8, rnd, (110, 132, 130), (164, 182, 178))
    # rocks
    for _ in range(10):
        x = rnd.randint(4, 34)
        y = rnd.randint(160, 166)
        d.ellipse([x, y, x + 4, y + 3], fill=rnd.choice([(170, 168, 160), (196, 192, 184), (140, 138, 132)]))

    # concrete path (where the humans walk)
    vgrad(d, 0, 168, W, H, (172, 172, 168), (196, 196, 190))
    d.line([(0, 168), (255, 168)], fill=(140, 140, 136))
    speckle(img, (0, 169, 256, 192), [(160, 160, 156), (206, 206, 200)], 0.08, rnd)
    for x in range(-20, 260, 64):
        d.line([(x, 192), (x + 14, 169)], fill=(150, 150, 146))
    # tree shadows on the path
    sh = Image.new("L", (W, H), 0)
    sd = ImageDraw.Draw(sh)
    for _ in range(9):
        x = rnd.randint(0, 255)
        y = rnd.randint(172, 190)
        sd.ellipse([x - 14, y - 3, x + 14, y + 3], fill=70)
    img = _shade(img, sh)
    return img


def _shade(img, mask, k=0.78):
    px = img.load()
    m = mask.load()
    for y in range(H):
        for x in range(W):
            if m[x, y]:
                r, g, b = px[x, y]
                px[x, y] = (int(r * k), int(g * k), int(b * k * 1.04))
    return img


def warm(img, k_sky=0.0):
    """Golden-hour version of a scene for the title screen."""
    out = img.copy()
    px = out.load()
    for y in range(H):
        for x in range(W):
            r, g, b = px[x, y]
            t = 0.55
            r2 = min(255, int(r * 0.9 + 70 * t))
            g2 = min(255, int(g * 0.72 + 26 * t))
            b2 = int(b * 0.5 + 20 * t)
            px[x, y] = (r2, g2, b2)
    # sunset sky gradient over the blue area
    for y in range(0, 100):
        for x in range(W):
            r, g, b = img.getpixel((x, y))
            if b > r + 40 and b > 150:  # sky pixel
                c = lerp((248, 140, 70), (255, 214, 140), y / 100)
                px[x, y] = c
    return out


def yahoo_logo(img, x, y, size, color, shadow=None):
    """Classic (pre-2013) Yahoo! wordmark: chunky slab letters that bounce
    up and down and tilt in alternating directions."""
    font = ImageFont.truetype(FONT_DIR + "SuperClarendon.ttc", size, index=7)
    letters = "YAHOO!"
    dys = [0, 0.12, -0.04, 0.09, -0.06, -0.12]
    rots = [-7, 6, -3, 5, -6, 9]
    cx = x
    for ch, dy, rot in zip(letters, dys, rots):
        tw = int(size * 1.2)
        tile = Image.new("L", (tw, tw), 0)
        ImageDraw.Draw(tile).text((size * 0.1, 0), ch, font=font, fill=255)
        tile = tile.rotate(rot, resample=Image.BICUBIC, center=(tw / 2, tw / 2))
        mask = tile.point(lambda v: 255 if v > 110 else 0)
        oy = int(y + dy * size)
        if shadow:
            img.paste(shadow, (cx + max(1, size // 14), oy + max(1, size // 14)), mask)
        img.paste(color, (cx, oy), mask)
        bbox = mask.getbbox()
        adv = (bbox[2] if bbox else tw) - (size * 0.06)
        if ch == "!":
            adv = bbox[2] if bbox else tw
        cx += int(adv) - int(size * 0.08)
    return cx


def yahoo(seed=11):
    rnd = random.Random(seed)
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    vgrad(d, 0, 0, W, 120, (172, 196, 222), (226, 232, 238))

    # left low building + solar canopy
    d.rectangle([0, 92, 70, 128], fill=(190, 194, 200))
    for x in range(2, 70, 8):
        d.rectangle([x, 98, x + 5, 124], fill=(150, 164, 180))
    d.polygon([(0, 80), (66, 72), (72, 78), (6, 88)], fill=(150, 130, 90))
    for i in range(0, 66, 6):
        d.line([(i, 80 - i // 9), (i + 6, 87 - i // 9)], fill=(90, 80, 60))
    d.line([(10, 88), (10, 128)], fill=(200, 200, 204), width=2)
    d.line([(60, 78), (60, 128)], fill=(200, 200, 204), width=2)

    # glass atrium on the right with curved roof
    d.rectangle([140, 52, 255, 128], fill=(178, 196, 210))
    d.pieslice([140, 30, 380, 90], 180, 270, fill=(160, 178, 194))
    d.rectangle([140, 60, 255, 128], fill=(176, 196, 212))
    for x in range(144, 256, 10):
        d.line([(x, 56), (x, 128)], fill=(226, 232, 238))
    for y in range(62, 128, 12):
        d.line([(140, y), (255, y)], fill=(226, 232, 238))
    for x in range(150, 256, 20):  # diagonal braces
        d.line([(x, 62), (x + 10, 86)], fill=(214, 222, 230))
        d.line([(x + 20, 62), (x + 10, 86)], fill=(214, 222, 230))
    d.rectangle([140, 104, 255, 108], fill=(150, 156, 164))  # canopy
    # sparkle on glass
    for _ in range(40):
        x = rnd.randint(142, 254)
        y = rnd.randint(58, 126)
        d.point((x, y), fill=(240, 246, 252))

    # the purple Yahoo! tower
    d.rectangle([62, 14, 142, 128], fill=(84, 46, 160))
    d.rectangle([62, 14, 66, 128], fill=(70, 36, 138))
    for y in range(18, 128, 3):
        if rnd.random() < 0.3:
            d.line([(67, y), (141, y)], fill=(90, 52, 168))
    # glass curtain wall on the lower tower
    d.rectangle([76, 66, 132, 128], fill=(120, 146, 170))
    for x in range(76, 133, 9):
        d.line([(x, 66), (x, 128)], fill=(214, 220, 228))
    for y in range(66, 129, 10):
        d.line([(76, y), (132, y)], fill=(214, 220, 228))
    d.rectangle([94, 110, 114, 128], fill=(70, 86, 104))  # entrance
    # centre the logo on the tower (x 62..142): measure it on a scratch image first
    scratch = Image.new("RGB", (W, H))
    logo_w = yahoo_logo(scratch, 0, 24, 14, (250, 250, 252))
    # optical centre: the tower's dark left strip makes true centre look left
    yahoo_logo(img, 103 - logo_w // 2, 24, 14, (250, 250, 252))

    # lamp posts + Yahoo banner + small trees
    for lx in (46, 150, 222):
        d.line([(lx, 60), (lx, 136)], fill=(200, 204, 210), width=2)
        d.ellipse([lx - 6, 56, lx + 6, 61], fill=(216, 220, 226))
    d.rectangle([152, 66, 162, 96], fill=(90, 50, 170))
    sf = ImageFont.truetype(FONT_DIR + "Arial Bold.ttf", 7)
    for i, ch in enumerate("YAHOO"):
        d.text((154, 67 + i * 6), ch, font=sf, fill=(250, 250, 252))
    for (tx, ty) in [(122, 104), (178, 108), (196, 102)]:
        d.line([(tx, ty), (tx, 132)], fill=(110, 80, 60), width=2)
        tree_canopy(d, img, tx, ty - 6, 10, rnd, (52, 96, 44), (86, 134, 60), (130, 170, 84))

    # lawn
    vgrad(d, 0, 128, W, 168, (86, 150, 60), (110, 170, 74))
    speckle(img, (0, 128, 256, 168), [(70, 130, 50), (130, 186, 90)], 0.2, rnd)
    # white YAHOO! sign wall (Momo's catwalk, top at y=116)
    d.polygon([(20, 118), (236, 116), (236, 156), (20, 158)], fill=(232, 232, 236))
    d.rectangle([20, 116, 236, 120], fill=(246, 246, 248))
    d.line([(20, 121), (236, 121)], fill=(196, 196, 204))
    d.line([(236, 116), (236, 156)], fill=(190, 190, 198))
    yahoo_logo(img, 56, 121, 30, (122, 30, 160), shadow=(70, 16, 100))
    # lawn in front + concrete walkway
    vgrad(d, 0, 156, W, 168, (96, 160, 66), (110, 172, 76))
    speckle(img, (0, 156, 256, 168), [(76, 138, 54), (136, 190, 96)], 0.2, rnd)
    vgrad(d, 0, 168, W, H, (198, 198, 194), (222, 222, 218))
    d.line([(0, 168), (255, 168)], fill=(160, 160, 156))
    speckle(img, (0, 169, 256, 192), [(186, 186, 182), (232, 232, 228)], 0.06, rnd)
    for x in range(0, 260, 48):
        d.line([(x, 169), (x - 10, 192)], fill=(176, 176, 172))
    return img


def living_room(seed=5):
    """Cat select: indoors by the window with the monstera (photo #2)."""
    rnd = random.Random(seed)
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, W, H], fill=(214, 196, 168))
    # window with the sunny garden outside
    d.rectangle([20, 10, 236, 120], fill=(236, 236, 230))
    d.rectangle([26, 16, 230, 114], fill=(150, 200, 120))
    vgrad(d, 26, 16, 231, 50, (190, 220, 160), (150, 200, 120))
    slat_fence(d, 26, 62, 230, 100, slat=(170, 176, 170), gap=(110, 120, 110), cap=(190, 196, 190))
    bougainvillea(d, img, 26, 30, 230, 70, rnd, flowers=30)
    bougainvillea(d, img, 26, 90, 230, 114, rnd, flowers=6)
    d.rectangle([126, 16, 130, 114], fill=(236, 236, 230))
    # monstera silhouettes (dark split leaves in front of the window)
    def leaf(cx, cy, r, ang, stem):
        m = Image.new("L", (W, H), 0)
        md = ImageDraw.Draw(m)
        md.ellipse([cx - r, cy - r * 0.8, cx + r, cy + r * 0.8], fill=255)
        for k in range(-3, 4):
            a = ang + k * 0.42
            x0 = cx + math.cos(a) * r * 0.35
            y0 = cy + math.sin(a) * r * 0.3
            md.line([(x0, y0), (cx + math.cos(a) * r * 1.2, cy + math.sin(a) * r)], fill=0, width=2)
        for k in (-2, 0, 2):
            a = ang + k * 0.42 + 0.2
            hx = cx + math.cos(a) * r * 0.25
            hy = cy + math.sin(a) * r * 0.2
            md.ellipse([hx - 1.5, hy - 1, hx + 1.5, hy + 1], fill=0)
        img.paste((22, 36, 26), mask=m)
        d.line([(cx - math.cos(ang) * r * 0.9, cy - math.sin(ang) * r * 0.7), stem], fill=(22, 36, 26), width=2)

    leaf(18, 64, 28, 0.2, (40, 152))
    leaf(236, 46, 22, 3.0, (230, 130))
    leaf(70, 112, 20, -0.6, (44, 152))
    # wooden floor
    vgrad(d, 0, 128, W, H, (170, 120, 80), (140, 96, 62))
    for y in range(132, H, 9):
        d.line([(0, y), (255, y)], fill=(120, 82, 52))
    for _ in range(30):
        y = rnd.randrange(132, H)
        x = rnd.randrange(0, W)
        d.line([(x, y), (x + rnd.randint(8, 20), y)], fill=(156, 108, 70))
    d.rectangle([0, 122, 255, 128], fill=(236, 230, 220))  # skirting
    # three cushions
    for cx, col in [(48, (220, 110, 110)), (128, (110, 150, 210)), (208, (120, 180, 120))]:
        d.ellipse([cx - 26, 156, cx + 26, 176], fill=tuple(int(c * 0.7) for c in col))
        d.ellipse([cx - 25, 152, cx + 25, 172], fill=col)
        d.ellipse([cx - 16, 156, cx + 16, 166], fill=tuple(min(255, int(c * 1.15)) for c in col))
    return img


def panel(seed=3):
    """Bottom screen backdrop: cream paper with faint paw prints."""
    rnd = random.Random(seed)
    img = Image.new("RGB", (W, H), (252, 240, 220))
    d = ImageDraw.Draw(img)
    for y in range(0, H, 2):
        d.line([(0, y), (255, y)], fill=(248, 234, 212))
    for _ in range(14):
        x = rnd.randint(8, 248)
        y = rnd.randint(8, 184)
        c = (240, 222, 196)
        d.ellipse([x - 4, y - 3, x + 4, y + 4], fill=c)
        for k, (dx, dy) in enumerate([(-5, -6), (-2, -8), (2, -8), (5, -6)]):
            d.ellipse([x + dx - 1, y + dy - 1, x + dx + 2, y + dy + 2], fill=c)
    return img


def intro_sky(seed=9):
    """Sunrise over the neighbourhood for the opening animation."""
    rnd = random.Random(seed)
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    vgrad(d, 0, 0, W, 130, (60, 80, 170), (250, 180, 120))
    d.ellipse([168, 70, 220, 122], fill=(255, 226, 150))
    d.ellipse([174, 76, 214, 116], fill=(255, 244, 200))
    # rooftops silhouettes
    for x0, w, h in [(0, 60, 40), (50, 50, 56), (96, 70, 36), (160, 40, 50), (196, 60, 30)]:
        y = 130 - h
        d.rectangle([x0, y, x0 + w, 130], fill=(70, 60, 90))
        d.polygon([(x0 - 4, y), (x0 + w // 2, y - 14), (x0 + w + 4, y)], fill=(60, 50, 80))
        for k in range(2):
            wx = x0 + 8 + k * (w // 2)
            d.rectangle([wx, y + 8, wx + 8, y + 16], fill=(250, 210, 120) if rnd.random() < 0.6 else (90, 80, 110))
    tree_canopy(d, img, 40, 104, 18, rnd, (40, 50, 50), (54, 66, 62), (70, 84, 76))
    # road
    vgrad(d, 0, 130, W, H, (120, 110, 120), (160, 150, 150))
    for x in range(0, W, 32):
        d.rectangle([x, 160, x + 16, 162], fill=(230, 220, 190))
    return img


ALL = {
    "bg_balcony": balcony,
    "bg_yahoo": yahoo,
    "bg_select": living_room,
    "bg_panel": panel,
    "bg_intro": intro_sky,
}


def bg_title():
    return warm(balcony())


ALL["bg_title"] = bg_title
