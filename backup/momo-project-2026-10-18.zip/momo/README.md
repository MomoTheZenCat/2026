# Momo Dev Story

*2026.10.26*. A Nintendo DS homebrew game built with [BlocksDS](https://blocksds.skylyrac.net),
starring Momo, with Evans & Shannon.

Momo the orange tabby sits on the balcony fence and watches humans walk by.
Charm them with cat skills so they feed you (HP), pet, brush or photograph
you (MP). HP slowly drains from hunger, so keep the fans coming!

## Gameplay

| Button | Action |
| --- | --- |
| Left / Right | Walk along the fence |
| Up / Down or Y (L / R jump columns) | Pick a skill |
| A (or tap a skill twice) | Use skill |
| **B (hold)** | **Hide behind the fence** from flaming humans |
| X | Skill tree (spend skill points) |
| START | Pause (SELECT on the pause screen quits to the title) |

- **Hearts** above a human show how well a skill worked: full heart (+3
  love), half heart (+2), empty heart (+1). A **"!"** means it failed and
  Momo loses HP. Collect enough love to clear the stage.
- **[ALL] skills** (Meow, Cute Pose, Purr) hit everyone in range. They are
  less likely to work and give smaller rewards each, but several successes at
  once give a **COMBO** bonus. **[1] skills** focus on one human: more
  reliable and bigger rewards.
- **Groom** is free: it restores some MP and makes your next skill more likely
  to work. Momo picks one of four routines: paw lick, the leg-up "drumstick",
  face wash or ear scratch. **Food Paw** always makes the human feed you if it works.
- **Shin Bump** and **Belly Up** make Momo jump off the fence. They cost a lot
  of MP but are very effective.
- **Cat Eye** (passive) gets stronger with each level: Lv1 mood, Lv2 what they
  like, Lv3 their weakness, Lv4 your exact success chance.
- **Red flames** behind a human (angry commuters, couriers in a hurry) cost HP,
  and **black flames** cost HP and MP, unless you hold **B** to hide.
- Every human has a weakness: cat lovers can't resist a Meow, joggers respect
  Cat Yoga, couriers fold to a Shin Bump, security guards to Belly Up...
- A secret human (Uncle Dev) may show up when Momo is struggling...
- Every level-up opens the skill tree (it closes once all points are spent).
  The first one is a big celebration: +5 points and Cat Eye +1.
- Charm **5 humans at once** and Momo ascends as the **Neko Nyorai** (Buddha
  cat), clearing the stage instantly.
- The **first time** Momo's HP hits 0, Dad Evans and Mom Shannon come to the
  rescue (only once per playthrough).
- After stage 1 everyone takes the time machine (88 MPH!) back to Yahoo! in
  2016. After Yahoo!, a Super-Mario-World-style **world map** opens with 18
  destinations (San Francisco, Alaska, Puerto Rico, Hawaii, Seattle,
  Mexico, Guatemala, Texas, Mt. Shasta with aliens, Florida, USVI, the Amazon,
  Machu Picchu, Tahiti, Taiwan, Japan, Henan, Paris). Locals dress
  for the place (aloha shirts, kimono, monk robes, parkas, stripes...).
- Visit 4 destinations to unlock **Home** - the final stage and the ending.
  Each destination you clear makes the next one harder.
- Every human has a **name** and fixed traits, so you can learn them:
  see [GUIDE.md](GUIDE.md) (generated with `./build/host/momo_host guide`).
- You have **3 lives**. When the run ends you get a score, enter your
  initials and see your rank and play time on the **leaderboard** (title
  screen: SELECT). It is saved to `momo_dev_story.sav` on the flashcart / SD
  card; in melonDS enable *Config > DLDI > Enable DLDI* to keep it.
- Leave Momo alone for a few seconds and she melts into a sunbeam.
- Secret / play-testing code: Up Up Down Down Left Right Left Right B A
  (melonDS keys: arrows, Z, X) works on every screen and skips one step
  ahead: title -> world map, stage 1 -> time machine -> Yahoo! -> world map,
  any destination -> cleared and back to the map, Home -> ending; on the
  map it stamps the selected destination.

Pick from three cats: **Momo** (orange tabby, bigger food rewards), **Mochi**
(ragdoll, bigger pet/brush rewards) or **Oreo** (tuxedo, cheaper jump skills).

Each area has its own chill background music (START > X turns it off).

## Music and sound

`tools/gen_audio.py` synthesises soft instrument samples (electric piano,
harp, marimba, flute, upright bass, pad, shaker and a woodblock "clock tick"),
composes the songs as XM tracker modules and renders the sound effects as WAV
files into `audio/`. The Makefile packs them with `mmutil` into a Maxmod
soundbank. Songs are slow (72-92 BPM) with maj7/add9 harmony and an echo
channel; effects are short, low-passed and pitch-jittered so repeats don't
grate.

```sh
python3 tools/gen_audio.py                              # regenerate audio/
python3 tools/gen_audio.py --preview build/audio_preview # WAV previews
afplay build/audio_preview/m_title.wav                   # listen on a Mac
```

## Building the ROM

Install BlocksDS ([macOS](https://blocksds.skylyrac.net/docs/setup/macos/),
[Linux](https://blocksds.skylyrac.net/docs/setup/linux/)), then:

```sh
make            # -> momo_dev_story.nds
```

Run `momo_dev_story.nds` in [melonDS](https://melonds.kuribo64.net) or
copy it to a flashcart.

## Art

There are no image files. All backgrounds and sprites are drawn in code by
`tools/gen_backgrounds.py` and `tools/gen_sprites.py`, and exported to
`source/gen/assets.{c,h}` (committed, so `make` does not need Python). After
changing the art:

```sh
python3 tools/gen_assets.py
python3 tools/preview_sprites.py /tmp   # optional contact sheets
```

## PC test harness

The game logic is plain C that renders into two RGB15 framebuffers, so it also
builds natively for automated tests:

```sh
./build.host.sh
./build/host/momo_host shots host/scripts/tour.txt /tmp/shots   # screenshots (PPM)
./build/host/momo_host sim 300                                  # balance simulation
./build/host/momo_host tally                                    # HP/MP flow per stage
```

`sim` plays the whole game with bot players (AFK, button-masher, casual,
average, good) and reports how often each clears every stage.

## Layout

```
source/main_nds.c   DS platform layer: video, input, PSG sound effects
source/game.c       all game logic and screens
source/gfx.c        software renderer (sprites, text, panels)
source/gen/         generated art
tools/              art generators
host/               PC harness + screenshot scripts
```
