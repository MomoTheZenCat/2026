# Momo Dev Story - procedural sprite art.
# Sprites are indexed (0 = transparent) and recoloured at runtime with
# palettes, so one set of frames serves many passers-by.

import math

from PIL import Image, ImageDraw

# --------------------------------------------------------------------------
# Canvas helpers
# --------------------------------------------------------------------------

OUT = 1  # outline index shared by every palette


class FillDraw:
    """ImageDraw wrapper whose shapes default to a solid 255 fill."""

    def __init__(self, img):
        self.d = ImageDraw.Draw(img)

    def __getattr__(self, name):
        fn = getattr(self.d, name)

        def call(*a, **k):
            k.setdefault("fill", 255)
            return fn(*a, **k)
        return call


class Canvas:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.px = [[0] * w for _ in range(h)]

    def mask(self):
        m = Image.new("L", (self.w, self.h), 0)
        return m, FillDraw(m)

    def part(self, draw_fn, fill, outline=True):
        """Draw a shape with its own outline on top of what's there."""
        m, md = self.mask()
        draw_fn(md)
        mp = m.load()
        inside = [[mp[x, y] > 0 for x in range(self.w)] for y in range(self.h)]
        if outline:
            for y in range(self.h):
                for x in range(self.w):
                    if inside[y][x]:
                        continue
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < self.w and 0 <= ny < self.h and inside[ny][nx]:
                            self.px[y][x] = OUT
                            break
        for y in range(self.h):
            for x in range(self.w):
                if inside[y][x]:
                    self.px[y][x] = fill
        return inside

    def paint(self, draw_fn, fill, clip=None):
        """Draw without outline; optionally only where clip is True."""
        m, md = self.mask()
        draw_fn(md)
        mp = m.load()
        for y in range(self.h):
            for x in range(self.w):
                if mp[x, y] and (clip is None or clip[y][x]):
                    self.px[y][x] = fill

    def put(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[y][x] = c

    def outline_edges(self):
        """Close any open edge where a filled pixel touches the border."""
        for y in range(self.h):
            for x in range(self.w):
                if self.px[y][x] and (x in (0, self.w - 1) or y in (0, self.h - 1)):
                    self.px[y][x] = OUT

    def flipped(self):
        c = Canvas(self.w, self.h)
        c.px = [row[::-1] for row in self.px]
        return c

    def rotated(self, deg):
        im = Image.new("L", (self.w, self.h))
        im.putdata([v for row in self.px for v in row])
        im = im.rotate(deg, resample=Image.NEAREST, center=(self.w / 2, self.h / 2))
        c = Canvas(self.w, self.h)
        data = list(im.getdata())
        c.px = [data[y * self.w:(y + 1) * self.w] for y in range(self.h)]
        return c

    def shifted(self, dx, dy):
        c = Canvas(self.w, self.h)
        for y in range(self.h):
            for x in range(self.w):
                sx, sy = x - dx, y - dy
                if 0 <= sx < self.w and 0 <= sy < self.h:
                    c.px[y][x] = self.px[sy][sx]
        return c

    def flat(self):
        return [v for row in self.px for v in row]


def from_ascii(rows, key):
    h = len(rows)
    w = max(len(r) for r in rows)
    c = Canvas(w, h)
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            c.px[y][x] = key.get(ch, 0)
    return c


def thick(md, pts, w):
    md.line(pts, fill=255, width=w)
    r = (w - 1) / 2
    for (x, y) in (pts[0], pts[-1]):
        md.ellipse([x - r, y - r, x + r, y + r], fill=255)


# --------------------------------------------------------------------------
# Cats
# --------------------------------------------------------------------------
# palette slots
C_BASE, C_SHADE, C_LIGHT, C_PATCH, C_EYE, C_PINK, C_WHITE, C_PUPIL, C_RED, C_DRED, C_STICK, C_CLOTH = range(2, 14)

CAT_PALETTES = {
    # outline, base, shade, light, patch, eye, pink, white, pupil, red, dark red, stick, cloth
    "momo": [(64, 30, 16), (240, 150, 60), (206, 112, 40), (255, 232, 196), (192, 92, 28),
             (186, 200, 110), (240, 140, 150), (255, 255, 255), (30, 20, 16),
             (220, 40, 40), (150, 20, 30), (140, 90, 50), (90, 140, 220)],
    "mochi": [(70, 56, 52), (250, 244, 232), (214, 204, 192), (255, 255, 255), (138, 104, 86),
              (80, 150, 240), (240, 150, 160), (255, 255, 255), (20, 30, 60),
              (220, 40, 40), (150, 20, 30), (140, 90, 50), (240, 200, 90)],
    "oreo": [(24, 24, 30), (250, 250, 250), (210, 212, 220), (255, 255, 255), (40, 40, 48),
             (190, 210, 60), (240, 140, 150), (255, 255, 255), (16, 16, 20),
             (220, 40, 40), (150, 20, 30), (140, 90, 50), (230, 90, 140)],
}


def cat_patch_front(c, kind, head_box, body_box, dy):
    """Markings on the front-facing cat (painted inside existing fill)."""
    x0, y0, x1, y1 = head_box
    cx = (x0 + x1) / 2
    if kind == "momo":
        for x in (15, 16):
            for y in range(y0 + 1, y0 + 4):
                c.put(x, y, C_PATCH)
        c.put(12, y0 + 2, C_PATCH)
        c.put(19, y0 + 2, C_PATCH)
        c.put(13, y0 + 1, C_PATCH)
        c.put(18, y0 + 1, C_PATCH)
        for y in (y0 + 7, y0 + 9):
            c.put(x0 + 1, y, C_PATCH)
            c.put(x0 + 2, y, C_PATCH)
            c.put(x1 - 1, y, C_PATCH)
            c.put(x1 - 2, y, C_PATCH)
        bx0, by0, bx1, by1 = body_box
        for y in range(by0 + 5, by1 - 3, 3):
            c.put(bx0 + 1, y, C_PATCH)
            c.put(bx0 + 2, y + 1, C_PATCH)
            c.put(bx1 - 1, y, C_PATCH)
            c.put(bx1 - 2, y + 1, C_PATCH)
    elif kind == "mochi":
        clip = [[v == C_BASE for v in row] for row in c.px]
        c.paint(lambda md: md.ellipse([x0 + 2, y0 + 3, x1 - 2, y0 + 10]), C_PATCH, clip)
    elif kind == "oreo":
        clip = [[v == C_BASE for v in row] for row in c.px]
        c.paint(lambda md: md.rectangle([x0, y0, x1, y0 + 6]), C_PATCH, clip)
        c.paint(lambda md: md.ellipse([x0 + 1, y0 + 4, x0 + 7, y0 + 10]), C_PATCH, clip)
        for y in range(y0, y0 + 7):  # white blaze
            for x in (15, 16):
                if c.px[y][x] == C_PATCH:
                    c.px[y][x] = C_BASE
        bx0, by0, bx1, by1 = body_box
        c.paint(lambda md: md.ellipse([bx1 - 6, by0 + 3, bx1 + 2, by0 + 10]), C_PATCH, clip)


def cat_front(kind, eyes="open", mouth="normal", tail=0, paw_up=False, loaf=False,
              head_dy=0, bandana=False, tilt=0, groom=0, reach=False, bliss=False):
    c = Canvas(32, 32)
    if loaf:
        head = (7, 9 + head_dy, 24, 24 + head_dy)
        body = (5, 18, 26, 31)
    else:
        head = (7, 4 + head_dy, 24, 19 + head_dy)
        body = (8, 15, 23, 31)
    hx0, hy0, hx1, hy1 = head
    # tail behind the body
    tails = [[(21, 30), (27, 27), (29, 21), (27, 16)],
             [(21, 30), (27, 28), (30, 24), (30, 18)],
             [(21, 30), (26, 29), (29, 27), (31, 23)]]
    if not loaf:
        tpts = tails[tail % 3]
        tmask = c.part(lambda md: thick(md, tpts, 3), C_BASE)
        if kind == "momo":  # ringed tabby tail
            for i, row in enumerate(tmask):
                for x, v in enumerate(row):
                    if v and (x + i) % 4 == 0:
                        c.px[i][x] = C_PATCH
        tip = tpts[-1]
        c.paint(lambda md: md.ellipse([tip[0] - 1, tip[1] - 1, tip[0] + 1, tip[1] + 1]),
                C_PATCH if kind != "momo" else C_SHADE,
                [[v != OUT for v in row] for row in c.px])
    c.part(lambda md: md.ellipse(list(body)), C_BASE)
    bclip = [[v == C_BASE for v in row] for row in c.px]
    if kind == "oreo":
        c.paint(lambda md: md.ellipse([12, body[1] + 3, 19, 31]), C_LIGHT, bclip)
    else:
        c.paint(lambda md: md.ellipse([12, body[1] + 4, 19, 30]), C_LIGHT, bclip)
    # body shading on the left
    c.paint(lambda md: md.ellipse([body[0], body[1] + 6, body[0] + 3, body[3] - 1]), C_SHADE, bclip)
    if not loaf:
        c.part(lambda md: md.ellipse([10, 27, 14, 31]), C_LIGHT)
        if not paw_up:
            c.part(lambda md: md.ellipse([17, 27, 21, 31]), C_LIGHT)
    # ears
    tx = tilt
    ear_c = C_PATCH if kind in ("mochi", "oreo") else C_BASE
    c.part(lambda md: md.polygon([(hx0 + 1, hy0 + 6), (hx0 + 2 + tx, hy0 - 3), (hx0 + 8, hy0 + 2)]), ear_c)
    c.part(lambda md: md.polygon([(hx1 - 1, hy0 + 6), (hx1 - 2 + tx, hy0 - 3), (hx1 - 8, hy0 + 2)]), ear_c)
    c.paint(lambda md: md.polygon([(hx0 + 2, hy0 + 4), (hx0 + 3 + tx, hy0), (hx0 + 6, hy0 + 3)]), C_PINK)
    c.paint(lambda md: md.polygon([(hx1 - 2, hy0 + 4), (hx1 - 3 + tx, hy0), (hx1 - 6, hy0 + 3)]), C_PINK)
    # head
    hclip = c.part(lambda md: md.ellipse(list(head)), C_BASE)
    if kind == "mochi":  # fluffy ruff
        c.paint(lambda md: md.ellipse([hx0 + 2, hy1 - 4, hx1 - 2, hy1 + 3]), C_LIGHT)
    cat_patch_front(c, kind, head, body, head_dy)
    c.paint(lambda md: md.ellipse([12, hy0 + 8, 19, hy0 + 13]), C_LIGHT, hclip)
    if kind == "momo":
        c.paint(lambda md: md.ellipse([13, hy0 + 11, 18, hy1]), C_WHITE, hclip)
    # eyes
    ey = hy0 + 5
    for (ex, hl) in ((10, 10), (19, 19)):
        if eyes == "open" or eyes == "wide":
            for yy in range(ey, ey + 3):
                for xx in range(ex, ex + 3):
                    c.put(xx, yy, C_EYE)
            for yy in range(ey, ey + 3):
                c.put(ex + 1, yy, C_PUPIL)
            if eyes == "wide":
                for xx in range(ex, ex + 3):
                    c.put(xx, ey - 1, C_EYE)
                c.put(ex + 1, ey - 1, C_PUPIL)
            c.put(hl, ey, C_WHITE)
        elif eyes == "sparkle":
            for yy in range(ey - 1, ey + 3):
                for xx in range(ex, ex + 3):
                    c.put(xx, yy, C_PUPIL)
            c.put(ex, ey - 1, C_WHITE)
            c.put(ex + 1, ey, C_WHITE)
            c.put(ex + 2, ey + 2, C_WHITE)
        elif eyes == "closed":
            for xx in range(ex, ex + 3):
                c.put(xx, ey + 1, OUT)
        elif eyes == "happy":
            c.put(ex, ey + 1, OUT)
            c.put(ex + 1, ey, OUT)
            c.put(ex + 2, ey + 1, OUT)
        elif eyes == "slow":  # half-closed slow blink
            for xx in range(ex, ex + 3):
                c.put(xx, ey + 1, OUT)
                c.put(xx, ey + 2, C_EYE)
            c.put(ex + 1, ey + 2, C_PUPIL)
    # blush when happy / cute
    if eyes in ("happy", "sparkle"):
        c.put(9, ey + 4, C_PINK)
        c.put(10, ey + 4, C_PINK)
        c.put(21, ey + 4, C_PINK)
        c.put(22, ey + 4, C_PINK)
    # nose + mouth
    ny = hy0 + 9
    c.put(15, ny, C_PINK)
    c.put(16, ny, C_PINK)
    if mouth == "yawn":
        for yy in range(ny + 1, ny + 6):
            for xx in range(13, 19):
                c.put(xx, yy, OUT)
        for yy in range(ny + 2, ny + 5):
            for xx in range(14, 18):
                c.put(xx, yy, C_PINK)
        c.put(14, ny + 2, C_WHITE)
        c.put(17, ny + 2, C_WHITE)
    elif mouth == "open":
        for yy in (ny + 1, ny + 2, ny + 3):
            for xx in (14, 15, 16, 17):
                c.put(xx, yy, OUT)
        c.put(15, ny + 2, C_PINK)
        c.put(16, ny + 2, C_PINK)
        c.put(15, ny + 3, C_PINK)
        c.put(16, ny + 3, C_PINK)
    else:
        c.put(14, ny + 2, OUT)
        c.put(15, ny + 1, OUT)
        c.put(16, ny + 1, OUT)
        c.put(17, ny + 2, OUT)
    # whiskers
    for (x, y) in ((hx0, ny), (hx0 - 1, ny + 1), (hx1, ny), (hx1 + 1, ny + 1)):
        if c.px[y][x] in (0,):
            c.put(x, y, C_SHADE if kind == "momo" else OUT)
    if paw_up:
        c.part(lambda md: md.ellipse([18, hy1 - 4, 23, hy1 + 1]), C_LIGHT)
        c.put(20, hy1 - 3, C_PINK)
    if groom:
        # paw raised to the mouth, little pink tongue licking it
        py = hy1 - 3 + (groom - 1)
        c.part(lambda md: md.ellipse([13, py, 19, py + 5]), C_LIGHT)
        c.put(15, py - 1, C_PINK)
        c.put(16, py - 1, C_PINK)
        if groom == 1:
            c.put(16, py - 2, C_PINK)
    if reach:
        # paw stretched out towards the viewer (the "is that for me?" paw)
        c.part(lambda md: md.ellipse([20, hy1 - 1, 27, hy1 + 5]), C_LIGHT)
        c.put(22, hy1 + 2, C_PINK)
        c.put(24, hy1 + 2, C_PINK)
        c.put(23, hy1 + 3, C_PINK)
    if bliss:
        # face up to the sun: eyes squeezed shut, chin raised
        for ex in (10, 19):
            c.put(ex, ey + 1, OUT)
            c.put(ex + 1, ey + 2, OUT)
            c.put(ex + 2, ey + 1, OUT)
    if bandana:
        c.part(lambda md: md.polygon([(10, hy1 - 1), (21, hy1 - 1), (15.5, hy1 + 5)]), C_RED)
        c.paint(lambda md: md.line([(10, hy1 - 1), (21, hy1 - 1)], fill=255), C_DRED)
    if tilt:
        c = c.rotated(-tilt * 6)
    c.outline_edges()
    return c


def cat_side_patches(c, kind, body, head):
    bx0, by0, bx1, by1 = body
    hx0, hy0, hx1, hy1 = head
    bclip = [[v == C_BASE for v in row] for row in c.px]
    if kind == "momo":
        for x in range(bx0 + 3, bx1 - 2, 3):
            for y in range(by0 + 1, by0 + 5):
                if c.px[y][x] == C_BASE:
                    c.px[y][x] = C_PATCH
        c.put(hx0 + 4, hy0 + 1, C_PATCH)
        c.put(hx0 + 6, hy0 + 1, C_PATCH)
    elif kind == "mochi":
        c.paint(lambda md: md.ellipse([hx0 + 3, hy0 + 2, hx1 - 1, hy0 + 7]), C_PATCH, bclip)
    elif kind == "oreo":
        c.paint(lambda md: md.ellipse([bx0 + 4, by0 - 1, bx0 + 12, by0 + 5]), C_PATCH, bclip)
        c.paint(lambda md: md.rectangle([hx0, hy0, hx1, hy0 + 4]), C_PATCH, bclip)


def cat_side(kind, phase=0, eyes="open", pose="walk", bandana=False, bindle=False):
    """Side view facing right, feet at y=31."""
    c = Canvas(32, 32)
    lift = 0
    if pose == "walk":
        sw = [(-2, 2), (0, 0), (2, -2), (0, 0)][phase % 4]
        lift = phase % 2
    else:
        sw = (-3, 3)
    body = (5, 16 - lift, 24, 26 - lift)
    head = (19, 8 - lift, 30, 19 - lift)
    if pose == "bump":
        head = (20, 13, 31, 24)
    by = body[3] - 1
    # tail
    tpts = [(7, 19 - lift), (3, 14), (2, 8), (4, 4)] if phase % 2 == 0 else [(7, 19 - lift), (2, 15), (1, 10), (2, 5)]
    if pose == "bump":
        tpts = [(7, 18), (3, 12), (4, 5), (7, 2)]
    c.part(lambda md: thick(md, tpts, 3), C_BASE)
    tip = tpts[-1]
    c.paint(lambda md: md.ellipse([tip[0] - 1, tip[1] - 1, tip[0] + 1, tip[1] + 1]),
            C_PATCH if kind != "momo" else C_SHADE, [[v != OUT for v in row] for row in c.px])
    # far legs (shade)
    legs_far = [(9 - sw[0], by), (21 - sw[1], by)]
    legs_near = [(7 + sw[0], by), (19 + sw[1], by)]
    for (lx, ly) in legs_far:
        c.part(lambda md: md.rectangle([lx, ly - 2, lx + 2, 31 if pose != "jump" else ly + 3]), C_SHADE)
    c.part(lambda md: md.ellipse(list(body)), C_BASE)
    bclip = [[v == C_BASE for v in row] for row in c.px]
    c.paint(lambda md: md.ellipse([10, body[1] + 5, 21, body[3]]), C_LIGHT if kind != "momo" else C_LIGHT, bclip)
    for (lx, ly) in legs_near:
        c.part(lambda md: md.rectangle([lx, ly - 2, lx + 2, 31 if pose != "jump" else ly + 3]), C_BASE)
        c.put(lx, 31 if pose != "jump" else ly + 3, C_LIGHT)
        c.put(lx + 1, 31 if pose != "jump" else ly + 3, C_LIGHT)
    hx0, hy0, hx1, hy1 = head
    ear_c = C_PATCH if kind in ("mochi", "oreo") else C_BASE
    c.part(lambda md: md.polygon([(hx0 + 1, hy0 + 4), (hx0 + 2, hy0 - 3), (hx0 + 6, hy0 + 2)]), ear_c)
    c.part(lambda md: md.polygon([(hx0 + 6, hy0 + 2), (hx0 + 9, hy0 - 3), (hx1, hy0 + 4)]), ear_c)
    c.paint(lambda md: md.polygon([(hx0 + 7, hy0 + 2), (hx0 + 9, hy0 - 1), (hx1 - 1, hy0 + 3)]), C_PINK)
    hclip = c.part(lambda md: md.ellipse(list(head)), C_BASE)
    cat_side_patches(c, kind, body, head)
    c.paint(lambda md: md.ellipse([hx0 + 5, hy0 + 6, hx1 + 1, hy1]), C_LIGHT, hclip)
    ex, ey = hx0 + 6, hy0 + 4
    if eyes == "open":
        c.put(ex, ey, C_EYE)
        c.put(ex + 1, ey, C_EYE)
        c.put(ex, ey + 1, C_EYE)
        c.put(ex + 1, ey + 1, C_PUPIL)
        c.put(ex, ey + 2, C_EYE)
        c.put(ex + 1, ey + 2, C_PUPIL)
        c.put(ex, ey, C_WHITE)
    else:
        c.put(ex - 1, ey + 1, OUT)
        c.put(ex, ey + 2, OUT)
        c.put(ex + 1, ey + 1, OUT)
    c.put(hx1, hy0 + 6, C_PINK)
    c.put(hx1 - 1, hy0 + 6, C_PINK)
    if bandana:
        c.part(lambda md: md.polygon([(hx0 - 1, hy1 - 3), (hx0 + 4, hy1 + 1), (hx0, hy1 + 4)]), C_RED)
    if bindle:
        c.part(lambda md: md.line([(hx0 - 2, hy1 - 2), (hx0 - 12, hy0 - 6)], fill=255, width=1), C_STICK, False)
        c.part(lambda md: md.ellipse([hx0 - 17, hy0 - 9, hx0 - 9, hy0 - 2]), C_CLOTH)
        c.put(hx0 - 14, hy0 - 6, C_WHITE)
        c.put(hx0 - 11, hy0 - 4, C_WHITE)
    if pose == "jump":
        c = c.rotated(18)
    c.outline_edges()
    return c


def cat_yoga(kind):
    """Big downward-cat stretch: front paws forward, butt in the air."""
    c = Canvas(32, 32)
    c.part(lambda md: thick(md, [(6, 16), (3, 9), (5, 3)], 3), C_BASE)
    c.part(lambda md: md.rectangle([5, 20, 7, 31]), C_SHADE)
    c.part(lambda md: md.rectangle([8, 20, 10, 31]), C_BASE)
    c.part(lambda md: md.polygon([(4, 14), (12, 13), (24, 24), (24, 29), (10, 22)]), C_BASE)
    c.part(lambda md: md.rectangle([18, 28, 31, 30]), C_BASE)
    c.put(30, 29, C_LIGHT)
    c.put(31, 29, C_LIGHT)
    head = (17, 18, 27, 28)
    c.part(lambda md: md.polygon([(18, 21), (17, 15), (22, 19)]), C_PATCH if kind in ("mochi", "oreo") else C_BASE)
    c.part(lambda md: md.polygon([(23, 19), (26, 14), (27, 21)]), C_PATCH if kind in ("mochi", "oreo") else C_BASE)
    hclip = c.part(lambda md: md.ellipse(list(head)), C_BASE)
    if kind == "oreo":
        c.paint(lambda md: md.rectangle([17, 18, 27, 21]), C_PATCH, hclip)
    if kind == "mochi":
        c.paint(lambda md: md.ellipse([19, 20, 27, 25]), C_PATCH, hclip)
    if kind == "momo":
        for x in (8, 12, 16):
            c.put(x, 15 + (x - 8) // 2, C_PATCH)
            c.put(x + 1, 15 + (x - 8) // 2, C_PATCH)
    c.paint(lambda md: md.ellipse([21, 23, 28, 28]), C_LIGHT, hclip)
    c.put(21, 22, OUT)
    c.put(22, 23, OUT)
    c.put(23, 22, OUT)
    c.put(27, 25, C_PINK)
    # yawn
    c.put(25, 26, OUT)
    c.put(26, 26, C_PINK)
    c.outline_edges()
    return c


def cat_cello(kind):
    """The famous leg-up grooming pose: one hind leg pointing at the sky."""
    c = cat_front(kind, eyes="closed", tail=2, groom=2)
    leg = c.part(lambda md: thick(md, [(20, 28), (24, 18), (27, 4)], 4), C_BASE)
    if kind == "momo":
        for i, row in enumerate(leg):
            for x, v in enumerate(row):
                if v and (i % 4) == 0:
                    c.px[i][x] = C_PATCH
    c.paint(lambda md: md.ellipse([25, 1, 29, 5]), C_LIGHT)
    c.put(27, 2, C_PINK)
    c.put(17, 15, C_PINK)  # tongue reaching
    c.outline_edges()
    return c


def cat_flat(kind):
    """Pancake: flattened out in a sunbeam, chin on the fence."""
    c = Canvas(32, 32)
    c.part(lambda md: thick(md, [(2, 29), (0, 26), (1, 22)], 3), C_BASE)
    c.part(lambda md: md.ellipse([1, 21, 26, 31]), C_BASE)
    bclip = [[v == C_BASE for v in row] for row in c.px]
    if kind == "momo":
        for x in range(5, 24, 4):
            for y in range(22, 26):
                if c.px[y][x] == C_BASE:
                    c.px[y][x] = C_PATCH
    elif kind == "oreo":
        c.paint(lambda md: md.ellipse([6, 20, 16, 28]), C_PATCH, bclip)
    head = (19, 20, 31, 31)
    ear = C_PATCH if kind in ("mochi", "oreo") else C_BASE
    c.part(lambda md: md.polygon([(20, 23), (20, 16), (25, 21)]), ear)
    c.part(lambda md: md.polygon([(26, 21), (30, 17), (31, 24)]), ear)
    hclip = c.part(lambda md: md.ellipse(list(head)), C_BASE)
    if kind == "mochi":
        c.paint(lambda md: md.ellipse([21, 22, 30, 27]), C_PATCH, hclip)
    if kind == "oreo":
        c.paint(lambda md: md.rectangle([19, 20, 31, 23]), C_PATCH, hclip)
    c.paint(lambda md: md.ellipse([23, 26, 30, 31]), C_LIGHT, hclip)
    c.put(22, 25, OUT)
    c.put(23, 26, OUT)
    c.put(24, 25, OUT)
    c.put(27, 25, OUT)
    c.put(28, 26, OUT)
    c.put(29, 25, OUT)
    c.put(26, 28, C_PINK)
    c.part(lambda md: md.ellipse([14, 27, 21, 31]), C_LIGHT)
    c.outline_edges()
    return c


def cat_drumstick(kind, phase):
    """Back view: hind leg straight up like a chicken drumstick, licking it."""
    c = Canvas(32, 32)
    ear = C_PATCH if kind in ("mochi", "oreo") else C_BASE
    # tail curled on the floor
    c.part(lambda md: thick(md, [(22, 30), (27, 30), (30, 27)], 3), C_BASE)
    body = c.part(lambda md: md.ellipse([7, 13, 26, 31]), C_BASE)
    if kind == "momo":
        for y in range(16, 30, 3):
            for x in range(10, 24):
                if body[y][x] and (x + y) % 5 < 2:
                    c.px[y][x] = C_PATCH
    elif kind == "oreo":
        c.paint(lambda md: md.ellipse([12, 13, 26, 24]), C_PATCH, body)
    elif kind == "mochi":
        c.paint(lambda md: md.ellipse([10, 14, 24, 22]), C_SHADE, body)
    c.paint(lambda md: md.ellipse([8, 20, 13, 30]), C_SHADE, body)
    # the drumstick leg
    leg = c.part(lambda md: thick(md, [(10, 27), (8, 14), (7, 2)], 4), C_BASE)
    if kind == "momo":
        for i, row in enumerate(leg):
            for x, v in enumerate(row):
                if v and i % 4 == 1:
                    c.px[i][x] = C_PATCH
    c.part(lambda md: md.ellipse([4, 0, 10, 4]), C_LIGHT)
    c.put(6, 1, C_PINK)
    c.put(8, 1, C_PINK)
    # head (back of it) leaning into the leg, bobbing as it licks
    hy = 6 + phase
    c.part(lambda md: md.polygon([(12, hy + 3), (12, hy - 4), (16, hy)]), ear)
    c.part(lambda md: md.polygon([(20, hy + 1), (24, hy - 4), (24, hy + 4)]), ear)
    c.paint(lambda md: md.polygon([(21, hy + 1), (23, hy - 2), (23, hy + 2)]), C_PINK)
    hclip = c.part(lambda md: md.ellipse([10, hy, 24, hy + 12]), C_BASE)
    if kind == "oreo":
        c.paint(lambda md: md.ellipse([10, hy, 24, hy + 12]), C_PATCH, hclip)
    if kind == "momo":
        for x in (15, 17, 19):
            c.put(x, hy + 2, C_PATCH)
            c.put(x, hy + 3, C_PATCH)
    c.put(10, hy + 6, C_PINK)  # tongue on the leg
    c.put(9, hy + 6 - phase, C_PINK)
    c.outline_edges()
    return c


def cat_wash(kind, phase):
    """Face wash: licked paw rubbed over the face, eyes shut."""
    c = cat_front(kind, eyes="closed", tail=phase)
    py = 6 + phase * 3
    c.part(lambda md: md.ellipse([8 + phase, py, 15 + phase, py + 6]), C_LIGHT)
    c.put(11 + phase, py + 1, C_PINK)
    c.put(13 + phase, py + 1, C_PINK)
    c.outline_edges()
    return c


def cat_scratch(kind, phase):
    """Sitting side-on, hind leg scratching behind the ear (blissful)."""
    c = Canvas(32, 32)
    ear = C_PATCH if kind in ("mochi", "oreo") else C_BASE
    c.part(lambda md: thick(md, [(8, 29), (3, 28), (1, 24)], 3), C_BASE)
    body = c.part(lambda md: md.ellipse([5, 14, 23, 31]), C_BASE)
    if kind == "momo":
        for x in range(8, 21, 3):
            for y in range(16, 22):
                if body[y][x]:
                    c.px[y][x] = C_PATCH
    elif kind == "oreo":
        c.paint(lambda md: md.ellipse([6, 14, 16, 24]), C_PATCH, body)
    c.paint(lambda md: md.ellipse([13, 18, 22, 30]), C_LIGHT, body)
    c.part(lambda md: md.rectangle([17, 25, 19, 31]), C_BASE)
    c.put(17, 31, C_LIGHT)
    c.put(18, 31, C_LIGHT)
    # head tilted towards the scratching foot
    head = (14, 3, 26, 15)
    c.part(lambda md: md.polygon([(15, 7), (15, 0), (19, 4)]), ear)
    c.part(lambda md: md.polygon([(21, 4), (26, 0), (26, 8)]), ear)
    hclip = c.part(lambda md: md.ellipse(list(head)), C_BASE)
    if kind == "mochi":
        c.paint(lambda md: md.ellipse([16, 5, 25, 11]), C_PATCH, hclip)
    if kind == "oreo":
        c.paint(lambda md: md.rectangle([14, 3, 26, 7]), C_PATCH, hclip)
    c.paint(lambda md: md.ellipse([18, 9, 26, 15]), C_LIGHT, hclip)
    for (x, y) in ((18, 8), (19, 7), (20, 8), (22, 8), (23, 7), (24, 8)):
        c.put(x, y, OUT)
    c.put(22, 11, C_PINK)
    # the scratching leg (two positions)
    foot = (13, 5) if phase == 0 else (11, 8)
    c.part(lambda md: thick(md, [(10, 26), (9, 16), foot], 3), C_BASE)
    c.part(lambda md: md.ellipse([foot[0] - 2, foot[1] - 2, foot[0] + 2, foot[1] + 2]), C_LIGHT)
    # motion lines
    for (x, y) in ((8, 2), (7, 3), (9, 9), (8, 10)) if phase == 0 else ((6, 5), (5, 6), (6, 12), (7, 12)):
        c.put(x, y, OUT)
    c.outline_edges()
    return c


# Neko Nyorai (Buddha cat) palette slots, used with BUDDHA_PALETTES
B_ROBE, B_ROBE2, B_CURL, B_CURL2, B_LOTUS, B_LOTUS2 = range(10, 16)


def cat_buddha(kind, phase):
    """Enlightened Momo: blue curls, urna dot, gold robe, blessing paw, lotus."""
    c = Canvas(32, 32)
    # lotus throne
    for (x0, x1, y0) in ((0, 12, 23), (20, 31, 23), (5, 17, 21), (14, 26, 21), (9, 22, 22)):
        c.part(lambda md: md.ellipse([x0, y0, x1, 31]), B_LOTUS)
        c.paint(lambda md: md.ellipse([x0 + 3, y0 + 2, x1 - 3, 30]), B_LOTUS2)
    # robed body
    body = c.part(lambda md: md.ellipse([7, 14, 24, 28]), B_ROBE)
    c.paint(lambda md: md.line([(9, 16), (20, 27)], fill=255), B_ROBE2, body)
    c.paint(lambda md: md.line([(12, 15), (22, 24)], fill=255), B_ROBE2, body)
    c.paint(lambda md: md.ellipse([12, 15, 17, 20]), C_BASE, body)  # bare shoulder fur
    # paw resting in the lap
    c.part(lambda md: md.ellipse([10, 22, 15, 26]), C_LIGHT)
    # ears poke out of the curls
    c.part(lambda md: md.polygon([(8, 9), (8, 1), (13, 5)]), C_BASE)
    c.part(lambda md: md.polygon([(23, 9), (23, 1), (18, 5)]), C_BASE)
    c.paint(lambda md: md.polygon([(9, 7), (9, 3), (11, 5)]), C_PINK)
    c.paint(lambda md: md.polygon([(22, 7), (22, 3), (20, 5)]), C_PINK)
    hclip = c.part(lambda md: md.ellipse([8, 4, 23, 17]), C_BASE)
    c.paint(lambda md: md.ellipse([12, 11, 19, 16]), C_LIGHT, hclip)
    if kind == "momo":
        c.paint(lambda md: md.ellipse([13, 13, 18, 17]), C_WHITE, hclip)
    # snail-shell curls and the ushnisha bump
    curls = c.part(lambda md: md.chord([9, 1, 22, 13], 180, 360), B_CURL)
    c.part(lambda md: md.ellipse([12, -1, 19, 4]), B_CURL)
    for (x, y) in ((9, 4), (11, 2), (20, 2), (22, 4), (10, 7), (21, 7)):  # bumpy curl edge
        c.part(lambda md: md.ellipse([x - 2, y - 2, x + 2, y + 2]), B_CURL)
    for (x, y) in ((11, 4), (14, 3), (17, 3), (20, 4), (12, 6), (16, 5), (19, 6), (14, 1), (17, 1)):
        c.put(x, y, B_CURL2)
    # urna, serene eyes, nose, smile
    c.put(15, 8, C_EYE if kind == "mochi" else B_CURL)
    c.put(16, 8, C_EYE if kind == "mochi" else B_CURL)
    for ex in (11, 18):
        c.put(ex, 10, OUT)
        c.put(ex + 1, 11, OUT)
        c.put(ex + 2, 11, OUT)
    c.put(15, 12, C_PINK)
    c.put(16, 12, C_PINK)
    c.put(14, 14, OUT)
    c.put(15, 14 + phase, OUT)
    c.put(16, 14 + phase, OUT)
    c.put(17, 14, OUT)
    # blessing paw raised (abhaya mudra) with pink beans
    py = 12 - phase
    c.part(lambda md: md.rectangle([21, py + 4, 24, 20]), B_ROBE)
    c.part(lambda md: md.ellipse([20, py, 26, py + 6]), C_LIGHT)
    c.put(23, py + 3, C_PINK)
    c.put(22, py + 1, C_PINK)
    c.put(24, py + 1, C_PINK)
    c.outline_edges()
    return c


BUDDHA_COLORS = [(230, 170, 60), (180, 120, 40), (70, 90, 200), (40, 50, 140), (246, 170, 196), (255, 220, 232)]


def cat_sleep(kind):
    """Curled-up nap (paws tucked, eyes shut)."""
    c = cat_front(kind, eyes="closed", loaf=True, head_dy=3)
    return c


def cat_belly(kind, phase=0):
    """Rolled over on its back showing the fluffy belly."""
    c = Canvas(32, 32)
    wig = phase % 2
    c.part(lambda md: thick(md, [(5, 27), (1, 25 - wig), (1, 20)], 3), C_BASE)
    for (lx, top) in ((8, 15 + wig), (12, 14), (18, 14 + wig), (22, 16)):
        c.part(lambda md: md.rectangle([lx, top, lx + 2, 22]), C_BASE)
        c.put(lx, top, C_PINK)
        c.put(lx + 1, top, C_PINK)
        c.put(lx + 2, top, C_PINK)
    c.part(lambda md: md.ellipse([4, 18, 25, 30]), C_BASE)
    bclip = [[v == C_BASE for v in row] for row in c.px]
    c.paint(lambda md: md.ellipse([7, 18, 22, 25]), C_LIGHT, bclip)
    if kind == "oreo":
        c.paint(lambda md: md.ellipse([4, 24, 14, 32]), C_PATCH, bclip)
    elif kind == "momo":
        for x in range(8, 22, 3):
            c.put(x, 27, C_PATCH)
            c.put(x, 28, C_PATCH)
    head = (20, 18, 31, 30)
    c.part(lambda md: md.polygon([(21, 27), (19, 31), (24, 29)]), C_PATCH if kind != "momo" else C_BASE)
    c.part(lambda md: md.polygon([(29, 27), (31, 31), (27, 30)]), C_PATCH if kind != "momo" else C_BASE)
    hclip = c.part(lambda md: md.ellipse(list(head)), C_BASE)
    if kind == "mochi":
        c.paint(lambda md: md.ellipse([21, 22, 30, 28]), C_PATCH, hclip)
    c.paint(lambda md: md.ellipse([22, 18, 29, 23]), C_LIGHT, hclip)
    # upside-down happy face
    for ex in (22, 27):
        c.put(ex, 24, OUT)
        c.put(ex + 1, 25, OUT)
        c.put(ex + 2, 24, OUT)
    c.put(25, 21, C_PINK)
    c.put(26, 21, C_PINK)
    c.outline_edges()
    return c


def cat_frames(kind):
    f = {}
    f["sit0"] = cat_front(kind, tail=0)
    f["sit1"] = cat_front(kind, tail=1)
    f["sit2"] = cat_front(kind, tail=2)
    f["blink"] = cat_front(kind, eyes="closed", tail=0)
    f["meow"] = cat_front(kind, eyes="happy", mouth="open", tail=1)
    f["slow"] = cat_front(kind, eyes="slow", tail=0)
    f["cute"] = cat_front(kind, eyes="sparkle", paw_up=True, tilt=1, tail=2)
    f["happy"] = cat_front(kind, eyes="happy", tail=1)
    f["shock"] = cat_front(kind, eyes="wide", mouth="open", tail=2, head_dy=-1)
    f["loaf"] = cat_front(kind, eyes="happy", loaf=True)
    f["purr"] = cat_front(kind, eyes="closed", loaf=True)
    for i in range(4):
        f["walk%d" % i] = cat_side(kind, phase=i)
    f["jump"] = cat_side(kind, pose="jump")
    f["bump"] = cat_side(kind, pose="bump", eyes="closed")
    f["belly0"] = cat_belly(kind, 0)
    f["belly1"] = cat_belly(kind, 1)
    f["adv0"] = cat_side(kind, phase=0, bandana=True, bindle=True)
    f["adv1"] = cat_side(kind, phase=1, bandana=True, bindle=True)
    f["adv2"] = cat_side(kind, phase=2, bandana=True, bindle=True)
    f["adv3"] = cat_side(kind, phase=3, bandana=True, bindle=True)
    f["advsit"] = cat_front(kind, eyes="sparkle", bandana=True, tail=1)
    f["groom0"] = cat_front(kind, eyes="closed", groom=1, tail=0)
    f["groom1"] = cat_front(kind, eyes="closed", groom=2, tail=1)
    f["reach"] = cat_front(kind, eyes="wide", reach=True, tilt=1, tail=2)
    f["bliss"] = cat_front(kind, eyes="none", bliss=True, head_dy=-1, tail=1)
    f["yoga"] = cat_yoga(kind)
    f["sleep"] = cat_sleep(kind)
    f["yawn"] = cat_front(kind, eyes="closed", mouth="yawn", tail=1, head_dy=-1)
    f["cello"] = cat_cello(kind)
    f["flat"] = cat_flat(kind)
    f["drum0"] = cat_drumstick(kind, 0)
    f["drum1"] = cat_drumstick(kind, 1)
    f["wash0"] = cat_wash(kind, 0)
    f["wash1"] = cat_wash(kind, 1)
    f["scratch0"] = cat_scratch(kind, 0)
    f["scratch1"] = cat_scratch(kind, 1)
    f["buddha0"] = cat_buddha(kind, 0)
    f["buddha1"] = cat_buddha(kind, 1)
    return f


CAT_FRAME_NAMES = ["sit0", "sit1", "sit2", "blink", "meow", "slow", "cute", "happy", "shock",
                   "loaf", "purr", "walk0", "walk1", "walk2", "walk3", "jump", "bump",
                   "belly0", "belly1", "adv0", "adv1", "adv2", "adv3", "advsit",
                   "groom0", "groom1", "reach", "bliss", "yoga", "sleep",
                   "yawn", "cello", "flat", "drum0", "drum1", "wash0", "wash1",
                   "scratch0", "scratch1", "buddha0", "buddha1"]

# --------------------------------------------------------------------------
# People (24x48, side view facing right, feet on y=47)
# --------------------------------------------------------------------------
P_SKIN, P_SKIN2, P_HAIR, P_TOP, P_TOP2, P_BOT, P_SHOE, P_ACC, P_ACC2, P_DARK, P_WHITE, P_ACC3, P_FUR, P_PINK = range(2, 16)


def person(style, pose="walk", phase=0):
    """style: dict with body/hair/flags. Returns a Canvas."""
    c = Canvas(24, 48)
    body = style.get("body", "adult")
    flags = style.get("flags", ())
    if body == "kid":
        head_r, torso, leg = 5, 10, 10
    else:
        head_r, torso, leg = 5, 15, 16
    hunch = 2 if body == "granny" else 0
    foot_y = 46
    kneel = pose == "kneel"
    if kneel:
        hip_y = foot_y - 7
    else:
        hip_y = foot_y - leg
    sh_y = hip_y - torso
    head_cy = sh_y - head_r - 1 + hunch
    head_cx = 12 + hunch
    skirt = "skirt" in flags

    # walk cycle offsets for legs (front, back) and arms
    if pose == "walk":
        lf, lb = [(4, -4), (1, -1), (-4, 4), (-1, 1)][phase % 4]
        bob = 0 if phase % 2 == 0 else -1
    else:
        lf, lb, bob = 1, -1, 0
    hip_y += bob
    sh_y += bob
    head_cy += bob

    leg_col = P_SKIN if skirt or "shorts" in flags else P_BOT
    maxi = "maxi" in flags
    tank = "tank" in flags or maxi
    arm_col = P_SKIN if tank else P_TOP
    arm_col2 = P_SKIN2 if tank else P_TOP2

    def draw_leg(dx, col, shoe_col):
        if maxi and not kneel:  # the long dress hides the legs; just feet
            fx = 12 + dx * 0.6
            c.part(lambda md: md.rectangle([fx - 1, foot_y - 1, fx + 3, foot_y]), P_SKIN)
            c.put(int(fx) + 3, foot_y, P_WHITE)
            c.put(int(fx) - 1, foot_y, P_WHITE)
            return
        if kneel:
            pts = [(12, hip_y), (12 + 6 * (1 if col == leg_col else -0.3), hip_y + 1), (12 + 6 * (1 if col == leg_col else -0.3), foot_y)]
        else:
            pts = [(12, hip_y), (12 + dx * 0.5, (hip_y + foot_y) / 2), (12 + dx, foot_y - 1)]
        c.part(lambda md: thick(md, pts, 3 if body != "kid" else 3), col)
        if "shorts" in flags and not kneel:  # shorts down to mid-thigh
            mid = (pts[0][0] * 0.55 + pts[1][0] * 0.45, pts[0][1] * 0.55 + pts[1][1] * 0.45 + 3)
            c.part(lambda md: thick(md, [pts[0], mid], 4), P_BOT)
        fx, fy = pts[-1]
        if "flipflops" in flags:  # bare feet on white flip-flops
            c.part(lambda md: md.rectangle([fx - 1, foot_y - 1, fx + 3, foot_y - 1]), P_SKIN)
            c.paint(lambda md: md.rectangle([fx - 1, foot_y, fx + 3, foot_y]), P_WHITE)
        else:
            c.part(lambda md: md.rectangle([fx - 1, foot_y - 1, fx + 3, foot_y]), shoe_col)

    # back arm
    if pose == "walk":
        ab = (-lf * 0.8, 0)
        c.part(lambda md: thick(md, [(12, sh_y + 2), (12 + ab[0], sh_y + 11)], 3), arm_col2)
    # back leg
    draw_leg(lb, P_SHOE if False else (leg_col if leg_col != P_BOT else P_BOT), P_SHOE)
    # backpack behind torso
    if "backpack" in flags:
        c.part(lambda md: md.rectangle([5, sh_y + 1, 9, sh_y + 10]), P_ACC)
    if "hood" in flags:
        c.part(lambda md: md.ellipse([7, sh_y - 2, 13, sh_y + 3]), P_TOP2)
    # torso
    tw0, tw1 = 9, 15
    if body == "kid":
        tw0, tw1 = 9, 14
    tclip = c.part(lambda md: md.rounded_rectangle([tw0 + hunch // 2, sh_y, tw1 + hunch // 2, hip_y + 1], radius=2), P_TOP)
    c.paint(lambda md: md.rectangle([tw0, sh_y, tw0 + 1, hip_y + 1]), P_TOP2, tclip)
    if skirt:
        c.part(lambda md: md.polygon([(tw0 - 1, hip_y - 2), (tw1 + 1, hip_y - 2), (tw1 + 3, hip_y + 7), (tw0 - 3, hip_y + 7)]), P_BOT)
    else:
        c.paint(lambda md: md.rectangle([tw0, hip_y - 1, tw1, hip_y + 1]), P_BOT, tclip)
    if "stripes" in flags:  # striped tank top
        for yy in range(sh_y + 1, hip_y - 1, 2):
            c.paint(lambda md: md.line([(tw0, yy), (tw1 + 1, yy)], fill=255), P_ACC2, tclip)
    if maxi:  # long flowing patterned dress
        sway = lf // 2 if pose == "walk" else 0
        dress = c.part(lambda md: md.polygon([(tw0, hip_y - 6), (tw1 + 1, hip_y - 6), (tw1 + 4 + sway, foot_y - 1),
                                              (tw0 - 3 + sway, foot_y - 1)]), P_TOP)
        for yy in range(sh_y + 1, foot_y - 1) if "plain" not in flags else ():
            for xx in range(0, 24):
                if (dress[yy][xx] or tclip[yy][xx]) and (xx * 3 + yy * 2) % 7 == 0:
                    c.px[yy][xx] = P_ACC if (xx + yy) % 2 else P_ACC2
        c.paint(lambda md: md.line([(12, sh_y - 1), (12, sh_y + 1)], fill=255), P_SKIN)  # straps / bare shoulder
    if "openjacket" in flags:  # zip jacket open over a yellow tee
        c.paint(lambda md: md.rectangle([12, sh_y + 1, 14, hip_y - 2]), P_ACC3, tclip)
    if "teeprint" in flags:  # the 幸せの肉 burger tee
        c.put(11, sh_y + 4, P_ACC)
        c.put(13, sh_y + 4, P_ACC)
        c.put(12, sh_y + 5, P_ACC)
        c.paint(lambda md: md.rectangle([11, sh_y + 8, 14, sh_y + 9]), P_ACC2, tclip)
    if "fleece" in flags:  # zip-up fleece over a shirt, coloured collar trim
        c.paint(lambda md: md.rectangle([13, sh_y + 1, 14, hip_y - 2]), P_ACC2, tclip)
        c.paint(lambda md: md.rectangle([tw0, sh_y, tw1, sh_y + 1]), P_ACC, tclip)
        c.paint(lambda md: md.line([(14, sh_y + 2), (14, hip_y - 2)], fill=255), P_ACC, tclip)
    if "turtleneck" in flags:  # open cardigan over a dark turtleneck
        c.paint(lambda md: md.rectangle([13, sh_y, 15, hip_y - 2]), P_ACC2, tclip)
        c.put(14, sh_y + 4, P_ACC3)
        c.put(14, sh_y + 7, P_ACC3)
    if "tie" in flags:
        c.paint(lambda md: md.polygon([(13, sh_y + 1), (14, sh_y + 1), (14, sh_y + 8), (13, sh_y + 9)]), P_ACC, tclip)
    if "lanyard" in flags:
        c.paint(lambda md: md.line([(11, sh_y), (13, sh_y + 6), (15, sh_y)], fill=255), P_ACC, tclip)
        c.paint(lambda md: md.rectangle([12, sh_y + 6, 14, sh_y + 9]), P_WHITE, tclip)
    if "badge" in flags:
        c.put(14, sh_y + 3, P_ACC2)
        c.put(13, sh_y + 3, P_ACC2)
    if "logo" in flags:  # Yahoo! purple Y on the shirt
        c.put(12, sh_y + 4, P_WHITE)
        c.put(14, sh_y + 4, P_WHITE)
        c.put(13, sh_y + 5, P_WHITE)
        c.put(13, sh_y + 6, P_WHITE)
    if "camera" in flags:
        c.paint(lambda md: md.line([(10, sh_y), (15, sh_y + 7)], fill=255), P_DARK, tclip)
        c.part(lambda md: md.rectangle([14, sh_y + 6, 17, sh_y + 9]), P_DARK)
        c.put(16, sh_y + 7, P_WHITE)
    # front leg
    draw_leg(lf, leg_col, P_SHOE)
    # head
    hx0, hy0, hx1, hy1 = head_cx - head_r, head_cy - head_r, head_cx + head_r, head_cy + head_r
    hair = style.get("hair", "short")
    if hair == "long":
        c.part(lambda md: md.rectangle([hx0 - 1, hy0 + 2, hx0 + 4, hy1 + 7]), P_HAIR)
    if hair == "bob":
        c.part(lambda md: md.rectangle([hx0 - 1, hy0 + 2, hx0 + 6, hy1 + 3]), P_HAIR)
    if hair == "pony":
        c.part(lambda md: thick(md, [(hx0 + 1, hy0 + 3), (hx0 - 3, hy0 + 6), (hx0 - 3, hy1 + 2)], 3), P_HAIR)
    if hair == "bun":
        c.part(lambda md: md.ellipse([hx0 - 3, hy0 - 2, hx0 + 3, hy0 + 4]), P_HAIR)
    c.part(lambda md: md.rectangle([head_cx - 1, hy1 - 1, head_cx + 1, sh_y + 1]), P_SKIN)
    hclip = c.part(lambda md: md.ellipse([hx0, hy0, hx1, hy1]), P_SKIN)
    # hair cap
    if hair == "spiky":
        # fluffy, slightly long, messy Japanese-style cut: volume on top,
        # short fringe over the forehead, covering the nape
        c.part(lambda md: md.ellipse([hx0 - 1, hy0 - 2, hx1, hy0 + 4]), P_HAIR)
        c.part(lambda md: md.rectangle([hx0 - 1, hy0 + 1, hx0 + 3, hy0 + 8]), P_HAIR)
        for (x, y) in ((hx0, hy0 - 3), (hx0 + 3, hy0 - 3), (hx0 + 6, hy0 - 3), (hx0 + 9, hy0 - 2),
                       (hx0 - 2, hy0 + 3), (hx0 - 2, hy0 + 6)):
            c.put(x, y, P_HAIR)
        for (x, y) in ((hx1 - 3, hy0 + 3), (hx1 - 1, hy0 + 3), (hx1, hy0 + 2), (hx1 + 1, hy0 + 2)):
            c.put(x, y, P_HAIR)
    if hair in ("short", "long", "pony", "bun", "curly", "bob"):
        c.paint(lambda md: md.ellipse([hx0, hy0, hx1, hy0 + 4]), P_HAIR, hclip)
        c.paint(lambda md: md.rectangle([hx0, hy0 + 2, hx0 + 4, hy0 + 7]), P_HAIR, hclip)
        if hair == "curly":
            c.part(lambda md: md.ellipse([hx0 - 1, hy0 - 2, hx1, hy0 + 5]), P_HAIR)
    elif hair == "buzz":
        c.paint(lambda md: md.ellipse([hx0, hy0, hx1, hy0 + 3]), P_HAIR, hclip)
        c.paint(lambda md: md.rectangle([hx0, hy0 + 1, hx0 + 3, hy0 + 5]), P_HAIR, hclip)
    elif hair == "bald":
        c.paint(lambda md: md.rectangle([hx0, hy0 + 3, hx0 + 2, hy0 + 6]), P_HAIR, hclip)
    # face (looking right)
    ey = head_cy - 1
    c.put(hx1 - 2, ey, P_DARK)
    c.put(hx1 - 2, ey - 1 if body == "kid" else ey, P_DARK)
    c.put(hx1, ey + 2, P_SKIN2)
    c.put(head_cx - 1, ey + 1, P_SKIN2)  # ear
    if "smile" in flags or pose != "walk":
        c.put(hx1 - 2, ey + 3, P_SKIN2)
        c.put(hx1 - 1, ey + 3, P_SKIN2)
    if "glasses" in flags:
        # black frames: a lens around the eye plus the arm back to the ear
        for x in range(hx1 - 4, hx1 + 1):
            c.put(x, ey - 1, P_DARK)
            c.put(x, ey + 1, P_DARK)
        c.put(hx1 - 4, ey, P_DARK)
        c.put(hx1, ey, P_DARK)
        c.put(hx1 - 2, ey, P_DARK)
        c.put(hx1 - 3, ey, P_SKIN)
        c.put(hx1 - 1, ey, P_SKIN)
        for x in range(head_cx - 1, hx1 - 4):
            c.put(x, ey - 1, P_DARK)
    if "alien" in flags:  # big black almond eye and an antenna
        c.put(hx1 - 3, ey - 1, P_DARK)
        c.put(hx1 - 2, ey - 1, P_DARK)
        c.put(hx1 - 3, ey, P_DARK)
        c.put(hx1 - 2, ey, P_DARK)
        c.put(hx1 - 1, ey, P_DARK)
        c.put(hx1 - 2, ey + 1, P_DARK)
        c.put(hx1 - 3, ey - 2, P_WHITE)
        c.paint(lambda md: md.line([(head_cx, hy0), (head_cx - 2, hy0 - 4)], fill=255), P_DARK)
        c.put(head_cx - 2, hy0 - 5, P_ACC)
        c.put(head_cx - 3, hy0 - 5, P_ACC)
    if "beard" in flags:  # long flowing beard down the chest
        c.part(lambda md: md.polygon([(hx1 - 4, ey + 3), (hx1, ey + 3), (hx1, hy1 + 2), (hx1 - 2, hy1 + 6), (hx1 - 4, hy1 + 2)]), P_HAIR)
        c.put(hx1 - 1, ey + 2, P_SKIN2)  # moustache line
    if "feathers" in flags:  # shaman's feather crown
        for k, x in enumerate(range(hx0, hx1 + 1, 2)):
            col = (P_ACC, P_ACC2, P_ACC3)[k % 3]
            c.put(x, hy0 - 1, col)
            c.put(x, hy0 - 2, col)
            c.put(x, hy0 - 3 - (k % 2), col)
    if "cap" in flags:
        c.part(lambda md: md.chord([hx0, hy0 - 1, hx1, hy0 + 7], 180, 360), P_ACC)
        c.part(lambda md: md.rectangle([head_cx, hy0 + 2, hx1 + 3, hy0 + 3]), P_ACC)
        if "logo" in flags:
            c.put(head_cx - 1, hy0 + 1, P_WHITE)
    if "headband" in flags:
        c.paint(lambda md: md.rectangle([hx0, hy0 + 3, hx1, hy0 + 4]), P_ACC, hclip)
    if "helmet" in flags:
        c.part(lambda md: md.chord([hx0 - 1, hy0 - 2, hx1 + 1, hy0 + 9], 180, 360), P_ACC)
    if "phone_ear" in flags and pose == "walk":
        c.put(head_cx - 1, ey, P_WHITE)
        c.put(head_cx - 1, ey + 1, P_WHITE)
        c.put(head_cx - 1, ey + 2, P_WHITE)
        c.put(head_cx - 2, ey + 1, OUT)
    if "earbuds" in flags:
        c.put(head_cx - 1, ey + 1, P_WHITE)

    # front arm by pose
    sx, sy = 12 + hunch // 2, sh_y + 2
    if pose == "walk":
        hand = (sx + lf * 0.8, sy + 10)
        if "box" in flags:
            hand = (sx + 6, sy + 6)
        if "boba" in flags or "coffee" in flags:
            hand = (sx + 4, sy + 7)
        if "cane" in flags:
            hand = (sx + 5, sy + 9)
        if "laptop" in flags:
            hand = (sx + 2, sy + 9)
    elif pose == "stand":
        hand = (sx + 1, sy + 10)
    elif pose == "reach":
        hand = (sx + 8, sy - 9)
    elif pose == "photo":
        hand = (sx + 7, sy - 4)
    elif pose == "kneel":
        hand = (sx + 9, sy + 6)
    else:
        hand = (sx, sy + 10)
    if "box" in flags and pose == "walk":
        c.part(lambda md: md.rectangle([sx + 2, sy + 1, sx + 10, sy + 9]), P_ACC)
        c.paint(lambda md: md.line([(sx + 2, sy + 4), (sx + 10, sy + 4)], fill=255), P_ACC2)
    if "laptop" in flags and pose == "walk":
        c.part(lambda md: md.rectangle([sx - 2, sy + 4, sx + 1, sy + 13]), P_ACC2)
    c.part(lambda md: thick(md, [(sx, sy), ((sx + hand[0]) / 2, (sy + hand[1]) / 2 + 1), hand], 3), arm_col)
    hx, hy = int(round(hand[0])), int(round(hand[1]))
    c.part(lambda md: md.rectangle([hx - 1, hy - 1, hx + 1, hy + 1]), P_SKIN)
    if pose == "walk":
        if "tote" in flags:
            c.part(lambda md: md.rectangle([hx - 3, hy + 1, hx + 3, hy + 8]), P_ACC)
            c.paint(lambda md: md.line([(hx - 2, hy + 1), (hx, hy - 1), (hx + 2, hy + 1)], fill=255), P_ACC2)
            c.put(hx, hy + 4, P_ACC2)
        if "briefcase" in flags:
            c.part(lambda md: md.rectangle([hx - 3, hy + 2, hx + 3, hy + 7]), P_ACC2)
        if "boba" in flags:
            c.part(lambda md: md.rectangle([hx, hy - 4, hx + 3, hy + 1]), P_ACC3)
            c.put(hx + 1, hy - 1, P_DARK)
            c.put(hx + 2, hy, P_DARK)
            c.put(hx + 2, hy - 5, P_PINK)
            c.put(hx + 2, hy - 6, P_PINK)
        if "coffee" in flags:
            c.part(lambda md: md.rectangle([hx, hy - 4, hx + 2, hy]), P_WHITE)
            c.put(hx + 1, hy - 2, P_ACC3)
        if "cane" in flags:
            c.part(lambda md: md.line([(hx + 1, hy), (hx + 3, foot_y)], fill=255), P_ACC2, False)
        if "leash" in flags:
            c.paint(lambda md: md.line([(hx, hy), (23, hy + 6)], fill=255), P_ACC)
    if "board" in flags and pose == "walk":  # surfboard under the arm
        c.part(lambda md: md.ellipse([2, sh_y + 2, 22, sh_y + 7]), P_ACC)
        c.paint(lambda md: md.line([(4, sh_y + 4), (20, sh_y + 4)], fill=255), P_ACC2)
    if "bracelet" in flags:
        c.put(hx - 1, hy - 2, P_ACC3)
        c.put(hx, hy - 2, P_ACC3)
    if "fishrod" in flags and pose in ("walk", "stand"):
        c.paint(lambda md: md.line([(hx, hy), (23, max(0, sh_y - 16))], fill=255), P_DARK)
        c.paint(lambda md: md.line([(23, max(0, sh_y - 16)), (23, sh_y + 4)], fill=255), P_WHITE)
        c.part(lambda md: md.ellipse([20, sh_y + 4, 23, sh_y + 10]), P_ACC3)  # a fish on the line
    if pose == "photo":
        c.part(lambda md: md.rectangle([hx, hy - 4, hx + 2, hy + 1]), P_DARK)
        c.put(hx + 1, hy - 3, P_WHITE)
    c.outline_edges()
    return c


def dog(phase):
    c = Canvas(24, 16)
    lf = [(2, -2), (-2, 2)][phase % 2]
    for (x, d) in ((6, lf[1]), (16, lf[0])):
        c.part(lambda md: md.rectangle([x + d, 10, x + 2 + d, 15]), P_FUR)
    c.part(lambda md: thick(md, [(4, 8), (1, 3 + phase % 2)], 2), P_FUR)
    c.part(lambda md: md.ellipse([3, 5, 19, 12]), P_FUR)
    for (x, d) in ((8, lf[0]), (18, lf[1])):
        c.part(lambda md: md.rectangle([x + d, 10, x + 2 + d, 15]), P_FUR)
    c.part(lambda md: md.ellipse([15, 1, 23, 9]), P_FUR)
    c.part(lambda md: md.polygon([(16, 2), (15, 8), (18, 4)]), P_ACC2)
    c.put(21, 4, P_DARK)
    c.put(23, 6, P_DARK)
    c.paint(lambda md: md.line([(15, 9), (19, 9)], fill=255), P_ACC)  # collar
    c.outline_edges()
    return c


# archetype -> drawing style (palette ranges are picked at runtime in C)
PEOPLE_STYLES = {
    "catlover": {"hair": "long", "flags": ("tote", "skirt", "smile")},
    "student": {"hair": "pony", "flags": ("backpack", "boba")},
    "granny": {"body": "granny", "hair": "bun", "flags": ("cane", "glasses", "skirt", "smile")},
    "kid": {"body": "kid", "hair": "short", "flags": ("cap", "shorts", "smile")},
    "jogger": {"hair": "buzz", "flags": ("headband", "shorts", "earbuds")},
    "commuter": {"hair": "short", "flags": ("phone_ear", "tie", "briefcase")},
    "dogwalker": {"hair": "curly", "flags": ("leash",)},
    "courier": {"hair": "short", "flags": ("helmet", "box")},
    "tourist": {"hair": "short", "flags": ("camera", "cap", "shorts", "smile")},
    "devdad": {"hair": "short", "flags": ("glasses", "hood", "laptop", "smile")},
    "engineer": {"hair": "short", "flags": ("hood", "laptop", "logo", "lanyard")},
    "pm": {"hair": "long", "flags": ("coffee", "lanyard", "smile")},
    "guard": {"hair": "buzz", "flags": ("cap", "badge")},
    "intern": {"hair": "pony", "flags": ("cap", "logo", "backpack", "smile")},
    "exec": {"hair": "bald", "flags": ("tie", "phone_ear", "briefcase")},
    # local characters on the world tour
    "alien": {"hair": "bald", "flags": ("alien",)},
    "shaman": {"hair": "long", "flags": ("feathers", "maxi", "bracelet")},
    "monk": {"hair": "bald", "flags": ("maxi", "smile")},
    "surfer": {"hair": "short", "flags": ("tank", "shorts", "flipflops", "board", "smile")},
    "prophet": {"body": "granny", "hair": "long", "flags": ("beard", "maxi", "plain", "smile")},
    # Momo's humans (only appear in the rescue scene); EVANS_PICK/SHANNON_PICK
    # choose which variant is used.
    "evans": None,
    "shannon": None,
}

EVANS_VARIANTS = [
    # A: striped tank, blue shorts, flip-flops (fishing photo)
    {"hair": "spiky", "flags": ("glasses", "tank", "stripes", "shorts", "flipflops", "smile")},
    # B: same, with the fishing rod and a fish
    {"hair": "spiky", "flags": ("glasses", "tank", "stripes", "shorts", "flipflops", "fishrod", "smile")},
    # C: yellow burger tee and jeans
    {"hair": "spiky", "flags": ("glasses", "teeprint", "smile")},
]
SHANNON_VARIANTS = [
    # A: long hair down, light blue patterned maxi dress, flip-flops
    {"hair": "long", "flags": ("maxi", "bracelet", "smile")},
    # B: maxi dress with hair tied back and glasses
    {"hair": "pony", "flags": ("maxi", "glasses", "bracelet", "smile")},
    # C: black top, jeans, glasses, hair tied back
    {"hair": "pony", "flags": ("glasses", "smile")},
]
# palettes (index 1..15) for each variant: outline, skin, skin2, hair, top, top2,
# bottom, shoes, acc, acc2, dark, white, acc3, fur, pink
_EV_SKIN = [(40, 28, 28), (240, 204, 172), (214, 172, 140), (24, 22, 26)]
EVANS_PALS = [
    _EV_SKIN + [(226, 96, 110), (190, 70, 86), (52, 96, 150), (236, 236, 236), (60, 70, 170), (250, 246, 246),
                (28, 24, 28), (255, 255, 255), (110, 130, 90), (0, 0, 0), (240, 110, 150)],
    _EV_SKIN + [(226, 96, 110), (190, 70, 86), (52, 96, 150), (236, 236, 236), (60, 70, 170), (250, 246, 246),
                (28, 24, 28), (255, 255, 255), (110, 130, 90), (0, 0, 0), (240, 110, 150)],
    _EV_SKIN + [(246, 238, 170), (220, 212, 140), (52, 60, 90), (50, 40, 40), (60, 70, 170), (214, 120, 70),
                (28, 24, 28), (255, 255, 255), (246, 238, 170), (0, 0, 0), (240, 110, 150)],
]
_SH_SKIN = [(40, 28, 28), (248, 218, 196), (222, 186, 160), (30, 22, 22)]
SHANNON_PALS = [
    _SH_SKIN + [(150, 200, 214), (120, 170, 186), (150, 200, 214), (200, 200, 210), (40, 110, 130), (232, 170, 130),
                (28, 24, 28), (255, 255, 255), (150, 90, 60), (0, 0, 0), (240, 110, 150)],
    _SH_SKIN + [(150, 200, 214), (120, 170, 186), (150, 200, 214), (200, 200, 210), (40, 110, 130), (232, 170, 130),
                (28, 24, 28), (255, 255, 255), (150, 90, 60), (0, 0, 0), (240, 110, 150)],
    _SH_SKIN + [(30, 28, 34), (50, 48, 56), (60, 64, 80), (232, 232, 232), (120, 84, 60), (120, 84, 60),
                (28, 24, 28), (255, 255, 255), (206, 170, 120), (0, 0, 0), (240, 110, 150)],
]
EVANS_PICK = 0
SHANNON_PICK = 0
PEOPLE_STYLES["evans"] = EVANS_VARIANTS[EVANS_PICK]
PEOPLE_STYLES["shannon"] = SHANNON_VARIANTS[SHANNON_PICK]
PEOPLE_ORDER = list(PEOPLE_STYLES.keys())
PERSON_POSES = ["walk0", "walk1", "walk2", "walk3", "stand", "reach", "photo", "kneel"]


def person_frames(name):
    st = PEOPLE_STYLES[name]
    out = []
    for i in range(4):
        out.append(person(st, "walk", i))
    for p in ("stand", "reach", "photo", "kneel"):
        out.append(person(st, p))
    return out


# --------------------------------------------------------------------------
# Time machine (a stainless gull-wing sports car with a flux gizmo)
# --------------------------------------------------------------------------
CAR_PAL = [(30, 30, 40), (226, 230, 236), (176, 182, 192), (120, 126, 138), (40, 60, 96),
           (24, 24, 28), (150, 150, 160), (255, 250, 200), (220, 40, 40), (240, 140, 40),
           (120, 230, 255), (238, 200, 166), (22, 18, 20), (240, 150, 60), (255, 255, 255)]
K_SIL, K_MID, K_DARK, K_GLASS, K_TIRE, K_RIM, K_LAMP, K_TAIL, K_COIL, K_GLOW, K_SKIN, K_HAIR, K_CAT, K_WHITE = range(2, 16)


def time_car(phase, momo):
    c = Canvas(64, 28)
    # low stainless wedge, facing right
    c.part(lambda md: md.polygon([(1, 13), (18, 11), (25, 6), (40, 6), (46, 11), (63, 15),
                                  (63, 21), (1, 21)]), K_MID)
    c.paint(lambda md: md.polygon([(1, 13), (18, 11), (46, 11), (63, 15), (63, 16), (1, 16)]), K_SIL)
    c.paint(lambda md: md.rectangle([1, 19, 63, 21]), K_DARK)
    c.paint(lambda md: md.line([(2, 17), (62, 17)], fill=255), K_MID)
    # windows: louvered rear window, passengers up front
    c.paint(lambda md: md.polygon([(19, 11), (25, 7), (30, 7), (30, 11)]), K_GLASS)
    for x in range(21, 30, 2):
        c.paint(lambda md: md.line([(x, 8), (x - 2, 11)], fill=255), K_DARK)
    c.paint(lambda md: md.polygon([(31, 11), (31, 7), (39, 7), (44, 11)]), K_GLASS)
    for hx in (33, 39):  # Shannon and Evans
        c.paint(lambda md: md.ellipse([hx - 2, 7, hx + 2, 11]), K_SKIN)
        c.paint(lambda md: md.rectangle([hx - 2, 7, hx + 2, 8]), K_HAIR)
    c.put(41, 9, K_GLOW)  # Evans' glasses glint
    if momo:  # orange ears peeking over the rear seat
        c.put(26, 9, K_CAT)
        c.put(28, 9, K_CAT)
        c.paint(lambda md: md.rectangle([25, 10, 29, 11]), K_CAT)
    # flux gizmo + coils on the back deck
    c.part(lambda md: md.rectangle([3, 9, 13, 12]), K_DARK)
    for x in (5, 8, 11):
        c.put(x, 8, K_COIL)
        c.put(x, 7, K_GLOW if phase else K_COIL)
    c.paint(lambda md: md.rectangle([1, 14, 3, 16]), K_TAIL)
    c.paint(lambda md: md.rectangle([60, 15, 63, 16]), K_LAMP)
    # wheels tucked under arches
    for wx in (14, 50):
        c.paint(lambda md: md.ellipse([wx - 7, 15, wx + 7, 29]), K_TIRE)
        c.part(lambda md: md.ellipse([wx - 5, 18, wx + 5, 28]), K_TIRE)
        c.paint(lambda md: md.ellipse([wx - 3, 20, wx + 3, 26]), K_RIM)
        if phase:
            c.put(wx, 20, K_TIRE)
            c.put(wx, 26, K_TIRE)
        else:
            c.put(wx - 3, 23, K_TIRE)
            c.put(wx + 3, 23, K_TIRE)
    c.outline_edges()
    return c


CAR_FRAMES = [time_car(0, False), time_car(1, False), time_car(0, True), time_car(1, True)]

# --------------------------------------------------------------------------
# Icons (fixed UI palette)
# --------------------------------------------------------------------------
UI_PAL = [(0, 0, 0), (40, 20, 30), (230, 40, 70), (150, 20, 50), (255, 255, 255), (255, 170, 190),
          (255, 214, 60), (240, 130, 30), (70, 140, 230), (130, 130, 140), (210, 210, 220),
          (140, 90, 50), (80, 180, 80), (20, 20, 24), (180, 120, 230), (250, 240, 220)]
UK = {".": 0, "o": 1, "r": 2, "R": 3, "w": 4, "p": 5, "y": 6, "O": 7, "b": 8, "g": 9, "G": 10,
      "n": 11, "e": 12, "k": 13, "v": 14, "c": 15}

ICONS = {
    "heart_full": [
        ".oo...oo..",
        "orpo.orro.",
        "orwrorrrro",
        "orprrrrrro",
        "orrrrrrRro",
        ".orrrrRro.",
        "..orrRro..",
        "...orro...",
        "....oo....",
    ],
    "heart_half": [
        ".oo...oo..",
        "orpo.owwo.",
        "orwrowwwwo",
        "orprwwwwwo",
        "orrrwwwwGo",
        ".orrwwwGo.",
        "..orwwGo..",
        "...orwo...",
        "....oo....",
    ],
    "heart_empty": [
        ".oo...oo..",
        "owwo.owwo.",
        "owwwowwwwo",
        "owwwwwwwwo",
        "owwwwwwwGo",
        ".owwwwwGo.",
        "..owwwGo..",
        "...owwo...",
        "....oo....",
    ],
    "exclaim": [
        ".ooo.",
        "oyyyo",
        "oyyyo",
        "oyyyo",
        "oyyyo",
        ".oyo.",
        ".oyo.",
        "..o..",
        ".ooo.",
        "oyyyo",
        ".ooo.",
    ],
    "fish": [
        "..oooo..o.",
        ".obbbbo.ob",
        "obwbbbboob",
        "obbbbbbbob",
        ".obbbbo.ob",
        "..oooo..o.",
    ],
    "hand": [
        "..o.o.o...",
        ".oyoyoyo..",
        ".oyoyoyo.o",
        ".oyyyyyooy",
        ".oyyyyyyyo",
        "..oyyyyyo.",
        "...ooooo..",
    ],
    "brush": [
        "oooooooo..",
        "owowowowo.",
        "onnnnnnnno",
        ".oooooonno",
        "......onno",
        "......ooo.",
    ],
    "camera": [
        "...ooo....",
        ".ooooooooo",
        "okkkkwkkko",
        "okkoGGokko",
        "okkGbbGkko",
        "okkoGGokko",
        ".ooooooooo",
    ],
    "sparkle": [
        "...y...",
        "...y...",
        "..yyy..",
        "yyywyyy",
        "..yyy..",
        "...y...",
        "...y...",
    ],
    "note": [
        "...ooo",
        "...ovo",
        "...o.o",
        "...o..",
        ".ooo..",
        "ovvo..",
        ".oo...",
    ],
    "arrow": [
        "ooooooo",
        "oyyyyyo",
        ".oyyyo.",
        "..oyo..",
        "...o...",
    ],
    "paw": [
        ".o.o.",
        "opopo",
        ".o.o.",
        ".ooo.",
        "opppo",
        ".ooo.",
    ],
    "zzz": [
        "oooo",
        "..o.",
        ".o..",
        "oooo",
    ],
    "eye": [
        "..ooooo..",
        ".orrrrro.",
        "orrkkkrro",
        "orkkRkkro",
        "orrkkkrro",
        ".orrrrro.",
        "..ooooo..",
    ],
    "bowl": [
        ".n.n.n.n.",
        "nnnnnnnnn",
        "obbbbbbbo",
        ".obbbbbo.",
        "..ooooo..",
    ],
    "hp": [
        "oo..oo.",
        "orrorro",
        "orrrrro",
        ".orrro.",
        "..oro..",
        "...o...",
    ],
    "mp": [
        "...o...",
        "..obo..",
        ".obbbo.",
        "obbwbbo",
        "obbbbbo",
        ".ooooo.",
    ],
}
FLAME = [
    [
        "....a....",
        "...aa....",
        "...aba...",
        "..abba.a.",
        ".aabbaaa.",
        ".abbcbba.",
        "aabccbbaa",
        "abbcccbba",
        "abccwccba",
        "abccwccba",
        ".abcccba.",
        "..abbba..",
        "...aaa...",
    ],
    [
        "......a..",
        ".a...aa..",
        ".aa..aba.",
        ".aba.abba",
        "..abaabba",
        ".abbbcba.",
        "aabbccbaa",
        "abbcccbba",
        "abccwccba",
        "abcwwccba",
        ".abcccba.",
        "..abbba..",
        "...aaa...",
    ],
]
# red rage flame / black "dark aura" flame
FLAME_KEYS = {
    "red": {"a": UK["R"], "b": UK["r"], "c": UK["O"], "w": UK["y"]},
    "black": {"a": UK["o"], "b": UK["k"], "c": UK["v"], "w": UK["g"]},
}
for col in ("red", "black"):
    for i in range(2):
        ICONS["flame_%s%d" % (col, i)] = (FLAME[i], FLAME_KEYS[col])

ICON_ORDER = list(ICONS.keys())


def icon(name):
    v = ICONS[name]
    if isinstance(v, tuple):
        return from_ascii(v[0], v[1])
    return from_ascii(v, UK)
