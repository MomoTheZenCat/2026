# Momo Dev Story - Who's Who

Every named human always has the same weakness, resistance and favourite reaction.
Resistance: lower is friendlier (0-100). Using their weakness adds +35% success.


## World travellers (any destination)

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Linda | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Hiro | Tourist | **Cute Pose** | 20 | Photos (MP+XP) | friendly |
| Marco | Courier | **Shin Bump** | 50 | Pets (MP) | grumpy, often furious |
| Fatima | Dog Walker | **Purr** | 55 | Brushing (MP+HP) | shoos cats (dog!) |

## The Balcony

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Linda | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Grandma Mei | Grandma/pa | **Slow Blink** | 10 | Food (HP) | friendly |
| Jake | Jogger | **Cat Yoga** | 70 | Pets (MP) | grumpy |
| Priya | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Marco | Courier | **Shin Bump** | 50 | Pets (MP) | grumpy, often furious |
| Ollie | Kid | **Belly Up** | 20 | Pets (MP) | friendly |
| Fatima | Dog Walker | **Purr** | 55 | Brushing (MP+HP) | shoos cats (dog!) |
| Greg | Commuter | **Loaf** | 60 | Photos (MP+XP) | grumpy, often furious |
| Rosa | Cat Lover | **Food Paw** | 8 | Food (HP) | friendly |
| Ben | Student | **Cat Yoga** | 30 | Photos (MP+XP) | friendly |
| Auntie Lily | Grandma/pa | **Food Paw** | 10 | Food (HP) | friendly |
| Darnell | Jogger | **Shin Bump** | 60 | Pets (MP) | grumpy |
| Sofia | Kid | **Cute Pose** | 15 | Pets (MP) | friendly |
| Hiro | Tourist | **Cute Pose** | 20 | Photos (MP+XP) | friendly |

## Yahoo! HQ 2016

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Raj | Engineer | **Slow Blink** | 35 | Brushing (MP+HP) | friendly |
| Wei | Engineer | **Cat Yoga** | 40 | Brushing (MP+HP) | friendly |
| Ashley | Product Mgr | **Cute Pose** | 30 | Photos (MP+XP) | friendly |
| Tom | Product Mgr | **Loaf** | 35 | Photos (MP+XP) | friendly |
| Kevin | Intern | **Food Paw** | 10 | Food (HP) | friendly |
| Mia | Intern | **Meow** | 10 | Food (HP) | friendly |
| Big Al | Security | **Belly Up** | 75 | Food (HP) | shoos cats, dark aura |
| Officer Chen | Security | **Slow Blink** | 70 | Food (HP) | shoos cats, dark aura |
| Mr. Yodel | Executive | **Purr** | 80 | Pets (MP) | grumpy, dark aura |
| Jake | Jogger | **Cat Yoga** | 70 | Pets (MP) | grumpy |
| Marco | Courier | **Shin Bump** | 50 | Pets (MP) | grumpy, often furious |
| Linda | Cat Lover | **Meow** | 5 | Food (HP) | friendly |

## San Francisco

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Sam | Commuter | **Loaf** | 55 | Photos (MP+XP) | grumpy, often furious |
| Luna | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Pete | Courier | **Shin Bump** | 50 | Pets (MP) | grumpy, often furious |
| Grandpa Joe | Grandma/pa | **Slow Blink** | 15 | Food (HP) | friendly |
| Ava | Dog Walker | **Purr** | 50 | Brushing (MP+HP) | shoos cats (dog!) |
| Kai | Jogger | **Cat Yoga** | 65 | Pets (MP) | grumpy |
| Noor | Engineer | **Slow Blink** | 35 | Brushing (MP+HP) | friendly |

## Alaska

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Aiyana | Cat Lover | **Meow** | 10 | Food (HP) | friendly |
| Bud | Dog Walker | **Purr** | 55 | Brushing (MP+HP) | shoos cats (dog!) |
| Hank | Courier | **Shin Bump** | 55 | Pets (MP) | grumpy, often furious |
| Elsa | Tourist | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Skip | Jogger | **Cat Yoga** | 70 | Pets (MP) | grumpy |
| Nana Ruth | Grandma/pa | **Slow Blink** | 10 | Food (HP) | friendly |
| Musher Mike | Dog Walker | **Loaf** | 60 | Brushing (MP+HP) | shoos cats (dog!) |
| Grandpa Joshua | Wanderer | **Slow Blink** | 15 | Food (HP) | friendly |

## Puerto Rico

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Isabella | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Luis | Commuter | **Loaf** | 55 | Photos (MP+XP) | grumpy, often furious |
| Abuela Carmen | Grandma/pa | **Food Paw** | 10 | Food (HP) | friendly |
| Javi | Kid | **Belly Up** | 20 | Pets (MP) | friendly |
| Marisol | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Tito | Courier | **Shin Bump** | 50 | Pets (MP) | grumpy, often furious |
| Coqui Kid | Kid | **Meow** | 15 | Pets (MP) | friendly |

## Hawaii

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Keoni | Surfer | **Cat Yoga** | 30 | Pets (MP) | friendly |
| Leilani | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Tutu Malia | Grandma/pa | **Slow Blink** | 10 | Food (HP) | friendly |
| Kimo | Surfer | **Belly Up** | 35 | Photos (MP+XP) | friendly |
| Mele | Student | **Cute Pose** | 20 | Photos (MP+XP) | friendly |
| Duke | Dog Walker | **Purr** | 50 | Brushing (MP+HP) | shoos cats (dog!) |
| Auntie Pua | Grandma/pa | **Food Paw** | 10 | Food (HP) | friendly |

## Seattle

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Riley | Engineer | **Slow Blink** | 35 | Brushing (MP+HP) | friendly |
| Juniper | Student | **Cat Yoga** | 30 | Photos (MP+XP) | friendly |
| Doug | Commuter | **Loaf** | 60 | Photos (MP+XP) | grumpy, often furious |
| Sasha | Dog Walker | **Purr** | 55 | Brushing (MP+HP) | shoos cats (dog!) |
| Brooks | Jogger | **Cat Yoga** | 70 | Pets (MP) | grumpy |
| Wren | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Barista Moss | Intern | **Food Paw** | 15 | Food (HP) | friendly |

## Mexico

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Lupita | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Diego | Courier | **Shin Bump** | 50 | Pets (MP) | grumpy, often furious |
| Dona Elena | Grandma/pa | **Food Paw** | 10 | Food (HP) | friendly |
| Mateo | Kid | **Belly Up** | 20 | Pets (MP) | friendly |
| Ximena | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Don Pancho | Commuter | **Loaf** | 60 | Photos (MP+XP) | grumpy, often furious |
| Mariachi Beto | Tourist | **Purr** | 30 | Photos (MP+XP) | friendly |

## Guatemala

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Ana | Cat Lover | **Slow Blink** | 10 | Food (HP) | friendly |
| Pedro | Courier | **Shin Bump** | 55 | Pets (MP) | grumpy, often furious |
| Rosa Maria | Grandma/pa | **Meow** | 10 | Food (HP) | friendly |
| Kevin Jr. | Kid | **Cute Pose** | 20 | Pets (MP) | friendly |
| Lucia | Tourist | **Cute Pose** | 20 | Photos (MP+XP) | friendly |
| Oscar | Dog Walker | **Purr** | 55 | Brushing (MP+HP) | shoos cats (dog!) |
| Weaver Itzel | Grandma/pa | **Loaf** | 15 | Brushing (MP+HP) | friendly |

## Texas

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Dolly | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Cody | Jogger | **Shin Bump** | 65 | Pets (MP) | grumpy |
| Earl | Grandma/pa | **Slow Blink** | 15 | Food (HP) | friendly |
| Tex | Courier | **Shin Bump** | 60 | Pets (MP) | grumpy, often furious |
| Bubba | Dog Walker | **Belly Up** | 60 | Brushing (MP+HP) | shoos cats (dog!) |
| Maria | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Oil Baron Bo | Executive | **Loaf** | 80 | Pets (MP) | grumpy, dark aura |

## Mount Shasta

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Zorp | Alien | **Purr** | 40 | Photos (MP+XP) | friendly |
| Blip | Alien | **Meow** | 30 | Photos (MP+XP) | friendly |
| Glorx | Alien | **Belly Up** | 60 | Pets (MP) | friendly |
| Sky | Tourist | **Cat Yoga** | 25 | Photos (MP+XP) | friendly |
| River | Cat Lover | **Slow Blink** | 10 | Food (HP) | friendly |
| Ranger Dan | Security | **Loaf** | 70 | Food (HP) | shoos cats, dark aura |
| Xyl-9 | Alien | **Cute Pose** | 45 | Brushing (MP+HP) | friendly |

## Florida

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Bev | Grandma/pa | **Slow Blink** | 10 | Food (HP) | friendly |
| Chad | Jogger | **Cat Yoga** | 65 | Pets (MP) | grumpy |
| Destiny | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Gator Gary | Dog Walker | **Belly Up** | 60 | Brushing (MP+HP) | shoos cats (dog!) |
| Coral | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Buzz | Executive | **Purr** | 80 | Pets (MP) | grumpy, dark aura |
| Shelly | Surfer | **Cat Yoga** | 30 | Photos (MP+XP) | friendly |

## U.S. Virgin Islands

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Keisha | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Captain Ray | Commuter | **Loaf** | 55 | Photos (MP+XP) | grumpy, often furious |
| Miss Hyacinth | Grandma/pa | **Food Paw** | 10 | Food (HP) | friendly |
| Jalen | Surfer | **Cat Yoga** | 35 | Pets (MP) | friendly |
| Nia | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Desmond | Courier | **Shin Bump** | 50 | Pets (MP) | grumpy, often furious |
| Sailor Jo | Tourist | **Belly Up** | 30 | Photos (MP+XP) | friendly |

## The Amazon

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Shaman Yawa | Shaman | **Slow Blink** | 40 | Brushing (MP+HP) | friendly |
| Taina | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Dr. Ruiz | Tourist | **Cute Pose** | 30 | Photos (MP+XP) | friendly |
| Iara | Student | **Cat Yoga** | 30 | Photos (MP+XP) | friendly |
| Bento | Courier | **Shin Bump** | 55 | Pets (MP) | grumpy, often furious |
| Shaman Kaya | Shaman | **Purr** | 45 | Pets (MP) | friendly |
| Little Caua | Kid | **Belly Up** | 20 | Pets (MP) | friendly |

## Machu Picchu

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Guide Quispe | Commuter | **Loaf** | 50 | Photos (MP+XP) | grumpy, often furious |
| Mama Rosa | Grandma/pa | **Food Paw** | 10 | Food (HP) | friendly |
| Inti | Kid | **Belly Up** | 20 | Pets (MP) | friendly |
| Killa | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Backpacker Ben | Tourist | **Cat Yoga** | 25 | Photos (MP+XP) | friendly |
| Tupac | Jogger | **Cat Yoga** | 70 | Pets (MP) | grumpy |
| Llama Lady | Dog Walker | **Slow Blink** | 45 | Brushing (MP+HP) | shoos cats (dog!) |

## Tahiti

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Moana | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Teva | Surfer | **Belly Up** | 35 | Photos (MP+XP) | friendly |
| Mama Tiare | Grandma/pa | **Slow Blink** | 10 | Food (HP) | friendly |
| Hina | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Manu | Surfer | **Cat Yoga** | 30 | Pets (MP) | friendly |
| Claire | Tourist | **Cute Pose** | 20 | Photos (MP+XP) | friendly |
| Resort Boss | Executive | **Purr** | 75 | Pets (MP) | grumpy, dark aura |

## Taiwan

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| A-Ma Chen | Grandma/pa | **Food Paw** | 5 | Food (HP) | friendly |
| Xiao Ming | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Uncle Lin | Commuter | **Loaf** | 55 | Photos (MP+XP) | grumpy, often furious |
| Yu-Ting | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Ah-Hao | Courier | **Shin Bump** | 55 | Pets (MP) | grumpy, often furious |
| Wen | Jogger | **Cat Yoga** | 60 | Pets (MP) | grumpy |
| Boba Jia-Hui | Intern | **Food Paw** | 10 | Food (HP) | friendly |

## Japan

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Yuki | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Kenji | Commuter | **Loaf** | 60 | Photos (MP+XP) | grumpy, often furious |
| Obaachan Hana | Grandma/pa | **Slow Blink** | 10 | Food (HP) | friendly |
| Sora | Kid | **Belly Up** | 20 | Pets (MP) | friendly |
| Takeshi | Courier | **Shin Bump** | 55 | Pets (MP) | grumpy, often furious |
| Sakura | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Salaryman Goto | Executive | **Loaf** | 75 | Pets (MP) | grumpy, dark aura |

## Henan

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Master Shi | Monk | **Slow Blink** | 60 | Brushing (MP+HP) | friendly |
| Brother Wu | Monk | **Cat Yoga** | 55 | Pets (MP) | friendly |
| Little Bao | Kid | **Belly Up** | 20 | Pets (MP) | friendly |
| Ling | Tourist | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Grandpa Zhang | Grandma/pa | **Purr** | 15 | Food (HP) | friendly |
| Abbot Fang | Monk | **Purr** | 75 | Pets (MP) | friendly |
| Brother Liu | Monk | **Loaf** | 50 | Brushing (MP+HP) | friendly |

## Paris

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Amelie | Cat Lover | **Meow** | 5 | Food (HP) | friendly |
| Pierre | Commuter | **Loaf** | 60 | Photos (MP+XP) | grumpy, often furious |
| Madame Colette | Grandma/pa | **Slow Blink** | 10 | Food (HP) | friendly |
| Jules | Courier | **Shin Bump** | 55 | Pets (MP) | grumpy, often furious |
| Chloe | Student | **Cute Pose** | 25 | Photos (MP+XP) | friendly |
| Bernard | Dog Walker | **Purr** | 55 | Brushing (MP+HP) | shoos cats (dog!) |
| Chef Gaston | Executive | **Food Paw** | 70 | Food (HP) | grumpy, dark aura |

## Home Sweet Home

| Name | Role | Weak to | Resist | Likes | Temper |
|---|---|---|---|---|---|
| Linda | Cat Lover | **Meow** | 10 | Food (HP) | friendly |
| Grandma Mei | Grandma/pa | **Slow Blink** | 15 | Food (HP) | friendly |
| Jake | Jogger | **Cat Yoga** | 75 | Pets (MP) | grumpy |
| Priya | Student | **Cute Pose** | 30 | Photos (MP+XP) | friendly |
| Marco | Courier | **Shin Bump** | 60 | Pets (MP) | grumpy, often furious |
| Fatima | Dog Walker | **Purr** | 60 | Brushing (MP+HP) | shoos cats (dog!) |
| Greg | Commuter | **Loaf** | 70 | Photos (MP+XP) | grumpy, often furious |
| Darnell | Jogger | **Shin Bump** | 70 | Pets (MP) | grumpy |
| Big Al | Security | **Belly Up** | 80 | Food (HP) | shoos cats, dark aura |
| Mr. Yodel | Executive | **Purr** | 85 | Pets (MP) | grumpy, dark aura |
