// Momo Dev Story - Nintendo DS platform layer (BlocksDS / libnds).
//
// Both screens use a 256x192 16-bit bitmap background (mode 5, BG3). The game
// renders into RAM buffers, which are DMA'd to VRAM. The top screen is double
// buffered across VRAM banks A and B; the bottom screen (bank C) is copied
// right after VBlank so the DMA stays ahead of the beam.

#include <fat.h>
#include <nds.h>
#include <stdio.h>
#include <time.h>

#include "game.h"
#include "plat.h"

#define FB_BYTES (SCREEN_W * SCREEN_H * 2)

static uint16_t top_fb[SCREEN_W * SCREEN_H] __attribute__((aligned(32)));
static uint16_t bot_fb[SCREEN_W * SCREEN_H] __attribute__((aligned(32)));

// --------------------------------------------------------------------------
// Sound: tiny PSG note sequences
// --------------------------------------------------------------------------

typedef struct {
    uint16_t freq;   // Hz, 0 = rest
    uint8_t frames;  // 0 terminates the sequence
    uint8_t duty;
} Note;

#define END { 0, 0, 0 }

static const Note sfx_select[] = { { 1200, 2, DutyCycle_25 }, END };
static const Note sfx_confirm[] = { { 880, 3, DutyCycle_25 }, { 1320, 5, DutyCycle_25 }, END };
static const Note sfx_back[] = { { 500, 3, DutyCycle_50 }, { 380, 4, DutyCycle_50 }, END };
static const Note sfx_meow[] = {
    { 620, 2, DutyCycle_37 }, { 760, 2, DutyCycle_37 }, { 900, 3, DutyCycle_37 },
    { 980, 3, DutyCycle_37 }, { 900, 3, DutyCycle_37 }, { 760, 4, DutyCycle_37 },
    { 640, 5, DutyCycle_37 }, END
};
static const Note sfx_purr[] = {
    { 90, 4, DutyCycle_12 }, { 0, 2, 0 }, { 95, 4, DutyCycle_12 }, { 0, 2, 0 },
    { 90, 4, DutyCycle_12 }, { 0, 2, 0 }, { 95, 6, DutyCycle_12 }, END
};
static const Note sfx_jump[] = {
    { 400, 2, DutyCycle_50 }, { 600, 2, DutyCycle_50 }, { 800, 2, DutyCycle_50 }, { 1000, 2, DutyCycle_50 }, END
};
static const Note sfx_heart[] = {
    { 1047, 4, DutyCycle_25 }, { 1319, 4, DutyCycle_25 }, { 1568, 8, DutyCycle_25 }, END
};
static const Note sfx_fail[] = { { 220, 6, DutyCycle_50 }, { 160, 10, DutyCycle_50 }, END };
static const Note sfx_woof[] = {
    { 300, 3, DutyCycle_75 }, { 200, 4, DutyCycle_75 }, { 0, 4, 0 },
    { 300, 3, DutyCycle_75 }, { 200, 4, DutyCycle_75 }, END
};
static const Note sfx_levelup[] = {
    { 523, 4, DutyCycle_25 }, { 659, 4, DutyCycle_25 }, { 784, 4, DutyCycle_25 }, { 1047, 10, DutyCycle_25 }, END
};
static const Note sfx_click[] = { { 2000, 1, DutyCycle_50 }, { 0, 2, 0 }, { 1500, 2, DutyCycle_50 }, END };
static const Note sfx_clear[] = {
    { 784, 6, DutyCycle_25 }, { 659, 6, DutyCycle_25 }, { 784, 6, DutyCycle_25 }, { 1047, 6, DutyCycle_25 },
    { 0, 4, 0 }, { 988, 6, DutyCycle_25 }, { 1047, 16, DutyCycle_25 }, END
};
static const Note sfx_gameover[] = {
    { 392, 10, DutyCycle_50 }, { 349, 10, DutyCycle_50 }, { 330, 10, DutyCycle_50 }, { 262, 24, DutyCycle_50 }, END
};

static const Note *const sfx_table[SFX_COUNT] = {
    [SFX_SELECT] = sfx_select,
    [SFX_CONFIRM] = sfx_confirm,
    [SFX_BACK] = sfx_back,
    [SFX_MEOW] = sfx_meow,
    [SFX_PURR] = sfx_purr,
    [SFX_JUMP] = sfx_jump,
    [SFX_HEART] = sfx_heart,
    [SFX_FAIL] = sfx_fail,
    [SFX_WOOF] = sfx_woof,
    [SFX_LEVELUP] = sfx_levelup,
    [SFX_CLICK] = sfx_click,
    [SFX_CLEAR] = sfx_clear,
    [SFX_GAMEOVER] = sfx_gameover,
};

static const Note *sfx_cur;
static int sfx_left;
static int sfx_chan = -1;

void plat_sfx(int id)
{
    if (id < 0 || id >= SFX_COUNT || !sfx_table[id])
        return;
    sfx_cur = sfx_table[id];
    sfx_left = 0;
}

static void sfx_tick(void)
{
    if (!sfx_cur)
        return;
    if (sfx_left > 0) {
        sfx_left--;
        return;
    }
    if (sfx_chan >= 0) {
        soundKill(sfx_chan);
        sfx_chan = -1;
    }
    if (sfx_cur->frames == 0) {
        sfx_cur = NULL;
        return;
    }
    if (sfx_cur->freq)
        sfx_chan = soundPlayPSG((DutyCycle)sfx_cur->duty, sfx_cur->freq, 56, 64);
    sfx_left = sfx_cur->frames - 1;
    sfx_cur++;
}

// --------------------------------------------------------------------------
// Music: two quiet PSG voices (melody + bass) playing looping songs
// --------------------------------------------------------------------------

#define MUSIC_VOL_MELODY 10   // sound effects play at 56
#define MUSIC_VOL_BASS 8

typedef struct {
    const char *melody;   // "C5:4 E5:2 r:2 ..." note:length in 16ths
    const char *chords;   // one chord root per bar, e.g. "C A F G"
    int speed;            // frames per 16th note
} Song;

static const Song songs[MUS_COUNT] = {
    [MUS_TITLE] = {
        // gentle, sunny
        "E5:4 G5:4 C6:6 B5:2 A5:4 E5:4 A5:8 F5:4 A5:4 C6:4 A5:4 G5:6 F5:2 E5:4 D5:4 "
        "E5:4 G5:4 C6:6 D6:2 E6:4 C6:4 A5:8 F5:4 A5:4 D6:4 C6:4 B5:4 D6:4 G5:8",
        "C A F G C A D G", 9 },
    [MUS_BALCONY] = {
        // bouncy walk along the fence
        "C5:2 F5:2 A5:2 F5:2 C6:4 A5:4 G5:2 E5:2 C5:2 E5:2 G5:8 "
        "A5:2 F5:2 D5:2 F5:2 A5:4 D6:4 D6:2 C6:2 A#5:2 A5:2 G5:4 F5:4 "
        "C5:2 F5:2 A5:2 C6:2 F6:4 C6:4 E6:2 D6:2 C6:2 G5:2 E5:8 "
        "F5:2 G5:2 A#5:2 D6:2 C6:2 A#5:2 A5:2 G5:2 A5:4 G5:4 E5:2 C5:2 r:4",
        "F C D A# F C A# C", 7 },
    [MUS_YAHOO] = {
        // busy campus groove
        "A5:2 r:2 A5:2 C6:2 E6:4 D6:2 C6:2 A5:2 r:2 A5:2 C6:2 F6:4 E6:2 C6:2 "
        "G5:2 r:2 G5:2 C6:2 E6:4 D6:2 C6:2 B5:4 G5:4 D6:4 B5:4 "
        "A5:2 E6:2 A5:2 E6:2 C6:2 E6:2 A5:2 E6:2 F5:2 C6:2 F5:2 C6:2 A5:4 F5:4 "
        "E5:2 G5:2 C6:2 E6:2 G6:4 E6:4 D6:4 B5:4 G5:4 r:4",
        "A F C G A F C G", 7 },
    [MUS_TROPICAL] = {
        // steel-drum-ish calypso for the beaches
        "E5:2 G5:2 r:2 G5:2 A5:2 G5:2 E5:4 F5:2 A5:2 r:2 A5:2 C6:2 A5:2 F5:4 "
        "D5:2 G5:2 r:2 G5:2 B5:2 G5:2 D5:4 C5:4 E5:4 G5:8 "
        "A5:2 C6:2 r:2 C6:2 E6:2 C6:2 A5:4 F5:2 A5:2 r:2 C6:2 F6:2 C6:2 A5:4 "
        "G5:2 B5:2 D6:2 B5:2 G5:2 F5:2 D5:4 C5:2 E5:2 G5:2 C6:2 G5:4 r:4",
        "C F G C A F G C", 7 },
    [MUS_ASIA] = {
        // pentatonic tune for Taiwan, Japan and Henan
        "A5:4 C6:2 D6:2 E6:4 D6:2 C6:2 A5:4 G5:2 A5:2 C6:8 "
        "G5:4 E5:2 G5:2 A5:4 G5:2 E5:2 D5:4 E5:4 G5:8 "
        "A5:2 C6:2 D6:2 E6:2 G6:4 E6:4 D6:2 C6:2 A5:4 C6:4 D6:4 "
        "E6:4 D6:2 C6:2 A5:4 G5:4 A5:12 r:4",
        "A F C G A F G A", 9 },
    [MUS_MAP] = {
        // adventurous world-map march
        "G5:2 B5:2 D6:4 B5:2 D6:2 G6:4 E6:2 C6:2 G5:4 C6:4 E6:4 "
        "F#6:2 E6:2 D6:4 A5:4 F#5:4 G5:4 B5:4 D6:8 "
        "E6:2 D6:2 B5:2 G5:2 E5:4 G5:4 C6:4 E6:4 G6:4 E6:4 "
        "D6:2 E6:2 F#6:2 E6:2 D6:4 A5:4 G5:8 G6:4 r:4",
        "G C D G E C D G", 8 },
};

typedef struct {
    uint8_t note;    // MIDI number, 0 = rest
    uint8_t len;     // 16ths
} Ev;

#define MAX_EVENTS 160

static Ev mel_ev[MUS_COUNT][MAX_EVENTS];
static Ev bass_ev[MUS_COUNT][MAX_EVENTS];
static int mel_n[MUS_COUNT], bass_n[MUS_COUNT];

static int note_number(const char **p)
{
    static const int8_t base[7] = { 9, 11, 0, 2, 4, 5, 7 }; // A B C D E F G
    const char *s = *p;
    int n;
    if (*s == 'r') {
        s++;
        n = 0;
    } else {
        n = base[*s - 'A'];
        s++;
        if (*s == '#') {
            n++;
            s++;
        }
        int oct = *s++ - '0';
        n += 12 * (oct + 1);
    }
    *p = s;
    return n;
}

static void parse_songs(void)
{
    for (int k = 0; k < MUS_COUNT; k++) {
        const Song *sg = &songs[k];
        if (!sg->melody)
            continue;
        const char *p = sg->melody;
        int n = 0;
        while (*p && n < MAX_EVENTS) {
            while (*p == ' ')
                p++;
            if (!*p)
                break;
            int note = note_number(&p);
            int len = 2;
            if (*p == ':') {
                p++;
                len = 0;
                while (*p >= '0' && *p <= '9')
                    len = len * 10 + (*p++ - '0');
            }
            mel_ev[k][n].note = (uint8_t)note;
            mel_ev[k][n].len = (uint8_t)len;
            n++;
        }
        mel_n[k] = n;

        // bass: root - fifth - octave - fifth in eighth notes, one bar per chord
        n = 0;
        for (p = sg->chords; *p && n + 4 <= MAX_EVENTS;) {
            while (*p == ' ')
                p++;
            if (!*p)
                break;
            static const int8_t base[7] = { 9, 11, 0, 2, 4, 5, 7 };
            int root = base[*p - 'A'] + 36;   // octave 2
            p++;
            if (*p == '#') {
                root++;
                p++;
            }
            const int pat[4] = { 0, 7, 12, 7 };
            for (int i = 0; i < 4; i++) {
                bass_ev[k][n].note = (uint8_t)(root + pat[i]);
                bass_ev[k][n].len = 4;
                n++;
            }
        }
        bass_n[k] = n;
    }
}

static uint16_t note_hz(int midi)
{
    // C4..B4 in 1/16 Hz
    static const uint16_t c4[12] = { 4186, 4435, 4699, 4978, 5274, 5588,
                                     5920, 6272, 6645, 7040, 7459, 7902 };
    int oct = midi / 12 - 1;
    uint32_t f = c4[midi % 12];
    if (oct >= 4)
        f <<= (oct - 4);
    else
        f >>= (4 - oct);
    return (uint16_t)(f >> 4);
}

typedef struct {
    const Ev *ev;
    int n, i;
    int left;    // frames until the next event
    int gate;    // frames until note off
    int chan;
    int vol;
    DutyCycle duty;
} Voice;

static int music_track = MUS_NONE;
static Voice voices[2];

static void voice_stop(Voice *v)
{
    if (v->chan >= 0) {
        soundKill(v->chan);
        v->chan = -1;
    }
}

void plat_music(int track)
{
    for (int i = 0; i < 2; i++)
        voice_stop(&voices[i]);
    music_track = track;
    if (track <= MUS_NONE || track >= MUS_COUNT || !mel_n[track])
        return;
    voices[0] = (Voice){ mel_ev[track], mel_n[track], 0, 0, 0, -1, MUSIC_VOL_MELODY, DutyCycle_50 };
    voices[1] = (Voice){ bass_ev[track], bass_n[track], 0, 0, 0, -1, MUSIC_VOL_BASS, DutyCycle_50 };
}

static void music_tick(void)
{
    if (music_track <= MUS_NONE)
        return;
    int speed = songs[music_track].speed;
    for (int k = 0; k < 2; k++) {
        Voice *v = &voices[k];
        if (v->gate > 0 && --v->gate == 0)
            voice_stop(v);
        if (v->left > 0) {
            v->left--;
            continue;
        }
        voice_stop(v);
        const Ev *e = &v->ev[v->i];
        if (e->note)
            v->chan = soundPlayPSG(v->duty, note_hz(e->note), v->vol, k ? 48 : 80);
        int frames = e->len * speed;
        v->left = frames - 1;
        v->gate = frames * 3 / 4;   // short release so notes don't smear
        if (++v->i >= v->n)
            v->i = 0;
    }
}

// --------------------------------------------------------------------------
// Leaderboard storage: a small file on the flashcart / DSi SD card
// --------------------------------------------------------------------------

static bool fat_ok;

static const char *const save_paths[] = {
    "sd:/momo_dev_story.sav",
    "fat:/momo_dev_story.sav",
};

bool plat_save(const void *data, int size)
{
    if (!fat_ok)
        return false;
    for (unsigned i = 0; i < sizeof(save_paths) / sizeof(save_paths[0]); i++) {
        FILE *f = fopen(save_paths[i], "wb");
        if (!f)
            continue;
        bool ok = fwrite(data, 1, (size_t)size, f) == (size_t)size;
        fclose(f);
        if (ok)
            return true;
    }
    return false;
}

bool plat_load(void *data, int size)
{
    if (!fat_ok)
        return false;
    for (unsigned i = 0; i < sizeof(save_paths) / sizeof(save_paths[0]); i++) {
        FILE *f = fopen(save_paths[i], "rb");
        if (!f)
            continue;
        bool ok = fread(data, 1, (size_t)size, f) == (size_t)size;
        fclose(f);
        if (ok)
            return true;
    }
    return false;
}

// --------------------------------------------------------------------------
// Main loop
// --------------------------------------------------------------------------

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;

    videoSetMode(MODE_5_2D);
    videoSetModeSub(MODE_5_2D);
    vramSetPrimaryBanks(VRAM_A_MAIN_BG_0x06000000, VRAM_B_MAIN_BG_0x06020000,
                        VRAM_C_SUB_BG_0x06200000, VRAM_D_LCD);

    int bg_top = bgInit(3, BgType_Bmp16, BgSize_B16_256x256, 0, 0);
    bgInitSub(3, BgType_Bmp16, BgSize_B16_256x256, 0, 0);

    soundEnable();
    parse_songs();
    // without a DLDI/SD card the leaderboard simply lives for this session
    fat_ok = fatInitDefault();

    game_init((uint32_t)time(NULL) * 2654435761u);

    int shown = 0;           // VRAM half currently displayed (bmp base 0 or 8)
    bool pending = false;    // a new top frame is waiting in the back buffer

    while (1) {
        swiWaitForVBlank();

        if (pending) {
            shown ^= 1;
            bgSetMapBase(bg_top, shown ? 8 : 0);
            pending = false;
        }
        DC_FlushRange(bot_fb, FB_BYTES);
        dmaCopy(bot_fb, BG_BMP_RAM_SUB(0), FB_BYTES);

        scanKeys();
        Input in = { 0 };
        in.held = keysHeld() & 0xFFF;
        in.down = keysDown() & 0xFFF;
        if (keysDown() & KEY_TOUCH) {
            touchPosition t;
            touchRead(&t);
            in.touch = true;
            in.tx = t.px;
            in.ty = t.py;
        }

        game_update(&in);
        game_render(top_fb, bot_fb);

        DC_FlushRange(top_fb, FB_BYTES);
        dmaCopy(top_fb, BG_BMP_RAM(shown ? 0 : 8), FB_BYTES);
        pending = true;

        sfx_tick();
        music_tick();
    }
    return 0;
}
