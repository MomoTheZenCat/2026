// Momo Dev Story - PC test harness.
//
//   momo_host shots <script> <outdir>   run a scripted session, dump PPM frames
//   momo_host sim [runs]                balance simulation with bot players
//
// Script lines: "<frame> <command> [args]" where command is one of
//   press KEY     (KEY = A B X Y L R START SELECT UP DOWN LEFT RIGHT)
//   hold KEY / release KEY
//   touch X Y
//   shot NAME
//   end

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../source/bot.h"
#include "../source/game.h"
#include "../source/plat.h"
#include "../source/world.h"

static int sfx_count[SFX_COUNT];

void plat_sfx(int id)
{
    if (id >= 0 && id < SFX_COUNT)
        sfx_count[id]++;
}

void plat_music(int track)
{
    (void)track;
}

// The leaderboard lives in build/host/scores.dat (disabled during sims).
static bool save_enabled = true;

bool plat_save(const void *data, int size)
{
    if (!save_enabled)
        return false;
    FILE *f = fopen("build/host/scores.dat", "wb");
    if (!f)
        return false;
    bool ok = fwrite(data, 1, (size_t)size, f) == (size_t)size;
    fclose(f);
    return ok;
}

bool plat_load(void *data, int size)
{
    if (!save_enabled)
        return false;
    FILE *f = fopen("build/host/scores.dat", "rb");
    if (!f)
        return false;
    bool ok = fread(data, 1, (size_t)size, f) == (size_t)size;
    fclose(f);
    return ok;
}

static uint16_t top[SCREEN_W * SCREEN_H], bot[SCREEN_W * SCREEN_H];

static void dump(const char *dir, const char *name)
{
    char path[512];
    snprintf(path, sizeof(path), "%s/%s.ppm", dir, name);
    FILE *f = fopen(path, "wb");
    if (!f) {
        perror(path);
        return;
    }
    fprintf(f, "P6\n%d %d\n255\n", SCREEN_W, SCREEN_H * 2 + 4);
    for (int y = 0; y < SCREEN_H * 2 + 4; y++) {
        for (int x = 0; x < SCREEN_W; x++) {
            uint16_t c;
            if (y < SCREEN_H)
                c = top[y * SCREEN_W + x];
            else if (y < SCREEN_H + 4)
                c = 0x8000;
            else
                c = bot[(y - SCREEN_H - 4) * SCREEN_W + x];
            unsigned char rgb[3] = {
                (unsigned char)((c & 31) << 3),
                (unsigned char)(((c >> 5) & 31) << 3),
                (unsigned char)(((c >> 10) & 31) << 3),
            };
            fwrite(rgb, 1, 3, f);
        }
    }
    fclose(f);
}

static uint32_t key_bit(const char *k)
{
    static const struct { const char *n; uint32_t b; } keys[] = {
        { "A", IN_A }, { "B", IN_B }, { "X", IN_X }, { "Y", IN_Y }, { "L", IN_L }, { "R", IN_R },
        { "START", IN_START }, { "SELECT", IN_SELECT }, { "UP", IN_UP }, { "DOWN", IN_DOWN },
        { "LEFT", IN_LEFT }, { "RIGHT", IN_RIGHT },
    };
    for (unsigned i = 0; i < sizeof(keys) / sizeof(keys[0]); i++)
        if (!strcmp(keys[i].n, k))
            return keys[i].b;
    fprintf(stderr, "unknown key %s\n", k);
    return 0;
}

static int run_shots(const char *script, const char *outdir)
{
    FILE *f = fopen(script, "r");
    if (!f) {
        perror(script);
        return 1;
    }
    game_init(12345);
    char line[256];
    int frame = 0;
    uint32_t held = 0;
    int pending_frame = -1;
    char cmd[32], a1[64], a2[64];
    int ok = fgets(line, sizeof(line), f) != NULL;
    while (ok) {
        if (line[0] == '#' || line[0] == '\n') {
            ok = fgets(line, sizeof(line), f) != NULL;
            continue;
        }
        a1[0] = a2[0] = 0;
        if (sscanf(line, "%d %31s %63s %63s", &pending_frame, cmd, a1, a2) < 2) {
            ok = fgets(line, sizeof(line), f) != NULL;
            continue;
        }
        // advance to the command's frame
        while (frame < pending_frame) {
            Input in = { held, 0, false, 0, 0 };
            game_update(&in);
            if (getenv("NULLBOT"))   // stress test: draw every frame without a bottom screen
                game_render(top, NULL);
            frame++;
        }
        Input in = { held, 0, false, 0, 0 };
        if (!strcmp(cmd, "press")) {
            in.down = key_bit(a1);
            in.held |= in.down;
            game_update(&in);
            frame++;
        } else if (!strcmp(cmd, "hold")) {
            held |= key_bit(a1);
        } else if (!strcmp(cmd, "release")) {
            held &= ~key_bit(a1);
        } else if (!strcmp(cmd, "touch")) {
            in.touch = true;
            in.tx = atoi(a1);
            in.ty = atoi(a2);
            game_update(&in);
            frame++;
        } else if (!strcmp(cmd, "shot")) {
            game_render(top, bot);
            dump(outdir, a1);
            printf("%-14s frame %5d  %s\n", a1, frame, game_debug());
        } else if (!strcmp(cmd, "cheat")) {
            game_cheat(atoi(a1));
        } else if (!strcmp(cmd, "end")) {
            break;
        }
        ok = fgets(line, sizeof(line), f) != NULL;
    }
    fclose(f);
    return 0;
}

static void tally(const BotCfg *cfg, int cat, int runs)
{
    long t[SIM_MAX][8] = { { 0 } };
    long fr[SIM_MAX] = { 0 }, n[SIM_MAX] = { 0 };
    for (int r = 0; r < runs; r++) {
        SimResult res;
        game_sim(cat, cfg, 1000 + r * 7919, &res);
        for (int s = 0; s < SIM_STAGES && s <= res.result && s < SIM_STAGES; s++) {
            n[s]++;
            fr[s] += res.frames[s];
            for (int k = 0; k < 8; k++)
                t[s][k] += res.tally[s][k];
        }
    }
    for (int s = 0; s < SIM_STAGES; s++) {
        if (!n[s])
            continue;
        printf("stage%d (n=%3ld): secs %3.0f drain %3ld fail %3ld rage %3ld | +hp %3ld +mp %3ld | tries %2ld spawns %2ld rages %ld\n",
               s + 1, n[s], fr[s] / 60.0 / n[s], t[s][0] / n[s], t[s][1] / n[s], t[s][2] / n[s],
               t[s][3] / n[s], t[s][4] / n[s], t[s][5] / n[s], t[s][6] / n[s], t[s][7] / n[s]);
    }
}

static void sim(int runs)
{
    static const struct { const char *name; BotCfg cfg; } bots[] = {
        { "afk", { 0, 0, 0, 9999, 0, 0 } },
        { "button-masher", { 0, 30, 100, 10, 0, 0 } },
        { "casual", { 0, 70, 70, 30, 0, 0 } },
        { "average", { 1, 75, 80, 25, 0, 0 } },
        { "good", { 1, 92, 95, 12, 0, 0 } },
        { "meow-fan", { 1, 92, 95, 12, 0, 1 } },
        { "buddha-hunter", { 1, 92, 95, 12, 0, 2 } },
    };
    printf("%-14s %-3s  reached stage (%%):  1    2    3    4    5    6    7    8    9  END  score  mins  buddha/run\n", "bot", "cat");
    for (unsigned b = 0; b < sizeof(bots) / sizeof(bots[0]); b++) {
        for (int cat = 0; cat < 3; cat++) {
            int cleared[SIM_STAGES + 1] = { 0 };
            long score = 0, frames = 0, buddhas = 0;
            for (int r = 0; r < runs; r++) {
                SimResult res;
                game_sim(cat, &bots[b].cfg, 1000 + r * 7919, &res);
                for (int s = 0; s <= res.result && s <= SIM_STAGES; s++)
                    cleared[s]++;
                score += res.score;
                frames += res.run_frames;
                buddhas += res.buddha;
            }
            printf("%-14s %-3d                    ", bots[b].name, cat);
            for (int s = 0; s <= SIM_STAGES; s++)
                printf("%4d ", cleared[s] * 100 / runs);
            printf(" %5ld %5.1f  %6.2f\n", score / runs, frames / 60.0 / 60.0 / runs, (double)buddhas / runs);
        }
    }
}

// Per stage: how often each bot clears it, dies there, gets rescued there.
static void deaths(int runs, int full)
{
    static const struct { const char *name; BotCfg cfg; } bots[] = {
        { "button-masher", { 0, 30, 100, 10, 0, 0 } },
        { "casual", { 0, 70, 70, 30, 0, 0 } },
        { "average", { 1, 75, 80, 25, 0, 0 } },
        { "good", { 1, 92, 95, 12, 0, 0 } },
    };
    for (unsigned b = 0; b < sizeof(bots) / sizeof(bots[0]); b++) {
        BotCfg cfg = bots[b].cfg;
        cfg.full = full;
        int reach[SIM_MAX] = { 0 }, low[SIM_MAX] = { 0 }, die[SIM_MAX] = { 0 }, resc[SIM_MAX + 1] = { 0 }, end = 0, lives = 0, len = 0;
        long fr[SIM_MAX] = { 0 }, total = 0;
        for (int cat = 0; cat < 3; cat++)
            for (int r = 0; r < runs; r++) {
                SimResult res;
                game_sim(cat, &cfg, 1000 + r * 7919, &res);
                len = res.stages;
                for (int s = 0; s < len; s++) {
                    if (s <= res.result) {
                        reach[s]++;
                        fr[s] += res.frames[s];
                        low[s] += res.min_hp[s] <= 10;
                    }
                    die[s] += res.deaths[s];
                    lives += res.deaths[s];
                }
                resc[res.rescued]++;
                end += res.result == len;
                total += res.run_frames;
            }
        int n = runs * 3;
        printf("%s: finished %d%%, avg lives lost %.2f (of 3), %.1f mins\n", bots[b].name, end * 100 / n,
               (double)lives / n, total / 3600.0 / n);
        printf("  stage  reach%%  deaths/100  hp<=10%%  rescued-here%%  mins\n");
        for (int s = 0; s < len; s++)
            printf("  %5d  %5d  %10d  %7d  %13d  %4.1f\n", s + 1, reach[s] * 100 / n,
                   reach[s] ? die[s] * 100 / reach[s] : 0, reach[s] ? low[s] * 100 / reach[s] : 0, resc[s + 1] * 100 / n,
                   reach[s] ? fr[s] / 3600.0 / reach[s] : 0);
    }
}

static void guide(void)
{
    static const char *sk[] = { "Meow", "Slow Blink", "Cute Pose", "Groom", "Food Paw", "Loaf",
                                "Cat Yoga", "Purr", "Shin Bump", "Belly Up" };
    static const char *likes[] = { "Food (HP)", "Pets (MP)", "Brushing (MP+HP)", "Photos (MP+XP)", "Massage" };
    static const char *roles[PK_COUNT] = {
        [PK_CATLOVER] = "Cat Lover", [PK_STUDENT] = "Student", [PK_GRANNY] = "Grandma/pa", [PK_KID] = "Kid",
        [PK_JOGGER] = "Jogger", [PK_COMMUTER] = "Commuter", [PK_DOGWALKER] = "Dog Walker",
        [PK_COURIER] = "Courier", [PK_TOURIST] = "Tourist", [PK_ENGINEER] = "Engineer", [PK_PM] = "Product Mgr",
        [PK_GUARD] = "Security", [PK_INTERN] = "Intern", [PK_EXEC] = "Executive", [PK_ALIEN] = "Alien",
        [PK_SHAMAN] = "Shaman", [PK_MONK] = "Monk", [PK_SURFER] = "Surfer",
        [PK_PROPHET] = "Wanderer",
    };
    static const char *temper[PK_COUNT] = {
        [PK_JOGGER] = "grumpy", [PK_COMMUTER] = "grumpy, often furious", [PK_DOGWALKER] = "shoos cats (dog!)",
        [PK_COURIER] = "grumpy, often furious", [PK_GUARD] = "shoos cats, dark aura", [PK_EXEC] = "grumpy, dark aura",
    };
    printf("# Momo Dev Story - Who's Who\n\n");
    printf("Every named human always has the same weakness, resistance and favourite reaction.\n");
    printf("Resistance: lower is friendlier (0-100). Using their weakness adds +35%% success.\n\n");
    int last = -1;
    for (int i = 0; i < npc_count; i++) {
        const Npc *n = &npcs[i];
        if (n->home != last) {
            last = n->home;
            if (n->home == NPC_TRAVELER)
                printf("\n## World travellers (any destination)\n\n");
            else
                printf("\n## %s\n\n", stages[n->home].place);
            printf("| Name | Role | Weak to | Resist | Likes | Temper |\n|---|---|---|---|---|---|\n");
        }
        printf("| %s | %s | **%s** | %d | %s | %s |\n", n->name, roles[n->arch] ? roles[n->arch] : "?",
               sk[n->weak], n->resist, likes[n->likes], temper[n->arch] ? temper[n->arch] : "friendly");
    }
}

int main(int argc, char **argv)
{
    if (argc >= 2 && !strcmp(argv[1], "guide")) {
        guide();
        return 0;
    }
    if (argc >= 4 && !strcmp(argv[1], "shots"))
        return run_shots(argv[2], argv[3]);
    if (argc >= 2 && (!strcmp(argv[1], "sim") || !strcmp(argv[1], "tally") || !strcmp(argv[1], "deaths")))
        save_enabled = false;
    if (argc >= 2 && !strcmp(argv[1], "deaths")) {
        deaths(argc >= 3 ? atoi(argv[2]) : 60, argc >= 4 && !strcmp(argv[3], "full"));
        return 0;
    }
    if (argc >= 2 && !strcmp(argv[1], "tally")) {
        BotCfg good = { 1, 92, 95, 12, 0, 0 }, casual = { 0, 70, 70, 30, 0, 0 };
        tally(argc >= 4 && !strcmp(argv[3], "casual") ? &casual : &good, 0, argc >= 3 ? atoi(argv[2]) : 100);
        return 0;
    }
    if (argc >= 2 && !strcmp(argv[1], "sim")) {
        sim(argc >= 3 ? atoi(argv[2]) : 200);
        return 0;
    }
    fprintf(stderr, "usage: %s shots <script> <outdir> | sim [runs] | deaths [runs] [full] | tally [runs] [casual]\n", argv[0]);
    return 1;
}
