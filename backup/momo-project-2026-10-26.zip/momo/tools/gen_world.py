# Momo Dev Story - world tour destinations (256x192 backgrounds).
#
# Every scene follows the same layout so gameplay works everywhere:
#   sky + landmark ........ y 0..115
#   Momo's ledge .......... top edge at y=116 (a wall, rail or fence)
#   ground ................ y 150..167
#   path for humans ....... y 168..191

import math
import random

from PIL import Image, ImageChops, ImageDraw, ImageFont

from gen_backgrounds import (FONT_DIR, H, W, blob, grass_clump, lerp, shrub, speckle,
                             tree_canopy, vgrad)

LEDGE = 116


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def new(sky0, sky1, horizon=116):
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    vgrad(d, 0, 0, W, horizon, sky0, sky1)
    return img, d


def sun(d, x, y, r, col=(255, 240, 180)):
    d.ellipse([x - r - 3, y - r - 3, x + r + 3, y + r + 3], fill=lerp(col, (255, 255, 255), 0.5))
    d.ellipse([x - r, y - r, x + r, y + r], fill=col)


def clouds(d, rnd, n, y0, y1, col=(250, 250, 252)):
    for _ in range(n):
        x = rnd.randint(0, W)
        y = rnd.randint(y0, y1)
        for k in range(4):
            r = rnd.randint(5, 10)
            d.ellipse([x + k * 8 - r, y - r * 0.6, x + k * 8 + r, y + r * 0.6], fill=col)


def mountains(d, pts, col, snow=None, snow_frac=0.25):
    d.polygon(pts, fill=col)
    if snow:
        top = min(p[1] for p in pts)
        bot = max(p[1] for p in pts)
        line = top + (bot - top) * snow_frac
        for i in range(1, len(pts) - 1):
            x, y = pts[i]
            if y < line:
                w = (line - y) * 0.9
                d.polygon([(x, y), (x - w, line), (x - w * 0.4, line - 2), (x, line + 3),
                           (x + w * 0.5, line - 1), (x + w, line)], fill=snow)


def sea(img, d, y0, y1, c0, c1, rnd, sparkle=(240, 250, 255)):
    vgrad(d, 0, y0, W, y1, c0, c1)
    for _ in range(int((y1 - y0) * 3)):
        x = rnd.randint(0, W - 6)
        y = rnd.randint(y0, y1 - 1)
        d.line([(x, y), (x + rnd.randint(2, 6), y)], fill=sparkle if rnd.random() < 0.4 else lerp(c0, c1, 0.3))


def pine(d, x, base, h, col=(30, 70, 46), snow=None):
    d.rectangle([x - 1, base - h // 5, x + 1, base], fill=(80, 56, 40))
    for k in range(4):
        w = h * (0.45 - k * 0.09)
        y = base - h // 5 - k * h // 5
        d.polygon([(x - w, y), (x + w, y), (x, y - h * 0.38)], fill=col)
        if snow:
            d.polygon([(x - w * 0.5, y - h * 0.2), (x + w * 0.5, y - h * 0.2), (x, y - h * 0.38)], fill=snow)


def palm(d, x, base, h, lean, rnd):
    pts = []
    for i in range(12):
        t = i / 11
        pts.append((x + lean * t * t, base - h * t))
    d.line(pts, fill=(130, 96, 60), width=3)
    tx, ty = pts[-1]
    for k in range(7):
        a = -math.pi * (0.05 + k / 7.0)
        for s in range(10):
            fx = tx + math.cos(a) * s * 2.0
            fy = ty + math.sin(a) * s * 1.1 + (s * s) * 0.09
            d.ellipse([fx - 1.5, fy - 1, fx + 1.5, fy + 1], fill=(40, 120, 50) if k % 2 else (60, 150, 60))
    d.ellipse([tx - 3, ty - 1, tx + 1, ty + 3], fill=(110, 80, 40))


def wall(img, d, style, x0=0, x1=255, y=LEDGE, rnd=None):
    """Momo's ledge. Top surface at y; wall face down to y+36."""
    rnd = rnd or random.Random(1)
    y1 = y + 36
    if style == "stone":
        d.rectangle([x0, y, x1, y1], fill=(150, 146, 138))
        for row, yy in enumerate(range(y + 5, y1, 7)):
            off = 6 if row % 2 else 0
            for xx in range(x0 + off, x1, 12):
                c = rnd.choice([(160, 156, 146), (140, 136, 128), (170, 164, 152)])
                d.rectangle([xx + 1, yy + 1, xx + 11, yy + 6], fill=c)
        d.rectangle([x0 - 2, y, x1 + 2, y + 4], fill=(184, 178, 166))
    elif style == "adobe":
        d.rectangle([x0, y, x1, y1], fill=(214, 168, 116))
        speckle(img, (x0, y + 4, x1, y1), [(196, 150, 100), (226, 182, 130)], 0.15, rnd)
        d.rectangle([x0 - 2, y, x1 + 2, y + 4], fill=(232, 192, 140))
    elif style == "brick":
        d.rectangle([x0, y, x1, y1], fill=(150, 70, 56))
        for row, yy in enumerate(range(y + 5, y1, 5)):
            d.line([(x0, yy), (x1, yy)], fill=(110, 60, 50))
            for xx in range(x0 + (5 if row % 2 else 0), x1, 10):
                d.line([(xx, yy), (xx, yy + 4)], fill=(110, 60, 50))
        d.rectangle([x0 - 2, y, x1 + 2, y + 4], fill=(170, 160, 150))
    elif style in ("wood", "log", "ranch"):
        col = (140, 96, 60) if style != "log" else (120, 80, 50)
        d.rectangle([x0, y, x1, y + 4], fill=lerp(col, (255, 255, 255), 0.15))
        for yy in (y + 12, y + 22):
            d.rectangle([x0, yy, x1, yy + 3], fill=col)
        for xx in range(x0, x1 + 1, 30):
            d.rectangle([xx, y, xx + 3, y1], fill=lerp(col, (0, 0, 0), 0.2))
    elif style == "rail":  # white painted pier / boardwalk railing
        d.rectangle([x0, y, x1, y + 3], fill=(240, 240, 236))
        d.rectangle([x0, y + 16, x1, y + 18], fill=(220, 220, 216))
        for xx in range(x0, x1 + 1, 12):
            d.rectangle([xx, y, xx + 1, y1], fill=(230, 230, 226))
    elif style == "lava":
        d.rectangle([x0, y, x1, y1], fill=(60, 56, 56))
        for _ in range(140):
            xx = rnd.randint(x0, x1)
            yy = rnd.randint(y, y1)
            d.ellipse([xx, yy, xx + 4, yy + 3], fill=rnd.choice([(80, 74, 72), (44, 40, 42), (96, 88, 84)]))
        d.rectangle([x0 - 2, y, x1 + 2, y + 3], fill=(96, 90, 86))
    elif style == "temple":  # red temple wall with tiled cap
        d.rectangle([x0, y, x1, y1], fill=(170, 40, 34))
        d.rectangle([x0 - 4, y - 2, x1 + 4, y + 4], fill=(60, 60, 64))
        for xx in range(x0 - 4, x1 + 4, 4):
            d.line([(xx, y - 2), (xx, y + 4)], fill=(90, 90, 96))
    elif style == "bamboo":
        for xx in range(x0, x1, 5):
            d.rectangle([xx, y, xx + 3, y1], fill=(150, 160, 70))
            for yy in range(y + 8, y1, 12):
                d.line([(xx, yy), (xx + 3, yy)], fill=(110, 120, 50))
        d.rectangle([x0, y, x1, y + 3], fill=(170, 180, 90))
        d.rectangle([x0, y + 20, x1, y + 22], fill=(120, 90, 50))
    elif style == "seawall":
        d.rectangle([x0, y, x1, y1], fill=(196, 196, 190))
        for xx in range(x0, x1, 24):
            d.line([(xx, y + 4), (xx, y1)], fill=(170, 170, 164))
        d.rectangle([x0 - 2, y, x1 + 2, y + 4], fill=(220, 220, 214))
    d.line([(x0 - 2, y), (x1 + 2, y)], fill=(250, 250, 250))
    d.line([(x0 - 2, y + 5), (x1 + 2, y + 5)], fill=(70, 66, 64))


def ground(img, d, rnd, col, path, y0=150):
    """Strip in front of the ledge plus the walking path."""
    d.rectangle([0, y0, W, 167], fill=col)
    speckle(img, (0, y0, W, 168), [lerp(col, (0, 0, 0), 0.15), lerp(col, (255, 255, 255), 0.15)], 0.25, rnd)
    kinds = {
        "concrete": ((176, 176, 172), (200, 200, 194)),
        "sand": ((226, 206, 160), (240, 224, 186)),
        "dirt": ((150, 110, 76), (172, 132, 92)),
        "cobble": ((150, 140, 130), (176, 166, 152)),
        "snow": ((226, 232, 240), (246, 248, 252)),
        "board": ((156, 112, 74), (176, 130, 88)),
        "stone": ((170, 162, 148), (190, 182, 166)),
    }
    c0, c1 = kinds[path]
    vgrad(d, 0, 168, W, H, c0, c1)
    d.line([(0, 168), (255, 168)], fill=lerp(c0, (0, 0, 0), 0.2))
    if path == "cobble":
        for yy in range(170, H, 5):
            for xx in range((yy // 5 % 2) * 4, W, 8):
                d.ellipse([xx, yy, xx + 6, yy + 4], outline=lerp(c0, (0, 0, 0), 0.2))
    elif path == "board":
        for xx in range(0, W, 9):
            d.line([(xx, 168), (xx - 6, H)], fill=lerp(c0, (0, 0, 0), 0.25))
    else:
        speckle(img, (0, 169, W, H), [lerp(c0, (0, 0, 0), 0.08), lerp(c1, (255, 255, 255), 0.2)], 0.08, rnd)


def title_sign(d, text):
    pass  # place names are drawn by the game, not baked in


# --------------------------------------------------------------------------
# destinations
# --------------------------------------------------------------------------

def _san_francisco_dapple(img, box, base, cols, density, rnd):
    """Speckle only pixels that still hold colour `base` (texture inside a shape)."""
    x0, y0, x1, y1 = box
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W, x1), min(H, y1)
    px = img.load()
    for _ in range(int((x1 - x0) * (y1 - y0) * density)):
        x = rnd.randrange(x0, x1)
        y = rnd.randrange(y0, y1)
        if px[x, y] == base:
            px[x, y] = rnd.choice(cols)


def _san_francisco_gulls(d, rnd, n, x0, x1, y0, y1, col=(250, 250, 250)):
    for _ in range(n):
        x = rnd.randint(x0, x1)
        y = rnd.randint(y0, y1)
        d.line([(x - 3, y - 1), (x - 1, y), (x, y + 1)], fill=col)
        d.line([(x, y + 1), (x + 1, y), (x + 3, y - 1)], fill=col)


def _san_francisco_tower(d, tx, top, base, red, dark, lite):
    for lx in (tx - 7, tx + 3):  # two legs
        d.rectangle([lx, top, lx + 4, base], fill=red)
        d.line([(lx, top), (lx, base)], fill=lite)
        d.line([(lx + 4, top), (lx + 4, base)], fill=dark)
        for yy in range(top + 6, base, 9):  # art-deco panel grooves
            d.line([(lx + 2, yy), (lx + 2, yy + 5)], fill=dark)
    d.rectangle([tx - 8, top - 3, tx + 8, top + 1], fill=red)  # cap
    d.line([(tx - 8, top - 3), (tx + 8, top - 3)], fill=lite)
    yy = top + 5
    for gap in (12, 14, 16, 18, 20):  # portal beams, gaps growing downwards
        if yy + 3 > base - 6:
            break
        d.rectangle([tx - 3, yy, tx + 3, yy + 3], fill=red)
        d.line([(tx - 3, yy + 4), (tx + 3, yy + 4)], fill=dark)
        yy += gap
    d.point((tx - 5, top - 5), fill=(255, 80, 60))  # aircraft beacons
    d.point((tx + 5, top - 5), fill=(255, 80, 60))


def _san_francisco_lady(d, x, base, w, h, col, trim):
    dark = lerp(col, (0, 0, 0), 0.3)
    roof = base - h
    d.rectangle([x, roof, x + w, base], fill=col)
    for yy in range(roof + 2, base, 3):  # clapboard siding
        d.line([(x, yy), (x + w, yy)], fill=lerp(col, (0, 0, 0), 0.08))
    d.polygon([(x - 2, roof + 1), (x + w // 2, roof - 11), (x + w + 2, roof + 1)], fill=dark)  # gable
    d.polygon([(x + 2, roof), (x + w // 2, roof - 8), (x + w - 2, roof)], fill=col)
    d.ellipse([x + w // 2 - 2, roof - 5, x + w // 2 + 2, roof - 1], fill=trim)  # gable rosette
    d.line([(x - 2, roof + 1), (x + w + 2, roof + 1)], fill=trim)
    for by in (roof + 3, roof + 12):  # stacked bay windows
        d.rectangle([x + 1, by, x + 8, by + 7], fill=trim)
        for wx in (x + 2, x + 5):
            d.rectangle([wx, by + 1, wx + 1, by + 5], fill=(60, 86, 120))
            d.point((wx, by + 1), fill=(170, 200, 230))
        d.line([(x + 1, by + 8), (x + 8, by + 8)], fill=dark)
    d.rectangle([x + 10, roof + 3, x + w - 1, roof + 10], fill=trim)  # upper window
    d.rectangle([x + 11, roof + 4, x + w - 2, roof + 9], fill=(60, 86, 120))
    d.rectangle([x + 10, base - 9, x + w - 1, base - 3], fill=trim)  # front door
    d.rectangle([x + 11, base - 8, x + w - 2, base - 3], fill=lerp(col, (60, 40, 30), 0.6))
    for k in range(3):  # stoop
        d.line([(x + 9 - k, base - 2 + k), (x + w - 1, base - 2 + k)], fill=(230, 226, 216) if k % 2 == 0 else (190, 186, 178))
    d.line([(x + w, roof), (x + w, base)], fill=dark)


def _san_francisco_cable_car(d, x, y):
    """Cable car with its floor at y, spanning x..x+28."""
    d.line([(x + 14, y - 16), (x + 20, y - 34)], fill=(60, 60, 64))  # trolley pole
    d.rectangle([x - 1, y - 17, x + 29, y - 15], fill=(120, 40, 36))  # roof
    d.rectangle([x, y - 15, x + 28, y - 1], fill=(170, 40, 40))
    d.rectangle([x, y - 15, x + 28, y - 10], fill=(236, 222, 180))
    for wx in range(x + 2, x + 26, 5):
        d.rectangle([wx, y - 14, wx + 3, y - 10], fill=(80, 100, 130))
    d.rectangle([x + 9, y - 8, x + 19, y - 5], fill=(236, 222, 180))
    d.line([(x + 10, y - 7), (x + 18, y - 7)], fill=(60, 60, 140))
    d.rectangle([x, y - 1, x + 28, y], fill=(50, 40, 36))
    for wx in (x + 5, x + 22):
        d.ellipse([wx - 2, y - 1, wx + 2, y + 2], fill=(30, 30, 30))


def san_francisco(rnd):
    img, d = new((104, 158, 218), (220, 232, 240))
    clouds(d, rnd, 3, 22, 34, (238, 244, 250))
    # far East Bay hills, hazy
    far = (150, 172, 176)
    mountains(d, [(0, 94), (0, 72), (30, 64), (60, 70), (96, 60), (130, 72), (170, 66), (210, 78), (256, 70), (256, 94)], far)
    _san_francisco_dapple(img, (0, 58, 256, 94), far, [(140, 162, 166), (162, 182, 184)], 0.2, rnd)
    # Karl the Fog rolling over the hills
    for k in range(12):
        x = k * 22 - 8 + rnd.randint(-5, 5)
        y = 64 + rnd.randint(-4, 4)
        d.ellipse([x - 16, y - 6, x + 18, y + 8], fill=(234, 238, 244))
        d.ellipse([x - 10, y - 9, x + 8, y + 1], fill=(246, 248, 252))
    # Marin Headlands on the left
    marin = (92, 124, 82)
    mountains(d, [(0, 94), (0, 70), (16, 64), (38, 72), (60, 68), (86, 80), (110, 90), (120, 94)], marin)
    _san_francisco_dapple(img, (0, 60, 122, 94), marin, [(76, 106, 70), (120, 146, 92), (140, 150, 96)], 0.3, rnd)
    d.ellipse([-10, 60, 30, 70], fill=(240, 242, 246))  # fog spilling over the crest
    d.ellipse([20, 64, 56, 72], fill=(232, 236, 242))
    # the bay
    sea(img, d, 90, 116, (64, 112, 150), (96, 144, 172), rnd, sparkle=(220, 236, 246))
    # Golden Gate Bridge
    red, dark, lite = (198, 72, 44), (140, 46, 30), (226, 110, 74)
    t1, t2, top, deck = 34, 140, 14, 84
    pts = []
    for x in range(0, W):
        if x < t1:
            y = top + (t1 - x) * 1.4
        elif x <= t2:
            u = (x - (t1 + t2) / 2) / ((t2 - t1) / 2)
            y = top + (1 - u * u) * 64
        else:
            y = top + (x - t2) * 1.0
        pts.append((x, min(y, deck)))
    for x in range(2, W - 2, 4):  # suspender cables
        if pts[x][1] < deck - 1 and abs(x - t1) > 6 and abs(x - t2) > 6:
            d.line([(x, pts[x][1]), (x, deck)], fill=(222, 128, 96))
    d.rectangle([0, deck, W, deck + 3], fill=red)  # roadway
    d.rectangle([0, deck + 4, W, deck + 6], fill=dark)  # truss
    for x in range(0, W, 4):
        d.line([(x, deck + 4), (x + 2, deck + 6)], fill=red)
    d.line([(0, deck), (W, deck)], fill=lite)
    for x in range(4, W, 11):  # traffic
        d.point((x + rnd.randint(0, 4), deck + 1), fill=rnd.choice([(250, 250, 250), (240, 200, 60), (60, 90, 160), (30, 30, 30)]))
    d.line(pts, fill=red, width=2)
    for tx in (t1, t2):
        _san_francisco_tower(d, tx, top, 112, red, dark, lite)
        d.rectangle([tx - 10, 108, tx + 10, 116], fill=(150, 150, 146))  # pier footing
        d.line([(tx - 10, 108), (tx + 10, 108)], fill=(186, 186, 180))
    d.ellipse([t1 - 12, 96, t1 + 2, 102], fill=(246, 248, 252))  # fog curling round the tower
    d.ellipse([t1 - 4, 98, t1 + 16, 104], fill=(236, 240, 246))
    # Alcatraz island in the bay
    d.polygon([(66, 112), (72, 105), (98, 104), (106, 112)], fill=(110, 112, 96))
    d.rectangle([76, 98, 96, 105], fill=(214, 206, 186))
    for wx in range(78, 95, 3):
        d.point((wx, 101), fill=(110, 104, 96))
    d.rectangle([86, 90, 88, 98], fill=(236, 232, 220))  # lighthouse
    d.point((87, 89), fill=(255, 240, 150))
    d.rectangle([92, 95, 94, 98], fill=(180, 172, 156))  # water tower
    # sailboats
    for sx, sy in ((112, 108), (8, 104), (50, 110)):
        d.polygon([(sx, sy), (sx + 10, sy), (sx + 8, sy + 3), (sx + 2, sy + 3)], fill=(250, 250, 250))
        d.polygon([(sx + 5, sy - 13), (sx + 5, sy - 1), (sx + 12, sy - 1)], fill=(250, 250, 252))
        d.polygon([(sx + 4, sy - 10), (sx + 4, sy - 1), (sx - 1, sy - 1)], fill=(220, 226, 236))
        d.line([(sx + 5, sy - 14), (sx + 5, sy)], fill=(90, 90, 96))
    # downtown skyline + Transamerica Pyramid, behind the hill
    for bx, bw, bh, col in ((160, 12, 34, (176, 182, 192)), (172, 10, 46, (150, 160, 176)), (182, 14, 40, (196, 198, 202)),
                            (210, 12, 50, (160, 166, 178)), (222, 16, 30, (186, 190, 198)), (238, 10, 44, (144, 152, 168)),
                            (246, 12, 36, (176, 180, 190))):
        d.rectangle([bx, 100 - bh, bx + bw, 100], fill=col)
        for wy in range(100 - bh + 3, 98, 4):
            d.line([(bx + 2, wy), (bx + bw - 2, wy)], fill=lerp(col, (60, 80, 110), 0.35))
        d.line([(bx + bw, 100 - bh), (bx + bw, 100)], fill=lerp(col, (0, 0, 0), 0.2))
    d.polygon([(196, 100), (203, 28), (210, 100)], fill=(230, 230, 226))  # Transamerica
    d.polygon([(203, 28), (210, 100), (206, 100)], fill=(196, 196, 194))
    d.line([(203, 22), (203, 28)], fill=(200, 200, 200))
    d.polygon([(194, 74), (196, 66), (198, 74)], fill=(220, 220, 216))  # wings
    d.polygon([(208, 74), (210, 66), (212, 74)], fill=(220, 220, 216))
    d.rectangle([186, 60, 190, 100], fill=(216, 210, 196))  # Coit Tower
    d.rectangle([185, 58, 191, 61], fill=(232, 226, 212))
    # Alamo Square hill
    hill = (98, 146, 78)
    d.polygon([(134, 116), (150, 100), (190, 92), (256, 86), (256, 116)], fill=hill)
    _san_francisco_dapple(img, (134, 86, 256, 116), hill, [(84, 130, 66), (120, 166, 92)], 0.3, rnd)
    for cx, cy, r in ((150, 98, 8), (162, 94, 7), (252, 86, 7)):  # cypress trees
        d.rectangle([cx - 1, cy, cx + 1, cy + 10], fill=(80, 60, 44))
        tree_canopy(d, img, cx, cy, r, rnd, (34, 70, 44), (52, 96, 56), (84, 128, 70))
    # the Painted Ladies
    ladies = [(232, 170, 186), (166, 198, 228), (242, 222, 150), (176, 216, 176), (214, 188, 228), (240, 176, 140)]
    for i, col in enumerate(ladies):
        _san_francisco_lady(d, 160 + i * 16, 116, 15, 22 + i % 2 * 2, col, (250, 248, 240) if i % 2 else (236, 236, 250))
    # cable car + overhead wire + street lamps
    d.polygon([(96, 116), (102, 108), (150, 108), (150, 116)], fill=(150, 146, 136))  # Embarcadero quay
    d.rectangle([102, 108, 150, 110], fill=(176, 172, 162))
    d.rectangle([100, 113, 160, 116], fill=(96, 96, 100))  # street + rails
    d.line([(100, 114), (160, 114)], fill=(170, 170, 176))
    d.line([(103, 78), (103, 113)], fill=(60, 60, 64), width=2)  # wire pole
    d.line([(103, 78), (160, 82)], fill=(60, 60, 64))
    _san_francisco_cable_car(d, 118, 113)
    for lx in (108, 154):
        d.line([(lx, 116), (lx, 98)], fill=(50, 54, 60))
        d.rectangle([lx - 2, 96, lx + 2, 98], fill=(240, 230, 180))
    # (gulls are animated by the game, none painted here)
    # seawall + ledge
    wall(img, d, "seawall", rnd=rnd)
    for _ in range(14):  # water stains on the seawall
        x = rnd.randint(4, 250)
        d.line([(x, 122), (x, 122 + rnd.randint(6, 20))], fill=(182, 182, 176))
    for x in range(20, W, 64):  # drain ports
        d.ellipse([x, 140, x + 6, 145], fill=(120, 122, 120))
    ground(img, d, rnd, (110, 150, 80), "concrete")
    # hedge + California poppies along the grass strip
    for x in range(6, W, 22):
        shrub(d, x + rnd.randint(-3, 3), 154, 5 + rnd.randint(0, 2), rnd)
    for _ in range(28):
        x = rnd.randint(2, 252)
        y = rnd.randint(158, 165)
        d.rectangle([x, y, x + 1, y + 1], fill=rnd.choice([(250, 150, 30), (255, 190, 60), (240, 240, 240)]))
    return img


def _alaska_cabin(d, img, x, base, rnd):
    """Snowed-in log cabin, x..x+44, with a lit window and chimney smoke."""
    for k, yy in enumerate(range(base - 26, base, 4)):  # stacked logs
        d.rectangle([x, yy, x + 44, yy + 3], fill=(120, 80, 50) if k % 2 else (136, 92, 58))
        d.line([(x, yy + 3), (x + 44, yy + 3)], fill=(84, 56, 36))
        d.ellipse([x - 3, yy, x + 1, yy + 3], fill=(176, 136, 96))  # log ends
        d.ellipse([x + 43, yy, x + 47, yy + 3], fill=(176, 136, 96))
    d.rectangle([x + 34, base - 44, x + 39, base - 26], fill=(110, 100, 96))  # stone chimney
    d.polygon([(x - 6, base - 25), (x + 22, base - 42), (x + 50, base - 25)], fill=(96, 60, 40))  # roof
    d.polygon([(x - 6, base - 26), (x + 22, base - 43), (x + 50, base - 26), (x + 46, base - 23),
               (x + 22, base - 38), (x - 2, base - 23)], fill=(240, 244, 252))  # snow on roof
    for k in range(5):  # icicles
        ix = x + 2 + k * 10
        d.line([(ix, base - 24), (ix, base - 20 - (k % 2) * 2)], fill=(200, 224, 246))
    d.rectangle([x + 6, base - 18, x + 16, base - 10], fill=(255, 210, 110))  # lit window
    d.line([(x + 11, base - 18), (x + 11, base - 10)], fill=(90, 60, 40))
    d.line([(x + 6, base - 14), (x + 16, base - 14)], fill=(90, 60, 40))
    d.rectangle([x + 26, base - 20, x + 36, base], fill=(80, 52, 34))  # door
    d.point((x + 34, base - 10), fill=(220, 200, 120))
    for k in range(5):  # smoke curling up
        sx = x + 37 + k * 3 + int(math.sin(k) * 3)
        sy = base - 48 - k * 6
        r = 2 + k
        d.ellipse([sx - r, sy - r, sx + r, sy + r], fill=lerp((200, 204, 220), (110, 120, 160), k / 5))
    for k in range(4):  # firewood stack
        for j in range(3 - k // 2):
            d.ellipse([x + 48 + j * 4, base - 3 - k * 3, x + 51 + j * 4, base - k * 3], fill=(170, 124, 80))


def _alaska_totem(d, x, base, h):
    cols = [(200, 60, 50), (40, 90, 150), (240, 200, 80), (40, 130, 100)]
    seg = h // 4
    for k in range(4):
        y0 = base - (k + 1) * seg
        d.rectangle([x - 4, y0, x + 4, y0 + seg], fill=(140, 96, 64))
        d.rectangle([x - 3, y0 + 2, x - 1, y0 + 4], fill=(250, 250, 240))  # eyes
        d.rectangle([x + 1, y0 + 2, x + 3, y0 + 4], fill=(250, 250, 240))
        d.point((x - 2, y0 + 3), fill=(20, 20, 20))
        d.point((x + 2, y0 + 3), fill=(20, 20, 20))
        d.rectangle([x - 2, y0 + seg - 4, x + 2, y0 + seg - 2], fill=cols[k])  # mouth
        d.line([(x - 4, y0), (x + 4, y0)], fill=(90, 60, 40))
    top = base - 4 * seg
    d.polygon([(x - 14, top + 4), (x - 4, top), (x - 4, top + 6)], fill=cols[0])  # thunderbird wings
    d.polygon([(x + 14, top + 4), (x + 4, top), (x + 4, top + 6)], fill=cols[0])
    d.polygon([(x - 4, top), (x, top - 6), (x + 4, top), (x + 1, top + 3)], fill=cols[2])  # beak


def _alaska_moose(d, x, y, col=(40, 32, 30)):
    """Moose silhouette facing left; y = hoof line."""
    d.rectangle([x, y - 12, x + 16, y - 6], fill=col)  # body
    d.polygon([(x + 2, y - 12), (x + 8, y - 15), (x + 12, y - 12)], fill=col)  # shoulder hump
    for lx in (x + 1, x + 4, x + 12, x + 15):
        d.line([(lx, y - 6), (lx, y)], fill=col)
    d.polygon([(x + 1, y - 12), (x - 6, y - 10), (x - 7, y - 7), (x - 3, y - 7), (x + 1, y - 8)], fill=col)  # head
    d.line([(x - 1, y - 7), (x - 1, y - 4)], fill=col)  # dewlap
    d.polygon([(x - 2, y - 13), (x - 8, y - 17), (x - 3, y - 15)], fill=col)  # antlers
    d.polygon([(x, y - 13), (x + 4, y - 18), (x + 2, y - 13)], fill=col)


def _alaska_wendys(d, x, base):
    """The classic Wendy's roadside sign: a red board in a black frame with
    big white WENDY'S lettering, Wendy in a white circle up top, a black
    swirl and a black pole. x = centre, base = ground line."""
    red, black, white = (196, 22, 36), (26, 24, 28), (250, 250, 250)
    d.rectangle([x - 3, base - 30, x + 3, base], fill=black)          # pole
    d.polygon([(x - 9, base - 32), (x + 9, base - 32), (x + 4, base - 26), (x - 4, base - 26)], fill=black)
    x0, y0, x1, y1 = x - 30, base - 54, x + 30, base - 31             # board
    cy = y0 - 2                                                       # crown with the portrait
    d.ellipse([x - 13, cy - 13, x + 13, cy + 13], fill=black)
    d.rectangle([x0 - 2, y0 - 2, x1 + 2, y1 + 2], fill=black)
    d.ellipse([x - 11, cy - 11, x + 11, cy + 11], fill=red)
    d.rectangle([x0, y0, x1, y1], fill=red)
    # Wendy: white circle, red hair and pigtails with blue bows, striped dress
    d.ellipse([x - 8, cy - 9, x + 8, cy + 7], fill=black)
    d.ellipse([x - 7, cy - 8, x + 7, cy + 6], fill=white)
    d.ellipse([x - 4, cy - 7, x + 4, cy + 1], fill=(214, 30, 30))     # hair
    d.ellipse([x - 3, cy - 4, x + 3, cy + 2], fill=(250, 214, 180))   # face
    d.point((x - 1, cy - 2), fill=(30, 40, 90))
    d.point((x + 1, cy - 2), fill=(30, 40, 90))
    d.point((x, cy + 1), fill=(200, 80, 80))                          # smile
    for side in (-1, 1):
        d.line([(x + side * 4, cy - 2), (x + side * 6, cy + 1)], fill=(214, 30, 30), width=2)
        d.point((x + side * 5, cy - 1), fill=(90, 190, 230))          # blue bows
    for k in range(-3, 4):
        d.point((x + k, cy + 4), fill=(90, 160, 220) if k % 2 else white)
        d.point((x + k, cy + 5), fill=(90, 160, 220) if k % 2 else white)
    # WENDY'S: big W, smaller caps, crisp white pixels
    big = ImageFont.truetype(FONT_DIR + "SuperClarendon.ttc", 14, index=7)
    sm = ImageFont.truetype(FONT_DIR + "SuperClarendon.ttc", 10, index=7)
    m = Image.new("L", (W, H), 0)
    md = ImageDraw.Draw(m)
    tw = md.textlength("W", font=big) + md.textlength("ENDY'S", font=sm)
    tx = x - tw / 2
    md.text((tx, y0 + 3), "W", font=big, fill=255)
    md.text((tx + md.textlength("W", font=big), y0 + 6), "ENDY'S", font=sm, fill=255)
    d._image.paste(white, (0, 0), m.point(lambda v: 255 if v > 90 else 0))
    # the little black swirl under the name
    sx = x - 2
    d.line([(sx - 10, y1 - 3), (sx + 14, y1 - 3)], fill=black)
    for cx in (sx - 10, sx, sx + 14):
        d.arc([cx - 2, y1 - 6, cx + 2, y1 - 2], 180, 450, fill=black)
    # snow on the frame
    d.rectangle([x0 - 2, y0 - 4, x - 13, y0 - 2], fill=(246, 248, 252))
    d.rectangle([x + 13, y0 - 4, x1 + 2, y0 - 2], fill=(246, 248, 252))
    d.ellipse([x - 8, cy - 15, x + 8, cy - 11], fill=(246, 248, 252))


def alaska(rnd):
    img, d = new((14, 22, 58), (96, 104, 160))
    for _ in range(90):  # stars
        x, y = rnd.randint(0, 255), rnd.randint(14, 70)
        d.point((x, y), fill=rnd.choice([(255, 255, 255), (200, 210, 255), (150, 160, 210)]))
    d.ellipse([214, 18, 226, 30], fill=(244, 240, 220))  # crescent moon
    d.ellipse([218, 16, 230, 28], fill=lerp((14, 22, 58), (96, 104, 160), 0.18))
    # aurora curtains: bright green at the hem fading up into violet
    for k, (base, amp, ph) in enumerate(((44, 10, 0.0), (32, 8, 2.0), (54, 6, 4.0))):
        for x in range(0, W):
            y = base + math.sin(x / 26.0 + ph) * amp + math.sin(x / 9.0 + k) * 2
            ln = 10 + int(8 * (0.5 + 0.5 * math.sin(x / 7.0 + ph * 3)))
            for j in range(ln):
                t = j / ln
                sky = lerp((14, 22, 58), (96, 104, 160), max(0.0, (y - j - 16) / 100.0))
                c = lerp((120, 250, 170), (170, 110, 230), t)
                c = lerp(c, sky, 0.25 + 0.6 * t + (0.25 if x % 3 == k else 0))
                d.point((x, int(y - j)), fill=c)
    # Denali massif
    rock, shade, snow = (92, 100, 132), (64, 70, 104), (236, 240, 252)
    mountains(d, [(-10, 100), (20, 70), (44, 60), (70, 46), (96, 30), (112, 22), (124, 28), (140, 40),
                  (164, 52), (190, 62), (220, 56), (246, 66), (266, 74), (266, 100)], rock, snow=snow, snow_frac=0.6)
    d.polygon([(112, 22), (124, 28), (140, 40), (164, 52), (150, 76), (128, 64), (118, 44)], fill=(186, 194, 220))  # shaded snow face
    d.polygon([(220, 56), (246, 66), (266, 74), (266, 86), (236, 80)], fill=(180, 188, 216))
    for (x0, y0, x1, y1) in ((70, 50, 64, 72), (190, 64, 182, 82), (100, 40, 96, 52)):
        d.line([(x0, y0), (x1, y1)], fill=shade)  # rocky ridges
    # nearer foothills
    mountains(d, [(-4, 104), (24, 82), (50, 90), (84, 76), (120, 92), (156, 80), (196, 92), (226, 82), (260, 90), (260, 104)],
              (52, 62, 96), snow=(170, 180, 214), snow_frac=0.3)
    # glacier tongue
    d.polygon([(118, 70), (128, 72), (140, 92), (150, 100), (110, 100), (116, 88)], fill=(200, 226, 244))
    for yy in range(78, 100, 4):
        d.line([(118 + (yy - 70) // 4, yy), (136 + (yy - 70) // 3, yy + 1)], fill=(160, 196, 226))
    # frozen lake
    vgrad(d, 0, 100, W, 116, (120, 150, 200), (180, 204, 232))
    for _ in range(30):  # cracks + aurora glints
        x, y = rnd.randint(0, 250), rnd.randint(101, 115)
        d.line([(x, y), (x + rnd.randint(3, 10), y + rnd.randint(-1, 1))],
               fill=rnd.choice([(210, 230, 250), (140, 230, 190), (104, 130, 180)]))
    # far shore spruce line
    for x in range(-2, W, 5):
        h = 8 + (x * 13) % 7
        d.polygon([(x - 3, 101), (x, 101 - h), (x + 3, 101)], fill=(26, 40, 52))
    # dog-sled team out on the ice
    for k in range(4):
        dx = 150 + k * 6
        d.rectangle([dx, 108, dx + 3, 110], fill=(70, 66, 70) if k % 2 else (200, 196, 190))
        d.point((dx + 4, 107), fill=(70, 66, 70))
    d.line([(150, 109), (138, 110)], fill=(40, 30, 30))
    d.rectangle([132, 108, 140, 111], fill=(150, 90, 50))
    d.rectangle([134, 103, 136, 108], fill=(200, 60, 50))  # musher
    d.point((135, 102), fill=(240, 220, 200))
    _alaska_moose(d, 172, 114)
    _alaska_totem(d, 82, 116, 44)
    _alaska_cabin(d, img, 20, 116, rnd)
    # big snowy spruces framing the scene
    for x, h in ((4, 64), (234, 58), (252, 70), (108, 40), (196, 36)):
        pine(d, x, 118, h, (22, 52, 46), snow=(226, 236, 250))
    _alaska_wendys(d, 214, 116)
    # behind the log fence: snowbank + saplings (shows through the rails)
    vgrad(d, 0, 116, W, 152, (200, 214, 236), (236, 242, 250))
    for x in range(6, W, 19):
        pine(d, x, 150, 22 + (x * 5) % 10, (30, 66, 54), snow=(232, 240, 252))
    wall(img, d, "log", rnd=rnd)
    for xx in range(0, W + 1, 30):  # snow caps on the fence posts
        d.ellipse([xx - 1, 113, xx + 4, 117], fill=(246, 248, 252))
    ground(img, d, rnd, (220, 228, 238), "snow")
    for x in range(0, W, 40):  # drifts + paw prints
        d.ellipse([x + rnd.randint(-6, 6), 151, x + 34, 157], fill=(242, 246, 252))
    for k in range(10):
        px = 30 + k * 20
        d.point((px, 162 + (k % 2) * 2), fill=(176, 186, 206))
        d.point((px + 2, 163 + (k % 2) * 2), fill=(176, 186, 206))
    return img


def _puerto_rico_garita(d, x, base):
    """El Morro's domed sentry box: cylinder on a corbel, x = centre."""
    stone, dark, lite = (226, 204, 160), (176, 150, 110), (240, 224, 188)
    d.polygon([(x - 8, base), (x + 8, base), (x + 4, base + 8), (x - 4, base + 8)], fill=dark)  # corbel
    for k in range(3):
        d.line([(x - 8 + k, base + 2 + k * 2), (x + 8 - k, base + 2 + k * 2)], fill=stone)
    d.rectangle([x - 8, base - 18, x + 8, base], fill=stone)
    d.rectangle([x + 4, base - 18, x + 8, base], fill=dark)
    d.rectangle([x - 8, base - 18, x - 6, base], fill=lite)
    d.rectangle([x - 2, base - 13, x + 1, base - 5], fill=(60, 44, 36))  # lookout slit
    d.rectangle([x - 10, base - 20, x + 10, base - 18], fill=lite)
    d.pieslice([x - 9, base - 30, x + 9, base - 12], 180, 360, fill=stone)  # dome
    d.pieslice([x, base - 30, x + 9, base - 12], 270, 360, fill=dark)
    d.ellipse([x - 2, base - 26, x + 2, base - 22], fill=lite)
    d.line([(x, base - 26), (x, base - 30)], fill=dark)


def _puerto_rico_flag(d, x, y):
    d.line([(x, y), (x, y + 30)], fill=(220, 220, 220))
    for k in range(5):
        d.rectangle([x + 1, y + k * 2, x + 18, y + k * 2 + 1], fill=(220, 40, 50) if k % 2 == 0 else (250, 250, 250))
    d.polygon([(x + 1, y), (x + 9, y + 5), (x + 1, y + 9)], fill=(40, 90, 200))
    d.point((x + 3, y + 4), fill=(255, 255, 255))
    d.point((x + 4, y + 5), fill=(255, 255, 255))


def _puerto_rico_house(d, x, base, w, h, col, trim, rnd):
    roof = base - h
    dark = lerp(col, (0, 0, 0), 0.25)
    d.rectangle([x, roof, x + w, base], fill=col)
    d.rectangle([x - 1, roof - 3, x + w + 1, roof + 1], fill=trim)  # parapet cornice
    d.line([(x - 1, roof + 2), (x + w + 1, roof + 2)], fill=dark)
    door = (50, 110, 90) if rnd.random() < 0.5 else (120, 60, 50)
    for k, wx in enumerate(range(x + 2, x + w - 4, 8)):
        d.rectangle([wx, roof + 5, wx + 5, roof + 14], fill=door)  # upper louvered doors
        for yy in range(roof + 6, roof + 14, 2):
            d.line([(wx, yy), (wx + 5, yy)], fill=lerp(door, (0, 0, 0), 0.3))
        d.rectangle([wx - 1, roof + 4, wx + 6, roof + 4], fill=trim)
        d.rectangle([wx, base - 13, wx + 5, base - 1], fill=lerp(door, (0, 0, 0), 0.15))  # street doors
        d.rectangle([wx - 1, base - 14, wx + 6, base - 14], fill=trim)
    # wrought-iron balcony with flower pots
    d.rectangle([x + 1, roof + 15, x + w - 1, roof + 16], fill=(40, 40, 46))
    for bx in range(x + 1, x + w, 2):
        d.line([(bx, roof + 11), (bx, roof + 15)], fill=(40, 40, 46))
    d.line([(x + 1, roof + 11), (x + w - 1, roof + 11)], fill=(40, 40, 46))
    for _ in range(3):
        fx = rnd.randint(x + 2, x + w - 3)
        d.rectangle([fx, roof + 9, fx + 2, roof + 10], fill=rnd.choice([(230, 40, 80), (250, 120, 160), (250, 200, 40)]))
        d.point((fx + 1, roof + 8), fill=(60, 140, 60))
    d.line([(x + w, roof), (x + w, base)], fill=dark)


def puerto_rico(rnd):
    img, d = new((60, 144, 232), (190, 226, 246))
    for _ in range(5):  # trade-wind cumulus
        cx, cy = rnd.randint(0, 256), rnd.randint(22, 46)
        blob(d, cx, cy, 9, (226, 234, 244), rnd, n=6, spread=0.9)
        blob(d, cx - 2, cy - 3, 7, (252, 252, 255), rnd, n=6, spread=0.8)
    # kites flying over El Morro's lawn
    for kx, ky, kc in ((40, 24, (240, 60, 60)), (70, 36, (250, 210, 40)), (112, 20, (60, 180, 220))):
        d.polygon([(kx, ky - 4), (kx + 3, ky), (kx, ky + 5), (kx - 3, ky)], fill=kc)
        d.line([(kx, ky + 5), (kx - 2, ky + 9), (kx + 1, ky + 12)], fill=kc)
        d.line([(kx, ky + 5), (kx + 14, ky + 50)], fill=(240, 240, 240))
    # El Yunque far away, cloud-capped
    mountains(d, [(100, 84), (130, 66), (150, 60), (176, 68), (210, 62), (256, 74), (256, 84)], (104, 150, 150))
    d.ellipse([136, 54, 170, 64], fill=(238, 244, 250))
    sea(img, d, 80, 116, (30, 110, 190), (60, 176, 210), rnd)
    for _ in range(14):  # whitecaps
        x, y = rnd.randint(0, 240), rnd.randint(84, 112)
        d.arc([x, y, x + 8, y + 4], 180, 360, fill=(250, 252, 255))
    # cruise ship heading into the bay
    d.polygon([(100, 86), (134, 86), (131, 91), (103, 91)], fill=(250, 250, 250))
    d.rectangle([106, 81, 128, 86], fill=(244, 244, 248))
    d.rectangle([111, 77, 124, 81], fill=(236, 236, 240))
    for wx in range(104, 132, 3):
        d.point((wx, 88), fill=(60, 90, 140))
        d.point((wx + 1, 83), fill=(60, 90, 140))
    d.rectangle([117, 72, 120, 77], fill=(40, 120, 200))
    # El Morro: tiered sandstone ramparts on the left
    tiers = [(116, 112, 0, (190, 162, 120)), (100, 98, 0, (204, 176, 132)), (82, 84, 0, (214, 190, 146))]
    for i, (xr, ytop, _, col) in enumerate(tiers):
        d.polygon([(0, 116), (0, ytop), (xr, ytop), (xr + 16, 116)], fill=col)
        d.rectangle([0, ytop - 3, xr + 2, ytop], fill=lerp(col, (255, 255, 255), 0.25))
        for ex in range(6, xr, 14):  # cannon embrasures
            d.rectangle([ex, ytop + 2, ex + 4, ytop + 5], fill=(80, 60, 46))
        d.polygon([(xr, ytop), (xr + 16, 116), (xr + 10, 116), (xr - 4, ytop)], fill=lerp(col, (0, 0, 0), 0.18))
    # lighthouse
    d.rectangle([28, 50, 40, 84], fill=(232, 216, 180))
    d.rectangle([28, 50, 31, 84], fill=(246, 236, 210))
    d.rectangle([26, 48, 42, 51], fill=(200, 184, 150))
    d.rectangle([30, 40, 38, 48], fill=(60, 60, 66))
    d.rectangle([31, 42, 37, 46], fill=(255, 236, 140))
    d.polygon([(29, 40), (34, 34), (39, 40)], fill=(60, 60, 66))
    for wy in (58, 70):
        d.rectangle([33, wy, 35, wy + 4], fill=(70, 56, 46))
    _puerto_rico_flag(d, 60, 52)
    _puerto_rico_garita(d, 84, 84)
    # Old San Juan: colourful row houses on the right
    cols = [(240, 112, 116), (250, 200, 76), (100, 186, 214), (240, 146, 200), (140, 208, 140), (250, 160, 80)]
    d.rectangle([150, 60, 160, 80], fill=(240, 232, 214))  # church bell tower behind
    d.pieslice([148, 50, 162, 66], 180, 360, fill=(220, 200, 170))
    d.rectangle([153, 64, 157, 70], fill=(70, 60, 50))
    d.line([(155, 50), (155, 44)], fill=(90, 80, 70))
    d.line([(153, 46), (157, 46)], fill=(90, 80, 70))
    for i, col in enumerate(cols):
        x = 134 + i * 21
        _puerto_rico_house(d, x, 116, 20, 28 + (i % 3) * 4, col, (250, 250, 246), rnd)
    # palms + bougainvillea between town and fort
    palm(d, 124, 116, 60, 6, rnd)
    palm(d, 250, 116, 50, -8, rnd)
    from gen_backgrounds import bougainvillea
    bougainvillea(d, img, 118, 104, 140, 116, rnd, flowers=12)
    # fortress wall ledge
    wall(img, d, "stone", rnd=rnd)
    for x in (50, 170):  # coqui frogs sat on the wall face
        d.ellipse([x, 134, x + 4, 137], fill=(110, 140, 60))
        d.point((x + 1, 133), fill=(30, 30, 30))
        d.point((x + 3, 133), fill=(30, 30, 30))
    for _ in range(8):  # moss in the mortar
        x = rnd.randint(0, 250)
        d.line([(x, 146), (x + rnd.randint(2, 8), 146)], fill=(110, 140, 90))
    ground(img, d, rnd, (90, 160, 80), "cobble")
    for x in range(10, W, 30):  # hibiscus bushes
        shrub(d, x + rnd.randint(-4, 4), 156, 6, rnd)
        for _ in range(3):
            fx, fy = x + rnd.randint(-5, 5), rnd.randint(150, 160)
            d.rectangle([fx, fy, fx + 1, fy + 1], fill=rnd.choice([(240, 40, 70), (250, 120, 50), (250, 200, 210)]))
    return img


def _hawaii_rainbow(d, cx, cy, r):
    for k, c in enumerate([(240, 110, 110), (246, 170, 100), (246, 226, 120), (140, 210, 130), (120, 170, 230), (170, 140, 220)]):
        rr = r - k * 2
        d.arc([cx - rr, cy - rr, cx + rr, cy + rr], 180, 360, fill=lerp(c, (200, 230, 250), 0.35), width=2)


def _hawaii_surfer(d, x, y, board, shirt):
    d.line([(x - 4, y), (x + 4, y)], fill=board, width=2)
    d.line([(x, y - 1), (x, y - 5)], fill=(150, 100, 70))
    d.line([(x - 2, y - 4), (x + 2, y - 4)], fill=shirt)
    d.point((x, y - 6), fill=(110, 70, 50))


def _hawaii_tiki_torch(d, x, base, h):
    d.line([(x, base), (x, base - h)], fill=(120, 84, 50), width=2)
    for yy in range(base - h + 4, base, 5):
        d.line([(x - 1, yy), (x + 1, yy)], fill=(80, 56, 34))
    d.rectangle([x - 2, base - h - 3, x + 2, base - h], fill=(80, 60, 40))
    d.polygon([(x - 2, base - h - 3), (x, base - h - 10), (x + 2, base - h - 3)], fill=(250, 150, 40))
    d.polygon([(x - 1, base - h - 3), (x, base - h - 7), (x + 1, base - h - 3)], fill=(255, 230, 120))


def _hawaii_honu(d, x, y):
    d.ellipse([x - 7, y - 4, x + 7, y + 4], fill=(90, 110, 60))
    d.ellipse([x - 5, y - 3, x + 5, y + 3], fill=(130, 140, 70))
    for k in range(-1, 2):
        d.point((x + k * 3, y), fill=(80, 96, 50))
    d.ellipse([x + 6, y - 2, x + 10, y + 1], fill=(120, 130, 80))
    for fx, fy in ((-6, -4), (4, -4), (-6, 3), (4, 3)):
        d.ellipse([x + fx, y + fy, x + fx + 3, y + fy + 2], fill=(110, 124, 70))


def hawaii(rnd):
    img, d = new((70, 160, 236), (206, 234, 250))
    sun(d, 224, 30, 10, (255, 244, 190))
    for _ in range(4):
        cx, cy = rnd.randint(140, 256), rnd.randint(40, 60)
        blob(d, cx, cy, 8, (240, 246, 252), rnd, n=6, spread=0.9)
    _hawaii_rainbow(d, 60, 86, 58)
    # Diamond Head (Le'ahi): long ridge rising to the summit on the right
    dh, dh_d, dh_l = (130, 120, 86), (98, 90, 66), (160, 150, 104)
    d.polygon([(-4, 92), (10, 80), (30, 72), (54, 66), (78, 60), (96, 52), (108, 40), (116, 38), (124, 46),
               (136, 60), (150, 76), (168, 92)], fill=dh)
    px = img.load()
    for gx in range(12, 164, 6):  # erosion gullies running down from the rim
        top = next((y for y in range(30, 92) if px[gx, y] == dh), 92)
        if top < 88:
            d.line([(gx, top + 3), (gx - 4, 92)], fill=dh_d)
            d.line([(gx + 1, top + 4), (gx - 3, 92)], fill=dh_l)
    _san_francisco_dapple(img, (0, 38, 170, 92), dh, [(118, 132, 78), (100, 120, 70)], 0.35, rnd)  # scrub
    d.polygon([(0, 92), (0, 84), (40, 82), (90, 84), (150, 86), (176, 92)], fill=(80, 130, 70))  # green base
    # Waikiki hotels along the shore + the pink Royal Hawaiian
    for hx, hw, hh, col in ((150, 10, 24, (232, 232, 226)), (162, 8, 32, (214, 220, 226)), (172, 12, 20, (240, 236, 228)),
                            (196, 10, 28, (226, 228, 232)), (208, 12, 36, (236, 234, 230)), (222, 8, 22, (210, 216, 224)),
                            (232, 14, 30, (240, 238, 232)), (248, 10, 26, (224, 226, 230))):
        d.rectangle([hx, 92 - hh, hx + hw, 92], fill=col)
        for wy in range(92 - hh + 2, 91, 3):
            d.line([(hx + 1, wy), (hx + hw - 1, wy)], fill=lerp(col, (90, 140, 180), 0.4))
    d.rectangle([182, 76, 196, 92], fill=(240, 160, 176))
    d.rectangle([186, 68, 192, 76], fill=(240, 160, 176))
    d.polygon([(185, 68), (189, 64), (193, 68)], fill=(220, 130, 150))
    for wx in range(184, 196, 3):
        d.rectangle([wx, 80, wx + 1, 84], fill=(160, 90, 110))
    # ocean: deep blue out, turquoise over the reef
    sea(img, d, 92, 116, (24, 110, 196), (70, 200, 214), rnd)
    for _ in range(8):  # reef patches
        x, y = rnd.randint(0, 240), rnd.randint(100, 110)
        d.ellipse([x, y, x + rnd.randint(10, 24), y + 3], fill=(60, 170, 190))
    for x in range(-8, W, 18):  # surf breaks
        y = 98 + (x * 7) % 5
        d.arc([x, y, x + 18, y + 6], 180, 360, fill=(255, 255, 255))
        d.line([(x + 3, y + 2), (x + 15, y + 2)], fill=(210, 240, 248))
    _hawaii_surfer(d, 40, 100, (250, 200, 60), (220, 60, 60))
    _hawaii_surfer(d, 128, 101, (240, 90, 120), (60, 160, 220))
    # outrigger canoe
    d.polygon([(80, 106), (110, 106), (106, 109), (84, 109)], fill=(130, 70, 40))
    d.line([(84, 104), (104, 104)], fill=(200, 180, 140))
    d.line([(88, 104), (88, 107)], fill=(200, 180, 140))
    d.line([(100, 104), (100, 107)], fill=(200, 180, 140))
    for px in (88, 94, 100):
        d.point((px, 104), fill=(100, 60, 40))
        d.line([(px, 105), (px, 102)], fill=(200, 60, 60))
    d.polygon([(206, 92), (218, 92), (215, 95), (209, 95)], fill=(250, 250, 250))  # sailboat
    d.polygon([(212, 78), (212, 91), (220, 91)], fill=(250, 250, 250))
    # beach with umbrellas and surfboards
    d.rectangle([0, 110, W, 116], fill=(240, 222, 170))
    d.line([(0, 110), (W, 110)], fill=(255, 255, 250))
    for ux, uc in ((70, (230, 60, 70)), (150, (250, 200, 60)), (232, (60, 170, 210))):
        d.line([(ux, 115), (ux, 104)], fill=(240, 240, 240))
        d.pieslice([ux - 9, 100, ux + 9, 110], 180, 360, fill=uc)
        d.line([(ux - 9, 105), (ux + 9, 105)], fill=lerp(uc, (0, 0, 0), 0.2))
    for bx, bc in ((112, (240, 120, 60)), (116, (80, 200, 220)), (196, (250, 240, 120))):
        d.rounded_rectangle([bx - 1, 98, bx + 2, 115], radius=1, fill=bc)
        d.line([(bx, 99), (bx, 114)], fill=lerp(bc, (255, 255, 255), 0.4))
    # palms + tiki torches
    for x, h, lean in ((14, 96, 16), (52, 72, -12), (176, 70, 12), (222, 100, -18), (250, 76, -6)):
        palm(d, x, 116, h, lean, rnd)
    for tx in (90, 140, 200):
        _hawaii_tiki_torch(d, tx, 116, 18)
    wall(img, d, "lava", rnd=rnd)
    ground(img, d, rnd, (236, 216, 164), "sand")
    # beach strip: hibiscus, plumeria, shells and a resting honu
    for x in range(10, W, 46):
        shrub(d, x, 155, 6, rnd)
        for _ in range(4):
            fx, fy = x + rnd.randint(-6, 5), rnd.randint(150, 158)
            d.ellipse([fx, fy, fx + 3, fy + 3], fill=rnd.choice([(240, 50, 70), (250, 230, 120), (250, 250, 250)]))
    _hawaii_honu(d, 128, 160)
    for _ in range(12):
        x, y = rnd.randint(0, 252), rnd.randint(158, 166)
        d.point((x, y), fill=rnd.choice([(250, 240, 230), (240, 190, 180), (200, 170, 140)]))
    return img


def _seattle_needle(d, x, top, base):
    """Space Needle centred on x: waisted legs, saucer with halo, spire."""
    leg, leg_d, white = (214, 218, 224), (150, 156, 168), (236, 238, 242)
    waist = top + int((base - top) * 0.55)
    deck = top + 14
    for sx in (-1, 1):  # outer legs: wide at base, pinched at the waist, flaring under the saucer
        d.line([(x + sx * 10, base), (x + sx * 2, waist), (x + sx * 7, deck + 2)], fill=leg, width=2)
        d.line([(x + sx * 5, base), (x + sx * 1, waist), (x + sx * 4, deck + 2)], fill=leg_d)
    d.rectangle([x - 1, deck, x + 1, base], fill=leg_d)  # elevator core
    for yy in range(deck + 6, base, 7):
        d.point((x, yy), fill=(255, 240, 180))
    for k, yy in enumerate((waist - 2, waist + 14)):  # bracing rings
        d.line([(x - 3 - k * 2, yy), (x + 3 + k * 2, yy)], fill=leg)
    d.rectangle([x - 6, base - 4, x + 6, base], fill=(140, 140, 150))  # base pavilion
    d.polygon([(x - 18, deck), (x + 18, deck), (x + 12, deck + 5), (x - 12, deck + 5)], fill=white)  # saucer underside
    d.rectangle([x - 16, deck - 3, x + 16, deck], fill=(120, 130, 150))  # glass ring
    for wx in range(x - 15, x + 16, 3):
        d.point((wx, deck - 2), fill=(240, 220, 150))
    d.polygon([(x - 18, deck - 3), (x - 10, deck - 8), (x + 10, deck - 8), (x + 18, deck - 3)], fill=white)  # halo roof
    d.line([(x - 18, deck - 3), (x + 18, deck - 3)], fill=(250, 250, 252))
    d.polygon([(x - 6, deck - 8), (x - 4, deck - 12), (x + 4, deck - 12), (x + 6, deck - 8)], fill=(200, 140, 70))  # top deck
    d.line([(x, deck - 12), (x, top)], fill=leg, width=1)
    d.point((x, top - 1), fill=(255, 80, 60))


def _seattle_wheel(d, cx, cy, r):
    d.line([(cx - 6, cy + r + 6), (cx, cy), (cx + 6, cy + r + 6)], fill=(230, 230, 232), width=2)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(240, 240, 244))
    d.ellipse([cx - r + 2, cy - r + 2, cx + r - 2, cy + r - 2], outline=(200, 204, 210))
    for k in range(14):
        a = k * math.tau / 14
        ex, ey = cx + math.cos(a) * r, cy + math.sin(a) * r
        d.line([(cx, cy), (ex, ey)], fill=(206, 210, 216))
        d.rectangle([ex - 1, ey - 1, ex + 1, ey + 1], fill=(240, 240, 244) if k % 3 else (220, 60, 60))
    d.ellipse([cx - 2, cy - 2, cx + 2, cy + 2], fill=(150, 150, 156))


def seattle(rnd):
    img, d = new((132, 150, 172), (210, 216, 224))
    # layered overcast
    for y, col in ((14, (164, 174, 188)), (28, (178, 186, 198)), (44, (192, 198, 208))):
        for x in range(-10, W, 26):
            r = rnd.randint(9, 14)
            d.ellipse([x - r, y - r // 2, x + r + 8, y + r // 2], fill=col)
    # Mount Rainier with glaciers
    mountains(d, [(110, 96), (150, 62), (176, 42), (192, 32), (204, 34), (226, 52), (262, 80), (262, 96)],
              (150, 158, 184), snow=(244, 246, 252), snow_frac=0.55)
    d.polygon([(198, 33), (204, 34), (226, 52), (238, 62), (214, 60), (206, 48)], fill=(206, 212, 230))  # shaded snow
    for gx, gy in ((176, 46), (186, 40), (214, 46)):
        d.line([(gx, gy), (gx - 4 + (gx > 200) * 10, gy + 18)], fill=(200, 208, 226))
    # evergreen hills + far Olympics
    mountains(d, [(0, 96), (0, 74), (20, 70), (44, 78), (70, 72), (96, 84), (110, 96)], (120, 136, 150))
    hill = (54, 84, 70)
    d.polygon([(0, 100), (0, 86), (30, 82), (70, 88), (120, 84), (170, 90), (220, 84), (256, 88), (256, 100)], fill=hill)
    for x in range(0, W, 4):  # fir-tree fringe
        y = 86 + int(math.sin(x / 13.0) * 3)
        d.polygon([(x - 2, y + 3), (x, y - 3 - (x * 7) % 4), (x + 2, y + 3)], fill=(40, 68, 58))
    # downtown skyline
    for bx, bw, bh, col in ((100, 12, 34, (110, 120, 136)), (112, 10, 46, (130, 140, 156)), (122, 14, 40, (96, 106, 124)),
                            (150, 12, 38, (124, 134, 150)), (176, 10, 52, (140, 148, 162)), (186, 14, 34, (108, 118, 134)),
                            (200, 10, 44, (124, 132, 148)), (226, 14, 30, (116, 126, 142)), (240, 16, 40, (132, 140, 156))):
        d.rectangle([bx, 100 - bh, bx + bw, 100], fill=col)
        for wy in range(100 - bh + 3, 98, 3):
            for wx in range(bx + 2, bx + bw - 1, 3):
                if rnd.random() < 0.55:
                    d.point((wx, wy), fill=rnd.choice([(190, 200, 214), (240, 220, 150), (160, 172, 190)]))
        d.line([(bx + bw, 100 - bh), (bx + bw, 100)], fill=lerp(col, (0, 0, 0), 0.25))
    d.polygon([(148, 100), (148, 30), (154, 26), (160, 30), (160, 100)], fill=(52, 58, 72))  # Columbia Center
    d.polygon([(144, 100), (144, 44), (148, 40), (148, 100)], fill=(64, 70, 86))
    for wy in range(32, 98, 3):
        d.line([(150, wy), (158, wy)], fill=(76, 84, 104))
    d.rectangle([236, 54, 244, 100], fill=(236, 234, 226))  # Smith Tower
    d.polygon([(235, 54), (240, 42), (245, 54)], fill=(222, 220, 212))
    d.line([(240, 42), (240, 38)], fill=(200, 200, 200))
    for wy in range(58, 98, 3):
        d.line([(237, wy), (243, wy)], fill=(196, 194, 186))
    # Elliott Bay
    sea(img, d, 100, 116, (88, 108, 124), (120, 140, 152), rnd, sparkle=(196, 208, 216))
    # port cranes on the left
    orange = (220, 110, 50)
    for cx in (8, 34):
        d.line([(cx, 116), (cx + 2, 66)], fill=orange, width=2)
        d.line([(cx + 12, 116), (cx + 10, 66)], fill=orange, width=2)
        d.line([(cx, 90), (cx + 12, 90)], fill=orange)
        d.line([(cx - 8, 64), (cx + 24, 64)], fill=orange, width=2)
        d.line([(cx + 6, 54), (cx - 8, 64)], fill=orange)
        d.line([(cx + 6, 54), (cx + 24, 64)], fill=orange)
        d.rectangle([cx + 2, 64, cx + 10, 70], fill=(240, 240, 236))
        d.line([(cx - 4, 64), (cx - 4, 78)], fill=(60, 60, 64))
    for k, col in enumerate([(180, 60, 50), (60, 110, 160), (220, 180, 60), (90, 140, 90)]):  # stacked containers
        d.rectangle([0 + k * 12, 108, 10 + k * 12, 112], fill=col)
        d.rectangle([4 + k * 12, 104, 14 + k * 12, 108], fill=lerp(col, (255, 255, 255), 0.2))
    # Washington State Ferry
    d.polygon([(44, 108), (84, 108), (80, 112), (48, 112)], fill=(250, 250, 250))
    d.line([(46, 110), (82, 110)], fill=(40, 120, 80))
    d.rectangle([50, 103, 78, 108], fill=(244, 244, 244))
    d.rectangle([56, 99, 72, 103], fill=(236, 236, 236))
    for wx in range(52, 77, 3):
        d.point((wx, 105), fill=(60, 80, 100))
    d.rectangle([62, 95, 65, 99], fill=(40, 120, 80))
    # waterfront pier + Great Wheel
    d.rectangle([92, 110, 256, 116], fill=(120, 110, 100))
    for px in range(94, 256, 8):
        d.line([(px, 112), (px, 116)], fill=(80, 70, 64))
    _seattle_wheel(d, 128, 92, 14)
    _seattle_needle(d, 98, 6, 116)
    # Pike Place Market: building + red neon sign + clock
    d.rectangle([146, 102, 256, 116], fill=(150, 90, 70))
    d.rectangle([146, 100, 256, 102], fill=(110, 70, 56))
    for wx in range(150, 254, 9):
        d.rectangle([wx, 105, wx + 5, 112], fill=(250, 220, 150))
        d.line([(wx, 108), (wx + 5, 108)], fill=(200, 150, 90))
    f = ImageFont.truetype(FONT_DIR + "Arial Bold.ttf", 9)
    tw = int(d.textlength("PUBLIC MARKET", font=f))
    sx = 178
    d.rectangle([sx - 3, 82, sx + tw + 3, 95], fill=(40, 40, 46))
    d.text((sx, 83), "PUBLIC MARKET", font=f, fill=(244, 56, 56))
    d.line([(sx + 8, 95), (sx + 8, 100)], fill=(60, 60, 60), width=2)
    d.line([(sx + tw - 8, 95), (sx + tw - 8, 100)], fill=(60, 60, 60), width=2)
    d.ellipse([158, 80, 172, 94], fill=(40, 40, 46))  # market clock
    d.ellipse([160, 82, 170, 92], fill=(240, 236, 220))
    d.line([(165, 87), (165, 83)], fill=(30, 30, 30))
    d.line([(165, 87), (168, 87)], fill=(30, 30, 30))
    d.line([(165, 94), (165, 100)], fill=(60, 60, 60), width=2)
    # gulls + rain
    for _ in range(110):
        x = rnd.randint(0, W)
        y = rnd.randint(14, 112)
        d.line([(x, y), (x - 2, y + 5)], fill=rnd.choice([(176, 190, 212), (200, 210, 226)]))
    wall(img, d, "brick", rnd=rnd)
    for _ in range(12):  # moss creeping up the bricks
        x = rnd.randint(0, 248)
        d.ellipse([x, 146, x + rnd.randint(4, 10), 152], fill=rnd.choice([(70, 110, 60), (90, 130, 70)]))
    ground(img, d, rnd, (70, 120, 70), "concrete")
    for x in range(8, W, 24):  # sword ferns
        grass_clump(d, x + rnd.randint(-3, 3), 166, 12, 6, rnd, (40, 90, 50), (80, 140, 70))
    for _ in range(4):  # puddles reflecting the grey sky
        x, y = rnd.randint(10, 220), rnd.randint(176, 186)
        d.ellipse([x, y, x + rnd.randint(14, 24), y + 3], fill=(196, 204, 214))
    return img


def _mexico_castillo(d, img, cx, base, rnd):
    """El Castillo (Chichen Itza): nine terraces, a central stair, temple on top."""
    lite, mid, dark, shadow = (222, 196, 150), (198, 170, 124), (160, 134, 96), (140, 110, 84)
    steps, sh = 9, 6
    for k in range(steps):
        w = 64 - k * 5
        y1 = base - k * sh
        y0 = y1 - sh
        d.rectangle([cx - w, y0, cx + w, y1], fill=lerp(mid, lite, k / steps))
        d.rectangle([cx + w * 0.45, y0, cx + w, y1], fill=lerp(shadow, dark, k / steps))  # shaded side
        d.line([(cx - w, y0), (cx + w, y0)], fill=lite)
        for px in range(int(cx - w + 3), int(cx + w - 3), 6):  # recessed panels
            d.rectangle([px, y0 + 2, px + 3, y1 - 1], fill=lerp(dark, mid, 0.3) if px < cx + w * 0.45 else shadow)
    top = base - steps * sh
    # central staircase with balustrades
    d.polygon([(cx - 12, base), (cx - 7, top), (cx + 7, top), (cx + 12, base)], fill=(206, 180, 136))
    for yy in range(top + 2, base, 2):
        t = (yy - top) / (base - top)
        hw = 7 + t * 5
        d.line([(cx - hw, yy), (cx + hw, yy)], fill=(176, 150, 110))
    d.line([(cx - 12, base), (cx - 7, top)], fill=(130, 104, 78), width=2)
    d.line([(cx + 12, base), (cx + 7, top)], fill=(130, 104, 78), width=2)
    # Kukulkan serpent heads at the foot of the stair
    for sx in (-1, 1):
        hx = cx + sx * 14
        d.rectangle([hx - 4, base - 5, hx + 4, base], fill=(150, 124, 90))
        d.rectangle([hx - 3, base - 2, hx + 3, base - 1], fill=(250, 240, 220))
        d.point((hx + sx * 2, base - 4), fill=(30, 30, 30))
    # temple
    d.rectangle([cx - 18, top - 16, cx + 18, top], fill=(214, 186, 140))
    d.rectangle([cx + 8, top - 16, cx + 18, top], fill=dark)
    d.rectangle([cx - 20, top - 19, cx + 20, top - 15], fill=lite)
    d.rectangle([cx - 20, top - 22, cx + 20, top - 19], fill=mid)
    for px in range(cx - 18, cx + 18, 4):  # carved frieze
        d.point((px, top - 21), fill=dark)
    for dx in (-10, 0, 10):  # three doorways divided by serpent columns
        d.rectangle([cx + dx - 3, top - 12, cx + dx + 3, top], fill=(60, 44, 36))
    d.rectangle([cx - 22, top - 2, cx + 22, top], fill=lite)


def _mexico_nopal(d, x, base, rnd):
    pads = [(0, 0, 6), (-6, -9, 5), (6, -10, 5), (-1, -18, 4), (10, -19, 4)]
    for ox, oy, r in pads:
        d.ellipse([x + ox - r * 0.7, base + oy - r - 6, x + ox + r * 0.7, base + oy], fill=(70, 140, 70))
        d.ellipse([x + ox - r * 0.4, base + oy - r - 4, x + ox, base + oy - 3], fill=(96, 166, 86))
        for _ in range(3):
            d.point((x + ox + rnd.randint(-2, 2), base + oy - rnd.randint(2, r + 4)), fill=(220, 230, 180))
    for ox, oy in ((-3, -24), (2, -26), (12, -26), (-8, -18)):  # tunas (prickly pears)
        d.ellipse([x + ox - 1, base + oy - 2, x + ox + 2, base + oy + 1], fill=(210, 40, 80))


def _mexico_agave(d, x, base):
    for k in range(-3, 4):
        d.polygon([(x - 1, base), (x + k * 4, base - 13 + abs(k) * 2), (x + 1, base)], fill=(90, 140, 130) if k % 2 else (120, 170, 150))


def mexico(rnd):
    img, d = new((236, 128, 86), (252, 214, 140))
    sun(d, 206, 62, 14, (255, 236, 140))
    for k in range(4):  # long sunset cloud streaks
        y = 36 + k * 9
        x = rnd.randint(-20, 120)
        d.line([(x, y), (x + rnd.randint(50, 110), y)], fill=(250, 170, 130), width=2)
    # Popocatepetl smoking in the distance
    mountains(d, [(140, 96), (190, 52), (204, 50), (250, 92), (256, 96)], (180, 120, 120), snow=(250, 232, 222), snow_frac=0.35)
    for k in range(5):
        r = 3 + k * 2
        sx, sy = 198 + k * 5, 46 - k * 6
        d.ellipse([sx - r, sy - r * 0.7, sx + r, sy + r * 0.7], fill=lerp((230, 210, 200), (246, 190, 150), k / 5))
    mountains(d, [(-4, 98), (30, 80), (70, 88), (110, 78), (150, 90), (200, 84), (260, 92), (260, 98)], (150, 110, 96))
    # Yucatan jungle canopy
    for x in range(-6, W, 10):
        tree_canopy(d, img, x + rnd.randint(-3, 3), 98 + rnd.randint(-3, 3), 9, rnd, (40, 86, 50), (60, 116, 60), (96, 146, 70))
    _mexico_castillo(d, img, 96, 112, rnd)
    # colourful casitas + yellow church on the right
    d.rectangle([176, 66, 190, 112], fill=(246, 200, 70))  # bell tower
    d.rectangle([174, 64, 192, 68], fill=(250, 240, 220))
    d.pieslice([176, 52, 190, 72], 180, 360, fill=(246, 200, 70))
    d.line([(183, 52), (183, 44)], fill=(90, 70, 50))
    d.line([(180, 47), (186, 47)], fill=(90, 70, 50))
    for by in (72, 88):
        d.pieslice([179, by, 187, by + 10], 180, 360, fill=(80, 54, 40))
        d.rectangle([179, by + 5, 187, by + 10], fill=(80, 54, 40))
    d.ellipse([181, by + 4, 185, by + 8], fill=(200, 160, 60))  # bell
    for i, col in enumerate([(240, 110, 150), (90, 170, 220), (250, 190, 60), (120, 200, 140), (240, 130, 70)]):
        x = 150 + i * 22 + (12 if i >= 2 else 0)
        if x > 250:
            break
        h = 22 + (i % 2) * 6
        d.rectangle([x, 116 - h, x + 20, 116], fill=col)
        d.rectangle([x - 1, 116 - h - 2, x + 21, 116 - h], fill=lerp(col, (255, 255, 255), 0.4))
        d.rectangle([x, 116 - h + 1, x + 20, 116 - h + 3], fill=(250, 246, 236))  # painted band
        d.rectangle([x + 4, 116 - h + 7, x + 9, 116 - h + 13], fill=(70, 100, 130))
        d.rectangle([x + 3, 116 - h + 13, x + 10, 116 - h + 14], fill=(250, 246, 236))
        d.rectangle([x + 12, 106, x + 18, 116], fill=(110, 70, 50))
        d.pieslice([x + 12, 103, x + 18, 109], 180, 360, fill=(110, 70, 50))
        for _ in range(4):  # pot plants on the sill
            fx = x + rnd.randint(3, 9)
            d.point((fx, 116 - h + 12), fill=rnd.choice([(230, 40, 60), (250, 160, 40), (60, 140, 60)]))
    from gen_backgrounds import bougainvillea
    bougainvillea(d, img, 190, 88, 214, 108, rnd, flowers=20)
    # desert plants framing the scene
    _mexico_nopal(d, 22, 116, rnd)
    _mexico_nopal(d, 236, 116, rnd)
    for x in (40, 56, 140, 162):
        _mexico_agave(d, x, 116)
    for x, h in ((8, 46), (166, 30)):  # organ-pipe cactus
        for k, dx in enumerate((-4, 0, 4)):
            hh = h - abs(dx) * 3
            d.rounded_rectangle([x + dx - 2, 116 - hh, x + dx + 2, 116], radius=2, fill=(56, 124, 70))
            d.line([(x + dx, 118 - hh), (x + dx, 115)], fill=(84, 150, 90))
    # papel picado + a pinata, strung below the HUD
    cols = [(230, 60, 120), (60, 170, 230), (250, 200, 50), (120, 200, 90), (240, 120, 40)]
    line = []
    for x in range(0, W + 1, 2):
        line.append((x, 20 + 6 * math.sin(math.pi * (x % 128) / 128.0)))
    d.line(line, fill=(120, 80, 60))
    for i, x in enumerate(range(2, W, 12)):
        y = 20 + 6 * math.sin(math.pi * (x % 128) / 128.0)
        c = cols[i % 5]
        d.polygon([(x, y), (x + 10, y), (x + 10, y + 9), (x + 8, y + 11), (x + 5, y + 9), (x + 2, y + 11), (x, y + 9)], fill=c)
        d.rectangle([x + 3, y + 3, x + 4, y + 4], fill=(250, 220, 160))
        d.rectangle([x + 6, y + 3, x + 7, y + 4], fill=(250, 220, 160))
        d.point((x + 5, y + 6), fill=(250, 220, 160))
    px, py = 44, 28  # star pinata hanging off the string
    d.line([(px, py - 4), (px, py)], fill=(120, 80, 60))
    d.ellipse([px - 5, py, px + 5, py + 10], fill=(250, 90, 160))
    for k, (dx, dy) in enumerate(((-9, 5), (9, 5), (0, 15), (-6, 13), (6, 13))):
        d.polygon([(px + dx * 0.4, py + 5 + dy * 0.2), (px + dx, py + dy), (px + dx * 0.3 + 2, py + 6)], fill=cols[k])
    wall(img, d, "adobe", rnd=rnd)
    for x in range(14, W, 60):  # talavera tiles set into the adobe
        d.rectangle([x, 128, x + 9, 137], fill=(240, 240, 236))
        d.rectangle([x + 2, 130, x + 7, 135], fill=(40, 80, 170))
        d.point((x + 4, 132), fill=(250, 200, 50))
    ground(img, d, rnd, (190, 150, 100), "dirt")
    for x in range(6, W, 34):  # marigolds + clay pots
        for _ in range(6):
            fx, fy = x + rnd.randint(-5, 5), rnd.randint(152, 160)
            d.ellipse([fx, fy, fx + 2, fy + 2], fill=rnd.choice([(250, 150, 20), (250, 190, 40), (230, 110, 20)]))
        d.polygon([(x + 12, 158), (x + 20, 158), (x + 18, 166), (x + 14, 166)], fill=(190, 96, 60))
        d.line([(x + 12, 158), (x + 20, 158)], fill=(220, 130, 90))
    return img


def _guatemala_house(d, rnd, x0, x1, top, col):
    d.rectangle([x0, top, x1, 116], fill=col)
    d.rectangle([x0, top, x1, top + 2], fill=lerp(col, (255, 255, 255), 0.4))
    d.rectangle([x0, 112, x1, 116], fill=lerp(col, (0, 0, 0), 0.25))  # dado band
    d.rectangle([x0 - 1, top - 4, x1 + 1, top], fill=(178, 76, 48))   # clay tile roof lip
    for xx in range(x0, x1 + 1, 3):
        d.line([(xx, top - 4), (xx, top - 1)], fill=(140, 56, 36))
    door = (x0 + x1) // 2
    d.rectangle([door - 4, 100, door + 4, 112], fill=(110, 66, 36))
    d.line([(door, 100), (door, 112)], fill=(80, 46, 26))
    for wx in (x0 + 3, x1 - 8):
        d.rectangle([wx, top + 6, wx + 5, top + 14], fill=(60, 50, 50))
        for gx in range(wx + 1, wx + 5, 2):
            d.line([(gx, top + 6), (gx, top + 14)], fill=(30, 26, 28))
        d.rectangle([wx - 1, top + 14, wx + 6, top + 15], fill=lerp(col, (255, 255, 255), 0.5))


def guatemala(rnd):
    from gen_backgrounds import bougainvillea, prayer_flags
    img, d = new((96, 160, 228), (226, 232, 238))
    clouds(d, rnd, 4, 18, 36, (246, 248, 252))
    # Volcan de Agua (left), Acatenango + smoking Fuego (right)
    mountains(d, [(-30, 116), (56, 26), (66, 26), (150, 116)], (98, 120, 134))
    d.polygon([(56, 26), (66, 26), (110, 80), (90, 84)], fill=(116, 138, 150))  # sunlit flank
    mountains(d, [(130, 116), (198, 40), (212, 30), (222, 30), (236, 44), (290, 116)], (104, 106, 120))
    d.polygon([(196, 42), (186, 60), (196, 56)], fill=(84, 84, 96))
    d.polygon([(222, 30), (236, 44), (262, 80), (240, 70)], fill=(122, 124, 136))
    for k, (px, py, r) in enumerate([(200, 34, 5), (194, 26, 6), (184, 19, 7), (172, 14, 8)]):
        d.ellipse([px - r, py - r * 0.7, px + r, py + r * 0.7], fill=lerp((200, 196, 196), (236, 236, 240), k / 3))
    # green foothills with coffee rows
    d.polygon([(0, 116), (0, 82), (40, 76), (90, 84), (140, 78), (200, 86), (256, 78), (256, 116)], fill=(84, 130, 74))
    for yy in range(84, 100, 3):
        for xx in range((yy % 2) * 3, W, 6):
            d.point((xx, yy), fill=(54, 100, 54))
    # giant barrilete kite + small kites
    kx, ky = 30, 40
    for k, c in enumerate([(230, 60, 80), (250, 200, 60), (60, 160, 220), (120, 200, 90), (240, 120, 40)]):
        r = 12 - k * 2.2
        d.ellipse([kx - r, ky - r, kx + r, ky + r], fill=c)
    for k in range(8):
        a = k * math.pi / 4
        d.line([(kx, ky), (kx + math.cos(a) * 12, ky + math.sin(a) * 12)], fill=(250, 250, 240))
    d.line([(kx, ky + 12), (kx + 6, ky + 30), (kx + 2, ky + 44)], fill=(240, 240, 240))
    for sx, sy, c in ((236, 22, (230, 60, 120)), (92, 18, (60, 170, 230))):
        d.polygon([(sx, sy - 4), (sx + 3, sy), (sx, sy + 4), (sx - 3, sy)], fill=c)
        d.line([(sx, sy + 4), (sx - 2, sy + 12)], fill=(240, 240, 240))
    # colonial street: pastel facades with tile roofs
    for x0, x1, top, col in ((-2, 30, 82, (110, 170, 190)), (32, 58, 88, (236, 150, 120)),
                             (60, 86, 84, (190, 150, 210)), (172, 198, 86, (130, 200, 150)),
                             (200, 228, 82, (240, 220, 140)), (230, 258, 88, (230, 120, 110))):
        _guatemala_house(d, rnd, x0, x1, top, col)
    # Santa Catalina Arch with clock tower
    yel, yel_d, trim = (240, 192, 56), (204, 156, 40), (252, 246, 226)
    d.rectangle([88, 72, 168, 116], fill=yel)
    d.pieslice([106, 84, 150, 128], 180, 360, fill=(150, 168, 180))   # opening, street beyond
    d.rectangle([106, 106, 150, 116], fill=(150, 168, 180))
    d.rectangle([114, 94, 142, 106], fill=(196, 190, 170))  # far facade through arch
    d.rectangle([124, 98, 132, 106], fill=(120, 90, 70))
    d.polygon([(110, 116), (146, 116), (136, 106), (120, 106)], fill=(160, 150, 140))
    d.arc([106, 84, 150, 128], 180, 360, fill=trim, width=2)
    d.rectangle([88, 72, 168, 75], fill=trim)
    d.rectangle([86, 70, 170, 72], fill=yel_d)
    for wx in range(92, 104, 6):  # little windows on the upper walkway
        d.rectangle([wx, 78, wx + 3, 86], fill=(80, 70, 60))
    for wx in range(154, 166, 6):
        d.rectangle([wx, 78, wx + 3, 86], fill=(80, 70, 60))
    for px in (90, 102, 154, 166):
        d.rectangle([px - 1, 88, px + 1, 116], fill=yel_d)
    d.rectangle([116, 46, 140, 72], fill=yel)   # clock tower
    d.rectangle([114, 44, 142, 47], fill=trim)
    d.ellipse([121, 52, 135, 66], fill=trim)
    d.ellipse([122, 53, 134, 65], outline=(80, 70, 60))
    d.line([(128, 59), (128, 54)], fill=(40, 40, 40))
    d.line([(128, 59), (132, 59)], fill=(40, 40, 40))
    d.rectangle([122, 36, 134, 44], fill=yel)
    d.rectangle([125, 38, 131, 44], fill=(90, 70, 50))
    d.polygon([(120, 36), (128, 26), (136, 36)], fill=(196, 70, 48))
    d.line([(128, 26), (128, 20)], fill=(60, 50, 40))
    d.line([(126, 22), (130, 22)], fill=(60, 50, 40))
    for bx in (116, 140):
        d.rectangle([bx - 2, 40, bx + 2, 46], fill=trim)
    for px in (96, 100, 158):  # pigeons on the ridge
        d.ellipse([px, 67, px + 4, 70], fill=(120, 120, 130))
    # jacaranda (left) and bougainvillea spill (right)
    d.line([(16, 116), (18, 82)], fill=(90, 64, 44), width=3)
    tree_canopy(d, img, 18, 70, 18, rnd, (110, 80, 160), (150, 110, 200), (196, 160, 230))
    bougainvillea(d, img, 202, 92, 250, 110, rnd, 50)
    # hand-woven textile banners across the street
    prayer_flags(d, 58, 92, 200, 92, 6, rnd, [(220, 40, 70), (40, 120, 200), (250, 190, 40), (40, 160, 90), (150, 60, 170)])
    for lx in (80, 176):  # street lamps
        d.line([(lx, 116), (lx, 98)], fill=(40, 40, 44))
        d.rectangle([lx - 2, 94, lx + 2, 98], fill=(250, 230, 160))
        d.line([(lx - 3, 93), (lx + 3, 93)], fill=(40, 40, 44))
    wall(img, d, "stone", rnd=rnd)
    ground(img, d, rnd, (110, 150, 80), "cobble")
    return img


def _texas_live_oak(d, img, x, rnd):
    d.line([(x, 116), (x, 96)], fill=(80, 60, 44), width=4)
    d.line([(x, 100), (x - 12, 88)], fill=(80, 60, 44), width=2)
    d.line([(x, 98), (x + 12, 90)], fill=(80, 60, 44), width=2)
    for ox in (-14, 0, 14):
        tree_canopy(d, img, x + ox, 82 + abs(ox) // 3, 11, rnd, (40, 74, 40), (66, 104, 52), (104, 140, 70))


def texas(rnd):
    """Aggieland: Texas A&M in College Station. Kyle Field, the Academic
    Building with its copper dome, the Century Tree and Reveille."""
    img, d = new((70, 140, 226), (246, 216, 160))
    sun(d, 236, 22, 10)
    clouds(d, rnd, 3, 20, 40, (252, 248, 240))
    d.line([(150, 20), (154, 18), (158, 20)], fill=(60, 50, 50))   # hawk circling
    maroon, maroon_d = (128, 0, 32), (92, 0, 24)
    # prairie / campus lawn
    d.rectangle([0, 92, W, 116], fill=(120, 170, 80))
    speckle(img, (0, 93, W, 116), [(100, 150, 64), (140, 186, 96)], 0.12, rnd)
    # Kyle Field on the left: tiered maroon stands and light towers
    d.polygon([(0, 96), (0, 40), (8, 36), (62, 36), (66, 40), (66, 96)], fill=(200, 196, 196))
    for k, yy in enumerate(range(42, 92, 7)):
        d.rectangle([0, yy, 64, yy + 3], fill=maroon if k % 2 == 0 else maroon_d)
    for x in range(4, 64, 8):   # concrete columns
        d.line([(x, 40), (x, 94)], fill=(176, 170, 170))
    d.rectangle([0, 32, 66, 36], fill=(150, 146, 150))
    for lx in (6, 58):
        d.line([(lx, 32), (lx, 12)], fill=(140, 140, 146))
        d.rectangle([lx - 5, 8, lx + 5, 13], fill=(230, 230, 236))
        for k in range(4):
            d.point((lx - 4 + k * 3, 10), fill=(255, 250, 200))
    big = ImageFont.truetype(FONT_DIR + "Arial Bold.ttf", 8)
    d.rectangle([6, 22, 52, 31], fill=maroon)
    d.text((8, 22), "KYLE FIELD", font=big, fill=(255, 255, 255))
    # the Academic Building: granite base, limestone storeys, copper dome
    st, st_d, st_l = (226, 214, 190), (190, 176, 150), (242, 234, 216)
    d.rectangle([84, 60, 196, 116], fill=st)
    speckle(img, (84, 60, 196, 116), [st_d, st_l], 0.05, rnd)
    d.rectangle([84, 104, 196, 116], fill=(176, 150, 140))   # pink granite base
    d.line([(82, 60), (198, 60)], fill=st_l, width=2)
    d.line([(84, 80), (196, 80)], fill=st_d)
    for wx in range(88, 194, 10):   # window rows
        if 122 <= wx <= 152:
            continue
        for wy in (64, 84):
            d.rectangle([wx, wy, wx + 5, wy + 10], fill=(80, 96, 120))
            d.line([(wx, wy), (wx + 5, wy)], fill=st_l)
    # drum and copper-green dome with lantern, rising from the roof
    d.rectangle([124, 30, 156, 60], fill=st)
    for cx in range(127, 156, 5):
        d.rectangle([cx, 33, cx + 1, 58], fill=st_d)
    d.rectangle([121, 28, 159, 31], fill=st_l)   # cornice under the dome
    d.rectangle([121, 58, 159, 60], fill=st_l)
    d.pieslice([123, 8, 157, 50], 180, 360, fill=(96, 168, 140))
    for k in range(-2, 3):
        d.line([(140 + k * 7, 28), (140 + k * 2, 10)], fill=(70, 136, 112))
    d.arc([126, 11, 154, 47], 200, 250, fill=(150, 210, 180))
    d.rectangle([137, 2, 143, 9], fill=st_l)
    d.line([(137, 2), (137, 9)], fill=st_d)
    d.polygon([(136, 2), (140, -2), (144, 2)], fill=(96, 168, 140))
    # portico with columns and pediment
    d.polygon([(118, 58), (140, 46), (162, 58)], fill=st_l)
    d.line([(118, 58), (140, 46), (162, 58)], fill=st_d)
    d.rectangle([120, 58, 160, 62], fill=st_d)
    for cx in range(122, 162, 7):
        d.rectangle([cx, 62, cx + 3, 104], fill=st_l)
        d.line([(cx + 3, 62), (cx + 3, 104)], fill=st_d)
    d.rectangle([132, 92, 148, 104], fill=(90, 70, 56))   # doorway
    for k in range(3):   # steps
        d.line([(118 - k * 2, 104 + k * 4), (162 + k * 2, 104 + k * 4)], fill=st_l)
    # the Century Tree: a wide old live oak with low sweeping branches
    tx = 220
    d.line([(tx, 116), (tx, 84)], fill=(80, 60, 44), width=6)
    for ex, ey in ((198, 96), (246, 98), (206, 82), (240, 80)):
        d.line([(tx, 92), (ex, ey)], fill=(80, 60, 44), width=3)
    for ox, oy, r in ((-22, 80, 13), (-8, 70, 15), (10, 68, 15), (26, 78, 13), (0, 82, 12)):
        tree_canopy(d, img, tx + ox, oy, r, rnd, (40, 80, 40), (66, 110, 52), (104, 146, 70))
    # flagpole: Texas flag over the maroon Aggie flag
    d.line([(176, 116), (176, 18)], fill=(200, 200, 206))
    d.rectangle([177, 18, 185, 32], fill=(30, 50, 120))
    d.rectangle([185, 18, 201, 25], fill=(250, 250, 250))
    d.rectangle([185, 25, 201, 32], fill=(200, 40, 50))
    star = [(181 + 3 * math.cos(math.pi / 2 + k * math.pi * 4 / 5), 25 - 3 * math.sin(math.pi / 2 + k * math.pi * 4 / 5)) for k in range(5)]
    d.polygon(star, fill=(255, 255, 255))
    d.rectangle([177, 34, 209, 52], fill=maroon)
    d.rectangle([177, 34, 209, 34], fill=maroon_d)
    sm = ImageFont.truetype(FONT_DIR + "Arial Bold.ttf", 13)
    d.text((193 - d.textlength("ATM", font=sm) / 2, 36), "ATM", font=sm, fill=(255, 255, 255))
    # "GIG 'EM" banner on the lawn
    d.rectangle([68, 98, 104, 107], fill=maroon)
    d.line([(68, 107), (68, 116)], fill=(90, 70, 56))
    d.line([(104, 107), (104, 116)], fill=(90, 70, 56))
    d.text((71, 98), "GIG 'EM", font=big, fill=(255, 255, 255))
    # bluebonnets along the walk
    for _ in range(60):
        bx = rnd.randint(0, 255)
        if 66 < bx < 200:
            continue
        by = rnd.randint(108, 113)
        d.line([(bx, by), (bx, by + 2)], fill=rnd.choice([(60, 90, 200), (90, 120, 230), (240, 240, 250)]))
    wall(img, d, "ranch", rnd=rnd)
    ground(img, d, rnd, (190, 160, 100), "dirt")
    return img


def _mount_shasta_lenticular(d, cx, cy, w):
    for k, c in enumerate([(176, 160, 200), (206, 192, 226), (230, 220, 240)]):
        ww = w - k * 8
        y = cy - k * 4
        d.ellipse([cx - ww, y - 3, cx + ww, y + 3], fill=c)
        d.line([(cx - ww + 4, y + 3), (cx + ww - 4, y + 3)], fill=(140, 120, 170))


def mount_shasta(rnd):
    img, d = new((14, 20, 64), (150, 120, 176))
    for _ in range(90):
        x, y = rnd.randint(0, W), rnd.randint(0, 76)
        d.point((x, y), fill=rnd.choice([(255, 255, 255), (200, 210, 255), (255, 240, 200)]))
    for x, y in ((40, 14), (90, 30), (230, 50)):
        d.line([(x - 2, y), (x + 2, y)], fill=(230, 236, 255))
        d.line([(x, y - 2), (x, y + 2)], fill=(230, 236, 255))
    d.ellipse([20, 22, 36, 38], fill=(250, 244, 210))   # crescent moon
    d.ellipse([25, 19, 41, 35], fill=lerp((14, 20, 64), (150, 120, 176), 0.22))
    # Mt. Shasta with the Shastina shoulder
    rock, rock_d = (96, 96, 140), (70, 70, 112)
    mountains(d, [(0, 116), (40, 86), (84, 52), (96, 50), (128, 22), (136, 24), (196, 70), (256, 104), (256, 116)],
              rock, snow=(232, 234, 250), snow_frac=0.5)
    d.polygon([(132, 23), (136, 24), (196, 70), (256, 104), (256, 116), (176, 116), (150, 70)], fill=rock_d)
    for gx, gy, gl in ((140, 34, 18), (150, 42, 16), (118, 38, 14), (100, 56, 10)):  # snowy gullies
        d.line([(gx, gy), (gx + (gx - 128) * 0.3, gy + gl)], fill=(212, 214, 236))
    # lenticular cloud cap: the "UFO cloud" Shasta is famous for
    _mount_shasta_lenticular(d, 132, 18, 34)
    _mount_shasta_lenticular(d, 210, 40, 16)
    # far forested ridges
    d.polygon([(0, 116), (0, 92), (60, 86), (120, 96), (180, 88), (256, 94), (256, 116)], fill=(40, 52, 80))
    for x in range(0, W, 5):
        y = 92 + int(math.sin(x / 13.0) * 3)
        d.polygon([(x - 3, y + 6), (x + 3, y + 6), (x, y - 2)], fill=(34, 46, 72))
    # Lake Siskiyou mirror with peak reflection
    d.rectangle([60, 102, 200, 112], fill=(60, 64, 110))
    d.polygon([(110, 102), (150, 102), (130, 112)], fill=(110, 110, 150))
    for k in range(10):
        x = 66 + k * 13
        d.line([(x, 104 + k % 3 * 3), (x + 5, 104 + k % 3 * 3)], fill=(150, 150, 190))
    # a small saucer drifting by, with a faint beam
    ux, uy = 200, 30
    d.polygon([(ux - 4, uy + 4), (ux + 4, uy + 4), (ux + 9, uy + 18), (ux - 9, uy + 18)], fill=(70, 100, 130))
    d.polygon([(ux - 2, uy + 4), (ux + 2, uy + 4), (ux + 5, uy + 18), (ux - 5, uy + 18)], fill=(86, 126, 140))
    d.ellipse([ux - 14, uy - 2, ux + 14, uy + 6], fill=(180, 186, 204))
    d.ellipse([ux - 6, uy - 7, ux + 6, uy + 2], fill=(150, 230, 255))
    for k, x in enumerate(range(ux - 10, ux + 11, 5)):
        d.point((x, uy + 3), fill=(255, 220, 60) if k % 2 else (255, 90, 90))
    for x in range(-4, W, 11):  # near pines
        if 60 < x < 200 and x not in (73, 183):
            continue
        pine(d, x, 116, 26 + (x * 7) % 16, (16, 36, 36))
    # glowing crystals and an alien-crossing sign
    for cx, c in ((70, (180, 120, 255)), (186, (120, 230, 220)), (196, (200, 140, 255))):
        d.polygon([(cx, 116), (cx + 2, 108), (cx + 4, 116)], fill=c)
        d.polygon([(cx + 3, 116), (cx + 6, 111), (cx + 7, 116)], fill=lerp(c, (255, 255, 255), 0.3))
    sx, sy = 230, 94
    d.line([(sx, sy), (sx, 116)], fill=(150, 150, 160))
    d.polygon([(sx, sy - 9), (sx + 9, sy), (sx, sy + 9), (sx - 9, sy)], fill=(240, 210, 60))
    d.ellipse([sx - 3, sy - 4, sx + 3, sy + 3], fill=(60, 60, 50))
    d.point((sx - 1, sy - 1), fill=(240, 210, 60))
    d.point((sx + 1, sy - 1), fill=(240, 210, 60))
    for _ in range(14):  # fireflies
        d.point((rnd.randint(0, W - 1), rnd.randint(96, 114)), fill=(220, 255, 140))
    wall(img, d, "stone", rnd=rnd)
    ground(img, d, rnd, (70, 90, 70), "dirt")
    return img


def _florida_lifeguard(d, x, col):
    for lx in (x + 1, x + 13):
        d.line([(lx, 116), (lx + (x + 7 - lx) * 0.2, 104)], fill=(240, 240, 236))
    d.rectangle([x, 96, x + 14, 104], fill=col)
    d.rectangle([x + 3, 98, x + 11, 102], fill=(80, 140, 170))
    d.polygon([(x - 2, 96), (x + 7, 90), (x + 16, 96)], fill=(250, 250, 250))
    d.line([(x + 14, 102), (x + 20, 116)], fill=(240, 240, 236))
    d.rectangle([x + 7, 86, x + 13, 89], fill=(230, 60, 60))
    d.line([(x + 7, 86), (x + 7, 90)], fill=(200, 200, 200))


def florida(rnd):
    img, d = new((60, 150, 236), (210, 234, 250))
    sun(d, 40, 24, 10, (255, 244, 190))
    clouds(d, rnd, 4, 14, 34)
    # little plane towing a beach banner
    d.line([(118, 44), (126, 44)], fill=(120, 120, 120))
    d.rectangle([84, 40, 118, 48], fill=(250, 250, 240))
    for k in range(5):
        d.rectangle([88 + k * 6, 42, 91 + k * 6, 46], fill=[(230, 60, 60), (40, 120, 200), (250, 170, 40), (40, 160, 90), (230, 80, 160)][k])
    d.polygon([(126, 42), (140, 42), (142, 45), (126, 46)], fill=(240, 240, 244))
    d.line([(132, 39), (134, 49)], fill=(200, 60, 50), width=2)
    d.line([(126, 40), (126, 44)], fill=(200, 60, 50))
    sea(img, d, 84, 116, (36, 130, 200), (96, 206, 220), rnd)
    # Cape Canaveral spit: VAB + rocket on its gantry
    d.polygon([(150, 92), (170, 86), (256, 86), (256, 94)], fill=(150, 170, 120))
    d.rectangle([174, 54, 200, 88], fill=(214, 214, 220))
    for yy in range(58, 88, 6):
        d.line([(174, yy), (200, yy)], fill=(190, 190, 198))
    d.rectangle([182, 60, 192, 88], fill=(170, 172, 186))
    d.rectangle([176, 56, 184, 64], fill=(30, 60, 140))
    for k in range(3):
        d.line([(185, 57 + k * 3), (198, 57 + k * 3)], fill=(220, 50, 50))
    d.rectangle([218, 38, 226, 86], fill=(244, 244, 248))
    d.rectangle([216, 52, 218, 86], fill=(240, 236, 220))
    d.rectangle([226, 52, 228, 86], fill=(240, 236, 220))
    d.polygon([(218, 38), (222, 26), (226, 38)], fill=(220, 60, 50))
    d.rectangle([218, 60, 226, 62], fill=(30, 30, 40))
    d.rectangle([232, 30, 238, 86], fill=(160, 70, 50))
    for yy in range(32, 86, 5):
        d.line([(232, yy), (238, yy + 4)], fill=(110, 46, 34))
    d.line([(226, 46), (232, 46)], fill=(110, 46, 34))
    d.rectangle([212, 84, 244, 88], fill=(130, 130, 140))
    # sailboat and gulls
    d.polygon([(100, 92), (116, 92), (112, 96), (104, 96)], fill=(240, 240, 240))
    d.polygon([(108, 74), (108, 91), (120, 91)], fill=(255, 255, 255))
    d.polygon([(107, 76), (107, 91), (98, 91)], fill=(240, 120, 90))
    # beach with surf
    d.polygon([(0, 116), (0, 104), (60, 106), (140, 102), (256, 108), (256, 116)], fill=(240, 222, 176))
    for x in range(0, W, 12):
        d.arc([x, 101 + (x // 12) % 2, x + 12, 107], 180, 360, fill=(255, 255, 255))
    for px in (150, 160):  # pelican on pilings
        d.rectangle([px, 100, px + 3, 116], fill=(110, 80, 56))
    d.ellipse([149, 94, 157, 101], fill=(170, 160, 150))
    d.ellipse([153, 91, 158, 95], fill=(220, 214, 200))
    d.polygon([(158, 93), (166, 95), (158, 96)], fill=(220, 150, 60))
    _florida_lifeguard(d, 172, (250, 150, 180))
    for ux, c in ((120, (240, 80, 80)), (204, (60, 170, 220))):  # umbrellas and towels
        d.line([(ux, 116), (ux, 102)], fill=(240, 240, 240))
        d.pieslice([ux - 9, 98, ux + 9, 108], 180, 360, fill=c)
        d.rectangle([ux + 2, 112, ux + 12, 115], fill=lerp(c, (255, 255, 255), 0.4))
    d.ellipse([60, 98, 76, 102], fill=(70, 100, 60))   # gator in the shallows
    for k in range(4):
        d.point((63 + k * 3, 98), fill=(50, 76, 46))
    d.ellipse([72, 96, 76, 99], fill=(80, 110, 66))
    d.point((74, 97), fill=(250, 220, 60))
    for x, h, lean in ((14, 84, 12), (44, 62, -8), (138, 56, -6)):
        palm(d, x, 116, h, lean, rnd)
    for fx in (88, 98):  # flamingos
        d.line([(fx, 116), (fx, 104)], fill=(240, 120, 150))
        d.line([(fx, 110), (fx + 3, 108)], fill=(240, 120, 150))
        d.ellipse([fx - 5, 96, fx + 5, 104], fill=(250, 140, 170))
        d.ellipse([fx - 5, 97, fx, 101], fill=(236, 110, 150))
        d.line([(fx + 4, 98), (fx + 6, 88)], fill=(250, 140, 170), width=2)
        d.ellipse([fx + 4, 85, fx + 9, 89], fill=(250, 140, 170))
        d.line([(fx + 9, 87), (fx + 10, 90)], fill=(40, 40, 40))
    for x in range(0, W, 20):
        grass_clump(d, x + rnd.randint(0, 8), 116, 6, 4, rnd, (120, 150, 80), (170, 190, 110))
    wall(img, d, "rail", rnd=rnd)
    ground(img, d, rnd, (232, 214, 170), "board")
    return img


def _usvi_boat(d, x, y, col):
    d.polygon([(x, y), (x + 18, y), (x + 14, y + 5), (x + 4, y + 5)], fill=col)
    d.line([(x + 8, y - 24), (x + 8, y)], fill=(80, 60, 50))
    d.polygon([(x + 9, y - 22), (x + 9, y - 1), (x + 20, y - 1)], fill=(255, 255, 255))
    d.polygon([(x + 7, y - 18), (x + 7, y - 1), (x, y - 1)], fill=(240, 240, 236))


def usvi(rnd):
    img, d = new((70, 160, 240), (206, 238, 250))
    sun(d, 220, 22, 9)
    clouds(d, rnd, 4, 14, 36)
    d.polygon([(150, 82), (180, 70), (210, 74), (256, 66), (256, 84)], fill=(130, 180, 170))  # far islands
    # St. Thomas hillside with Charlotte Amalie houses
    d.polygon([(0, 96), (0, 44), (30, 36), (70, 50), (100, 40), (130, 58), (170, 82), (180, 96)], fill=(66, 140, 70))
    d.polygon([(0, 96), (0, 60), (40, 56), (90, 66), (150, 86), (160, 96)], fill=(76, 154, 76))
    for _ in range(60):
        x = rnd.randint(0, 150)
        y = rnd.randint(int(46 + x * 0.25), 92)
        c = rnd.choice([(250, 250, 246), (250, 230, 170), (250, 200, 200), (190, 230, 240), (250, 250, 246)])
        d.rectangle([x, y, x + 4, y + 3], fill=c)
        d.rectangle([x - 1, y - 1, x + 5, y], fill=rnd.choice([(196, 70, 50), (210, 90, 60), (220, 220, 220)]))
    for _ in range(40):
        x, y, r = rnd.randint(0, 150), rnd.randint(50, 92), rnd.randint(2, 4)
        d.ellipse([x - r, y - r, x + r, y + r], fill=rnd.choice([(40, 110, 50), (90, 170, 70)]))
    for _ in range(10):  # flamboyant trees in bloom
        x, y = rnd.randint(4, 140), rnd.randint(60, 90)
        d.ellipse([x - 3, y - 2, x + 3, y + 2], fill=(230, 70, 40))
    sea(img, d, 92, 116, (20, 170, 200), (70, 216, 210), rnd)
    d.rectangle([0, 92, 160, 95], fill=(220, 220, 210))  # waterfront
    # Fort Christian (red Danish fort with clock tower)
    fr, fr_d = (190, 60, 46), (150, 44, 36)
    d.rectangle([20, 76, 70, 94], fill=fr)
    for mx in range(20, 70, 6):
        d.rectangle([mx, 73, mx + 3, 76], fill=fr)
    d.rectangle([38, 58, 50, 76], fill=fr)
    d.rectangle([40, 62, 48, 68], fill=(250, 250, 240))
    d.point((44, 65), fill=(30, 30, 30))
    d.polygon([(36, 58), (44, 50), (52, 58)], fill=(240, 220, 120))
    for wx in range(24, 70, 8):
        d.rectangle([wx, 82, wx + 3, 88], fill=fr_d)
    # cruise ship in the harbour
    d.polygon([(166, 88), (250, 88), (244, 100), (172, 100)], fill=(250, 250, 252))
    d.rectangle([174, 80, 236, 88], fill=(240, 242, 246))
    d.rectangle([184, 74, 226, 80], fill=(232, 234, 240))
    d.rectangle([214, 66, 222, 74], fill=(220, 60, 50))
    d.rectangle([214, 66, 222, 68], fill=(40, 40, 50))
    for row, yy in enumerate((83, 90, 94)):
        for xx in range(176 + row * 2, 240 - row * 2, 4):
            d.point((xx, yy), fill=(40, 90, 150))
    d.line([(172, 99), (244, 99)], fill=(30, 60, 120))
    _usvi_boat(d, 96, 100, (120, 80, 60))
    _usvi_boat(d, 132, 106, (250, 250, 250))
    _usvi_boat(d, 6, 108, (60, 120, 180))
    px, py = 120, 30   # seaplane
    d.ellipse([px - 12, py - 2, px + 10, py + 3], fill=(250, 250, 250))
    d.line([(px - 14, py - 5), (px + 14, py - 5)], fill=(220, 60, 50), width=2)
    d.polygon([(px - 12, py - 2), (px - 16, py - 8), (px - 10, py - 2)], fill=(220, 60, 50))
    d.line([(px - 6, py + 6), (px + 6, py + 6)], fill=(200, 200, 200))
    d.line([(px - 3, py + 3), (px - 3, py + 6)], fill=(200, 200, 200))
    d.line([(px + 3, py + 3), (px + 3, py + 6)], fill=(200, 200, 200))
    for gx, gy in ((150, 44), (160, 40), (90, 20)):
        d.line([(gx - 3, gy), (gx, gy + 2), (gx + 3, gy)], fill=(70, 80, 90))
    # sea turtle and coral heads in the shallows
    d.ellipse([60, 108, 76, 114], fill=(40, 150, 140))
    d.ellipse([64, 109, 72, 113], fill=(90, 120, 70))
    d.ellipse([74, 109, 79, 112], fill=(90, 120, 70))
    for cx in (176, 200, 226):
        d.ellipse([cx, 110, cx + 10, 114], fill=(240, 130, 110))
        d.point((cx + 3, 110), fill=(250, 180, 160))
    palm(d, 250, 116, 70, -14, rnd)
    palm(d, 160, 116, 50, 8, rnd)
    for hx in range(236, 256, 6):  # hibiscus
        shrub(d, hx, 110, 5, rnd)
        d.ellipse([hx - 2, 106, hx + 2, 110], fill=(240, 40, 80))
    ix, iy = 84, 112   # sunbathing iguana
    d.ellipse([ix, iy, ix + 12, iy + 4], fill=(110, 160, 80))
    d.ellipse([ix + 10, iy - 1, ix + 16, iy + 3], fill=(110, 160, 80))
    d.line([(ix, iy + 2), (ix - 10, iy + 3)], fill=(90, 130, 60))
    for k in range(4):
        d.point((ix + 2 + k * 3, iy - 1), fill=(70, 110, 50))
    d.point((ix + 14, iy), fill=(20, 20, 20))
    wall(img, d, "stone", rnd=rnd)
    ground(img, d, rnd, (236, 220, 180), "sand")
    return img


def sloth(d, x, y, body=True, branch=True, look=0, reach=0):
    """A three-toed sloth hanging upside down from a branch at height y.
    The background only paints the branch; the sloth itself is an animated
    sprite (look: head turn, reach: one arm stretching)."""
    fur, fur_d, mask = (160, 128, 92), (112, 86, 60), (236, 222, 190)
    if branch:
        d.line([(x - 34, y + 3), (x + 30, y - 3)], fill=(90, 64, 40), width=4)   # branch
    if not body:
        return
    for k, (lx, dx) in enumerate(((x - 16, 3), (x - 9, 2), (x + 5, -2), (x + 12, -3))):  # four long limbs
        top = y - (3 if (reach and k == 3) else 0)
        ex = lx + dx + (5 if (reach and k == 3) else 0)
        d.line([(lx + (4 if (reach and k == 3) else 0), top), (ex, y + 16)], fill=fur_d, width=4)
        d.line([(lx - 2 + (4 if (reach and k == 3) else 0), top - 2), (lx + 2 + (4 if (reach and k == 3) else 0), top - 2)],
               fill=(50, 36, 24), width=2)  # hooked claws
    d.ellipse([x - 20, y + 10, x + 16, y + 30], fill=fur)                     # body
    d.ellipse([x - 14, y + 13, x + 6, y + 24], fill=(184, 152, 112))
    hx, hy = x + 16 + look, y + 30                                            # head drooping down
    d.ellipse([hx - 11, hy - 9, hx + 11, hy + 9], fill=fur)
    d.ellipse([hx - 9, hy - 7, hx + 9, hy + 7], fill=mask)
    for ex in (hx - 4, hx + 4):                                               # dark eye patches
        d.ellipse([ex - 3, hy - 3, ex + 3, hy + 1], fill=(70, 46, 32))
        d.point((ex + (1 if look else 0), hy - 1), fill=(255, 255, 255))
    d.ellipse([hx - 2, hy + 2, hx + 2, hy + 5], fill=(50, 34, 26))            # nose
    d.arc([hx - 4, hy - 2, hx + 4, hy + 3], 200, 340, fill=(90, 60, 44))      # sleepy smile (upside down)


def _amazon_macaw(d, x, y, body, wing):
    d.ellipse([x - 3, y - 4, x + 3, y + 4], fill=body)
    d.polygon([(x - 1, y + 3), (x + 1, y + 3), (x, y + 14)], fill=wing)
    d.polygon([(x - 3, y), (x - 8, y + 6), (x - 2, y + 4)], fill=wing)
    d.ellipse([x - 2, y - 7, x + 3, y - 2], fill=body)
    d.point((x + 2, y - 5), fill=(255, 255, 255))
    d.point((x + 3, y - 3), fill=(30, 30, 30))


def amazon(rnd):
    img, d = new((170, 210, 200), (220, 234, 214))
    for k in range(14):  # far misty canopy
        blob(d, k * 20 + 4, 54 + (k % 3) * 4, 16, (140, 180, 150), rnd, n=8)
    for k in range(12):
        tree_canopy(d, img, k * 24 - 4, 64 + (k % 2) * 6, 18, rnd, (70, 120, 80), (96, 146, 96), (130, 176, 120))
    # emergent kapok tree on the left
    d.rectangle([20, 18, 30, 92], fill=(130, 110, 90))
    d.line([(24, 18), (24, 92)], fill=(150, 130, 108))
    tree_canopy(d, img, 26, 18, 26, rnd, (30, 80, 36), (56, 116, 50), (100, 164, 70))
    for k in range(10):  # near canopy (top band)
        tree_canopy(d, img, k * 28 - 6, 4 + (k % 3) * 6, 18, rnd, (20, 70, 30), (40, 110, 40), (90, 160, 60))
    for x in (44, 70, 100, 180, 204):  # hanging lianas
        pts = [(x + math.sin(t / 6.0) * 2, t) for t in range(10, 40 + (x % 30), 2)]
        d.line(pts, fill=(60, 96, 40))
        for i in range(0, len(pts), 4):
            px_, py_ = pts[i]
            d.ellipse([px_ - 2, py_ - 1, px_ + 1, py_ + 1], fill=(70, 130, 50))
    # sloth's tree trunk on the right
    d.rectangle([244, 0, 252, 116], fill=(110, 86, 60))
    d.line([(246, 0), (246, 116)], fill=(130, 104, 74))
    d.polygon([(236, 116), (244, 96), (244, 116)], fill=(100, 78, 54))
    tree_canopy(d, img, 240, 22, 18, rnd, (24, 76, 34), (44, 112, 44), (90, 160, 60))
    # brown river with giant lily pads and a pink river dolphin
    sea(img, d, 92, 116, (126, 104, 64), (156, 130, 84), rnd, sparkle=(196, 176, 126))
    for lx, ly in ((10, 100), (34, 106), (232, 108)):
        d.ellipse([lx - 9, ly - 3, lx + 9, ly + 3], fill=(70, 140, 60))
        d.ellipse([lx - 8, ly - 3, lx + 8, ly + 1], fill=(90, 166, 70))
        d.line([(lx, ly - 1), (lx + 8, ly)], fill=(126, 104, 64))
    d.ellipse([230, 104, 236, 108], fill=(250, 220, 236))
    d.arc([202, 98, 224, 110], 200, 340, fill=(236, 150, 170), width=3)
    d.polygon([(210, 98), (214, 94), (216, 99)], fill=(236, 150, 170))
    # shaman's maloca: a big round thatched dome hut
    d.pieslice([90, 44, 196, 140], 180, 360, fill=(170, 130, 70))
    for k in range(9):
        a = math.pi + k * math.pi / 8
        d.line([(143, 92), (143 + math.cos(a) * 53, 92 + math.sin(a) * 48)], fill=(140, 100, 50))
    for yy in range(52, 92, 6):
        d.arc([90 + (92 - yy) * 0.1, yy, 196 - (92 - yy) * 0.1, 92 + (92 - yy)], 190, 350, fill=(196, 156, 90))
    d.rectangle([90, 92, 196, 104], fill=(150, 110, 60))
    for px in range(94, 196, 8):  # painted geometric band
        d.polygon([(px, 96), (px + 4, 99), (px, 102)], fill=(120, 40, 30))
        d.point((px + 5, 99), fill=(240, 230, 200))
    d.rectangle([134, 92, 152, 104], fill=(40, 30, 24))
    d.line([(143, 44), (143, 34)], fill=(110, 80, 40), width=2)
    d.rectangle([88, 104, 198, 106], fill=(110, 80, 50))  # stilt deck
    for sx in range(92, 198, 12):
        d.line([(sx, 106), (sx, 114)], fill=(90, 64, 40))
    # canoe with a paddler
    d.polygon([(20, 108), (70, 108), (64, 113), (26, 113)], fill=(110, 70, 40))
    d.rectangle([42, 100, 46, 108], fill=(200, 60, 50))
    d.ellipse([41, 96, 47, 101], fill=(120, 80, 56))
    d.line([(52, 98), (40, 114)], fill=(150, 110, 70))
    # the sloth (requested), macaws, toucan, morpho butterflies
    sloth(d, 222, 56, body=False)   # the sloth itself is an animated sprite
    _amazon_macaw(d, 34, 50, (220, 40, 40), (40, 90, 200))
    _amazon_macaw(d, 60, 40, (40, 120, 220), (250, 200, 40))
    tx, ty = 82, 56
    d.line([(74, ty + 6), (92, ty + 6)], fill=(90, 64, 40), width=2)
    d.ellipse([tx - 4, ty - 4, tx + 3, ty + 6], fill=(24, 24, 28))
    d.ellipse([tx - 2, ty - 3, tx + 2, ty + 1], fill=(250, 240, 200))
    d.polygon([(tx + 2, ty - 3), (tx + 11, ty - 1), (tx + 2, ty + 1)], fill=(250, 150, 40))
    d.point((tx, ty - 2), fill=(40, 40, 40))
    for bx, by in ((116, 30), (176, 40), (70, 80)):
        d.polygon([(bx, by), (bx - 4, by - 3), (bx - 3, by + 2)], fill=(40, 120, 240))
        d.polygon([(bx, by), (bx + 4, by - 3), (bx + 3, by + 2)], fill=(70, 160, 250))
    # ferns and bromeliads along the bank
    for x in range(0, W, 22):
        grass_clump(d, x + rnd.randint(-3, 3), 116, 7, 5, rnd, (40, 110, 40), (90, 160, 60))
    for bx in (16, 118, 200):
        for k in range(5):
            a = math.pi * (1.1 + k * 0.2)
            d.line([(bx, 116), (bx + math.cos(a) * 8, 116 + math.sin(a) * 8)], fill=(170, 60, 110), width=2)
    wall(img, d, "wood", rnd=rnd)
    ground(img, d, rnd, (90, 130, 60), "dirt")
    return img


def _machu_picchu_ruin(d, x, y, w, h, thatch=False):
    stone, stone_d = (176, 168, 150), (140, 132, 118)
    d.rectangle([x, y, x + w, y + h], fill=stone)
    if thatch:
        d.polygon([(x - 1, y), (x + w // 2, y - h * 0.8), (x + w + 1, y)], fill=(170, 140, 80))
        for k in range(0, w + 1, 2):
            d.line([(x + w // 2, y - h * 0.8), (x + k, y)], fill=(140, 110, 60))
    else:
        d.polygon([(x, y), (x + w // 2, y - h * 0.7), (x + w, y)], fill=stone)
        d.polygon([(x + 3, y), (x + w // 2, y - h * 0.4), (x + w - 3, y)], fill=(120, 160, 96))
    for yy in range(y + 2, y + h, 3):
        d.line([(x, yy), (x + w, yy)], fill=stone_d)
    d.polygon([(x + w // 2 - 2, y + h), (x + w // 2 - 1, y + 2), (x + w // 2 + 1, y + 2), (x + w // 2 + 2, y + h)], fill=(60, 56, 52))


def machu_picchu(rnd):
    """The classic postcard view: Huayna Picchu's steep peak rising behind the
    stone citadel, green terraces stepping down, mist in the valley."""
    img, d = new((96, 150, 216), (220, 230, 238))
    # wispy high clouds
    for (x, y, w) in ((20, 16, 60), (150, 10, 50), (210, 26, 40)):
        d.ellipse([x, y, x + w, y + 6], fill=(240, 244, 248))
        d.ellipse([x + w * 0.3, y - 3, x + w * 0.8, y + 4], fill=(246, 248, 250))
    # hazy distant Andes (two layers) with a snowy summit
    mountains(d, [(-10, 96), (14, 58), (34, 70), (58, 40), (84, 66), (110, 54), (130, 96)], (166, 180, 198),
              snow=(240, 244, 250), snow_frac=0.3)
    mountains(d, [(120, 96), (150, 60), (170, 72), (240, 44), (270, 96)], (160, 176, 194), snow=(240, 244, 250), snow_frac=0.25)
    mountains(d, [(-10, 100), (30, 66), (70, 78), (110, 100)], (128, 150, 150))
    # Huayna Picchu: a steep thumb of rock and forest, lit face and shade face
    peak = [(138, 104), (150, 78), (160, 70), (166, 74), (172, 52), (180, 26), (188, 14), (198, 12), (206, 18),
            (212, 34), (218, 58), (230, 84), (246, 104)]
    d.polygon(peak, fill=(70, 120, 76))
    d.polygon([(198, 12), (206, 18), (212, 34), (218, 58), (230, 84), (246, 104), (204, 104), (200, 40)], fill=(46, 92, 60))
    for k in range(60):   # forest texture streaks
        x = rnd.randint(150, 240)
        y = rnd.randint(20, 100)
        if img.getpixel((x, y)) in ((70, 120, 76), (46, 92, 60)):
            c = (88, 140, 88) if img.getpixel((x, y)) == (70, 120, 76) else (40, 80, 54)
            d.line([(x, y), (x + rnd.choice((-1, 1)), y + rnd.randint(2, 5))], fill=c)
    for k, yy in enumerate(range(18, 40, 4)):   # tiny terraces up at the summit
        d.line([(188 - k, yy), (196 + k // 2, yy)], fill=(150, 146, 124))
    # Machu Picchu mountain shoulder on the left
    d.polygon([(0, 112), (0, 74), (24, 64), (54, 72), (86, 98), (96, 112)], fill=(84, 132, 84))
    # valley mist wrapping the peaks
    for (x, y, w) in ((-10, 84, 70), (40, 90, 80), (120, 86, 60), (200, 92, 70)):
        d.ellipse([x, y, x + w, y + 9], fill=(232, 238, 242))
    # the citadel's saddle and the great green plaza
    d.polygon([(0, 116), (0, 100), (30, 84), (236, 84), (256, 98), (256, 116)], fill=(96, 148, 74))
    for k in range(4):   # terraces under the peak on the right too
        y = 116 - k * 5
        d.line([(200 + k * 6, y), (256, y)], fill=(150, 142, 122))
    d.polygon([(92, 100), (100, 92), (160, 92), (168, 100)], fill=(136, 186, 96))
    # stone rooms: roofless walls in neat grids (lit top edge, dark interior)
    stone, stone_l, shadow = (150, 144, 130), (196, 190, 172), (78, 74, 70)
    def room(x, y, w, h):
        d.rectangle([x, y, x + w, y + h], fill=stone)
        d.rectangle([x + 1, y + 2, x + w - 1, y + h], fill=shadow)
        d.line([(x, y), (x + w, y)], fill=stone_l)
        d.line([(x, y + h), (x + w, y + h)], fill=stone_l)
    for (cx, cy, cols, rows) in ((40, 86, 5, 3), (170, 86, 6, 3), (104, 102, 6, 2), (60, 104, 4, 1), (200, 104, 4, 1)):
        for r in range(rows):
            for c in range(cols):
                room(cx + c * 9, cy + r * 6, 7, 4)
    # two thatched huts (the reconstructed guardhouses)
    for (x, y) in ((86, 84), (228, 82)):
        d.rectangle([x, y, x + 9, y + 6], fill=stone)
        d.polygon([(x - 1, y), (x + 4.5, y - 6), (x + 10, y)], fill=(176, 132, 70))
        d.line([(x + 4.5, y - 6), (x + 10, y)], fill=(130, 96, 50))
    # Temple of the Sun's curved wall
    d.pieslice([140, 100, 154, 114], 180, 360, fill=stone_l)
    d.arc([140, 100, 154, 114], 180, 360, fill=(120, 114, 102))
    # agricultural terraces cascading down the left in gentle curves
    for k in range(8):
        y = 116 - k * 4
        x1 = 70 - k * 4
        d.polygon([(0, y), (0, y - 3), (x1, y - 4), (x1 + 6, y)], fill=lerp((86, 140, 66), (120, 172, 86), k / 7))
        d.line([(0, y), (x1 + 6, y)], fill=(150, 142, 122))
    # (the llama is an animated sprite drawn by the game)
    wall(img, d, "stone", rnd=rnd)
    ground(img, d, rnd, (110, 150, 80), "stone")
    return img


def _tahiti_bungalow(d, x, y, rnd, w=20):
    """Overwater bungalow: thatched hip roof, wooden walls, deck, stilts."""
    for sx in range(x + 1, x + w, 5):
        d.line([(sx, y + 10), (sx, y + 20)], fill=(100, 72, 48))
        d.line([(sx, y + 21), (sx, y + 24)], fill=(70, 150, 170))       # stilt reflection
    d.rectangle([x - 2, y + 8, x + w + 4, y + 10], fill=(170, 120, 76))  # deck
    d.line([(x - 2, y + 8), (x + w + 4, y + 8)], fill=(200, 156, 104))
    d.rectangle([x + 2, y, x + w - 2, y + 8], fill=(196, 150, 100))
    d.rectangle([x + 5, y + 2, x + 9, y + 8], fill=(70, 50, 36))         # door
    d.rectangle([x + 12, y + 2, x + 16, y + 5], fill=(110, 190, 210))    # window
    d.polygon([(x - 2, y + 1), (x + w + 2, y + 1), (x + w // 2 + 3, y - 9), (x + w // 2 - 3, y - 9)], fill=(176, 140, 76))
    for k in range(6):  # thatch texture
        yy = y - 8 + k * 2
        d.line([(x + w // 2 - 3 - k * 2, yy), (x + w // 2 + 3 + k * 2, yy)], fill=rnd.choice([(150, 116, 60), (196, 160, 96)]))
    d.line([(x - 2, y + 1), (x + w + 2, y + 1)], fill=(130, 96, 50))
    d.line([(x + w + 3, y + 10), (x + w + 3, y + 20)], fill=(200, 200, 190))  # ladder into the lagoon
    d.line([(x + w + 5, y + 10), (x + w + 5, y + 20)], fill=(200, 200, 190))
    for ly in range(y + 12, y + 20, 3):
        d.line([(x + w + 3, ly), (x + w + 5, ly)], fill=(200, 200, 190))


def _tahiti_canoe(d, x, y):
    d.polygon([(x, y), (x + 24, y), (x + 20, y + 3), (x + 4, y + 3)], fill=(150, 60, 40))
    d.line([(x + 2, y), (x + 22, y)], fill=(240, 220, 160))
    d.line([(x + 8, y), (x + 8, y - 6)], fill=(110, 80, 50))     # outrigger booms
    d.line([(x + 16, y), (x + 16, y - 6)], fill=(110, 80, 50))
    d.line([(x + 6, y - 6), (x + 20, y - 6)], fill=(200, 180, 140), width=2)
    for px in (x + 6, x + 13):  # paddlers
        d.rectangle([px, y - 5, px + 2, y - 1], fill=(170, 110, 70))
        d.point((px + 1, y - 6), fill=(60, 40, 30))
    d.line([(x + 4, y - 3), (x + 1, y + 4)], fill=(200, 170, 110))


def _tahiti_tiki(d, x, base):
    wood, dk = (130, 90, 56), (80, 54, 34)
    d.rectangle([x - 6, base - 24, x + 6, base], fill=wood)
    d.rectangle([x - 7, base - 27, x + 7, base - 22], fill=dk)        # headdress
    d.rectangle([x - 4, base - 20, x - 1, base - 17], fill=(240, 230, 200))
    d.rectangle([x + 1, base - 20, x + 4, base - 17], fill=(240, 230, 200))
    d.point((x - 2, base - 18), fill=dk)
    d.point((x + 2, base - 18), fill=dk)
    d.line([(x, base - 16), (x, base - 13)], fill=dk)
    d.rectangle([x - 4, base - 12, x + 4, base - 10], fill=dk)        # wide mouth
    d.line([(x - 3, base - 11), (x + 3, base - 11)], fill=(200, 80, 60))
    d.line([(x - 5, base - 6), (x + 5, base - 6)], fill=dk)
    d.line([(x - 6, base - 3), (x + 6, base - 3)], fill=dk)


def _tahiti_flowers(d, cx, cy, r, rnd):
    blob(d, cx, cy, r, (40, 110, 50), rnd, n=8, spread=0.7)
    blob(d, cx - 1, cy - 2, r * 0.7, (70, 150, 60), rnd, n=6)
    for _ in range(int(r)):
        x = cx + rnd.randint(-r, r)
        y = cy + rnd.randint(-r, r) * 0.6
        c = rnd.choice([(230, 40, 60), (250, 120, 60), (250, 250, 240), (240, 80, 150)])
        d.rectangle([x, y, x + 1, y + 1], fill=c)
        d.point((x, y), fill=(255, 230, 120))


def tahiti(rnd):
    img, d = new((60, 150, 236), (214, 242, 250))
    sun(d, 40, 26, 8, (255, 246, 200))
    clouds(d, rnd, 4, 14, 40)
    for _ in range(3):  # frigate birds
        x, y = rnd.randint(70, 200), rnd.randint(18, 36)
        d.line([(x - 3, y - 1), (x - 1, y), (x, y - 1), (x + 1, y), (x + 3, y - 1)], fill=(50, 50, 60))
    # deep ocean at the horizon
    vgrad(d, 0, 80, W, 90, (20, 90, 170), (30, 120, 190))
    # Bora Bora island: Mt Otemanu basalt crown and Mt Pahia
    green, green_d, rock = (44, 116, 64), (30, 86, 50), (62, 84, 70)
    d.polygon([(100, 92), (128, 66), (140, 56), (152, 58), (164, 34), (168, 22), (180, 18), (186, 24),
               (190, 40), (198, 50), (212, 46), (226, 62), (246, 76), (256, 82), (256, 92)], fill=green)
    d.polygon([(164, 34), (168, 22), (180, 18), (186, 24), (190, 40), (184, 52), (172, 54), (166, 46)], fill=rock)  # sheer cliff
    d.polygon([(180, 18), (186, 24), (190, 40), (184, 52), (182, 30)], fill=(44, 62, 54))
    px = img.load()
    for _ in range(500):  # jungle texture: gullies and sunlit canopy, only on the island
        x = rnd.randint(104, 255)
        y = rnd.randint(30, 90)
        if px[x, y] == green:
            if rnd.random() < 0.3:
                for k in range(rnd.randint(2, 6)):
                    if px[x, min(91, y + k)] == green:
                        px[x, min(91, y + k)] = green_d
            else:
                px[x, y] = rnd.choice([(76, 150, 80), (36, 100, 56)])
    # palm fringe along the island shore
    for x in range(104, 256, 7):
        d.line([(x, 92), (x + 1, 86)], fill=(110, 90, 60))
        blob(d, x + 1, 85, 3, (50, 130, 60), rnd, n=3)
    # surf on the reef, then the turquoise lagoon
    vgrad(d, 0, 92, W, 116, (40, 190, 210), (120, 230, 220))
    for x in range(0, W, 3):
        d.point((x, 92 + (x // 3) % 2), fill=(240, 250, 252))
    for _ in range(90):
        x = rnd.randint(0, W - 6)
        y = rnd.randint(94, 115)
        d.line([(x, y), (x + rnd.randint(2, 5), y)], fill=rnd.choice([(230, 250, 252), (80, 200, 214), (150, 236, 226)]))
    for _ in range(12):  # coral heads under the water
        x = rnd.randint(0, W)
        y = rnd.randint(104, 114)
        d.ellipse([x, y, x + 6, y + 2], fill=(60, 170, 190))
    # motu (small islet) on the left horizon
    d.ellipse([0, 86, 60, 94], fill=(236, 220, 170))
    for x in (8, 22, 38, 50):
        d.line([(x, 90), (x + 2, 80)], fill=(120, 96, 60))
        blob(d, x + 2, 79, 4, (50, 130, 60), rnd, n=4)
    # sailboat
    d.polygon([(70, 92), (82, 92), (80, 94), (72, 94)], fill=(250, 250, 250))
    d.line([(76, 92), (76, 76)], fill=(90, 90, 90))
    d.polygon([(77, 77), (77, 91), (84, 91)], fill=(250, 250, 250))
    d.polygon([(75, 79), (75, 91), (69, 91)], fill=(240, 236, 220))
    # overwater bungalows on a boardwalk
    d.line([(0, 104), (36, 104), (36, 98), (100, 98)], fill=(150, 108, 70), width=2)
    for sx in range(4, 100, 8):
        d.line([(sx, 105), (sx, 110)], fill=(100, 72, 48))
    for (bx, by) in ((6, 88), (40, 82), (72, 82), (104, 88)):
        _tahiti_bungalow(d, bx, by, rnd)
    _tahiti_canoe(d, 150, 108)
    # beach behind the bamboo fence (fills the gaps)
    vgrad(d, 0, 116, W, 152, (232, 214, 170), (220, 200, 156))
    # palms, hibiscus, tiki
    palm(d, 236, 128, 84, -18, rnd)
    palm(d, 20, 120, 60, 10, rnd)
    _tahiti_flowers(d, 216, 110, 9, rnd)
    _tahiti_flowers(d, 44, 112, 7, rnd)
    _tahiti_tiki(d, 196, 116)
    wall(img, d, "bamboo", rnd=rnd)
    # flower lei draped across the fence
    lei = [(x, 124 + math.sin(x / 20.0) * 4) for x in range(0, W, 3)]
    for i, (x, y) in enumerate(lei):
        d.rectangle([x, y, x + 1, y + 1], fill=[(240, 60, 80), (250, 250, 240), (250, 170, 60)][i % 3])
    ground(img, d, rnd, (240, 226, 186), "sand")
    for i, (x, y) in enumerate(((30, 160), (90, 156), (150, 162), (210, 158))):  # shells and starfish
        if i % 2 == 0:
            for a in range(5):
                ang = a * math.tau / 5 - math.pi / 2
                d.line([(x, y), (x + math.cos(ang) * 3, y + math.sin(ang) * 3)], fill=(240, 120, 80))
        else:
            d.pieslice([x - 3, y - 2, x + 3, y + 4], 180, 360, fill=(250, 220, 210))
            d.line([(x, y - 2), (x, y + 1)], fill=(220, 180, 170))
    for x in range(0, W, 48):  # beach grass / sea morning glory
        grass_clump(d, x + 12, 167, 6, 5, rnd, (90, 140, 70), (140, 180, 90))
    return img


def _taiwan_101(d, cx):
    """Taipei 101: podium, tapering plinth, 8 flared bamboo-like sections, spire."""
    glass, glass_d, glass_l, frame = (84, 150, 150), (60, 118, 122), (150, 206, 200), (46, 90, 96)
    # podium (mall)
    d.rectangle([cx - 22, 104, cx + 22, 116], fill=(120, 150, 150))
    d.line([(cx - 22, 104), (cx + 22, 104)], fill=(170, 196, 194))
    for x in range(cx - 20, cx + 20, 4):
        d.rectangle([x, 107, x + 2, 114], fill=(70, 100, 110))
    # tapering plinth
    d.polygon([(cx - 14, 104), (cx + 14, 104), (cx + 10, 82), (cx - 10, 82)], fill=glass_d)
    d.polygon([(cx - 14, 104), (cx - 4, 104), (cx - 2, 82), (cx - 10, 82)], fill=glass)
    for y in range(84, 104, 2):
        d.line([(cx - 13 + (104 - y) * 0.18, y), (cx + 13 - (104 - y) * 0.18, y)], fill=frame)
    # ruyi medallions over the plinth
    for sx in (-6, 6):
        d.ellipse([cx + sx - 3, 85, cx + sx + 3, 91], fill=(220, 190, 90))
        d.point((cx + sx, 88), fill=frame)
    # eight stacked flared sections
    y = 82
    for k in range(8):
        h = 7
        d.polygon([(cx - 9, y), (cx + 9, y), (cx + 12, y - h), (cx - 12, y - h)], fill=glass_d)
        d.polygon([(cx - 9, y), (cx - 2, y), (cx - 1, y - h), (cx - 12, y - h)], fill=glass)
        d.line([(cx - 12, y - h), (cx + 12, y - h)], fill=glass_l)
        for yy in range(y - h + 2, y, 2):
            t = (y - yy) / float(h)
            w = 9 + 3 * t
            d.line([(cx - w + 1, yy), (cx + w - 1, yy)], fill=frame)
        d.line([(cx - 12, y - h), (cx - 9, y)], fill=frame)
        d.line([(cx + 12, y - h), (cx + 9, y)], fill=frame)
        y -= h
    # crown, pinnacle and spire
    d.polygon([(cx - 7, y), (cx + 7, y), (cx + 5, y - 6), (cx - 5, y - 6)], fill=glass)
    d.rectangle([cx - 3, y - 12, cx + 3, y - 6], fill=glass_d)
    d.line([(cx - 3, y - 12), (cx + 3, y - 12)], fill=glass_l)
    d.line([(cx, y - 12), (cx, y - 24)], fill=(170, 180, 190), width=2)
    d.point((cx, y - 25), fill=(250, 80, 60))


def _taiwan_temple(img, d, x0, x1, rnd):
    """Longshan-style temple with swallowtail ridges and dragon decorations."""
    red, red_d = (190, 40, 34), (140, 28, 24)
    d.rectangle([x0 + 4, 86, x1 - 4, 116], fill=(220, 190, 140))
    for px in range(x0 + 8, x1 - 4, 10):
        d.rectangle([px, 88, px + 3, 116], fill=red)
        d.line([(px + 1, 90), (px + 1, 114)], fill=(80, 140, 90))    # coiled dragon column hint
    d.rectangle([(x0 + x1) // 2 - 8, 96, (x0 + x1) // 2 + 8, 116], fill=red_d)
    d.line([((x0 + x1) // 2, 96), ((x0 + x1) // 2, 116)], fill=(230, 190, 80))
    for gx in ((x0 + x1) // 2 - 5, (x0 + x1) // 2 + 3):  # door-god panels
        d.rectangle([gx, 100, gx + 2, 110], fill=(230, 190, 80))
    # bracket band of colour
    d.rectangle([x0, 82, x1, 86], fill=(40, 100, 120))
    for x in range(x0, x1, 3):
        d.point((x, 84), fill=rnd.choice([(240, 200, 60), (230, 80, 60), (80, 180, 120)]))
    # roof with swallowtail ridge
    roof = (200, 120, 50)
    d.polygon([(x0 - 6, 82), (x1 + 6, 82), (x1 - 4, 70), (x0 + 4, 70)], fill=roof)
    for x in range(x0 - 4, x1 + 4, 3):
        d.line([(x, 82), (x + (1 if x > (x0 + x1) // 2 else -1), 71)], fill=(170, 96, 40))
    d.rectangle([x0 + 2, 66, x1 - 2, 70], fill=(230, 210, 170))
    for x in range(x0 + 4, x1 - 4, 4):
        d.point((x, 68), fill=rnd.choice([(220, 60, 60), (60, 160, 100), (60, 110, 200), (240, 200, 60)]))
    # swallowtails curling up at both ends
    d.polygon([(x0 + 2, 66), (x0 - 6, 54), (x0 - 2, 58), (x0 + 8, 66)], fill=(230, 210, 170))
    d.polygon([(x1 - 2, 66), (x1 + 6, 54), (x1 + 2, 58), (x1 - 8, 66)], fill=(230, 210, 170))
    # twin dragons facing a pearl on the ridge
    mx = (x0 + x1) // 2
    for s in (-1, 1):
        pts = [(mx + s * (4 + i * 2), 64 - 3 * math.sin(i * 0.9)) for i in range(10)]
        d.line(pts, fill=(60, 160, 100), width=2)
        d.point(pts[-1], fill=(240, 200, 60))
        d.point((mx + s * 4, 62), fill=(240, 60, 40))
    d.ellipse([mx - 2, 58, mx + 2, 62], fill=(250, 220, 80))
    d.polygon([(mx - 2, 58), (mx + 2, 58), (mx, 54)], fill=(250, 140, 60))


def _taiwan_scooter(d, x, y, col):
    d.ellipse([x, y - 4, x + 4, y], fill=(30, 30, 34))
    d.ellipse([x + 10, y - 4, x + 14, y], fill=(30, 30, 34))
    d.polygon([(x + 1, y - 4), (x + 13, y - 4), (x + 12, y - 8), (x + 6, y - 8), (x + 3, y - 6)], fill=col)
    d.line([(x + 12, y - 8), (x + 13, y - 13)], fill=(60, 60, 64))
    d.line([(x + 11, y - 13), (x + 15, y - 13)], fill=(60, 60, 64))
    d.rectangle([x + 4, y - 10, x + 9, y - 8], fill=(40, 34, 30))
    d.point((x + 14, y - 11), fill=(250, 240, 180))


def taiwan(rnd):
    img, d = new((100, 164, 230), (220, 230, 240))
    sun(d, 214, 24, 6)
    clouds(d, rnd, 4, 18, 46)
    # far Yangmingshan ridges, then nearer green hills
    mountains(d, [(0, 116), (0, 70), (40, 56), (90, 72), (150, 50), (200, 66), (256, 58), (256, 116)], (130, 170, 160))
    mountains(d, [(0, 116), (0, 84), (30, 76), (70, 90), (110, 96), (170, 92), (220, 80), (256, 86), (256, 116)], (80, 134, 100))
    # Taipei skyline
    x = 0
    while x < W:
        w = rnd.randint(8, 16)
        top = rnd.randint(78, 98)
        c = rnd.choice([(170, 186, 200), (150, 168, 186), (186, 196, 206)])
        d.rectangle([x, top, x + w - 1, 116], fill=c)
        for wy in range(top + 2, 114, 3):
            for wx in range(x + 2, x + w - 2, 3):
                if rnd.random() < 0.7:
                    d.point((wx, wy), fill=lerp(c, (40, 60, 90), 0.4))
        x += w + rnd.randint(0, 2)
    _taiwan_101(d, 128)
    # Elephant Mountain hiking slope framing the right
    d.polygon([(150, 116), (196, 76), (226, 68), (256, 72), (256, 116)], fill=(60, 110, 70))
    for _ in range(26):
        blob(d, rnd.randint(170, 256), rnd.randint(76, 112), 5, rnd.choice([(50, 96, 60), (80, 134, 76)]), rnd, n=3)
    _taiwan_temple(img, d, 8, 92, rnd)
    # night-market bubble-tea stall
    d.rectangle([176, 92, 240, 116], fill=(244, 236, 220))
    for k, ax in enumerate(range(172, 244, 6)):   # striped awning
        d.polygon([(ax, 86), (ax + 6, 86), (ax + 6, 92), (ax + 3, 94), (ax, 92)],
                  fill=(240, 130, 60) if k % 2 else (250, 240, 220))
    d.rectangle([180, 96, 236, 102], fill=(50, 40, 40))          # menu board (coloured tiles, no text)
    for mx_ in range(182, 234, 6):
        d.rectangle([mx_, 97, mx_ + 3, 101], fill=rnd.choice([(240, 200, 120), (200, 120, 160), (140, 200, 140), (240, 240, 240)]))
    d.rectangle([178, 108, 238, 116], fill=(190, 140, 90))       # counter
    for cxp in range(184, 236, 9):                                # boba cups
        d.polygon([(cxp, 102), (cxp + 5, 102), (cxp + 4, 108), (cxp + 1, 108)], fill=(240, 236, 228))
        d.rectangle([cxp + 1, 104, cxp + 4, 107], fill=rnd.choice([(200, 160, 110), (230, 180, 190), (170, 120, 80)]))
        d.point((cxp + 2, 107), fill=(40, 30, 30))
        d.line([(cxp + 3, 102), (cxp + 4, 99)], fill=(240, 80, 120))
    # parked scooters
    _taiwan_scooter(d, 100, 113, (240, 240, 236))
    _taiwan_scooter(d, 150, 113, (80, 150, 210))
    _taiwan_scooter(d, 162, 113, (220, 60, 60))
    # lantern strings with tassels
    for (x0, y0, x1, y1) in ((0, 22, 104, 34), (152, 34, 256, 22)):
        pts = [(x0 + (x1 - x0) * t / 20.0, y0 + (y1 - y0) * t / 20.0 + math.sin(t / 20.0 * math.pi) * 6) for t in range(21)]
        d.line(pts, fill=(80, 60, 50))
        for i in range(2, 20, 4):
            lx, ly = pts[i]
            d.ellipse([lx - 4, ly, lx + 4, ly + 10], fill=(220, 40, 40))
            d.line([(lx - 3, ly + 5), (lx + 3, ly + 5)], fill=(250, 200, 70))
            d.rectangle([lx - 2, ly - 1, lx + 2, ly], fill=(240, 200, 60))
            d.rectangle([lx - 2, ly + 10, lx + 2, ly + 11], fill=(240, 200, 60))
            d.line([(lx, ly + 12), (lx, ly + 15)], fill=(240, 200, 60))
    wall(img, d, "temple", rnd=rnd)
    # gold "fu" diamond plaques on the wall
    for px in range(28, W, 50):
        d.polygon([(px, 122), (px + 8, 130), (px, 138), (px - 8, 130)], fill=(230, 60, 50))
        d.polygon([(px, 125), (px + 5, 130), (px, 135), (px - 5, 130)], outline=(240, 200, 70))
    ground(img, d, rnd, (120, 150, 90), "concrete")
    for x in (24, 92, 164, 232):  # potted plants on the strip
        d.rectangle([x - 4, 160, x + 4, 167], fill=(150, 90, 60))
        blob(d, x, 156, 5, (60, 120, 60), rnd, n=5)
    return img


def _japan_sakura(d, img, x, y, r, rnd, trunk=True):
    if trunk:
        d.line([(x, y + r), (x - 2, y + r + 18)], fill=(80, 56, 50), width=3)
        d.line([(x, y + r - 2), (x - r * 0.8, y - 2)], fill=(80, 56, 50), width=2)
        d.line([(x, y + r - 2), (x + r * 0.8, y)], fill=(80, 56, 50), width=2)
    blob(d, x, y, r, (226, 150, 176), rnd, n=12, spread=0.8)
    blob(d, x - r * 0.15, y - r * 0.2, r * 0.75, (244, 186, 206), rnd, n=10, spread=0.7)
    blob(d, x - r * 0.3, y - r * 0.4, r * 0.4, (255, 224, 234), rnd, n=6, spread=0.6)
    for _ in range(int(r * 2)):
        d.point((x + rnd.randint(-r, r), y + rnd.randint(-r, r) * 0.8), fill=(255, 240, 246))


def _japan_pagoda(d, cx, base):
    """Chureito-style five-storey pagoda with upturned eaves and sorin spire."""
    red, red_d, white, roof, roof_l = (200, 50, 40), (150, 34, 30), (240, 232, 214), (56, 50, 54), (96, 90, 94)
    d.rectangle([cx - 20, base - 5, cx + 20, base], fill=(170, 164, 150))
    d.line([(cx - 20, base - 5), (cx + 20, base - 5)], fill=(200, 196, 184))
    y = base - 5
    for k in range(5):
        w = 15 - k * 2
        h = 10 if k == 0 else 7
        d.rectangle([cx - w, y - h, cx + w, y], fill=white)
        for px in (cx - w, cx - w // 3, cx + w // 3, cx + w):
            d.rectangle([px - 1, y - h, px, y], fill=red)
        d.rectangle([cx - 2, y - h + 2, cx + 2, y], fill=red_d)
        d.rectangle([cx - w - 2, y - h - 2, cx + w + 2, y - h], fill=red)   # bracket band
        for bx in range(cx - w - 1, cx + w + 2, 3):
            d.point((bx, y - h - 1), fill=(240, 200, 90))
        ey = y - h - 2
        ew = w + 9
        d.polygon([(cx - ew, ey + 1), (cx + ew, ey + 1), (cx + ew - 5, ey - 4), (cx - ew + 5, ey - 4)], fill=roof)
        d.polygon([(cx - ew, ey + 1), (cx - ew - 3, ey - 3), (cx - ew + 4, ey - 1)], fill=roof)   # upturned tips
        d.polygon([(cx + ew, ey + 1), (cx + ew + 3, ey - 3), (cx + ew - 4, ey - 1)], fill=roof)
        d.line([(cx - ew + 5, ey - 4), (cx + ew - 5, ey - 4)], fill=roof_l)
        d.line([(cx - ew, ey + 1), (cx + ew, ey + 1)], fill=(30, 26, 30))
        y = ey - 4
    # sorin spire with nine rings
    d.rectangle([cx - 3, y - 3, cx + 3, y], fill=roof)
    d.line([(cx, y - 3), (cx, y - 22)], fill=(200, 160, 70), width=2)
    for k in range(9):
        d.line([(cx - 2, y - 5 - k * 2), (cx + 2, y - 5 - k * 2)], fill=(230, 196, 100))
    d.ellipse([cx - 2, y - 26, cx + 2, y - 22], fill=(230, 196, 100))


def _japan_torii(d, x0, x1, top, base):
    red, red_d, blk = (220, 64, 40), (170, 44, 30), (36, 32, 34)
    for px in (x0 + 8, x1 - 8):
        d.polygon([(px - 3, top + 4), (px + 3, top + 4), (px + 4, base), (px - 4, base)], fill=red)
        d.line([(px - 3, top + 4), (px - 4, base)], fill=(240, 110, 80))
        d.rectangle([px - 5, base - 6, px + 5, base], fill=blk)      # kamaki base
    # kasagi (curved top beam) with shimaki
    pts_top, pts_bot = [], []
    for i in range(21):
        t = i / 20.0
        x = x0 - 6 + (x1 - x0 + 12) * t
        sag = 4 * (1 - (2 * t - 1) ** 2)
        lift = 4 * abs(2 * t - 1) ** 4
        pts_top.append((x, top - 4 + sag * 0.5 - lift))
        pts_bot.append((x, top + 1 + sag * 0.3 - lift * 0.6))
    d.polygon(pts_top + pts_bot[::-1], fill=blk)
    d.line(pts_bot, fill=red, width=3)
    # nuki (lower crossbeam) and gakuzuka plaque
    d.rectangle([x0 - 2, top + 12, x1 + 2, top + 16], fill=red)
    d.line([(x0 - 2, top + 16), (x1 + 2, top + 16)], fill=red_d)
    mx = (x0 + x1) // 2
    d.rectangle([mx - 2, top + 2, mx + 2, top + 12], fill=red)
    d.rectangle([mx - 5, top + 4, mx + 5, top + 11], fill=blk)
    d.rectangle([mx - 3, top + 5, mx + 3, top + 10], outline=(230, 190, 80))
    d.line([(mx, top + 6), (mx, top + 9)], fill=(230, 190, 80))
    # shimenawa rope with shide
    d.line([(x0 + 10, top + 20), (mx, top + 23), (x1 - 10, top + 20)], fill=(220, 200, 150), width=2)
    for sx in (x0 + 18, mx, x1 - 18):
        d.polygon([(sx - 1, top + 22), (sx + 1, top + 22), (sx + 2, top + 26), (sx, top + 25), (sx - 1, top + 28)], fill=(250, 250, 250))


def _japan_lantern(d, x, base):
    st, st_d = (176, 172, 162), (130, 126, 118)
    d.rectangle([x - 5, base - 3, x + 5, base], fill=st_d)
    d.rectangle([x - 2, base - 14, x + 2, base - 3], fill=st)
    d.rectangle([x - 4, base - 16, x + 4, base - 14], fill=st_d)
    d.rectangle([x - 3, base - 22, x + 3, base - 16], fill=st)
    d.rectangle([x - 1, base - 21, x + 1, base - 18], fill=(250, 220, 140))
    d.polygon([(x - 7, base - 22), (x + 7, base - 22), (x + 2, base - 27), (x - 2, base - 27)], fill=st_d)
    d.ellipse([x - 1, base - 30, x + 1, base - 27], fill=st)


def _japan_house(d, x, base, w, rnd):
    d.rectangle([x, base - 9, x + w, base], fill=(232, 224, 206))
    for px in range(x, x + w + 1, 6):
        d.line([(px, base - 9), (px, base)], fill=(110, 80, 60))
    d.rectangle([x + 2, base - 6, x + 5, base - 2], fill=(90, 80, 70))
    d.polygon([(x - 3, base - 9), (x + w + 3, base - 9), (x + w - 2, base - 15), (x + 2, base - 15)], fill=(70, 74, 86))
    d.line([(x + 2, base - 15), (x + w - 2, base - 15)], fill=(110, 114, 126))


def japan(rnd):
    img, d = new((120, 170, 236), (236, 230, 240))
    clouds(d, rnd, 3, 14, 34, (250, 248, 252))
    # Mount Fuji: broad concave slopes, flat crater top, streaked snow cap
    fx = 112
    body, body_d = (98, 116, 168), (80, 96, 148)
    left = [(fx - 14 - 96 * ((t / 20.0) ** 1.6), 28 + 76 * (t / 20.0)) for t in range(21)]
    right = [(fx + 14 + 100 * ((t / 20.0) ** 1.6), 28 + 76 * (t / 20.0)) for t in range(21)]
    d.polygon(left[::-1] + right + [(W, 116), (0, 116)], fill=body)
    d.polygon([(fx + 2, 30)] + right + [(fx + 40, 104)], fill=body_d)                  # shaded flank
    snow = [(x, y) for (x, y) in left if y <= 58] + [(x, y) for (x, y) in right if y <= 58][::-1]
    d.polygon(snow, fill=(250, 250, 252))
    for k, sx in enumerate(range(fx - 26, fx + 30, 5)):                                  # snow streaks down ridges
        ln = 6 + (k * 7) % 11
        d.polygon([(sx - 2, 57), (sx + 2, 57), (sx, 57 + ln)], fill=(250, 250, 252))
    d.polygon([(fx + 4, 30), (fx + 14, 28), (fx + 32, 52), (fx + 12, 56)], fill=(214, 222, 240))  # shadowed snow
    for cx_ in range(fx - 12, fx + 14, 4):                                               # crater notches
        d.point((cx_, 28), fill=(200, 206, 226))
    # cloud belt around the mountain
    for (cx_, cy_) in ((60, 70), (150, 66), (196, 74)):
        blob(d, cx_, cy_, 9, (244, 244, 250), rnd, n=7, spread=1.2)
    # far forested hills and Lake Kawaguchi
    mountains(d, [(0, 116), (0, 90), (30, 84), (60, 92), (90, 88), (120, 96), (160, 90), (200, 94), (256, 86), (256, 116)], (66, 100, 96))
    vgrad(d, 0, 100, W, 108, (120, 160, 200), (150, 190, 220))
    for _ in range(40):
        x = rnd.randint(0, W - 4)
        y = rnd.randint(100, 107)
        d.line([(x, y), (x + rnd.randint(2, 5), y)], fill=rnd.choice([(230, 240, 250), (100, 140, 184)]))
    d.polygon([(fx - 20, 100), (fx + 20, 100), (fx + 4, 106), (fx - 4, 106)], fill=(200, 214, 236))  # Fuji reflection
    # lakeside village
    for (hx, hw) in ((4, 16), (24, 12), (110, 14), (128, 18), (150, 12)):
        _japan_house(d, hx, 116, hw, rnd)
    # Chureito pagoda among the cherry trees on the right
    _japan_sakura(d, img, 176, 86, 12, rnd)
    _japan_pagoda(d, 214, 116)
    _japan_sakura(d, img, 250, 92, 12, rnd)
    _japan_sakura(d, img, 186, 104, 8, rnd, trunk=False)
    # torii gate and stone lanterns on the left
    _japan_torii(d, 38, 96, 54, 116)
    _japan_lantern(d, 30, 116)
    _japan_lantern(d, 104, 116)
    # framing cherry branch in the top-left corner
    d.line([(0, 6), (26, 14), (48, 12)], fill=(80, 56, 50), width=3)
    d.line([(20, 12), (30, 26)], fill=(80, 56, 50), width=2)
    for (bx, by, r) in ((10, 8, 10), (34, 12, 9), (52, 10, 7), (30, 26, 7)):
        _japan_sakura(d, img, bx, by, r, rnd, trunk=False)
    # paper lanterns strung along the wall top
    vgrad(d, 0, 116, W, 152, (54, 90, 60), (40, 70, 48))          # hedge behind the fence
    for x in range(0, W, 10):
        blob(d, x + rnd.randint(-2, 2), 124 + rnd.randint(0, 20), 6, (66, 110, 66), rnd, n=4)
    wall(img, d, "wood", rnd=rnd)
    for lx in range(14, W, 34):
        d.line([(lx, 116), (lx, 120)], fill=(60, 40, 30))
        d.ellipse([lx - 4, 120, lx + 4, 130], fill=(250, 236, 210))
        d.line([(lx - 4, 125), (lx + 4, 125)], fill=(220, 60, 40))
        d.rectangle([lx - 2, 119, lx + 2, 120], fill=(40, 34, 30))
        d.rectangle([lx - 2, 130, lx + 2, 131], fill=(40, 34, 30))
    ground(img, d, rnd, (110, 150, 90), "stone")
    for x in range(10, W, 36):  # azalea shrubs along the strip
        shrub(d, x, 159, 6, rnd)
        for _ in range(5):
            d.point((x + rnd.randint(-5, 5), 155 + rnd.randint(0, 6)), fill=(240, 120, 170))
    # falling petals everywhere
    for _ in range(70):
        x = rnd.randint(0, W - 2)
        y = rnd.randint(0, 166)
        c = rnd.choice([(255, 200, 220), (255, 226, 236), (240, 170, 196)])
        d.point((x, y), fill=c)
        if rnd.random() < 0.4:
            d.point((x + 1, y), fill=c)
    return img


def _henan_niche(d, x, y, w, h, rnd, rock_d=(104, 92, 80)):
    """Small arched grotto niche with a tiny seated Buddha inside."""
    d.rectangle([x, y + w // 2, x + w, y + h], fill=rock_d)
    d.pieslice([x, y, x + w, y + w], 180, 360, fill=rock_d)
    d.line([(x - 1, y + h + 1), (x + w + 1, y + h + 1)], fill=(196, 182, 156))
    if w >= 5:
        cx = x + w / 2.0
        hr = max(1, w // 5)
        body = (170, 156, 132)
        d.ellipse([cx - hr - 2, y + 1, cx + hr + 2, y + 2 * hr + 5], fill=(134, 120, 104))  # halo
        d.ellipse([cx - hr, y + 2, cx + hr, y + 2 + 2 * hr], fill=body)
        d.polygon([(cx - w * 0.32, y + h), (cx + w * 0.32, y + h), (cx + w * 0.2, y + 3 + 2 * hr), (cx - w * 0.2, y + 3 + 2 * hr)], fill=body)


def _henan_vairocana(img, d, cx, rnd):
    """Fengxian Temple: giant seated Vairocana with flanking figures."""
    stone, stone_l, stone_d = (186, 170, 146), (210, 196, 170), (132, 118, 100)
    recess = (96, 84, 72)
    # the great open niche cut into the cliff
    d.polygon([(cx - 54, 116), (cx - 50, 30), (cx - 38, 18), (cx + 38, 18), (cx + 50, 30), (cx + 54, 116)], fill=recess)
    speckle(img, (cx - 50, 20, cx + 50, 116), [(86, 76, 66), (108, 96, 84)], 0.2, rnd)
    # mandorla / halo with carved flame rings
    for r, c in ((34, (122, 108, 92)), (30, (110, 98, 84)), (24, (132, 118, 100)), (14, (146, 132, 112))):
        d.ellipse([cx - r, 42 - r, cx + r, 42 + r], fill=c)
    for a in range(0, 360, 20):
        ang = math.radians(a)
        d.point((cx + math.cos(ang) * 31, 42 + math.sin(ang) * 31), fill=(160, 144, 120))
        d.point((cx + math.cos(ang) * 27, 42 + math.sin(ang) * 27), fill=(96, 86, 74))
    # lotus pedestal
    d.rectangle([cx - 30, 104, cx + 30, 114], fill=stone_d)
    for k in range(-30, 30, 6):
        d.pieslice([cx + k, 100, cx + k + 6, 108], 180, 360, fill=stone)
        d.line([(cx + k + 3, 101), (cx + k + 3, 106)], fill=stone_d)
    d.line([(cx - 30, 109), (cx + 30, 109)], fill=(110, 98, 84))
    # crossed legs with robe folds
    d.ellipse([cx - 32, 88, cx + 32, 106], fill=stone)
    for k in range(5):
        d.arc([cx - 28 + k * 3, 90 + k, cx + 28 - k * 3, 104 + k], 200, 340, fill=stone_d)
    # torso and robe over both shoulders
    d.polygon([(cx - 24, 96), (cx - 22, 64), (cx - 14, 56), (cx + 14, 56), (cx + 22, 64), (cx + 24, 96)], fill=stone)
    d.polygon([(cx - 22, 64), (cx - 14, 56), (cx - 8, 58), (cx - 18, 96), (cx - 24, 96)], fill=stone_l)  # lit side
    for k in range(4):  # U-shaped robe folds
        d.arc([cx - 16 + k * 2, 52 + k * 7, cx + 16 - k * 2, 72 + k * 7], 20, 160, fill=stone_d)
    # hands resting in the lap (broken forearms, worn stone)
    d.ellipse([cx - 12, 84, cx + 12, 94], fill=stone_l)
    d.line([(cx - 10, 89), (cx + 10, 89)], fill=stone_d)
    # neck with folds
    d.rectangle([cx - 5, 50, cx + 5, 57], fill=stone)
    d.line([(cx - 4, 53), (cx + 4, 53)], fill=stone_d)
    # head: long ears, curls, ushnisha
    d.ellipse([cx - 10, 30, cx + 10, 53], fill=stone)
    d.rectangle([cx - 12, 37, cx - 10, 49], fill=stone_d)   # ears
    d.rectangle([cx + 10, 37, cx + 12, 49], fill=stone_d)
    d.ellipse([cx - 10, 28, cx + 10, 38], fill=(120, 106, 92))  # hair curls
    d.ellipse([cx - 5, 23, cx + 5, 31], fill=(120, 106, 92))    # ushnisha
    for yy in range(25, 37, 2):
        for xx in range(cx - 9, cx + 10, 2):
            if (xx - cx) ** 2 / 100.0 + (yy - 33) ** 2 / 25.0 < 1 or (xx - cx) ** 2 + (yy - 27) ** 2 < 16:
                d.point((xx + (yy // 2) % 2, yy), fill=(100, 90, 78))
    d.line([(cx - 7, 41), (cx - 3, 42)], fill=(96, 84, 72))    # serene downcast eyes
    d.line([(cx + 3, 42), (cx + 7, 41)], fill=(96, 84, 72))
    d.line([(cx - 7, 39), (cx - 3, 39)], fill=stone_d)         # brows
    d.line([(cx + 3, 39), (cx + 7, 39)], fill=stone_d)
    d.line([(cx, 41), (cx, 46)], fill=stone_d)                 # nose
    d.line([(cx - 2, 48), (cx + 2, 48)], fill=(140, 110, 96))  # gentle smile
    d.point((cx - 3, 47), fill=(140, 110, 96))
    d.point((cx + 3, 47), fill=(140, 110, 96))
    d.point((cx, 37), fill=stone_l)                            # urna
    d.line([(cx - 8, 34), (cx - 8, 46)], fill=stone_l)         # lit cheek
    # flanking disciples and bodhisattvas (standing, smaller)
    for side in (-1, 1):
        for off, hgt, crown in ((36, 50, False), (46, 42, True)):
            fx = cx + side * off
            top = 116 - hgt - 8
            d.ellipse([fx - 7, top - 4, fx + 7, top + 10], fill=(118, 104, 90))  # halo
            d.ellipse([fx - 3, top, fx + 3, top + 7], fill=stone)
            if crown:
                d.polygon([(fx - 3, top + 1), (fx, top - 4), (fx + 3, top + 1)], fill=stone_d)
            d.polygon([(fx - 2, top + 7), (fx + 2, top + 7), (fx + 6, top + 11), (fx + 5, 108),
                       (fx - 5, 108), (fx - 6, top + 11)], fill=stone)
            d.line([(fx - 2, top + 22), (fx + 2, top + 22)], fill=stone_l)  # clasped hands
            d.line([(fx - side * 4, top + 8), (fx - side * 6, 108)], fill=stone_l)
            for yy in range(top + 14, 106, 6):
                d.line([(fx - 4, yy), (fx + 4, yy + 2)], fill=stone_d)
            d.rectangle([fx - 6, 108, fx + 6, 112], fill=stone_d)
    # weathering streaks
    for _ in range(14):
        x = cx + rnd.choice([-1, 1]) * rnd.randint(36, 48)
        y = rnd.randint(26, 60)
        d.line([(x, y), (x + rnd.randint(-1, 1), y + rnd.randint(4, 12))], fill=(84, 74, 64))


def _henan_stupa(d, x, base, h, col=(150, 110, 90)):
    """Brick stupa from Shaolin's Pagoda Forest."""
    tiers = max(3, h // 6)
    d.rectangle([x - 4, base - 3, x + 4, base], fill=lerp(col, (0, 0, 0), 0.2))
    for k in range(tiers):
        y = base - 3 - k * (h - 6) / tiers
        w = 3.5 - k * 0.3
        d.rectangle([x - w, y - (h - 6) / tiers + 1, x + w, y], fill=col)
        d.line([(x - w - 1.5, y - (h - 6) / tiers + 1), (x + w + 1.5, y - (h - 6) / tiers + 1)], fill=(80, 70, 66))
    d.line([(x, base - h), (x, base - h + 4)], fill=(200, 170, 80))


def henan(rnd):
    img, d = new((150, 186, 214), (236, 230, 214))
    sun(d, 222, 26, 6, (255, 240, 200))
    # far Song Shan ridges
    mountains(d, [(120, 116), (150, 44), (176, 60), (206, 30), (240, 54), (256, 46), (256, 116)], (160, 176, 176))
    mountains(d, [(130, 116), (160, 70), (190, 84), (226, 58), (256, 76), (256, 116)], (130, 152, 140))
    clouds(d, rnd, 3, 40, 64, (244, 242, 236))
    for _ in range(4):
        x, y = rnd.randint(150, 240), rnd.randint(20, 40)
        d.line([(x - 2, y - 1), (x, y), (x + 2, y - 1)], fill=(80, 80, 90))
    # Longmen cliff (limestone) on the left, with the Yi river at its foot
    rock, rock_l, rock_d = (176, 160, 136), (198, 184, 158), (140, 126, 108)
    d.polygon([(0, 116), (0, 16), (14, 12), (30, 16), (46, 10), (70, 14), (96, 10), (120, 16), (140, 22),
               (152, 34), (160, 60), (166, 116)], fill=rock)
    px = img.load()
    for _ in range(3200):  # rock texture, only on the cliff itself
        x, y = rnd.randint(0, 165), rnd.randint(10, 115)
        if px[x, y] == rock:
            px[x, y] = rnd.choice([rock_l, rock_d, (162, 148, 126)])
    for _ in range(18):  # strata and cracks
        x = rnd.randint(0, 150)
        y = rnd.randint(18, 110)
        d.line([(x, y), (x + rnd.randint(8, 22), y + rnd.randint(-2, 2))], fill=rock_d)
    for _ in range(8):
        x = rnd.randint(0, 150)
        y = rnd.randint(18, 90)
        d.line([(x, y), (x + rnd.randint(-3, 3), y + rnd.randint(6, 16))], fill=(120, 108, 92))
    d.line([(152, 34), (160, 60), (166, 116)], fill=rock_d, width=2)
    # honeycomb of small niches (thousands of Buddhas)
    placed = [(4, 26, 20, 48), (140, 78, 153, 94), (2, 74, 17, 92), (140, 48, 151, 60)]
    for _ in range(400):
        w = rnd.choice([3, 3, 4, 5, 6, 7])
        x = rnd.randint(1, 156)
        y = rnd.randint(20, 104)
        if 30 < x + w + 2 and x - 2 < 140:  # keep the big niche clear
            continue
        if x + w > 150 + (y - 34) * 0.3:  # stay inside the cliff edge
            continue
        if y + w * 1.4 > 114:
            continue
        box = (x - 1, y - 1, x + w + 1, y + int(w * 1.4) + 2)
        if any(box[0] < b[2] and b[0] < box[2] and box[1] < b[3] and b[1] < box[3] for b in placed):
            continue
        placed.append(box)
        _henan_niche(d, x, y, w, int(w * 1.4), rnd)
    for (x, y, w) in ((6, 28, 12), (142, 80, 9), (4, 76, 11), (142, 50, 7)):
        _henan_niche(d, x, y, w, int(w * 1.5), rnd)
    # shrubs clinging to the cliff top and ledges
    for x in range(4, 156, 12):
        blob(d, x, 14 + rnd.randint(-2, 3), 4, (70, 104, 66), rnd, n=4)
        blob(d, x - 1, 12 + rnd.randint(-2, 2), 2, (104, 140, 84), rnd, n=2)
    _henan_vairocana(img, d, 85, rnd)
    # stone stairs climbing to the niche
    for k in range(4):
        d.rectangle([60 - k * 2, 112 + k, 100 + k * 2, 113 + k], fill=(200, 188, 166) if k % 2 == 0 else (170, 158, 138))
    # Shaolin hall on the right: red columns, sweeping grey-tile roof, plaque
    hx0, hx1 = 172, 252
    d.rectangle([hx0, 84, hx1, 116], fill=(176, 44, 36))
    d.rectangle([hx0, 84, hx1, 88], fill=(60, 100, 110))       # painted brackets
    for x in range(hx0 + 2, hx1, 4):
        d.point((x, 86), fill=(220, 180, 70))
    for x in range(hx0 + 4, hx1, 12):
        d.rectangle([x, 88, x + 3, 116], fill=(136, 32, 26))
    for x in range(hx0 + 10, hx1 - 6, 12):                      # lattice windows
        d.rectangle([x, 94, x + 6, 106], fill=(120, 60, 40))
        for yy in range(95, 106, 2):
            d.line([(x + 1, yy), (x + 5, yy)], fill=(200, 150, 90))
    d.rectangle([204, 96, 220, 116], fill=(100, 30, 24))         # door
    for yy in range(99, 115, 3):
        for xx in (207, 211, 215):
            d.point((xx, yy), fill=(230, 190, 80))
    roof, roof_l = (64, 66, 66), (96, 98, 96)
    d.polygon([(hx0 - 12, 84), (hx1 + 12, 84), (hx1 - 4, 70), (hx0 + 4, 70)], fill=roof)
    d.polygon([(hx0 - 12, 84), (hx0 - 18, 76), (hx0 - 6, 82)], fill=roof)
    d.polygon([(hx1 + 12, 84), (hx1 + 18, 76), (hx1 + 6, 82)], fill=roof)
    for x in range(hx0 - 8, hx1 + 8, 3):
        d.line([(x, 84), (x + (2 if x > 212 else -2), 71)], fill=roof_l)
    d.polygon([(hx0 + 8, 70), (hx1 - 8, 70), (hx1 - 16, 60), (hx0 + 16, 60)], fill=(72, 74, 74))
    d.line([(hx0 + 14, 60), (hx1 - 14, 60)], fill=(110, 112, 110), width=2)
    for ex in (hx0 + 12, hx1 - 12):                               # ridge beasts
        d.polygon([(ex - 2, 60), (ex + 2, 60), (ex + (2 if ex > 212 else -2), 54)], fill=(90, 92, 90))
    d.rectangle([200, 72, 224, 80], fill=(30, 34, 50))            # plaque (no text)
    d.rectangle([201, 73, 223, 79], outline=(220, 180, 70))
    for gx in (205, 211, 217):
        d.rectangle([gx, 75, gx + 2, 77], fill=(230, 196, 90))
    # bronze incense burner with smoke, and a bell tower post
    d.rectangle([186, 106, 194, 113], fill=(90, 70, 50))
    d.rectangle([184, 104, 196, 106], fill=(120, 96, 64))
    d.line([(186, 113), (186, 116)], fill=(70, 56, 40))
    d.line([(194, 113), (194, 116)], fill=(70, 56, 40))
    for k in range(8):
        d.point((190 + int(math.sin(k * 0.9) * 2), 102 - k * 2), fill=(220, 220, 220))
    # Pagoda Forest between cliff and hall
    for (sx, sh) in ((158, 22), (166, 16), (176, 12)):
        _henan_stupa(d, sx, 116, sh)
    # old pines and cypresses
    for (x, y, r) in ((168, 54, 10), (250, 50, 9)):
        d.line([(x, y + 8), (x + 2, 116)], fill=(90, 70, 50), width=3)
        tree_canopy(d, img, x, y, r, rnd, (30, 60, 40), (50, 90, 50), (80, 120, 70))
        tree_canopy(d, img, x + 4, y + 14, r - 3, rnd, (30, 60, 40), (50, 90, 50), (80, 120, 70))
    # red lanterns under the eaves
    for lx in (180, 244):
        d.line([(lx, 84), (lx, 88)], fill=(60, 40, 30))
        d.ellipse([lx - 3, 88, lx + 3, 96], fill=(220, 50, 40))
        d.line([(lx, 96), (lx, 99)], fill=(240, 200, 70))
    wall(img, d, "temple", rnd=rnd)
    # monk's staff and practice posts along the ledge face
    for px in (40, 132, 214):
        d.rectangle([px - 6, 124, px + 6, 140], fill=(150, 34, 30))
        d.rectangle([px - 5, 125, px + 5, 139], outline=(220, 180, 70))
    ground(img, d, rnd, (150, 140, 110), "stone")
    for x in (20, 100, 180, 240):  # gingko saplings / tufts on the strip
        grass_clump(d, x, 166, 8, 6, rnd, (100, 120, 70), (150, 170, 90))
    return img


def _paris_eiffel(d, cx=128, top=8, base=116):
    """Eiffel Tower: concave tapered legs, base arch, 3 platforms, lattice."""
    dark, mid, hi = (96, 66, 44), (132, 92, 60), (168, 122, 82)
    p1, p2, p3 = 90, 64, 30          # platform heights

    def ow(y):  # outer half-width (concave curve)
        t = max(0.0, (y - (top + 8)) / float(base - top - 8))
        return 1.5 + 47 * t ** 2.3

    def iw(y):  # inner half-width of the gap between the legs
        if y >= p1:
            # big arch between the legs below platform 1
            t = (y - p1) / float(base - p1)
            return 32 * t ** 0.55 + 2 if t > 0 else 0
        if y >= p2:
            t = (y - p2) / float(p1 - p2)
            return 4 + 8 * t
        return 0

    # lattice body, scanline by scanline
    for y in range(top + 8, base + 1):
        o = ow(y)
        i = iw(y)
        for side in (-1, 1):
            xs = int(round(cx + side * i))
            xe = int(round(cx + side * o))
            lo, hi_ = min(xs, xe), max(xs, xe)
            for x in range(lo, hi_ + 1):
                edge = x <= lo + 1 or x >= hi_ - 1
                k = (x - cx) + y
                q = (x - cx) - y
                if edge or (o - i) < 5:
                    col = dark if (x == lo or x == hi_) else mid
                elif k % 6 == 0 or q % 6 == 0:
                    col = mid
                elif y % 6 == 0:
                    col = dark
                else:
                    continue
                d.point((x, y), fill=col)
        # sunlit highlight on the left outer edge
        d.point((int(round(cx - o)) + 1, y), fill=hi)
    # base arch trim (decorative arc under platform 1)
    pts = []
    for s in range(0, 33):
        t = s / 32.0
        x = cx - 32 + 64 * t
        pts.append((x, p1 + 4 + (1 - math.sin(t * math.pi)) * (base - p1 - 6)))
    d.line(pts, fill=dark, width=2)
    d.line([(px, py + 2) for px, py in pts[4:-4]], fill=hi)
    # platforms
    for py, extra, hgt in ((p1, 4, 5), (p2, 3, 4), (p3, 2, 3)):
        w = ow(py) + extra
        d.rectangle([cx - w, py - hgt, cx + w, py], fill=mid)
        d.line([(cx - w, py - hgt), (cx + w, py - hgt)], fill=hi)
        d.line([(cx - w, py), (cx + w, py)], fill=dark)
        for x in range(int(cx - w) + 1, int(cx + w), 3):  # railing posts / gallery arches
            d.point((x, py - hgt + 2), fill=dark)
        d.line([(cx - w, py - hgt - 1), (cx + w, py - hgt - 1)], fill=dark)
    # top cabin, lantern and antenna
    d.rectangle([cx - 3, top + 4, cx + 3, top + 9], fill=mid)
    d.line([(cx - 3, top + 4), (cx + 3, top + 4)], fill=hi)
    d.rectangle([cx - 2, top + 1, cx + 2, top + 4], fill=dark)
    d.line([(cx, top + 1), (cx, top - 6)], fill=dark)
    d.point((cx, top - 7), fill=(230, 80, 60))
    d.point((cx - 1, top - 2), fill=dark)
    d.point((cx + 1, top - 2), fill=dark)
    # little flag on top
    d.polygon([(cx + 1, top - 6), (cx + 5, top - 5), (cx + 1, top - 4)], fill=(240, 240, 240))
    # foot pillars (masonry piers)
    for side in (-1, 1):
        x0 = cx + side * ow(base)
        x1 = cx + side * (iw(base) - 1)
        lo, hi_ = min(x0, x1), max(x0, x1)
        d.rectangle([lo, base - 3, hi_, base], fill=(150, 140, 124))
        d.line([(lo, base - 3), (hi_, base - 3)], fill=(190, 180, 160))


def _paris_building(img, d, x0, x1, top, rnd, stone=(234, 220, 192), shop=None):
    """Haussmann block: zinc mansard, dormers, chimneys, iron balconies."""
    shade = lerp(stone, (0, 0, 0), 0.18)
    zinc, zinc_d = (110, 122, 140), (80, 90, 108)
    roof_top = top - 12
    # chimney stacks with terracotta pots
    for cxh in range(x0 + 6, x1 - 4, 14):
        h = rnd.randint(5, 8)
        d.rectangle([cxh, roof_top - h, cxh + 6, roof_top + 2], fill=(196, 170, 140))
        d.line([(cxh, roof_top - h), (cxh + 6, roof_top - h)], fill=(150, 120, 96))
        for p in range(cxh + 1, cxh + 6, 2):
            d.rectangle([p, roof_top - h - 3, p, roof_top - h - 1], fill=(190, 96, 60))
    # mansard roof
    d.polygon([(x0, top), (x1, top), (x1 - 4, roof_top), (x0 + 4, roof_top)], fill=zinc)
    for xx in range(x0 + 3, x1 - 2, 3):
        d.line([(xx, top - 1), (xx + (1 if xx > (x0 + x1) // 2 else -1), roof_top + 1)], fill=zinc_d)
    d.line([(x0 + 4, roof_top), (x1 - 4, roof_top)], fill=(150, 160, 176))
    # dormers (oeil-de-boeuf and square)
    for k, wx in enumerate(range(x0 + 6, x1 - 8, 12)):
        d.rectangle([wx, top - 9, wx + 6, top - 1], fill=stone)
        d.polygon([(wx - 1, top - 9), (wx + 7, top - 9), (wx + 3, top - 12)], fill=zinc_d)
        if k % 2:
            d.ellipse([wx + 1, top - 7, wx + 5, top - 3], fill=(60, 74, 96))
        else:
            d.rectangle([wx + 2, top - 7, wx + 4, top - 2], fill=(60, 74, 96))
    # facade
    d.rectangle([x0, top, x1, 116], fill=stone)
    speckle(img, (max(0, x0), top, min(W, x1), 116), [shade, lerp(stone, (255, 255, 255), 0.25)], 0.05, rnd)
    d.rectangle([x0, top, x1, top + 2], fill=lerp(stone, (255, 255, 255), 0.3))  # cornice
    d.line([(x0, top + 3), (x1, top + 3)], fill=shade)
    d.line([(x1, top), (x1, 116)], fill=shade)
    floors = [top + 6, top + 18, top + 30, top + 42]
    floors = [f for f in floors if f + 9 < 98]
    for fi, wy in enumerate(floors):
        for wx in range(x0 + 4, x1 - 5, 9):
            d.rectangle([wx, wy, wx + 5, wy + 9], fill=(70, 88, 116))
            d.line([(wx + 1, wy + 1), (wx + 1, wy + 5)], fill=(130, 150, 176))  # glint
            d.line([(wx + 3, wy), (wx + 3, wy + 9)], fill=(200, 196, 186))      # mullion
            d.rectangle([wx - 1, wy - 2, wx + 6, wy - 1], fill=shade)           # pediment
            if fi == 0 or fi == 2:
                pass
            else:
                # flower box with red geraniums
                d.rectangle([wx, wy + 9, wx + 5, wy + 10], fill=(110, 80, 60))
                for fx in range(wx, wx + 6, 2):
                    d.point((fx, wy + 8), fill=rnd.choice([(220, 40, 50), (240, 80, 90), (60, 120, 50)]))
        # wrought-iron balcony on 2nd floor and top floor (continuous)
        if fi in (0, 2):
            by = wy + 10
            d.line([(x0 + 1, by - 3), (x1 - 1, by - 3)], fill=(30, 30, 34))
            d.line([(x0 + 1, by), (x1 - 1, by)], fill=(30, 30, 34))
            for bx in range(x0 + 2, x1 - 1, 2):
                d.point((bx, by - 2 + (bx // 2) % 2), fill=(40, 40, 44))
            d.line([(x0, by + 1), (x1, by + 1)], fill=shade)
    # ground floor shop front
    d.rectangle([x0, 98, x1, 116], fill=lerp(stone, (0, 0, 0), 0.1))
    d.line([(x0, 98), (x1, 98)], fill=shade)
    if shop:
        name_col, aw_col = shop
        d.rectangle([x0 + 2, 99, x1 - 2, 103], fill=name_col)
        for gx in range(x0 + 5, x1 - 5, 4):  # gold lettering dashes (no words)
            d.line([(gx, 101), (gx + 2, 101)], fill=(236, 200, 110))
        # striped awning
        for k, ax in enumerate(range(x0 + 1, x1 - 1, 5)):
            c = aw_col if k % 2 else (250, 248, 240)
            d.polygon([(ax, 104), (ax + 5, 104), (ax + 6, 109), (ax + 1, 109)], fill=c)
            d.polygon([(ax + 1, 109), (ax + 6, 109), (ax + 3, 111)], fill=c)
        d.rectangle([x0 + 3, 110, x1 - 3, 116], fill=(60, 50, 44))
        for gx in range(x0 + 6, x1 - 6, 10):
            d.rectangle([gx, 111, gx + 6, 116], fill=(220, 180, 110))  # warm interior
    else:
        for gx in range(x0 + 3, x1 - 6, 10):
            d.rectangle([gx, 102, gx + 6, 116], fill=(64, 76, 96))
            d.arc([gx, 99, gx + 6, 105], 180, 360, fill=shade)


def _paris_cafe_table(d, x, y=116):
    d.ellipse([x - 4, y - 9, x + 4, y - 7], fill=(200, 200, 196))
    d.line([(x, y - 7), (x, y - 1)], fill=(60, 60, 60))
    d.line([(x - 2, y), (x + 2, y)], fill=(60, 60, 60))
    for s in (-1, 1):  # bistro chairs
        cxh = x + s * 7
        d.line([(cxh, y - 10), (cxh, y)], fill=(150, 60, 40))
        d.line([(cxh, y - 5), (cxh - s * 3, y - 5)], fill=(150, 60, 40))
        d.line([(cxh - s * 3, y - 5), (cxh - s * 3, y)], fill=(150, 60, 40))
    d.point((x - 1, y - 10), fill=(250, 250, 250))  # little cup
    d.point((x + 1, y - 10), fill=(180, 40, 60))    # wine glass


def _paris_lamp(d, x, base, h):
    d.line([(x, base), (x, base - h)], fill=(30, 40, 36))
    d.rectangle([x - 1, base - 3, x + 1, base], fill=(30, 40, 36))
    d.polygon([(x - 2, base - h - 1), (x + 2, base - h - 1), (x + 1, base - h - 5), (x - 1, base - h - 5)], fill=(250, 230, 160))
    d.line([(x - 2, base - h - 5), (x + 2, base - h - 5)], fill=(30, 40, 36))
    d.point((x, base - h - 6), fill=(30, 40, 36))


def paris(rnd):
    img, d = new((120, 166, 226), (240, 226, 214))
    sun(d, 40, 30, 7, (255, 236, 190))
    clouds(d, rnd, 4, 20, 50, (248, 244, 240))
    for _ in range(5):  # pigeons
        x, y = rnd.randint(60, 200), rnd.randint(18, 44)
        d.line([(x - 2, y - 1), (x, y), (x + 2, y - 1)], fill=(90, 90, 100))
    # far hazy city: rooftops, Sacre-Coeur domes, Invalides dome
    haze, haze_d = (196, 198, 210), (176, 180, 196)
    x = 0
    while x < W:
        w = rnd.randint(10, 22)
        h = rnd.randint(86, 98)
        d.rectangle([x, h, x + w, 116], fill=haze if (x // 7) % 2 else haze_d)
        d.polygon([(x, h), (x + w, h), (x + w - 2, h - 3), (x + 2, h - 3)], fill=haze_d)
        x += w
    for (dx, dy, r) in ((36, 70, 7), (26, 76, 4), (46, 76, 4)):     # Sacre-Coeur on its hill
        d.ellipse([dx - r, dy - r, dx + r, dy + r], fill=(228, 226, 226))
        d.rectangle([dx - r, dy, dx + r, dy + 10], fill=(228, 226, 226))
        d.line([(dx, dy - r), (dx, dy - r - 3)], fill=(210, 208, 210))
    d.polygon([(0, 96), (20, 84), (60, 82), (90, 96)], fill=(160, 176, 160))
    d.ellipse([210, 72, 226, 88], fill=(222, 190, 100))                 # Invalides golden dome
    d.rectangle([208, 80, 228, 98], fill=(206, 204, 206))
    d.line([(218, 72), (218, 64)], fill=(222, 190, 100))
    # Champ de Mars trees behind the tower base
    for tx in range(66, 194, 10):
        tree_canopy(d, img, tx, 112, 5, rnd, (132, 158, 132), (150, 174, 144), (170, 190, 160))
    _paris_eiffel(d, 128, 8, 116)
    # chestnut trees in front of the tower feet
    for tx in (78, 178):
        d.line([(tx, 116), (tx, 106)], fill=(80, 60, 44), width=2)
        tree_canopy(d, img, tx, 102, 7, rnd, (40, 84, 46), (62, 114, 56), (100, 150, 74))
    # Haussmann blocks framing the tower
    _paris_building(img, d, -2, 38, 46, rnd, (236, 222, 194), ((40, 70, 50), (200, 40, 50)))
    _paris_building(img, d, 38, 76, 54, rnd, (226, 210, 182))
    _paris_building(img, d, 182, 220, 52, rnd, (232, 216, 188), ((120, 30, 40), (40, 90, 160)))
    _paris_building(img, d, 220, 258, 44, rnd, (238, 226, 200))
    # cafe terraces and street furniture
    for x in (12, 28, 196, 210):
        _paris_cafe_table(d, x)
    _paris_lamp(d, 88, 116, 18)
    _paris_lamp(d, 168, 116, 18)
    # Morris column (poster kiosk)
    d.rectangle([64, 98, 72, 116], fill=(40, 80, 60))
    d.rectangle([65, 100, 71, 112], fill=(220, 200, 150))
    for py in (102, 106, 109):
        d.line([(66, py), (70, py)], fill=rnd.choice([(200, 60, 60), (60, 80, 160), (40, 40, 40)]))
    d.ellipse([63, 94, 73, 100], fill=(40, 80, 60))
    d.point((68, 93), fill=(40, 80, 60))
    wall(img, d, "stone", rnd=rnd)
    # ivy and flower pots on the ledge wall
    from gen_backgrounds import bougainvillea
    for (ix, iw_) in ((6, 30), (150, 40)):
        bougainvillea(d, img, ix, 120, ix + iw_, 140, rnd, flowers=0)
    for px in (50, 210, 244):
        d.rectangle([px - 4, 108, px + 4, 116], fill=(190, 100, 70))
        d.line([(px - 4, 108), (px + 4, 108)], fill=(220, 140, 100))
        blob(d, px, 106, 4, (60, 120, 50), rnd, n=4)
        for _ in range(4):
            d.point((px + rnd.randint(-4, 4), 103 + rnd.randint(0, 4)), fill=(230, 60, 80))
    ground(img, d, rnd, (110, 150, 90), "cobble")
    for x in range(14, W, 40):  # clipped box hedges along the strip
        shrub(d, x, 158, 6, rnd)
    return img


# order = map order
DESTINATIONS = [
    ("bg_sf", san_francisco),
    ("bg_alaska", alaska),
    ("bg_puertorico", puerto_rico),
    ("bg_hawaii", hawaii),
    ("bg_seattle", seattle),
    ("bg_mexico", mexico),
    ("bg_guatemala", guatemala),
    ("bg_texas", texas),
    ("bg_shasta", mount_shasta),
    ("bg_florida", florida),
    ("bg_usvi", usvi),
    ("bg_amazon", amazon),
    ("bg_machupicchu", machu_picchu),
    ("bg_tahiti", tahiti),
    ("bg_taiwan", taiwan),
    ("bg_japan", japan),
    ("bg_henan", henan),
    ("bg_paris", paris),
]


MAP_W = 512


def cat_planet(seed=26, sky_only=False):
    """The ending: a pastel planet shaped like a cat, covered in a feast, with
    a little golden stupa on a slim red shrine carrying om mani padme hum in
    the middle. Characters stand on the path (feet y 170..188); food fills
    y 104..166. Giant purple mantra letters drift across the sky at runtime
    (see pureland_sky()); sky_only returns just the sky and glow so we can
    tell where those letters may show."""
    rnd = random.Random(seed)
    img, d = new((44, 24, 96), (250, 170, 200), horizon=150)
    for _ in range(70):  # stars
        x, y = rnd.randint(0, W - 1), rnd.randint(0, 80)
        c = rnd.choice([(255, 255, 255), (255, 240, 180), (200, 220, 255)])
        d.point((x, y), fill=c)
        if rnd.random() < 0.15:
            d.line([(x - 1, y), (x + 1, y)], fill=c)
            d.line([(x, y - 1), (x, y + 1)], fill=c)
    if not sky_only:   # planets and clouds sit in front of the drifting letters
        # little Earth far away, and a ringed planet
        d.ellipse([214, 10, 236, 32], fill=(60, 120, 220))
        for pts in ([(218, 16), (226, 13), (228, 22), (220, 26)], [(229, 24), (234, 22), (233, 29)]):
            d.polygon(pts, fill=(80, 180, 90))
        d.ellipse([22, 26, 46, 50], fill=(250, 200, 120))
        d.arc([12, 33, 56, 43], 160, 380, fill=(255, 236, 190), width=2)
        # fish-shaped clouds
        for cx, cy in ((90, 30), (160, 50)):
            d.ellipse([cx - 14, cy - 5, cx + 8, cy + 5], fill=(255, 220, 236))
            d.polygon([(cx + 6, cy), (cx + 16, cy - 6), (cx + 16, cy + 6)], fill=(255, 220, 236))
            d.point((cx - 9, cy - 1), fill=(150, 90, 140))
    if not sky_only:
        # cat-ear mountains along the horizon
        for x, r, col in ((26, 26, (196, 130, 200)), (78, 18, (170, 120, 196)), (186, 20, (170, 120, 196)),
                          (234, 28, (196, 130, 200))):
            top = 116 - r
            for side in (-1, 1):
                ex = x + side * r * 0.55
                d.polygon([(ex - r * 0.4, top + 8), (ex + side * r * 0.12, top - r * 0.55), (ex + r * 0.4, top + 8)],
                          fill=col)
                d.polygon([(ex - r * 0.2, top + 6), (ex + side * r * 0.08, top - r * 0.3), (ex + r * 0.2, top + 6)],
                          fill=(255, 176, 210))
            d.ellipse([x - r, top, x + r, top + 2 * r], fill=col)
    # the shrine in the middle: soft glow, golden stupa on a slim red shrine
    for r, col in ((54, (92, 60, 140)), (40, (130, 84, 160)), (28, (176, 116, 176))):
        d.ellipse([128 - r, 46 - r, 128 + r, 46 + r], fill=col)
    if sky_only:
        return img
    d.polygon([(121, 60), (128, 20), (135, 60)], fill=(230, 176, 60))
    for k, yy in enumerate(range(28, 58, 6)):
        d.line([(128 - 2 - k, yy), (128 + 2 + k, yy)], fill=(196, 140, 40))
    d.ellipse([124, 14, 132, 22], fill=(255, 220, 110))
    x0, x1, y0 = 80, 176, 64
    d.polygon([(x0 - 4, y0), (x1 + 4, y0), (x1, y0 - 6), (x0, y0 - 6)], fill=(70, 80, 70))
    for x in range(x0, x1, 5):
        d.line([(x, y0 - 5), (x + 2, y0)], fill=(96, 108, 96))
    d.rectangle([x0, y0, x1, 110], fill=(168, 36, 34))
    d.rectangle([x0, y0, x1, y0 + 2], fill=(226, 172, 60))
    d.rectangle([x0, 101, x1, 103], fill=(226, 172, 60))
    # om mani padme hum, one syllable at a time with a little breathing room
    # and a slightly uneven baseline, like hand-painted letters. Two shades
    # of gold only, so the strokes never blend into muddy reds.
    syllables = ["\u0f68\u0f7c\u0f7e\u0f0b", "\u0f58\u0f0b", "\u0f4e\u0f72\u0f0b", "\u0f54\u0f51\u0fa8\u0f7a\u0f0b",
                 "\u0f67\u0f71\u0f74\u0f83"]
    font = ImageFont.truetype(FONT_DIR + "Kailasa.ttc", 17, layout_engine=ImageFont.Layout.RAQM)
    m = Image.new("L", (W, H), 0)
    md = ImageDraw.Draw(m)
    widths = [md.textlength(sy, font=font) for sy in syllables]
    gap = 4
    sx = 128 - (sum(widths) + gap * (len(syllables) - 1)) / 2
    for k, (sy, sw) in enumerate(zip(syllables, widths)):
        md.text((sx, 70 + (0, 1, -1, 1, 0)[k]), sy, font=font, fill=255)
        sx += sw + gap
    bb = m.getbbox()                       # centre the block between the gold trims
    m = ImageChops.offset(m, 0, int((y0 + 3 + 100) / 2 - (bb[1] + bb[3]) / 2))
    img.paste((206, 136, 40), (0, 0), m.point(lambda v: 255 if v > 50 else 0))
    img.paste((255, 214, 90), (0, 0), m.point(lambda v: 255 if v > 150 else 0))
    # the curved planet surface
    d.ellipse([-120, 104, W + 120, 520], fill=(170, 226, 190))
    d.ellipse([-120, 110, W + 120, 520], fill=(150, 214, 176))
    for px, py in ((24, 132), (230, 136), (112, 158)):  # paw-print craters
        d.ellipse([px - 6, py - 3, px + 6, py + 5], fill=(124, 190, 152))
        for k in (-6, -2, 2, 6):
            d.ellipse([px + k - 2, py - 8 - (k in (-2, 2)) * 2, px + k + 2, py - 5 - (k in (-2, 2)) * 2],
                      fill=(124, 190, 152))
    # a few lotus flowers by the mantra wall and in the grass
    def lotus(x, y, big=False):
        k = 1 if big else 0
        d.ellipse([x - 8 - k, y + 1, x + 8 + k, y + 5], fill=(90, 170, 110))      # leaf pad
        d.ellipse([x - 9 - k, y - 4, x - 1, y + 3], fill=(236, 140, 180))        # side petals
        d.ellipse([x + 1, y - 4, x + 9 + k, y + 3], fill=(236, 140, 180))
        d.polygon([(x - 4, y + 2), (x, y - 7 - k), (x + 4, y + 2)], fill=(250, 186, 212))   # centre petal
        d.line([(x, y - 5 - k), (x, y + 1)], fill=(255, 220, 232))
        d.point((x, y + 2), fill=(255, 214, 90))
    for x in (84, 172):
        lotus(x, 110)
    lotus(176, 158, True)
    ground(img, d, rnd, (150, 214, 176), "sand", y0=166)


    # ---- the feast ----
    # giant tuna can
    d.rectangle([4, 120, 44, 150], fill=(196, 200, 210))
    d.rectangle([4, 128, 44, 142], fill=(60, 110, 200))
    d.ellipse([4, 115, 44, 125], fill=(220, 224, 232))
    d.ellipse([8, 117, 40, 123], fill=(240, 150, 150))
    lbl = ImageFont.truetype(FONT_DIR + "Arial Bold.ttf", 9)
    d.text((10, 129), "TUNA", font=lbl, fill=(255, 255, 255))
    # croissant (Paris)
    for k in range(5):
        a = math.pi * (0.15 + k * 0.175)
        x, y = 66 - math.cos(a) * 14, 150 - math.sin(a) * 8
        d.ellipse([x - 7, y - 6, x + 7, y + 6], fill=(214, 150, 70) if k % 2 else (236, 176, 90))
    # bao steamer (Henan / Taiwan)
    d.rectangle([84, 140, 112, 152], fill=(190, 150, 90))
    for x in range(86, 112, 6):
        d.line([(x, 140), (x, 152)], fill=(160, 120, 70))
    for x in (90, 104):
        d.ellipse([x - 7, 130, x + 7, 142], fill=(250, 246, 236))
        d.point((x, 132), fill=(200, 190, 170))
    # tower cake with a strawberry
    d.rectangle([116, 112, 140, 124], fill=(250, 200, 220))
    d.rectangle([112, 124, 144, 138], fill=(255, 236, 240))
    d.rectangle([108, 138, 148, 152], fill=(250, 200, 220))
    for y in (124, 138, 152):
        d.line([(108 if y > 124 else 112, y), (148 if y > 124 else 144, y)], fill=(230, 120, 160), width=2)
    d.ellipse([123, 103, 133, 113], fill=(230, 40, 60))
    d.point((126, 106), fill=(255, 220, 120))
    # sushi plate (Japan)
    d.ellipse([150, 144, 190, 154], fill=(240, 240, 246))
    for x, top in ((158, (250, 120, 90)), (170, (250, 160, 120)), (182, (240, 240, 240))):
        d.rectangle([x - 5, 140, x + 5, 147], fill=(255, 255, 250))
        d.rectangle([x - 6, 136, x + 6, 141], fill=top)
        if x == 182:  # tamago with a nori belt
            d.rectangle([x - 1, 136, x + 1, 147], fill=(30, 40, 30))
    # boba tea (Taiwan)
    d.polygon([(198, 116), (216, 116), (213, 150), (201, 150)], fill=(220, 176, 130))
    d.ellipse([197, 112, 217, 120], fill=(255, 255, 255))
    d.line([(210, 102), (207, 118)], fill=(230, 60, 90), width=2)
    for x, y in ((203, 144), (207, 146), (211, 143), (205, 140), (209, 140)):
        d.ellipse([x - 2, y - 2, x + 2, y + 2], fill=(50, 30, 30))
    # ice cream cone
    d.polygon([(226, 128), (244, 128), (235, 154)], fill=(214, 160, 90))
    d.line([(229, 133), (241, 133)], fill=(180, 120, 60))
    d.ellipse([224, 116, 246, 132], fill=(180, 230, 210))
    d.ellipse([228, 106, 242, 120], fill=(255, 190, 210))
    # a fish on a plate, for the classics
    d.ellipse([46, 158, 80, 166], fill=(240, 240, 246))
    d.ellipse([50, 155, 70, 163], fill=(120, 170, 220))
    d.polygon([(68, 159), (76, 154), (76, 164)], fill=(120, 170, 220))
    d.point((54, 158), fill=(20, 20, 30))
    return img


def world_map(seed=4):
    """Super-Mario-World-style travel map, two screens wide (512x192):
    green land on tall tan cliffs, cream paths, hills with eyes."""
    rnd = random.Random(seed)
    img = Image.new("RGB", (MAP_W, H), (80, 140, 210))
    d = ImageDraw.Draw(img)
    for _ in range(500):  # little wave dashes
        x = rnd.randint(0, MAP_W - 4)
        y = rnd.randint(0, H - 1)
        d.line([(x, y), (x + 2, y)], fill=(110, 166, 226))

    green, green_d, green_l = (88, 184, 72), (52, 140, 56), (150, 220, 110)
    cliff, cliff_d = (214, 160, 96), (168, 112, 60)

    def land(pts, top=green, depth=7):
        sh = [(x, y + depth) for x, y in pts]
        d.polygon(sh, fill=cliff_d)
        d.polygon([(x, y + depth - 2) for x, y in pts], fill=cliff)
        for k in range(len(pts)):  # cliff stripes
            x, y = pts[k]
            d.line([(x, y + 1), (x, y + depth)], fill=cliff_d)
        d.polygon(pts, fill=top)
        d.line(pts + [pts[0]], fill=(30, 70, 40))

    # North America (with Alaska and Florida), Central America
    land([(30, 26), (70, 12), (130, 10), (190, 14), (232, 28), (236, 52), (222, 78), (214, 88), (220, 106),
          (212, 110), (200, 96), (182, 102), (176, 116), (196, 132), (200, 146), (186, 150), (164, 140),
          (140, 124), (120, 108), (96, 96), (84, 78), (90, 60), (70, 44), (44, 44)])
    # South America
    land([(204, 148), (236, 146), (272, 158), (276, 172), (262, 190), (220, 192), (200, 178), (196, 160)])
    # Eurasia
    land([(300, 26), (360, 14), (430, 12), (462, 20), (468, 44), (458, 70), (440, 86), (426, 98),
          (408, 92), (380, 84), (350, 74), (322, 66), (304, 50)])
    # islands: Hawaii, Tahiti, Caribbean, Japan, Taiwan
    for pts in ([(22, 104), (34, 100), (40, 108), (30, 114)],
                [(32, 160), (46, 158), (50, 166), (38, 170)],
                [(232, 114), (246, 112), (248, 120), (234, 122)],
                [(252, 120), (262, 118), (264, 126), (254, 128)],
                [(482, 34), (494, 28), (505, 42), (502, 64), (492, 84), (482, 78), (487, 58)],   # Japan
                [(444, 106), (454, 103), (457, 118), (447, 122)]):                                 # Taiwan
        land(pts, depth=4)

    # snowy Alaska and the north, tan deserts in the southwest / Mexico
    d.polygon([(34, 28), (70, 14), (110, 14), (96, 34), (60, 40)], fill=(240, 246, 250))
    d.polygon([(140, 96), (176, 92), (186, 112), (170, 126), (146, 114)], fill=(236, 214, 150))
    d.polygon([(360, 18), (430, 16), (420, 30), (370, 32)], fill=(240, 246, 250))

    def hill(x, y, h):  # the famous round hills with little eyes
        d.rounded_rectangle([x - 5, y - h, x + 5, y], radius=5, fill=green_d, outline=(30, 70, 40))
        d.line([(x - 3, y - h + 3), (x - 3, y - h + 6)], fill=green_l)
        d.point((x - 1, y - h + 4), fill=(20, 30, 20))
        d.point((x + 2, y - h + 4), fill=(20, 30, 20))

    def tree(x, y):
        d.ellipse([x - 4, y - 7, x + 4, y + 1], fill=green_d, outline=(30, 70, 40))
        d.point((x - 1, y - 5), fill=green_l)

    def mountain(x, y, w, h, snow=False):
        d.polygon([(x - w, y), (x, y - h), (x + w, y)], fill=(176, 140, 96), outline=(110, 80, 50))
        if snow:
            d.polygon([(x - w * 0.35, y - h * 0.65), (x, y - h), (x + w * 0.35, y - h * 0.65)], fill=(250, 250, 250))

    for (x, y) in ((126, 40), (150, 30), (176, 44), (200, 58), (316, 44), (356, 46), (402, 40), (446, 32)):
        hill(x, y, 12)
    for (x, y) in ((140, 60), (186, 70), (226, 166), (244, 176), (380, 56), (430, 76), (446, 50), (340, 60)):
        tree(x, y)
        tree(x + 7, y + 3)
    for (x, y, w, h, sn) in ((80, 70, 8, 14, True), (126, 78, 6, 10, True), (214, 186, 7, 12, True),
                             (400, 76, 8, 14, False), (494, 72, 5, 10, True), (150, 108, 5, 7, False)):
        mountain(x, y, w, h, sn)
    # clouds
    for (x, y) in ((14, 12), (260, 70), (300, 150), (380, 140), (480, 150)):
        d.ellipse([x, y, x + 20, y + 7], fill=(250, 250, 252))
        d.ellipse([x + 8, y - 4, x + 26, y + 5], fill=(250, 250, 252))

    # paths between destinations (land roads are cream, sea routes dotted)
    road = (246, 226, 160)
    def path(a, b, sea=False):
        (x0, y0), (x1, y1) = MAP_PINS[a], MAP_PINS[b]
        n = max(abs(x1 - x0), abs(y1 - y0)) // (6 if sea else 1) + 1
        for k in range(n + 1):
            x = x0 + (x1 - x0) * k / n
            y = y0 + (y1 - y0) * k / n
            if sea:
                d.ellipse([x - 1, y - 1, x + 1, y + 1], fill=(250, 250, 250))
            else:
                d.rectangle([x - 1, y - 1, x + 1, y + 1], fill=road)
    for a, b in ((18, 0), (0, 8), (8, 4), (4, 1), (0, 7), (7, 9), (7, 5), (5, 6), (6, 12), (12, 11), (17, 16)):
        path(a, b)
    for a, b in ((0, 3), (3, 13), (9, 2), (2, 10), (10, 11), (9, 17), (16, 14), (14, 15)):
        path(a, b, sea=True)
    for (x, y) in MAP_PINS:  # level dots
        d.ellipse([x - 3, y - 2, x + 3, y + 2], fill=(200, 50, 50), outline=(110, 20, 20))
    return img


# pin positions on the map, same order as DESTINATIONS, plus HOME last
MAP_PINS = [
    (98, 86),   # San Francisco
    (52, 30),   # Alaska
    (240, 116), # Puerto Rico
    (31, 107),  # Hawaii
    (104, 52),  # Seattle
    (160, 118), # Mexico
    (186, 138), # Guatemala
    (164, 86),  # Texas
    (110, 68),  # Mt Shasta
    (212, 100), # Florida
    (258, 122), # USVI
    (240, 158), # Amazon
    (214, 176), # Machu Picchu
    (41, 164),  # Tahiti
    (450, 113), # Taiwan (island off the coast)
    (494, 50),  # Japan (island across the sea)
    (412, 62),  # Henan (inland China)
    (330, 46),  # Paris
    (112, 96),  # Home (the balcony)
]


PURE_SKY_W, PURE_SKY_H = 360, 104   # the drifting sky mantra: a looping strip


def pureland_sky():
    """Layers for the giant purple mantra drifting across the Pureland sky.
    Returns (letters, allowed): letters is a looping PURE_SKY_W x PURE_SKY_H
    1-bit strip of the five syllables; allowed marks the screen pixels
    (top PURE_SKY_H rows) where only sky or glow shows, so the letters pass
    behind the mountains, the stupa and the shrine."""
    syllables = ["\u0f68\u0f7c\u0f7e", "\u0f58", "\u0f4e\u0f72", "\u0f54\u0f51\u0fa8\u0f7a", "\u0f67\u0f71\u0f74\u0f83"]
    # different sizes and heights so it doesn't feel stiff; HUM is the biggest
    sizes = (52, 46, 62, 48, 86)
    centres = (44, 60, 34, 62, 52)
    letters = Image.new("L", (PURE_SKY_W, PURE_SKY_H), 0)
    md = ImageDraw.Draw(letters)
    fonts = [ImageFont.truetype(FONT_DIR + "Kailasa.ttc", sz, layout_engine=ImageFont.Layout.RAQM) for sz in sizes]
    boxes = [md.textbbox((0, 0), sy, font=f) for sy, f in zip(syllables, fonts)]
    widths = [b[2] - b[0] for b in boxes]
    gap = (PURE_SKY_W - sum(widths)) / len(syllables)
    x = gap / 2
    for sy, f, (l, t, r, b), w, cy in zip(syllables, fonts, boxes, widths, centres):
        for wrap in (0, -PURE_SKY_W, PURE_SKY_W):     # seamless loop
            md.text((x + wrap - l, cy - (t + b) / 2), sy, font=f, fill=255)
        x += w + gap
    letters = letters.point(lambda v: 255 if v > 90 else 0)
    full = cat_planet().convert("RGB").load()
    sky = cat_planet(sky_only=True).convert("RGB").load()
    allowed = Image.new("L", (W, PURE_SKY_H), 0)
    ap = allowed.load()
    for y in range(PURE_SKY_H):
        for x in range(W):
            if full[x, y] == sky[x, y]:
                ap[x, y] = 255
    return letters, allowed


# --------------------------------------------------------------------------
# Small animated critters drawn over the backgrounds by the game
# --------------------------------------------------------------------------

REVEILLE_ORIGIN = (178, 98)  # Reveille's canvas on the Texas background
SLOTH_ORIGIN = (186, 46)     # where the sloth sprite sits on the Amazon background
LLAMA_ORIGIN = (204, 76)     # where the llama sprite's canvas starts on Machu Picchu


def sloth_frames():
    """0: hanging still, 1: head turned, 2: stretching an arm."""
    out = []
    for look, reach in ((0, 0), (2, 0), (0, 1)):
        im = Image.new("RGBA", (72, 52), (0, 0, 0, 0))
        sloth(ImageDraw.Draw(im), 222 - SLOTH_ORIGIN[0], 56 - SLOTH_ORIGIN[1], branch=False, look=look, reach=reach)
        out.append(im)
    return out


def reveille_frames():
    """Reveille, the Texas A&M collie, lying on the lawn in her maroon blanket
    (faces right). 0: head up, 1: tail wag, 2: ear twitch, 3: napping."""
    coat, white, dark, maroon = (170, 110, 60), (246, 240, 228), (120, 76, 40), (128, 0, 32)
    out = []
    for pose in ("up", "wag", "ear", "nap"):
        im = Image.new("RGBA", (36, 18), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        rx, ry = 196 - REVEILLE_ORIGIN[0], 110 - REVEILLE_ORIGIN[1]
        tail_y = ry - 5 if pose == "wag" else ry - 1                  # tail swish
        d.line([(rx - 10, ry + 1), (rx - 15, tail_y)], fill=coat, width=2)
        d.point((rx - 16, tail_y), fill=white)
        d.ellipse([rx - 10, ry - 4, rx + 6, ry + 4], fill=coat)      # body
        d.ellipse([rx - 4, ry - 3, rx + 4, ry + 3], fill=maroon)     # blanket
        hy = ry + 2 if pose == "nap" else ry                         # head rests on the paws
        d.ellipse([rx + 3, hy - 2, rx + 8, hy + 4], fill=white)      # white ruff
        d.ellipse([rx + 4, hy - 6, rx + 11, hy + 1], fill=coat)      # head
        d.polygon([(rx + 9, hy - 3), (rx + 15, hy - 1), (rx + 9, hy + 1)], fill=white)   # long snout
        ear_top = hy - 8 if pose == "ear" else hy - 9
        d.polygon([(rx + 5, hy - 6), (rx + 6, ear_top), (rx + 8, hy - 6)], fill=dark)
        if pose == "nap":
            d.line([(rx + 9, hy - 3), (rx + 10, hy - 3)], fill=(30, 20, 20))   # closed eye
        else:
            d.point((rx + 10, hy - 3), fill=(30, 20, 20))
        d.rectangle([rx + 7, ry + 3, rx + 13, ry + 4], fill=white)   # front paws
        out.append(im)
    return out


def llama_frames():
    """0: standing, 1: grazing (head down), 2-3: walking."""
    wool, leg, saddle = (244, 240, 230), (220, 214, 200), (214, 60, 60)
    out = []
    for pose in ("stand", "graze", "walk0", "walk1"):
        im = Image.new("RGBA", (32, 40), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        bx, by = 8, 24                                      # body
        d.ellipse([bx, by, bx + 14, by + 8], fill=wool)
        d.rectangle([bx + 3, by + 1, bx + 7, by + 4], fill=saddle)   # little woven blanket
        legs = ((bx + 1, 0), (bx + 4, 0), (bx + 8, 0), (bx + 11, 0))
        if pose == "walk0":
            legs = ((bx, 1), (bx + 4, -1), (bx + 7, 1), (bx + 12, -1))
        if pose == "walk1":
            legs = ((bx + 2, -1), (bx + 4, 1), (bx + 9, -1), (bx + 11, 1))
        for lx, dx in legs:
            d.line([(lx, by + 7), (lx + dx, by + 13)], fill=leg, width=1)
        if pose == "graze":                                 # neck down to the grass
            d.polygon([(bx + 12, by + 2), (bx + 15, by + 2), (bx + 19, by + 11), (bx + 16, by + 12)], fill=wool)
            d.ellipse([bx + 15, by + 10, bx + 22, by + 14], fill=wool)
            d.point((bx + 20, by + 11), fill=(30, 30, 30))
        else:                                               # neck up, ears perked
            d.rectangle([bx + 12, by - 12, bx + 15, by + 2], fill=wool)
            d.ellipse([bx + 10, by - 16, bx + 19, by - 10], fill=wool)
            d.polygon([(bx + 11, by - 16), (bx + 12, by - 20), (bx + 13, by - 16)], fill=wool)
            d.polygon([(bx + 16, by - 16), (bx + 17, by - 20), (bx + 18, by - 16)], fill=wool)
            d.point((bx + 17, by - 14), fill=(30, 30, 30))
        d.line([(bx - 1, by + 2), (bx, by + 5)], fill=wool, width=2)   # tail tuft
        out.append(im)
    return out


def squirrel_frames():
    """A little grey-brown squirrel for the balcony fence (faces right).
    0-1: running, 2: sitting, 3: sitting with a tail flick."""
    fur, belly, dark, tail = (150, 110, 80), (226, 204, 170), (60, 40, 30), (168, 126, 90)
    out = []
    for pose in ("run0", "run1", "sit", "flick"):
        im = Image.new("RGBA", (22, 18), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        if pose.startswith("run"):
            stretch = pose == "run1"
            d.ellipse([5, 9, 15, 15], fill=fur)                       # long body
            d.ellipse([13, 7, 19, 13], fill=fur)                      # head
            d.polygon([(14, 8), (15, 4), (16, 8)], fill=fur)          # ear
            d.point((17, 9), fill=dark)
            d.line([(7, 15), (5 if stretch else 8, 17)], fill=dark)   # legs
            d.line([(14, 15), (17 if stretch else 13, 17)], fill=dark)
            d.ellipse([0, 4 if stretch else 6, 7, 12 if stretch else 13], fill=tail)   # tail streaming
        else:
            d.ellipse([7, 6, 14, 16], fill=fur)                       # upright body
            d.ellipse([9, 9, 13, 15], fill=belly)
            d.ellipse([10, 1, 17, 8], fill=fur)                       # head
            d.polygon([(11, 2), (12, -1), (13, 2)], fill=fur)
            d.point((15, 4), fill=dark)
            d.point((14, 10), fill=dark)                              # little paws holding a nut
            d.ellipse([13, 9, 16, 12], fill=(140, 90, 50))
            if pose == "sit":
                d.ellipse([1, 3, 8, 16], fill=tail)                   # big curled tail
                d.ellipse([3, 5, 7, 12], fill=(186, 146, 108))
            else:
                d.ellipse([0, 0, 6, 12], fill=tail)                   # tail flicked up
                d.ellipse([1, 2, 5, 8], fill=(186, 146, 108))
        # thin dark outline so it reads against the grey fence
        px = im.load()
        w, h = im.size
        solid = [[px[x, y][3] > 0 for x in range(w)] for y in range(h)]
        for y in range(h):
            for x in range(w):
                if not solid[y][x] and any(0 <= x + dx < w and 0 <= y + dy < h and solid[y + dy][x + dx]
                                           for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                    px[x, y] = (54, 36, 28, 255)
        out.append(im)
    return out


def _outline(im, col=(46, 34, 30, 255)):
    px = im.load()
    w, h = im.size
    solid = [[px[x, y][3] > 0 for x in range(w)] for y in range(h)]
    for y in range(h):
        for x in range(w):
            if not solid[y][x] and any(0 <= x + dx < w and 0 <= y + dy < h and solid[y + dy][x + dx]
                                       for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                px[x, y] = col
    return im


def maru_frames():
    """Maru the call duck: tiny, round and white, waddling (faces right)."""
    out = []
    for k in range(2):
        im = Image.new("RGBA", (20, 18), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        bob = k
        d.ellipse([2, 7 + bob, 15, 16 + bob], fill=(250, 250, 246))          # round body
        d.polygon([(2, 10 + bob), (0, 7 + bob), (4, 9 + bob)], fill=(250, 250, 246))   # perky tail
        d.ellipse([9, 1 + bob, 17, 9 + bob], fill=(250, 250, 246))           # big round head
        d.ellipse([15, 5 + bob, 20, 8 + bob], fill=(250, 170, 60))           # orange bill
        d.point((14, 4 + bob), fill=(30, 30, 30))
        d.ellipse([5, 10 + bob, 11, 14 + bob], fill=(232, 232, 226))         # wing
        d.line([(7, 16), (6 + 2 * k, 17)], fill=(250, 160, 50))              # feet
        d.line([(11, 16), (12 - 2 * k, 17)], fill=(250, 160, 50))
        out.append(_outline(im))
    return out


def bieji_frames():
    """BieJi the black silkie: a fluffy black puffball with a little crest,
    blue-ish face and fluffy feet (faces right)."""
    out = []
    for k in range(2):
        im = Image.new("RGBA", (20, 18), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        bob = k
        for (x0, y0, x1, y1) in ((2, 6, 15, 16), (0, 5, 7, 13), (9, 2, 17, 10)):
            d.ellipse([x0, y0 + bob, x1, y1 + bob], fill=(34, 32, 38))      # fluffy body, tail, head
        for (x, y) in ((4, 8), (8, 12), (12, 9), (3, 12), (11, 4)):       # silky sheen
            d.point((x, y + bob), fill=(84, 80, 96))
        d.ellipse([11, 0 + bob, 16, 4 + bob], fill=(40, 38, 46))           # pom-pom crest
        d.ellipse([13, 4 + bob, 17, 8 + bob], fill=(70, 90, 140))          # blue-black face
        d.point((15, 5 + bob), fill=(240, 240, 240))
        d.polygon([(17, 6 + bob), (19, 7 + bob), (17, 8 + bob)], fill=(120, 110, 120))   # beak
        d.line([(6, 16), (5 + 2 * k, 17)], fill=(60, 60, 70), width=2)      # feathered feet
        d.line([(11, 16), (12 - 2 * k, 17)], fill=(60, 60, 70), width=2)
        out.append(_outline(im, (16, 14, 18, 255)))
    return out


def msdong_frames():
    """Ms. Dong: a round little hen with big puffed-out cheek muffs (faces right)."""
    out = []
    for k in range(2):
        im = Image.new("RGBA", (20, 18), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        bob = k
        d.ellipse([2, 7 + bob, 15, 16 + bob], fill=(236, 200, 140))         # buff body
        d.polygon([(3, 9 + bob), (0, 3 + bob), (5, 7 + bob)], fill=(200, 150, 90))   # tail feathers
        d.ellipse([9, 1 + bob, 17, 9 + bob], fill=(236, 200, 140))          # head
        d.polygon([(12, 1 + bob), (13, -1 + bob), (14, 1 + bob), (15, 0 + bob), (15, 2 + bob)], fill=(220, 60, 60))   # comb
        d.ellipse([10, 5 + bob, 15, 10 + bob], fill=(250, 232, 196))        # the puffy cheeks!
        d.ellipse([13, 6 + bob, 18, 11 + bob], fill=(250, 232, 196))
        d.point((14, 4 + bob), fill=(30, 30, 30))
        d.polygon([(17, 4 + bob), (19, 5 + bob), (17, 6 + bob)], fill=(240, 180, 60))   # beak
        d.ellipse([5, 10 + bob, 11, 14 + bob], fill=(214, 172, 110))       # wing
        d.line([(7, 16), (6 + 2 * k, 17)], fill=(240, 170, 60))
        d.line([(11, 16), (12 - 2 * k, 17)], fill=(240, 170, 60))
        out.append(_outline(im))
    return out
